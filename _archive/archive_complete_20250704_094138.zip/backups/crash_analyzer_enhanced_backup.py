"""
TuoKit - Crash Analyzer Pro (Enhanced v2)
Enhanced crash dump analysis with full large file support
Handles files up to 5MB with intelligent chunking
"""
import streamlit as st
import json
import hashlib
import re
import time
from datetime import datetime, timedelta
from utils import (
    DatabaseManager, 
    safe_ollama_generate,
    capture_knowledge,
    validate_file_size
)

# Initialize database
db = DatabaseManager()

# Configuration (can be moved to config file later)
CRASH_ANALYZER_CONFIG = {
    "max_file_size_mb": 5,
    "chunk_size": 8000,
    "chunk_overlap": 400,
    "max_chunks": 700,  # Increased to handle 5MB files (needs ~690 chunks)
    "smart_sampling_threshold_mb": 1,
    "performance_warning_threshold_seconds": 30,
    "pattern_match_context_chars": 100,
    "enable_abort": True,
    "chunk_processing_delay": 0.1  # Small delay between chunks to prevent overload
}

# Enhanced pattern definitions with severity levels
KNOWN_PATTERNS = {
    "NullPointerException": {
        "pattern": r"NullPointerException|NPE|null.*reference|nil.*reference|accessing null object|nil object",
        "quick_fix": "Add null checks before object access: `if (obj != null)`",
        "prevention": "Use defensive programming and Optional types",
        "severity": "High"
    },
    "OutOfMemoryError": {
        "pattern": r"OutOfMemoryError|OOM|heap.*space|memory.*exhausted|GC overhead limit|Java heap space",
        "quick_fix": "Increase JVM heap size: `-Xmx2g` or `-Xmx4g`. Check for memory leaks",
        "prevention": "Profile memory usage, fix memory leaks, optimize collections",
        "severity": "Critical"
    },
    "StackOverflow": {
        "pattern": r"StackOverflowError|stack.*overflow|recursion.*limit|too many nested calls",
        "quick_fix": "Check for infinite recursion or circular references",
        "prevention": "Add recursion depth limits and base cases",
        "severity": "High"
    },
    "DatabaseTimeout": {
        "pattern": r"timeout|connection.*timed.*out|query.*timeout|lock.*wait.*timeout",
        "quick_fix": "Increase timeout settings or optimize query",
        "prevention": "Add indexes, optimize queries, use connection pooling",
        "severity": "Medium"
    },
    "FileNotFound": {
        "pattern": r"FileNotFoundException|file.*not.*found|no.*such.*file|cannot.*open.*file",
        "quick_fix": "Verify file path and permissions",
        "prevention": "Add file existence checks before access",
        "severity": "Low"
    },
    "DeadlockDetected": {
        "pattern": r"deadlock.*detected|circular.*lock|transaction.*rollback.*deadlock",
        "quick_fix": "Retry transaction or reorder lock acquisition",
        "prevention": "Use consistent lock ordering, minimize lock scope",
        "severity": "High"
    }
}

# --- NEW FEATURE: Enhanced pattern matching with context ---
def match_known_patterns(content):
    """Match crash content against known patterns with context awareness"""
    matches = []
    context_chars = CRASH_ANALYZER_CONFIG["pattern_match_context_chars"]
    
    for pattern_name, pattern_info in KNOWN_PATTERNS.items():
        if re.search(pattern_info["pattern"], content, re.IGNORECASE):
            # Extract context around match
            match_obj = re.search(
                pattern_info["pattern"], 
                content, 
                re.IGNORECASE
            )
            if match_obj:
                start = max(0, match_obj.start() - context_chars)
                end = min(len(content), match_obj.end() + context_chars)
                context = content[start:end].strip()
                
                matches.append({
                    "pattern": pattern_name,
                    "quick_fix": pattern_info["quick_fix"],
                    "prevention": pattern_info["prevention"],
                    "severity": pattern_info.get("severity", "Medium"),
                    "context": context,
                    "position": match_obj.start()
                })
    
    # Sort by severity and position
    severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}
    matches.sort(key=lambda x: (-severity_order.get(x["severity"], 0), x["position"]))
    
    return matches

# --- NEW FEATURE: Smart content extraction ---
def extract_critical_sections(content, max_length=10000):
    """
    Extracts the most important sections from a crash dump.
    Prioritizes stack traces and exception messages.
    """
    sections = []
    
    # Extract exception info
    exception_patterns = [
        r'(.*Exception:.*)',
        r'(.*Error:.*)',
        r'(FATAL:.*)',
        r'(SEVERE:.*)',
        r'(CRITICAL:.*)'
    ]
    
    for pattern in exception_patterns:
        matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
        for match in matches:
            # Get surrounding context
            start = max(0, match.start() - 200)
            end = min(len(content), match.end() + 500)
            sections.append(("exception", content[start:end]))
    
    # Extract stack traces
    stack_patterns = [
        r'(?s)(\s+at\s+.*\n)+',
        r'(Thread\s+\d+.*\n(?:.*\n){0,10})',
        r'(Call stack:.*?\n\n)',
        r'(Stack trace:.*?\n\n)'
    ]
    
    for pattern in stack_patterns:
        matches = re.finditer(pattern, content, re.MULTILINE)
        for match in matches:
            sections.append(("stack_trace", match.group(0)))
    
    # Build critical content
    critical_content = ""
    
    if sections:
        # Group by type
        exception_sections = [s for t, s in sections if t == "exception"]
        stack_sections = [s for t, s in sections if t == "stack_trace"]
        
        if exception_sections:
            critical_content += "--- EXCEPTION INFO ---\n"
            critical_content += "\n---\n".join(exception_sections[:3])  # Top 3 exceptions
            critical_content += "\n\n"
        
        if stack_sections:
            critical_content += "--- STACK TRACES ---\n"
            critical_content += "\n---\n".join(stack_sections[:2])  # Top 2 stack traces
            critical_content += "\n\n"
    
    # Fallback if no patterns matched
    if not critical_content:
        # Return beginning and end of file
        if len(content) > 4000:
            critical_content = content[:2000] + "\n\n[... middle section omitted ...]\n\n" + content[-2000:]
        else:
            critical_content = content
    
    # Truncate to max_length
    if len(critical_content) > max_length:
        critical_content = critical_content[:max_length] + "\n[... truncated ...]"
    
    return critical_content

# --- ENHANCED FEATURE: Full file chunking for 5MB support ---
def analyze_with_chunking(content, chunk_size=None, overlap=None, progress_callback=None):
    """
    Analyzes large files using chunked processing.
    Supports files up to 5MB with progress tracking and abort capability.
    """
    if chunk_size is None:
        chunk_size = CRASH_ANALYZER_CONFIG["chunk_size"]
    if overlap is None:
        overlap = CRASH_ANALYZER_CONFIG["chunk_overlap"]
    
    # Calculate chunks
    chunks = []
    start = 0
    while start < len(content):
        end = min(start + chunk_size, len(content))
        chunks.append((start, end, content[start:end]))
        start = end - overlap if end < len(content) else end
    
    total_chunks = len(chunks)
    st.info(f"📊 Processing {total_chunks} chunks from {len(content):,} characters...")
    
    # Initialize results storage
    chunk_results = {
        "errors": set(),
        "error_types": set(),
        "severities": [],
        "root_causes": [],
        "locations": set(),
        "patterns": [],
        "summaries": []
    }
    
    # Progress tracking
    progress_bar = st.progress(0, text=f"Processing chunk 0/{total_chunks}")
    status_container = st.container()
    abort_button = st.button("🛑 Abort Processing") if CRASH_ANALYZER_CONFIG["enable_abort"] else None
    
    start_time = time.time()
    
    for i, (start_pos, end_pos, chunk) in enumerate(chunks):
        # Check for abort
        if abort_button and st.session_state.get('abort_processing', False):
            st.warning("Processing aborted by user")
            break
        
        with status_container:
            st.write(f"🔍 Analyzing chunk {i+1}/{total_chunks} (chars {start_pos:,}-{end_pos:,})")
        
        # Prepare chunk with position context
        chunk_prompt = f"""
        Analyze this section of a crash dump (position {start_pos}-{end_pos} in file).
        
        CHUNK CONTENT:
        {chunk}
        
        Provide analysis in JSON format:
        {{
            "errors_found": ["list of specific errors in this chunk"],
            "error_types": ["types of errors found"],
            "severity": "Critical/High/Medium/Low (highest in chunk)",
            "root_cause_hints": "any root cause indicators in this chunk",
            "error_locations": ["specific locations mentioned"],
            "summary": "brief summary of this chunk's findings"
        }}
        """
        
        try:
            response = safe_ollama_generate(
                model=st.session_state.get("selected_model", "deepseek-r1:latest"),
                prompt=chunk_prompt,
                format="json"
            )
            
            if isinstance(response, dict):
                response_text = response.get('response', '{}')
            else:
                response_text = str(response)
            
            chunk_data = json.loads(response_text)
            
            # Aggregate results
            chunk_results["errors"].update(chunk_data.get("errors_found", []))
            chunk_results["error_types"].update(chunk_data.get("error_types", []))
            chunk_results["severities"].append(chunk_data.get("severity", "Unknown"))
            if chunk_data.get("root_cause_hints"):
                chunk_results["root_causes"].append(chunk_data["root_cause_hints"])
            chunk_results["locations"].update(chunk_data.get("error_locations", []))
            chunk_results["summaries"].append(chunk_data.get("summary", ""))
            
            # Also check for patterns in this chunk
            chunk_patterns = match_known_patterns(chunk)
            chunk_results["patterns"].extend(chunk_patterns)
            
        except Exception as e:
            st.warning(f"Error processing chunk {i+1}: {str(e)}")
            chunk_results["summaries"].append(f"Chunk {i+1} processing failed")
        
        # Update progress
        progress = (i + 1) / total_chunks
        progress_bar.progress(progress, text=f"Processing chunk {i+1}/{total_chunks}")
        
        # Small delay to prevent overload
        if CRASH_ANALYZER_CONFIG["chunk_processing_delay"] > 0:
            time.sleep(CRASH_ANALYZER_CONFIG["chunk_processing_delay"])
        
        if progress_callback:
            progress_callback(i + 1, total_chunks)
    
    # Clear progress indicators
    progress_bar.empty()
    status_container.empty()
    
    # Processing time
    elapsed_time = time.time() - start_time
    st.session_state.chunk_analysis_time = f"{elapsed_time:.2f}s"
    
    # Synthesize final results
    severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Unknown": 0}
    highest_severity = max(chunk_results["severities"], 
                          key=lambda x: severity_order.get(x, 0)) if chunk_results["severities"] else "Unknown"
    
    # Determine most likely root cause
    root_cause = "Not identified"
    if chunk_results["root_causes"]:
        # Simple frequency analysis
        cause_freq = {}
        for cause in chunk_results["root_causes"]:
            cause_freq[cause] = cause_freq.get(cause, 0) + 1
        root_cause = max(cause_freq.items(), key=lambda x: x[1])[0]
    
    # Compile final analysis
    final_analysis = {
        "root_cause": root_cause,
        "error_location": ", ".join(list(chunk_results["locations"])[:3]) or "Multiple locations",
        "error_type": ", ".join(list(chunk_results["error_types"])[:3]) or "Multiple types",
        "severity": highest_severity,
        "quick_fix": "Review the detailed chunk summaries for specific fixes",
        "prevention": "Address the root cause and implement proper error handling",
        "total_errors": len(chunk_results["errors"]),
        "chunks_processed": i + 1,
        "patterns_found": len(chunk_results["patterns"]),
        "processing_time": elapsed_time,
        "chunk_summaries": chunk_results["summaries"]
    }
    
    return final_analysis

# --- NEW FEATURE: Smart sampling for large files ---
def generate_strategic_samples(content, max_samples=10, sample_size=2000):
    """Extract strategic samples from large files"""
    samples = []
    
    # 1. Get file header
    samples.append({
        "type": "header",
        "content": content[:sample_size],
        "description": "File beginning"
    })
    
    # 2. Find error/exception locations
    error_keywords = r'error|exception|crash|fatal|failed|critical|severe'
    error_positions = [m.start() for m in re.finditer(error_keywords, content, re.IGNORECASE)]
    
    # 3. Sample around errors (limit to avoid too many samples)
    sampled_positions = set()
    for pos in error_positions[:max_samples-2]:
        # Avoid overlapping samples
        if not any(abs(pos - p) < sample_size for p in sampled_positions):
            start = max(0, pos - sample_size//2)
            end = min(len(content), pos + sample_size//2)
            samples.append({
                "type": "error_context",
                "content": content[start:end],
                "description": f"Error context at position {pos}"
            })
            sampled_positions.add(pos)
    
    # 4. Get file end
    samples.append({
        "type": "footer", 
        "content": content[-sample_size:],
        "description": "File end"
    })
    
    return samples

# --- NEW FEATURE: File size decision logic ---
def determine_analysis_method(content_size):
    """Determine best analysis method based on file size"""
    size_mb = content_size / (1024 * 1024)
    
    if size_mb < 0.1:  # <100KB
        return "standard", None
    elif size_mb < 1:  # <1MB
        return "standard_with_extraction", None
    elif size_mb < CRASH_ANALYZER_CONFIG["smart_sampling_threshold_mb"]:
        return "full_chunking", f"File is {size_mb:.1f}MB. Full analysis may take {int(size_mb * 30)} seconds."
    else:
        chunks_estimate = int(content_size / CRASH_ANALYZER_CONFIG["chunk_size"])
        time_estimate = chunks_estimate * 2  # ~2 seconds per chunk
        return "full_chunking", f"File is {size_mb:.1f}MB. Full analysis will process {chunks_estimate} chunks (~{time_estimate//60} minutes)."

# Original analyze_crash_dump with performance tracking
def analyze_crash_dump(content):
    """Basic crash analysis - fast JSON response"""
    start_time = time.time()
    
    # Use smart extraction for better results
    extracted = extract_critical_sections(content, 15000)
    
    prompt = f"""Analyze this crash dump and provide a structured analysis.

CRASH DUMP:
{extracted}

Provide your analysis in this exact JSON format:
{{
    "root_cause": "Brief technical description of what caused the crash",
    "error_location": "File/method/line where crash occurred",
    "error_type": "Exception type or error category",  
    "severity": "Critical/High/Medium/Low",
    "quick_fix": "Immediate solution to resolve the crash",
    "prevention": "How to prevent this in the future"
}}

Be concise and technical. Focus only on the actual error."""
    
    try:
        response = safe_ollama_generate(
            model=st.session_state.get("selected_model", "deepseek-r1:latest"),
            prompt=prompt,
            format="json"
        )
        
        # Track performance
        elapsed = time.time() - start_time
        st.session_state.last_analysis_time = f"{elapsed:.2f}s"
        
        # Extract response from dictionary if needed
        if isinstance(response, dict):
            response_text = response.get('response', '{}')
        else:
            response_text = str(response)
        
        analysis = json.loads(response_text)
        
        # Ensure all required fields
        required_fields = ["root_cause", "error_location", "error_type", 
                          "severity", "quick_fix", "prevention"]
        for field in required_fields:
            if field not in analysis:
                analysis[field] = "Not identified"
                
        return analysis
        
    except (json.JSONDecodeError, Exception) as e:
        # Track performance even on error
        elapsed = time.time() - start_time
        st.session_state.last_analysis_time = f"{elapsed:.2f}s"
        
        return {
            "root_cause": "Analysis failed - check crash dump format",
            "error_location": "Unknown",
            "error_type": str(type(e).__name__),
            "severity": "Medium",
            "quick_fix": "Review the crash dump manually",
            "prevention": "Ensure proper error handling"
        }

# Enhanced expert report generation
def generate_expert_report(content):
    """Generate detailed expert report - comprehensive but slower"""
    start_time = time.time()
    
    # Use smart extraction
    extracted = extract_critical_sections(content, 20000)
    
    from pages.crash_analyzer import EXPERT_PROMPT_TEMPLATE
    prompt = EXPERT_PROMPT_TEMPLATE.format(crash_content=extracted)
    
    result = safe_ollama_generate(
        model=st.session_state.get("selected_model", "deepseek-r1:latest"),
        prompt=prompt,
        temperature=0.3  # Lower temperature for more focused analysis
    )
    
    # Track performance
    elapsed = time.time() - start_time
    st.session_state.last_expert_time = f"{elapsed:.2f}s"
    
    # Extract the response string from the dictionary
    if isinstance(result, dict):
        return result.get('response', 'Failed to generate report')
    return str(result)  # Fallback for unexpected types

# --- NEW FEATURE: Performance monitoring display ---
def show_performance_stats():
    """Display analysis performance metrics"""
    if any(key in st.session_state for key in ['last_analysis_time', 'last_expert_time', 'chunk_analysis_time']):
        st.subheader("⏱️ Performance Metrics")
        cols = st.columns(4)
        
        if 'last_analysis_time' in st.session_state:
            cols[0].metric("Basic Analysis", st.session_state.last_analysis_time)
        
        if 'last_expert_time' in st.session_state:
            cols[1].metric("Expert Analysis", st.session_state.last_expert_time)
        
        if 'chunk_analysis_time' in st.session_state:
            cols[2].metric("Chunk Analysis", st.session_state.chunk_analysis_time)
        
        if 'last_method_used' in st.session_state:
            cols[3].metric("Method Used", st.session_state.last_method_used)

# --- NEW FEATURE: Enhanced file analysis status ---
def show_file_analysis_status(content):
    """Show visual indicators of file analysis status"""
    st.subheader("🔍 File Analysis Insights")
    cols = st.columns(5)
    
    # Line count
    lines = content.splitlines()
    cols[0].metric("Lines", f"{len(lines):,}")
    
    # File size
    size_kb = len(content) / 1024
    if size_kb > 1024:
        cols[1].metric("Size", f"{size_kb/1024:.1f} MB")
    else:
        cols[1].metric("Size", f"{size_kb:.1f} KB")
    
    # Error count estimate
    error_count = len(re.findall(r'error|exception|fail|fatal|crash', content, re.IGNORECASE))
    cols[2].metric("Error Keywords", error_count)
    
    # Stack trace detection
    stack_traces = len(re.findall(r'^\s+at\s+', content, re.MULTILINE))
    cols[3].metric("Stack Frames", stack_traces)
    
    # Timestamp detection
    timestamps = re.findall(r'\d{4}-\d{2}-\d{2}[\s\-T]\d{2}:\d{2}:\d{2}', content)
    if timestamps:
        cols[4].metric("Timestamps", len(timestamps))
    else:
        cols[4].metric("Timestamps", "None found")

# Import remaining functions from original
from pages.crash_analyzer import (
    find_similar_crashes,
    export_crash_report,
    extract_mermaid_diagrams,
    save_crash_analysis,
    recognize_crash_patterns,
    search_similar_crashes,
    export_management_report,
    show_crash_statistics_dashboard
)

# Enhanced main show function
def show():
    st.title("🚨 Crash Analyzer Pro")
    st.caption("AI-powered crash analysis with full support for files up to 5MB")
    
    # Initialize session state
    if 'analysis' not in st.session_state:
        st.session_state.analysis = None
    if 'expert_report' not in st.session_state:
        st.session_state.expert_report = None
    if 'chunk_analysis' not in st.session_state:
        st.session_state.chunk_analysis = None
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload crash dump", 
        type=["txt", "log", "dmp", "wcr", "crash", "error"],
        help=f"Maximum file size: {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB. Full processing available for all sizes."
    )
    
    if uploaded_file:
        # Validate file size
        if not validate_file_size(uploaded_file, max_size_mb=CRASH_ANALYZER_CONFIG['max_file_size_mb']):
            st.error(f"File too large. Maximum size is {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB.")
            return
            
        # Read content
        try:
            content = uploaded_file.getvalue().decode("utf-8", errors='ignore')
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")
            return
        
        # Determine analysis method
        method, warning = determine_analysis_method(len(content))
        st.session_state.last_method_used = method.replace("_", " ").title()
        
        # File info header
        st.subheader(f"📄 Analyzing: {uploaded_file.name}")
        cols = st.columns(3)
        cols[0].info(f"**Size:** {len(content):,} bytes")
        cols[1].info(f"**Hash:** `{content_hash}`")
        cols[2].info(f"**Method:** {st.session_state.last_method_used}")
        
        # Show warning if needed
        if warning:
            st.warning(f"⚠️ {warning}")
        
        # Show file insights
        show_file_analysis_status(content)
        
        # Pattern detection
        pattern_matches = match_known_patterns(content)
        if pattern_matches:
            with st.expander(f"🔍 Detected {len(pattern_matches)} Known Patterns", expanded=True):
                for match in pattern_matches[:3]:  # Show top 3
                    severity_emoji = {
                        "Critical": "🔴", "High": "🟠",
                        "Medium": "🟡", "Low": "🟢"
                    }.get(match['severity'], "⚪")
                    
                    st.markdown(f"{severity_emoji} **{match['pattern']}** - {match['severity']} severity")
                    st.code(match['context'], language="text")
                    st.markdown(f"**Quick Fix:** {match['quick_fix']}")
                    st.markdown(f"**Prevention:** {match['prevention']}")
                    st.divider()
        
        # Content preview
        with st.expander("📋 View Crash Dump", expanded=False):
            preview = content[:3000] + ("..." if len(content) > 3000 else "")
            st.code(preview)
        
        # Analysis options
        st.subheader("🔍 Analysis Methods")
        
        # For large files, show all options including full processing
        method_cols = st.columns(4)
        
        with method_cols[0]:
            if st.button("⚡ Basic Analysis", use_container_width=True, 
                        help="Fast analysis using critical sections (5-15 seconds)"):
                with st.spinner("Analyzing critical sections..."):
                    st.session_state.analysis = analyze_crash_dump(content)
                    st.session_state.expert_report = None
                    st.session_state.chunk_analysis = None
                st.success("Basic analysis complete!")
                st.toast("✅ Analysis complete!", icon="✅")
        
        with method_cols[1]:
            if st.button("🕵️ Expert Diagnostics", use_container_width=True,
                        help="Comprehensive report (30-60 seconds)"):
                with st.spinner("Generating expert report..."):
                    st.session_state.expert_report = generate_expert_report(content)
                    st.session_state.analysis = None
                    st.session_state.chunk_analysis = None
                st.success("Expert report generated!")
                st.toast("✅ Expert report ready!", icon="✅")
        
        with method_cols[2]:
            if st.button("📊 Smart Sampling", use_container_width=True,
                        help="Analyze strategic samples for quick insights"):
                with st.spinner("Analyzing strategic samples..."):
                    samples = generate_strategic_samples(content)
                    combined_samples = "\n\n--- SAMPLE ---\n\n".join([s['content'] for s in samples])
                    st.session_state.analysis = analyze_crash_dump(combined_samples)
                    st.session_state.expert_report = None
                    st.session_state.chunk_analysis = None
                st.success("Sample analysis complete!")
                st.toast("✅ Sample analysis done!", icon="✅")
        
        with method_cols[3]:
            # Full processing available for all file sizes
            help_text = f"Process entire file ({len(content)//1024//1024:.1f}MB)"
            if len(content) > 3 * 1024 * 1024:
                help_text += " - May take several minutes"
                
            if st.button("🧩 Full File Analysis", use_container_width=True, help=help_text):
                # Warning for large files
                size_mb = len(content) / (1024 * 1024)
                if size_mb > 2:
                    chunks_estimate = int(len(content) / CRASH_ANALYZER_CONFIG["chunk_size"])
                    time_estimate = chunks_estimate * 2
                    
                    st.warning(f"""
                    ⚠️ **Large File Processing**
                    - File size: {size_mb:.1f}MB
                    - Estimated chunks: {chunks_estimate}
                    - Estimated time: {time_estimate//60} minutes {time_estimate%60} seconds
                    - You can abort processing at any time
                    """)
                    
                    if not st.checkbox("I understand and want to proceed with full analysis"):
                        st.stop()
                
                with st.spinner("Performing full file analysis..."):
                    st.session_state.chunk_analysis = analyze_with_chunking(content)
                    st.session_state.analysis = None
                    st.session_state.expert_report = None
                st.success("Full analysis complete!")
                st.toast("✅ Full analysis done!", icon="✅")
        
        # Show performance stats
        show_performance_stats()
        
        # Display analysis results
        if st.session_state.analysis:
            st.subheader("📊 Basic Analysis Results")
            
            # Severity indicator
            severity_color = {
                "Critical": "🔴", "High": "🟠", 
                "Medium": "🟡", "Low": "🟢"
            }.get(st.session_state.analysis.get("severity", "Medium"), "⚪")
            
            st.markdown(f"**Severity:** {severity_color} {st.session_state.analysis.get('severity', 'Unknown')}")
            
            # Editable analysis fields
            col1, col2 = st.columns(2)
            
            with col1:
                st.session_state.analysis["root_cause"] = st.text_area(
                    "Root Cause",
                    value=st.session_state.analysis["root_cause"],
                    height=100
                )
                st.session_state.analysis["error_location"] = st.text_input(
                    "Error Location",
                    value=st.session_state.analysis["error_location"]
                )
                st.session_state.analysis["error_type"] = st.text_input(
                    "Error Type",
                    value=st.session_state.analysis["error_type"]
                )
                
            with col2:
                st.session_state.analysis["severity"] = st.selectbox(
                    "Severity",
                    ["Critical", "High", "Medium", "Low"],
                    index=["Critical", "High", "Medium", "Low"].index(
                        st.session_state.analysis.get("severity", "Medium"))
                )
                st.session_state.analysis["quick_fix"] = st.text_area(
                    "Quick Fix",
                    value=st.session_state.analysis["quick_fix"],
                    height=100
                )
                st.session_state.analysis["prevention"] = st.text_area(
                    "Prevention Strategy",
                    value=st.session_state.analysis["prevention"],
                    height=100
                )
        
        if st.session_state.expert_report:
            st.subheader("📝 Expert Diagnostic Report")
            
            # Full report in expander
            with st.expander("View Full Expert Report", expanded=True):
                st.markdown(st.session_state.expert_report)
            
            # Extract and display any Mermaid diagrams
            diagrams = extract_mermaid_diagrams(st.session_state.expert_report)
            if diagrams:
                st.subheader("📊 Visualizations")
                for i, diagram in enumerate(diagrams):
                    st.caption(f"Diagram {i+1}")
                    st.code(diagram, language="mermaid")
        
        if st.session_state.chunk_analysis:
            st.subheader("🧩 Full File Analysis Results")
            
            # Display metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Errors", st.session_state.chunk_analysis.get("total_errors", 0))
            with col2:
                st.metric("Chunks Processed", st.session_state.chunk_analysis.get("chunks_processed", 0))
            with col3:
                st.metric("Patterns Found", st.session_state.chunk_analysis.get("patterns_found", 0))
            with col4:
                st.metric("Processing Time", f"{st.session_state.chunk_analysis.get('processing_time', 0):.1f}s")
            
            # Show aggregated results
            st.markdown("### 📊 Aggregated Analysis")
            
            # Severity indicator
            severity_color = {
                "Critical": "🔴", "High": "🟠", 
                "Medium": "🟡", "Low": "🟢"
            }.get(st.session_state.chunk_analysis.get("severity", "Medium"), "⚪")
            
            st.markdown(f"**Severity:** {severity_color} {st.session_state.chunk_analysis.get('severity', 'Unknown')}")
            st.markdown(f"**Root Cause:** {st.session_state.chunk_analysis.get('root_cause', 'Not identified')}")
            st.markdown(f"**Error Types:** {st.session_state.chunk_analysis.get('error_type', 'Multiple types')}")
            st.markdown(f"**Locations:** {st.session_state.chunk_analysis.get('error_location', 'Multiple locations')}")
            
            # Show chunk summaries
            if st.session_state.chunk_analysis.get("chunk_summaries"):
                with st.expander("📋 Chunk-by-Chunk Analysis", expanded=False):
                    for i, summary in enumerate(st.session_state.chunk_analysis["chunk_summaries"][:10]):
                        st.markdown(f"**Chunk {i+1}:** {summary}")
        
        # Show similar crashes if analysis available
        if any([st.session_state.analysis, st.session_state.chunk_analysis]):
            analysis_data = st.session_state.analysis or st.session_state.chunk_analysis
            if analysis_data.get("error_type"):
                similar = find_similar_crashes(analysis_data["error_type"], limit=5)
                if similar:
                    st.subheader("🔗 Similar Previous Crashes")
                    for crash in similar:
                        severity_emoji = {
                            "Critical": "🔴", "High": "🟠",
                            "Medium": "🟡", "Low": "🟢"
                        }.get(crash['severity'], "⚪")
                        
                        st.markdown(f"""
                        {severity_emoji} **{crash['filename']}** - {crash['created_at'].strftime('%Y-%m-%d')}
                        - Root cause: {crash['root_cause'][:100]}...
                        - Fixed by: {crash['validated_by']}
                        """)
        
        # Save section
        if any([st.session_state.analysis, st.session_state.expert_report, st.session_state.chunk_analysis]):
            st.divider()
            st.subheader("💾 Save to Knowledge Base")
            
            validator_name = st.text_input(
                "Your Name (required for validation)",
                placeholder="Enter your name"
            )
            
            include_expert = False
            if st.session_state.expert_report:
                include_expert = st.checkbox(
                    "Include expert report in knowledge base", 
                    value=True,
                    help="Expert reports provide valuable context for future reference"
                )
            
            col1, col2, col3 = st.columns([2, 1, 1])
            with col1:
                if st.button("💾 Save Validated Analysis", type="primary", use_container_width=True):
                    if not validator_name:
                        st.warning("⚠️ Please enter your name for validation")
                    else:
                        # Use whichever analysis is available
                        analysis_to_save = (st.session_state.analysis or 
                                          st.session_state.chunk_analysis or 
                                          {})
                        
                        if save_crash_analysis(
                            uploaded_file.name,
                            content_hash,
                            analysis_to_save,
                            st.session_state.expert_report,
                            validator_name,
                            include_expert
                        ):
                            st.success("✅ Analysis saved to knowledge base!")
                            st.balloons()
            
            with col2:
                quality = st.number_input("Quality", 1, 5, 3, help="Rate analysis quality")
            
            with col3:
                if st.button("📄 Export Report", use_container_width=True):
                    analysis_to_export = (st.session_state.analysis or 
                                        st.session_state.chunk_analysis or 
                                        {})
                    report = export_crash_report(
                        uploaded_file.name,
                        analysis_to_export,
                        st.session_state.expert_report if include_expert else None
                    )
                    st.download_button(
                        label="Download Report",
                        data=report,
                        file_name=f"crash_report_{uploaded_file.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                        mime="text/markdown"
                    )
    
    # Recent analyses and database setup sections remain the same
    with st.expander("📋 Recent Crash Analyses", expanded=False):
        try:
            recent = db.fetch_all(
                """SELECT filename, analysis->>'severity' as severity, 
                   analysis->>'root_cause' as root_cause, 
                   validated_by, created_at,
                   CASE WHEN expert_report IS NOT NULL THEN TRUE ELSE FALSE END as has_expert
                   FROM crash_analysis 
                   ORDER BY created_at DESC LIMIT 10"""
            )
            
            if recent:
                for entry in recent:
                    severity_emoji = {
                        "Critical": "🔴", "High": "🟠", 
                        "Medium": "🟡", "Low": "🟢"
                    }.get(entry['severity'], "⚪")
                    
                    expert_badge = "📝" if entry['has_expert'] else ""
                    
                    st.markdown(f"""
                    {severity_emoji} **{entry['filename']}** {expert_badge}
                    - Root cause: {entry['root_cause'][:80]}...
                    - By: {entry['validated_by']} on {entry['created_at'].strftime('%Y-%m-%d %H:%M')}
                    """)
            else:
                st.info("No crash analyses found yet")
        except:
            st.info("Initialize the database to see recent analyses")
    
    # Pattern analysis dashboard
    with st.expander("📊 Crash Statistics Dashboard", expanded=False):
        show_crash_statistics_dashboard()

if __name__ == "__main__":
    show()

"""
TuoKit - Crash Analyzer Pro (Enhanced)
Enhanced crash dump analysis with intelligent diagnostics
Includes all suggested improvements for production use
"""
import streamlit as st
import json
import hashlib
import re
import time
from datetime import datetime, timedelta
from utils import (
    DatabaseManager, 
    safe_ollama_generate,
    capture_knowledge,
    validate_file_size
)

# Initialize database
db = DatabaseManager()

# Configuration
CRASH_ANALYZER_CONFIG = {
    "max_file_size_mb": 5,
    "chunk_size": 8000,
    "chunk_overlap": 400,
    "max_chunks": 700,  # Supports up to 5MB files
    "smart_sampling_threshold_mb": 1,
    "performance_warning_threshold_seconds": 30,
    "pattern_match_context_chars": 100,
    "enable_abort": True,
    "chunk_processing_delay": 0.1,
    "skip_empty_chunks": True,  # Skip chunks without error keywords
    "max_consecutive_failures": 10  # Stop after too many failures
}

# Enhanced pattern definitions with severity levels
KNOWN_PATTERNS = {
    "NullPointerException": {
        "pattern": r"NullPointerException|NPE|null.*reference|nil.*reference|accessing null object|nil object",
        "quick_fix": "Add null checks before object access: `if (obj != null)`",
        "prevention": "Use defensive programming and Optional types",
        "severity": "High"
    },
    "OutOfMemoryError": {
        "pattern": r"OutOfMemoryError|OOM|heap.*space|memory.*exhausted|GC overhead limit|Java heap space",
        "quick_fix": "Increase JVM heap size: `-Xmx2g` or `-Xmx4g`. Check for memory leaks",
        "prevention": "Profile memory usage, fix memory leaks, optimize collections",
        "severity": "Critical"
    },
    "StackOverflow": {
        "pattern": r"StackOverflowError|stack.*overflow|recursion.*limit|too many nested calls",
        "quick_fix": "Check for infinite recursion or circular references",
        "prevention": "Add recursion depth limits and base cases",
        "severity": "High"
    },
    "DatabaseTimeout": {
        "pattern": r"timeout|connection.*timed.*out|query.*timeout|lock.*wait.*timeout",
        "quick_fix": "Increase timeout settings or optimize query",
        "prevention": "Add indexes, optimize queries, use connection pooling",
        "severity": "Medium"
    },
    "FileNotFound": {
        "pattern": r"FileNotFoundException|file.*not.*found|no.*such.*file|cannot.*open.*file",
        "quick_fix": "Verify file path and permissions",
        "prevention": "Add file existence checks before access",
        "severity": "Low"
    },
    "DeadlockDetected": {
        "pattern": r"deadlock.*detected|circular.*lock|transaction.*rollback.*deadlock",
        "quick_fix": "Retry transaction or reorder lock acquisition",
        "prevention": "Use consistent lock ordering, minimize lock scope",
        "severity": "High"
    },
    "PermissionDenied": {
        "pattern": r"permission.*denied|access.*denied|unauthorized|forbidden",
        "quick_fix": "Check file/resource permissions and user privileges",
        "prevention": "Implement proper permission checks before operations",
        "severity": "Medium"
    },
    "NetworkError": {
        "pattern": r"network.*error|connection.*refused|socket.*error|unreachable",
        "quick_fix": "Check network connectivity and firewall settings",
        "prevention": "Implement retry logic with exponential backoff",
        "severity": "Medium"
    }
}

# --- Enhanced pattern matching with context ---
def match_known_patterns(content):
    """Match crash content against known patterns with context awareness"""
    matches = []
    context_chars = CRASH_ANALYZER_CONFIG["pattern_match_context_chars"]
    
    for pattern_name, pattern_info in KNOWN_PATTERNS.items():
        pattern_matches = list(re.finditer(pattern_info["pattern"], content, re.IGNORECASE))
        
        for match_obj in pattern_matches:
            start = max(0, match_obj.start() - context_chars)
            end = min(len(content), match_obj.end() + context_chars)
            context = content[start:end].strip()
            
            # Clean up context for display
            context = re.sub(r'\s+', ' ', context)  # Normalize whitespace
            if len(context) > 200:
                context = context[:200] + "..."
            
            matches.append({
                "pattern": pattern_name,
                "quick_fix": pattern_info["quick_fix"],
                "prevention": pattern_info["prevention"],
                "severity": pattern_info.get("severity", "Medium"),
                "context": context,
                "position": match_obj.start(),
                "match_text": match_obj.group(0)
            })
    
    # Sort by severity and position
    severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}
    matches.sort(key=lambda x: (-severity_order.get(x["severity"], 0), x["position"]))
    
    return matches

# --- Smart content extraction ---
def extract_critical_sections(content, max_length=10000):
    """
    Extracts the most important sections from a crash dump.
    Prioritizes stack traces and exception messages.
    """
    sections = []
    
    # Extract exception info with priority
    exception_patterns = [
        (r'(FATAL:.*)', 'fatal'),
        (r'(CRITICAL:.*)', 'critical'),
        (r'(.*Exception:.*)', 'exception'),
        (r'(.*Error:.*)', 'error'),
        (r'(SEVERE:.*)', 'severe'),
        (r'(WARNING:.*)', 'warning')
    ]
    
    for pattern, priority in exception_patterns:
        matches = re.finditer(pattern, content, re.IGNORECASE | re.MULTILINE)
        for match in matches:
            # Get surrounding context
            start = max(0, match.start() - 200)
            end = min(len(content), match.end() + 500)
            sections.append((priority, content[start:end]))
    
    # Extract stack traces
    stack_patterns = [
        r'(?s)(\s+at\s+.*\n)+',
        r'(Thread\s+\d+.*\n(?:.*\n){0,10})',
        r'(Call stack:.*?\n\n)',
        r'(Stack trace:.*?\n\n)',
        r'(Traceback.*?\n\n)'
    ]
    
    for pattern in stack_patterns:
        matches = re.finditer(pattern, content, re.MULTILINE)
        for match in matches:
            sections.append(("stack_trace", match.group(0)))
    
    # Build critical content with priority
    critical_content = ""
    
    # Group by type and add in priority order
    priority_order = ['fatal', 'critical', 'exception', 'error', 'severe', 'stack_trace', 'warning']
    
    for priority in priority_order:
        priority_sections = [s for p, s in sections if p == priority]
        if priority_sections:
            critical_content += f"\n--- {priority.upper()} ---\n"
            # Limit number of sections per type
            for section in priority_sections[:3]:
                critical_content += section + "\n---\n"
    
    # Fallback if no patterns matched
    if not critical_content:
        # Look for any error keywords
        error_lines = []
        for i, line in enumerate(content.splitlines()):
            if re.search(r'error|fail|crash|exception|fatal', line, re.IGNORECASE):
                # Get context around error line
                start_line = max(0, i - 5)
                end_line = min(len(content.splitlines()), i + 5)
                context_lines = content.splitlines()[start_line:end_line]
                error_lines.append('\n'.join(context_lines))
        
        if error_lines:
            critical_content = "\n--- ERROR CONTEXTS ---\n" + "\n---\n".join(error_lines[:5])
        else:
            # Last resort: beginning and end
            if len(content) > 4000:
                critical_content = content[:2000] + "\n\n[... middle section omitted ...]\n\n" + content[-2000:]
            else:
                critical_content = content
    
    # Truncate to max_length
    if len(critical_content) > max_length:
        critical_content = critical_content[:max_length] + "\n[... truncated ...]"
    
    return critical_content

# --- Full file chunking for 5MB support ---
def analyze_with_chunking(content, chunk_size=None, overlap=None, progress_callback=None):
    """
    Analyzes large files using chunked processing.
    Supports files up to 5MB with progress tracking and abort capability.
    """
    if chunk_size is None:
        chunk_size = CRASH_ANALYZER_CONFIG["chunk_size"]
    if overlap is None:
        overlap = CRASH_ANALYZER_CONFIG["chunk_overlap"]
    
    # Calculate chunks
    chunks = []
    start = 0
    while start < len(content):
        end = min(start + chunk_size, len(content))
        chunks.append((start, end, content[start:end]))
        start = end - overlap if end < len(content) else end
    
    total_chunks = len(chunks)
    st.info(f"📊 Processing {total_chunks} chunks from {len(content):,} characters...")
    
    # Initialize results storage
    chunk_results = {
        "errors": set(),
        "error_types": set(),
        "severities": [],
        "root_causes": [],
        "locations": set(),
        "patterns": [],
        "summaries": []
    }
    
    # Progress tracking
    progress_bar = st.progress(0, text=f"Processing chunk 0/{total_chunks}")
    status_container = st.container()
    
    # Failure tracking
    consecutive_failures = 0
    max_failures = CRASH_ANALYZER_CONFIG.get("max_consecutive_failures", 10)
    total_failures = 0
    chunks_with_errors = 0
    
    # Abort functionality
    col1, col2 = st.columns([3, 1])
    with col2:
        abort_button = st.button("🛑 Abort", key="abort_chunking") if CRASH_ANALYZER_CONFIG["enable_abort"] else None
    
    start_time = time.time()
    aborted = False
    
    for i, (start_pos, end_pos, chunk) in enumerate(chunks):
        # Check for abort
        if abort_button and abort_button:
            aborted = True
            st.warning("⚠️ Processing aborted by user")
            break
        
        with status_container:
            st.write(f"🔍 Analyzing chunk {i+1}/{total_chunks} (chars {start_pos:,}-{end_pos:,})")
        
        # Check if chunk likely contains errors (improved detection)
        has_error_keywords = bool(re.search(
            r'error|exception|fail|crash|fatal|severe|panic|abort|warning|critical', 
            chunk, 
            re.IGNORECASE
        ))
        
        # Skip chunks without any error indicators if configured
        if (CRASH_ANALYZER_CONFIG.get("skip_empty_chunks", True) and 
            not has_error_keywords and 
            consecutive_failures < 3):  # Still process if we're having issues
            # Quick skip for chunks without errors
            chunk_results["summaries"].append(f"Chunk {i+1}: Skipped (no error keywords)")
            # Update progress without delay
            progress = (i + 1) / total_chunks
            progress_bar.progress(progress, text=f"Processing chunk {i+1}/{total_chunks} ({progress*100:.1f}%) - Skipped")
            continue
        
        
        try:
            # Import enhanced JSON helper
            from utils.json_helper_enhanced import get_chunk_analysis_safe
            
            # Use the safe analysis function
            chunk_data = get_chunk_analysis_safe(
                chunk=chunk,
                chunk_info=f" (position {start_pos}-{end_pos} in file)",
                model=st.session_state.get("selected_model", "deepseek-r1:latest")
            )
            
            # Check if we got valid data
            if chunk_data and isinstance(chunk_data, dict):
                # Reset consecutive failures on any successful parse
                consecutive_failures = 0
                
                # Check if chunk has actual errors
                if chunk_data.get("errors_found") or chunk_data.get("error_types"):
                    chunks_with_errors += 1
                
                # Also run pattern matching for additional insights
                chunk_patterns = match_known_patterns(chunk)
                if chunk_patterns:
                    chunk_results["patterns"].extend(chunk_patterns)
                    # Add pattern-based error types
                    for pattern in chunk_patterns:
                        chunk_results["error_types"].add(pattern["pattern"])
                        if pattern["severity"] not in chunk_data.get("severities", []):
                            chunk_results["severities"].append(pattern["severity"])
            else:
                # Shouldn't happen with enhanced helper, but just in case
                st.warning(f"⚠️ Unexpected response format for chunk {i+1}")
                chunk_data = {
                    "errors_found": [],
                    "error_types": [],
                    "severity": "Unknown",
                    "root_cause_hints": "",
                    "error_locations": [],
                    "summary": "Processing error"
                }
                total_failures += 1
                consecutive_failures += 1
            
            # Aggregate results
            chunk_results["errors"].update(chunk_data.get("errors_found", []))
            chunk_results["error_types"].update(chunk_data.get("error_types", []))
            
            severity = chunk_data.get("severity", "Unknown")
            if severity and severity != "Unknown":
                chunk_results["severities"].append(severity)
            
            if chunk_data.get("root_cause_hints") and chunk_data["root_cause_hints"] != "Unable to parse response":
                chunk_results["root_causes"].append(chunk_data["root_cause_hints"])
            
            chunk_results["locations"].update(chunk_data.get("error_locations", []))
            
            # Create meaningful summary
            summary = chunk_data.get('summary', 'No findings')
            if chunk_data.get("errors_found"):
                summary = f"{summary} ({len(chunk_data['errors_found'])} errors)"
            chunk_results["summaries"].append(f"Chunk {i+1}: {summary}")
            
        except Exception as e:
            st.warning(f"⚠️ Error processing chunk {i+1}: {str(e)}")
            total_failures += 1
            consecutive_failures += 1
            
            # Still try pattern matching as fallback
            try:
                chunk_patterns = match_known_patterns(chunk)
                if chunk_patterns:
                    chunk_results["patterns"].extend(chunk_patterns)
                    chunk_results["summaries"].append(f"Chunk {i+1}: Pattern matching only (error: {str(e)[:50]})")
                else:
                    chunk_results["summaries"].append(f"Chunk {i+1}: Processing failed")
            except:
                chunk_results["summaries"].append(f"Chunk {i+1}: Complete failure")
            
            # Check if we should stop
            if consecutive_failures >= max_failures:
                st.error(f"❌ Stopping after {consecutive_failures} consecutive failures")
                break
        
        # Update progress
        progress = (i + 1) / total_chunks
        progress_bar.progress(progress, text=f"Processing chunk {i+1}/{total_chunks} ({progress*100:.1f}%)")
        
        # Estimated time remaining
        elapsed = time.time() - start_time
        if i > 0:
            avg_time_per_chunk = elapsed / (i + 1)
            remaining_chunks = total_chunks - (i + 1)
            eta = avg_time_per_chunk * remaining_chunks
            status_container.caption(f"⏱️ Estimated time remaining: {int(eta//60)}m {int(eta%60)}s")
        
        # Small delay to prevent overload
        if CRASH_ANALYZER_CONFIG["chunk_processing_delay"] > 0:
            time.sleep(CRASH_ANALYZER_CONFIG["chunk_processing_delay"])
        
        if progress_callback:
            progress_callback(i + 1, total_chunks)
    
    # Clear progress indicators
    progress_bar.empty()
    status_container.empty()
    
    # Processing time
    elapsed_time = time.time() - start_time
    st.session_state.chunk_analysis_time = f"{elapsed_time:.2f}s"
    
    if aborted:
        st.info(f"Processed {i+1}/{total_chunks} chunks before abort")
    
    # Synthesize final results
    severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Unknown": 0}
    highest_severity = max(chunk_results["severities"], 
                          key=lambda x: severity_order.get(x, 0)) if chunk_results["severities"] else "Unknown"
    
    # Determine most likely root cause
    root_cause = "Not identified"
    if chunk_results["root_causes"]:
        # Simple frequency analysis
        cause_freq = {}
        for cause in chunk_results["root_causes"]:
            cause_freq[cause] = cause_freq.get(cause, 0) + 1
        root_cause = max(cause_freq.items(), key=lambda x: x[1])[0]
    
    # Compile final analysis
    final_analysis = {
        "root_cause": root_cause,
        "error_location": ", ".join(list(chunk_results["locations"])[:3]) or "Multiple locations",
        "error_type": ", ".join(list(chunk_results["error_types"])[:3]) or "Multiple types",
        "severity": highest_severity,
        "quick_fix": "Review the detailed chunk summaries for specific fixes",
        "prevention": "Address the root cause and implement proper error handling",
        "total_errors": len(chunk_results["errors"]),
        "chunks_processed": i + 1,
        "chunks_failed": total_failures,
        "chunks_with_errors": chunks_with_errors,
        "patterns_found": len(chunk_results["patterns"]),
        "processing_time": elapsed_time,
        "chunk_summaries": chunk_results["summaries"],
        "aborted": aborted,
        "stopped_early": consecutive_failures >= max_failures
    }
    
    return final_analysis

# --- Smart sampling for large files ---
def generate_strategic_samples(content, max_samples=10, sample_size=2000):
    """Extract strategic samples from large files for quick analysis"""
    samples = []
    
    # 1. Get file header
    samples.append({
        "type": "header",
        "content": content[:sample_size],
        "description": "File beginning",
        "position": 0
    })
    
    # 2. Find error/exception locations
    error_keywords = r'error|exception|crash|fatal|failed|critical|severe|panic|abort'
    error_positions = []
    
    for match in re.finditer(error_keywords, content, re.IGNORECASE):
        error_positions.append(match.start())
    
    # 3. Sample around errors (limit to avoid too many samples)
    sampled_positions = set()
    error_samples_added = 0
    
    for pos in error_positions:
        # Avoid overlapping samples
        if not any(abs(pos - p) < sample_size for p in sampled_positions):
            start = max(0, pos - sample_size//2)
            end = min(len(content), pos + sample_size//2)
            
            # Extract the actual error line for description
            line_start = content.rfind('\n', 0, pos) + 1
            line_end = content.find('\n', pos)
            if line_end == -1:
                line_end = len(content)
            error_line = content[line_start:line_end].strip()[:50]
            
            samples.append({
                "type": "error_context",
                "content": content[start:end],
                "description": f"Error: {error_line}...",
                "position": pos
            })
            sampled_positions.add(pos)
            error_samples_added += 1
            
            if error_samples_added >= max_samples - 2:
                break
    
    # 4. Look for stack traces specifically
    stack_trace_pattern = r'(?m)^\s+at\s+.*$'
    stack_matches = list(re.finditer(stack_trace_pattern, content))
    
    if stack_matches and len(samples) < max_samples - 1:
        # Get first stack trace
        stack_start = stack_matches[0].start()
        start = max(0, stack_start - 500)
        end = min(len(content), stack_start + 1500)
        
        samples.append({
            "type": "stack_trace",
            "content": content[start:end],
            "description": "Stack trace context",
            "position": stack_start
        })
    
    # 5. Get file end
    samples.append({
        "type": "footer", 
        "content": content[-sample_size:],
        "description": "File end",
        "position": len(content) - sample_size
    })
    
    return samples

# --- File size decision logic ---
def determine_analysis_method(content_size):
    """Determine best analysis method based on file size"""
    size_mb = content_size / (1024 * 1024)
    
    if size_mb < 0.1:  # <100KB
        return "standard", None
    elif size_mb < 1:  # <1MB
        return "standard_with_extraction", None
    elif size_mb < CRASH_ANALYZER_CONFIG["smart_sampling_threshold_mb"]:
        return "full_chunking", f"File is {size_mb:.1f}MB. Full analysis may take {int(size_mb * 30)} seconds."
    else:
        chunks_estimate = int(content_size / CRASH_ANALYZER_CONFIG["chunk_size"])
        time_estimate = chunks_estimate * 2  # ~2 seconds per chunk
        return "full_chunking", f"File is {size_mb:.1f}MB ({chunks_estimate} chunks, ~{time_estimate//60}m {time_estimate%60}s)"

# Enhanced analyze_crash_dump with performance tracking
def analyze_crash_dump(content):
    """Basic crash analysis - fast JSON response with smart extraction"""
    start_time = time.time()
    
    # Use smart extraction for better results
    extracted = extract_critical_sections(content, 15000)
    
    prompt = f"""Analyze this crash dump and provide a structured analysis.
Focus on identifying the root cause, error types, and providing actionable solutions.

CRASH DUMP:
{extracted}

Provide your analysis in this exact JSON format:
{{
    "root_cause": "Brief technical description of what caused the crash",
    "error_location": "File/method/line where crash occurred",
    "error_type": "Exception type or error category",  
    "severity": "Critical/High/Medium/Low",
    "quick_fix": "Immediate solution to resolve the crash",
    "prevention": "How to prevent this in the future"
}}

Be concise and technical. Focus only on the actual error."""
    
    try:
        # Use enhanced JSON helper
        from utils.json_helper_enhanced import safe_json_analysis
        
        analysis = safe_json_analysis(
            content=extracted,
            model=st.session_state.get("selected_model", "deepseek-r1:latest"),
            prompt=prompt,
            max_retries=3
        )
        
        # Track performance
        elapsed = time.time() - start_time
        st.session_state.last_analysis_time = f"{elapsed:.2f}s"
        
        # Ensure all required fields with better defaults
        required_fields = {
            "root_cause": "Unable to determine root cause",
            "error_location": "Location not identified", 
            "error_type": "Unknown error type",
            "severity": "Medium",
            "quick_fix": "Manual review required",
            "prevention": "Implement proper error handling"
        }
        
        # Fill in any missing fields
        for field, default in required_fields.items():
            if field not in analysis or not analysis[field] or analysis[field] == "Not identified":
                # Try pattern matching as fallback
                if field in ["error_type", "severity", "quick_fix", "prevention"]:
                    patterns = match_known_patterns(extracted[:5000])
                    if patterns:
                        first_pattern = patterns[0]
                        if field == "error_type":
                            analysis[field] = first_pattern['pattern']
                        elif field == "severity":
                            analysis[field] = first_pattern['severity']
                        elif field == "quick_fix":
                            analysis[field] = first_pattern['quick_fix']
                        elif field == "prevention":
                            analysis[field] = first_pattern['prevention']
                    else:
                        analysis[field] = default
                else:
                    analysis[field] = default
                
        return analysis
        
    except Exception as e:
        # Track performance even on error
        elapsed = time.time() - start_time
        st.session_state.last_analysis_time = f"{elapsed:.2f}s"
        
        # Try pattern matching as complete fallback
        patterns = match_known_patterns(content[:10000])
        if patterns:
            first_pattern = patterns[0]
            return {
                "root_cause": f"Detected {first_pattern['pattern']} error pattern",
                "error_location": f"Found at position {first_pattern['position']}",
                "error_type": first_pattern['pattern'],
                "severity": first_pattern['severity'],
                "quick_fix": first_pattern['quick_fix'],
                "prevention": first_pattern['prevention']
            }
        
        return {
            "root_cause": f"Analysis error: {str(e)}",
            "error_location": "Unknown",
            "error_type": str(type(e).__name__),
            "severity": "Medium",
            "quick_fix": "Check crash dump format and try again",
            "prevention": "Ensure proper error logging format"
        }

# Expert prompt template
EXPERT_PROMPT_TEMPLATE = """You are an expert Whats'On/VisualWorks investigator with deep knowledge of Smalltalk architecture. 
Think rigorously step-by-step, but output only the final report. Hide intermediate reasoning.

## Task
Analyse the runtime diagnostic dump below and deliver an actionable report.

## Report sections (use exactly these headings)

0. TOP 3 FINDINGS
   1) <one-sentence insight> — evidence: line/section reference
   2) <one-sentence insight> — evidence: line/section reference
   3) <one-sentence insight> — evidence: line/section reference

1. OVERVIEW  
   • Who: user, computer, site, build & DB info  
   • When: timestamp and temporal correlation
   • What: exception class & message  
   • Severity: [Critical/High/Medium/Low]

2. ELI5: WHAT HAPPENED
   • Explain in 3-5 simple sentences using everyday analogies
   • No technical jargon - think "explaining to your grandma"
   • Use a real-world metaphor

3. ROOT-CAUSE ANALYSIS  
   a. Failing call-chain summary
   b. Plain-English explanation of key frames
   c. Most likely cause with confidence level
   d. Match against known patterns or state "Unknown"

4. USER IMPACT  
   • What the user saw/lost
   • Functionality affected
   • Data loss risk

5. FIX PROPOSALS  
   • Quick operator win 🟢/🟡/🔴
   • Code hot-fix 🟢/🟡/🔴
   • Prevention strategy 🟢/🟡/🔴

6. NEXT STEPS  
   • Action items with priority
   • Questions for investigation

## Output format
Markdown with concise bullets. Quote dump lines sparingly.

## Runtime Diagnostic Dump
{crash_content}"""

# Enhanced expert report generation
def generate_expert_report(content):
    """Generate detailed expert report - comprehensive but slower"""
    start_time = time.time()
    
    # Use smart extraction
    extracted = extract_critical_sections(content, 20000)
    
    prompt = EXPERT_PROMPT_TEMPLATE.format(crash_content=extracted)
    
    result = safe_ollama_generate(
        model=st.session_state.get("selected_model", "deepseek-r1:latest"),
        prompt=prompt,
        temperature=0.3  # Lower temperature for more focused analysis
    )
    
    # Track performance
    elapsed = time.time() - start_time
    st.session_state.last_expert_time = f"{elapsed:.2f}s"
    
    # Extract the response string from the dictionary
    if isinstance(result, dict):
        return result.get('response', 'Failed to generate report')
    return str(result)

# --- Performance monitoring display ---
def show_performance_stats():
    """Display analysis performance metrics"""
    if any(key in st.session_state for key in ['last_analysis_time', 'last_expert_time', 'chunk_analysis_time']):
        st.markdown("### ⏱️ Performance Metrics")
        cols = st.columns(4)
        
        if 'last_analysis_time' in st.session_state:
            cols[0].metric("Basic Analysis", st.session_state.last_analysis_time)
        
        if 'last_expert_time' in st.session_state:
            cols[1].metric("Expert Analysis", st.session_state.last_expert_time)
        
        if 'chunk_analysis_time' in st.session_state:
            cols[2].metric("Chunk Analysis", st.session_state.chunk_analysis_time)
        
        if 'last_method_used' in st.session_state:
            cols[3].metric("Method Used", st.session_state.last_method_used)

# --- Enhanced file analysis status ---
def show_file_analysis_status(content):
    """Show visual indicators of file analysis status"""
    st.markdown("### 🔍 File Analysis Insights")
    cols = st.columns(6)
    
    # Line count
    lines = content.splitlines()
    cols[0].metric("📄 Lines", f"{len(lines):,}")
    
    # File size
    size_kb = len(content) / 1024
    if size_kb > 1024:
        cols[1].metric("💾 Size", f"{size_kb/1024:.1f} MB")
    else:
        cols[1].metric("💾 Size", f"{size_kb:.1f} KB")
    
    # Error count estimate
    error_count = len(re.findall(r'error|exception|fail|fatal|crash', content, re.IGNORECASE))
    cols[2].metric("🐛 Errors", error_count)
    
    # Stack trace detection
    stack_traces = len(re.findall(r'^\s+at\s+', content, re.MULTILINE))
    cols[3].metric("📚 Stack Frames", stack_traces)
    
    # Timestamp detection
    timestamps = re.findall(r'\d{4}-\d{2}-\d{2}[\s\-T]\d{2}:\d{2}:\d{2}', content)
    if timestamps:
        cols[4].metric("🕐 Timestamps", len(timestamps))
        # Show time range
        if len(timestamps) > 1:
            cols[5].metric("📅 Time Range", f"{timestamps[0][:10]} to {timestamps[-1][:10]}")
    else:
        cols[4].metric("🕐 Timestamps", "None")
    
    # Pattern preview
    patterns = match_known_patterns(content[:10000])  # Quick scan of first 10KB
    if patterns:
        st.info(f"🔍 Quick scan found {len(patterns)} known error patterns in first 10KB")

# Original helper functions
def find_similar_crashes(error_type, limit=5):
    """Find crashes with similar error patterns"""
    try:
        return db.fetch_all("""
            SELECT filename, 
                   analysis->>'severity' as severity,
                   analysis->>'root_cause' as root_cause,
                   validated_by,
                   created_at
            FROM crash_analysis
            WHERE analysis->>'error_type' ILIKE %s
               OR analysis->>'root_cause' ILIKE %s
            ORDER BY created_at DESC
            LIMIT %s
        """, (f"%{error_type}%", f"%{error_type}%", limit))
    except:
        return []

def export_crash_report(filename, analysis, expert_report=None):
    """Export crash analysis as markdown"""
    severity_emoji = {
        "Critical": "🔴", "High": "🟠", 
        "Medium": "🟡", "Low": "🟢"
    }.get(analysis.get("severity", "Medium"), "⚪")
    
    report = f"""# Crash Analysis Report

**File**: {filename}  
**Date**: {datetime.now().strftime('%Y-%m-%d %H:%M')}  
**Severity**: {severity_emoji} {analysis.get('severity', 'Unknown')}

## Summary
- **Error Type**: {analysis.get('error_type', 'Unknown')}
- **Location**: {analysis.get('error_location', 'Unknown')}
- **Root Cause**: {analysis.get('root_cause', 'Not identified')}

## Quick Fix
{analysis.get('quick_fix', 'No quick fix available')}

## Prevention
{analysis.get('prevention', 'No prevention strategy defined')}
"""
    
    if expert_report:
        report += f"\n---\n\n## Expert Analysis\n\n{expert_report}"
    
    return report

def extract_mermaid_diagrams(text):
    """Extract Mermaid diagrams from markdown text"""
    diagrams = []
    if isinstance(text, dict):
        text = text.get('response', '')
    lines = text.split('\n')
    in_mermaid = False
    current_diagram = []
    
    for line in lines:
        if line.strip().startswith("```mermaid"):
            in_mermaid = True
            continue
        elif in_mermaid and line.strip().startswith("```"):
            in_mermaid = False
            if current_diagram:
                diagrams.append('\n'.join(current_diagram))
                current_diagram = []
        elif in_mermaid:
            current_diagram.append(line)
    
    return diagrams

def save_crash_analysis(filename, content_hash, analysis, expert_report, validated_by, include_expert):
    """Save validated analysis to database"""
    try:
        # Save to crash_analysis table
        db.execute(
            """INSERT INTO crash_analysis 
            (filename, content_hash, analysis, expert_report, validated_by, created_at) 
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (content_hash) DO UPDATE 
            SET analysis = %s, expert_report = %s, validated_by = %s, created_at = %s""",
            (filename, content_hash, json.dumps(analysis), 
             expert_report if include_expert else None, validated_by, datetime.now(),
             json.dumps(analysis), expert_report if include_expert else None, 
             validated_by, datetime.now())
        )
        
        # Capture to general knowledge base
        capture_knowledge(
            tool_name="crash_analyzer",
            prompt=f"Analyze crash in {filename}",
            response=json.dumps(analysis, indent=2) + 
                    ("\n\n---EXPERT REPORT---\n" + expert_report if include_expert and expert_report else ""),
            metadata={
                "filename": filename,
                "severity": analysis.get("severity", "Unknown"),
                "validated_by": validated_by,
                "has_expert_report": include_expert
            }
        )
        return True
    except Exception as e:
        st.error(f"Database error: {str(e)}")
        return False

def recognize_crash_patterns(limit=50, min_occurrences=2):
    """
    Analyze crash patterns across multiple dumps to identify recurring issues.
    Returns patterns with frequency, affected systems, and trend analysis.
    """
    try:
        # Fetch recent crash analyses
        recent_crashes = db.fetch_all("""
            SELECT 
                analysis->>'error_type' as error_type,
                analysis->>'error_location' as error_location,
                analysis->>'root_cause' as root_cause,
                analysis->>'severity' as severity,
                filename,
                created_at
            FROM crash_analysis
            ORDER BY created_at DESC
            LIMIT %s
        """, (limit,))
        
        if not recent_crashes:
            return {
                "patterns": [],
                "summary": "No crash data available for pattern analysis"
            }
        
        # Group crashes by error type and root cause
        pattern_groups = {}
        for crash in recent_crashes:
            # Create pattern key from error type and root cause
            pattern_key = f"{crash['error_type'] or 'Unknown'}:{crash['root_cause'] or 'Unknown'}"
            
            if pattern_key not in pattern_groups:
                pattern_groups[pattern_key] = {
                    "error_type": crash['error_type'] or 'Unknown',
                    "root_cause": crash['root_cause'] or 'Unknown',
                    "occurrences": 0,
                    "severities": [],
                    "locations": set(),
                    "files": [],
                    "first_seen": crash['created_at'],
                    "last_seen": crash['created_at']
                }
            
            group = pattern_groups[pattern_key]
            group['occurrences'] += 1
            group['severities'].append(crash['severity'] or 'Unknown')
            if crash['error_location']:
                group['locations'].add(crash['error_location'])
            group['files'].append({
                "filename": crash['filename'],
                "timestamp": crash['created_at']
            })
            
            # Update time range
            if crash['created_at'] < group['first_seen']:
                group['first_seen'] = crash['created_at']
            if crash['created_at'] > group['last_seen']:
                group['last_seen'] = crash['created_at']
        
        # Filter patterns with minimum occurrences and calculate metrics
        significant_patterns = []
        for pattern_key, group in pattern_groups.items():
            if group['occurrences'] >= min_occurrences:
                # Calculate severity distribution
                severity_counts = {}
                for severity in group['severities']:
                    severity_counts[severity] = severity_counts.get(severity, 0) + 1
                
                # Determine dominant severity
                dominant_severity = max(severity_counts.items(), key=lambda x: x[1])[0]
                
                # Calculate trend (increasing/decreasing/stable)
                time_diff = (group['last_seen'] - group['first_seen']).total_seconds()
                if time_diff > 0:
                    # Check if occurrences are concentrated in recent time
                    recent_count = sum(1 for f in group['files'][-5:] 
                                     if (group['last_seen'] - f['timestamp']).days <= 1)
                    trend = "increasing" if recent_count >= 3 else "stable"
                else:
                    trend = "new"
                
                significant_patterns.append({
                    "pattern_id": pattern_key,
                    "error_type": group['error_type'],
                    "root_cause": group['root_cause'],
                    "occurrences": group['occurrences'],
                    "affected_locations": list(group['locations'])[:5],  # Top 5 locations
                    "severity_distribution": severity_counts,
                    "dominant_severity": dominant_severity,
                    "trend": trend,
                    "time_span_days": max(1, (group['last_seen'] - group['first_seen']).days),
                    "recent_files": [f['filename'] for f in group['files'][-3:]]  # Last 3 files
                })
        
        # Sort by occurrences and severity
        severity_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1, "Unknown": 0}
        significant_patterns.sort(
            key=lambda p: (p['occurrences'], severity_order.get(p['dominant_severity'], 0)),
            reverse=True
        )
        
        # Generate summary
        total_crashes = len(recent_crashes)
        pattern_count = len(significant_patterns)
        most_common = significant_patterns[0] if significant_patterns else None
        
        summary = f"Analyzed {total_crashes} crashes, found {pattern_count} recurring patterns."
        if most_common:
            summary += f" Most common: {most_common['error_type']} ({most_common['occurrences']} occurrences)"
        
        return {
            "patterns": significant_patterns[:10],  # Top 10 patterns
            "summary": summary,
            "total_analyzed": total_crashes,
            "pattern_count": pattern_count
        }
        
    except Exception as e:
        return {
            "patterns": [],
            "summary": f"Pattern analysis failed: {str(e)}"
        }

def show_crash_statistics_dashboard():
    """
    Display interactive crash statistics dashboard with real-time metrics,
    severity trends, pattern analysis, and team performance indicators.
    """
    try:
        st.markdown("### 📊 Crash Statistics Dashboard")
        
        # Date range selector
        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input(
                "Start Date", 
                value=datetime.now() - timedelta(days=30),
                max_value=datetime.now().date()
            )
        with col2:
            end_date = st.date_input(
                "End Date", 
                value=datetime.now().date(),
                max_value=datetime.now().date()
            )
        
        # Fetch crash data for the period
        crash_data = db.fetch_all("""
            SELECT 
                analysis->>'severity' as severity,
                analysis->>'error_type' as error_type,
                analysis->>'root_cause' as root_cause,
                filename,
                validated_by,
                created_at
            FROM crash_analysis
            WHERE DATE(created_at) BETWEEN %s AND %s
            ORDER BY created_at DESC
        """, (start_date, end_date))
        
        if not crash_data:
            st.warning("No crash data available for the selected period.")
            return
        
        # Calculate key metrics
        total_crashes = len(crash_data)
        severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        for crash in crash_data:
            severity = crash['severity'] or 'Unknown'
            if severity in severity_counts:
                severity_counts[severity] += 1
        
        # Display key metrics
        st.markdown("#### 🎯 Key Metrics")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Crashes", total_crashes)
        with col2:
            critical_count = severity_counts['Critical']
            st.metric("Critical Issues", critical_count,
                     delta=f"{round(critical_count/total_crashes*100, 1)}%" if total_crashes > 0 else "0%")
        with col3:
            days_in_period = max(1, (end_date - start_date).days + 1)
            avg_per_day = round(total_crashes / days_in_period, 1)
            st.metric("Daily Average", avg_per_day)
        with col4:
            unique_validators = len(set(crash['validated_by'] for crash in crash_data))
            st.metric("Active Validators", unique_validators)
        
        # Severity distribution chart
        st.markdown("#### 🔴 Severity Distribution")
        severity_data = []
        colors = {"Critical": "#FF0000", "High": "#FF6600", "Medium": "#FFB800", "Low": "#00CC00"}
        
        for severity, count in severity_counts.items():
            if count > 0:
                severity_data.append({
                    "Severity": severity,
                    "Count": count,
                    "Percentage": round(count/total_crashes*100, 1)
                })
        
        if severity_data:
            # Create bar chart using columns
            cols = st.columns(len(severity_data))
            for i, data in enumerate(severity_data):
                with cols[i]:
                    st.metric(
                        data["Severity"],
                        data["Count"],
                        f"{data['Percentage']}%"
                    )
                    # Visual bar representation
                    bar_height = int(data["Percentage"] / 2)
                    st.markdown(
                        f'<div style="background-color: {colors.get(data["Severity"], "#666")}; '
                        f'height: {bar_height}px; width: 100%; margin-top: 5px;"></div>',
                        unsafe_allow_html=True
                    )
        
        # Daily trend
        st.markdown("#### 📈 Daily Crash Trend")
        daily_counts = {}
        for crash in crash_data:
            day_key = crash['created_at'].strftime('%Y-%m-%d')
            daily_counts[day_key] = daily_counts.get(day_key, 0) + 1
        
        if daily_counts:
            # Simple text-based chart
            max_count = max(daily_counts.values())
            st.code(
                "\n".join([
                    f"{date}: {'█' * int(count/max_count * 30)} {count}"
                    for date, count in sorted(daily_counts.items())[-7:]  # Last 7 days
                ])
            )
        
        # Top error types
        st.markdown("#### 🔍 Top Error Types")
        error_type_counts = {}
        for crash in crash_data:
            error_type = crash['error_type'] or 'Unknown'
            error_type_counts[error_type] = error_type_counts.get(error_type, 0) + 1
        
        top_errors = sorted(error_type_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        for i, (error_type, count) in enumerate(top_errors, 1):
            percentage = round(count/total_crashes*100, 1)
            st.write(f"{i}. **{error_type}**: {count} occurrences ({percentage}%)")
        
        # Pattern analysis summary
        with st.expander("🔄 Pattern Analysis", expanded=False):
            patterns = recognize_crash_patterns(limit=50, min_occurrences=2)
            if patterns['patterns']:
                st.write(patterns['summary'])
                for i, pattern in enumerate(patterns['patterns'][:3], 1):
                    st.write(f"\n**Pattern {i}**: {pattern['error_type']}")
                    st.write(f"- Occurrences: {pattern['occurrences']}")
                    st.write(f"- Trend: {pattern['trend']}")
                    st.write(f"- Severity: {pattern['dominant_severity']}")
        
        # Team performance
        st.markdown("#### 👥 Validator Performance")
        validator_counts = {}
        for crash in crash_data:
            validator = crash['validated_by'] or 'Unknown'
            validator_counts[validator] = validator_counts.get(validator, 0) + 1
        
        top_validators = sorted(validator_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        if top_validators:
            cols = st.columns(len(top_validators))
            for i, (validator, count) in enumerate(top_validators):
                with cols[i]:
                    st.metric(validator, count)
        
    except Exception as e:
        st.error(f"Error loading dashboard: {str(e)}")

# Main show function
def show():
    st.title("🚨 Crash Analyzer Pro")
    st.caption("AI-powered crash analysis with intelligent diagnostics - supports files up to 5MB")
    
    # Initialize session state
    if 'analysis' not in st.session_state:
        st.session_state.analysis = None
    if 'expert_report' not in st.session_state:
        st.session_state.expert_report = None
    if 'chunk_analysis' not in st.session_state:
        st.session_state.chunk_analysis = None
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload crash dump", 
        type=["txt", "log", "dmp", "wcr", "crash", "error"],
        help=f"Maximum file size: {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB. Full processing available for all sizes."
    )
    
    if uploaded_file:
        # Validate file size
        if not validate_file_size(uploaded_file, max_size_mb=CRASH_ANALYZER_CONFIG['max_file_size_mb']):
            st.error(f"File too large. Maximum size is {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB.")
            return
            
        # Read content
        try:
            content = uploaded_file.getvalue().decode("utf-8", errors='ignore')
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")
            return
        
        # Determine analysis method
        method, warning = determine_analysis_method(len(content))
        st.session_state.last_method_used = method.replace("_", " ").title()
        
        # File info header
        st.markdown(f"### 📄 Analyzing: {uploaded_file.name}")
        cols = st.columns(4)
        cols[0].info(f"**Size:** {len(content):,} bytes")
        cols[1].info(f"**Hash:** `{content_hash}`")
        cols[2].info(f"**Method:** {st.session_state.last_method_used}")
        cols[3].info(f"**Modified:** {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        # Show warning if needed
        if warning:
            st.warning(f"⚠️ {warning}")
        
        # Show file insights
        show_file_analysis_status(content)
        
        # Pattern detection
        with st.spinner("🔍 Scanning for known patterns..."):
            pattern_matches = match_known_patterns(content)
        
        if pattern_matches:
            with st.expander(f"🎯 Detected {len(pattern_matches)} Known Patterns", expanded=True):
                # Group by severity
                severity_groups = {}
                for match in pattern_matches:
                    severity = match['severity']
                    if severity not in severity_groups:
                        severity_groups[severity] = []
                    severity_groups[severity].append(match)
                
                # Display by severity
                for severity in ["Critical", "High", "Medium", "Low"]:
                    if severity in severity_groups:
                        severity_emoji = {
                            "Critical": "🔴", "High": "🟠",
                            "Medium": "🟡", "Low": "🟢"
                        }.get(severity, "⚪")
                        
                        st.markdown(f"#### {severity_emoji} {severity} Severity")
                        
                        for match in severity_groups[severity][:2]:  # Show max 2 per severity
                            col1, col2 = st.columns([3, 1])
                            with col1:
                                st.markdown(f"**{match['pattern']}** - Found: `{match['match_text']}`")
                                # Show context in a collapsible way without nested expander
                                if st.checkbox(f"Show context for {match['pattern']}", key=f"context_{match['pattern']}_{match['position']}"):
                                    st.code(match['context'], language="text")
                            with col2:
                                st.markdown("**Quick Fix:**")
                                st.caption(match['quick_fix'])
        
        # Content preview
        with st.expander("📋 View Crash Dump", expanded=False):
            preview_type = st.radio("Preview type", ["First 3KB", "Smart Extract", "Full (slow)"], horizontal=True)
            
            if preview_type == "First 3KB":
                st.code(content[:3000] + ("..." if len(content) > 3000 else ""))
            elif preview_type == "Smart Extract":
                extracted = extract_critical_sections(content, 5000)
                st.code(extracted)
            else:
                st.code(content)
        
        # Analysis options
        st.markdown("### 🔍 Analysis Methods")
        
        # Analysis buttons
        method_cols = st.columns(4)
        
        with method_cols[0]:
            if st.button("⚡ Basic Analysis", use_container_width=True, 
                        help="Fast analysis using critical sections (5-15 seconds)",
                        type="primary"):
                with st.spinner("Analyzing critical sections..."):
                    st.session_state.analysis = analyze_crash_dump(content)
                    st.session_state.expert_report = None
                    st.session_state.chunk_analysis = None
                st.success("✅ Basic analysis complete!")
                st.toast("Analysis complete!", icon="✅")
        
        with method_cols[1]:
            if st.button("🕵️ Expert Diagnostics", use_container_width=True,
                        help="Comprehensive report with actionable insights (30-60 seconds)"):
                with st.spinner("Generating expert report..."):
                    st.session_state.expert_report = generate_expert_report(content)
                    st.session_state.analysis = None
                    st.session_state.chunk_analysis = None
                st.success("✅ Expert report generated!")
                st.toast("Expert report ready!", icon="📝")
        
        with method_cols[2]:
            if st.button("📊 Smart Sampling", use_container_width=True,
                        help="Analyze strategic samples for quick insights"):
                with st.spinner("Analyzing strategic samples..."):
                    samples = generate_strategic_samples(content)
                    
                    # Show sample info
                    st.info(f"📍 Extracted {len(samples)} strategic samples")
                    
                    combined_samples = "\n\n--- SAMPLE BOUNDARY ---\n\n".join([s['content'] for s in samples])
                    st.session_state.analysis = analyze_crash_dump(combined_samples)
                    
                    # Store sample info
                    st.session_state.analysis['sample_info'] = {
                        'count': len(samples),
                        'types': [s['type'] for s in samples]
                    }
                    st.session_state.expert_report = None
                    st.session_state.chunk_analysis = None
                st.success("✅ Sample analysis complete!")
                st.toast("Sample analysis done!", icon="📊")
        
        with method_cols[3]:
            # Full processing available for all file sizes
            size_mb = len(content) / (1024 * 1024)
            help_text = f"Process entire {size_mb:.1f}MB file"
            
            if size_mb > 2:
                chunks_estimate = int(len(content) / CRASH_ANALYZER_CONFIG["chunk_size"])
                time_estimate = chunks_estimate * 2
                help_text += f" ({chunks_estimate} chunks, ~{time_estimate//60}m)"
                
            if st.button("🧩 Full File Analysis", use_container_width=True, help=help_text):
                # Warning for large files
                if size_mb > 2:
                    st.warning(f"""
                    ⚠️ **Large File Processing**
                    - File size: {size_mb:.1f}MB
                    - Estimated chunks: {chunks_estimate}
                    - Estimated time: {time_estimate//60} minutes {time_estimate%60} seconds
                    - You can abort processing at any time
                    """)
                    
                    if not st.checkbox("I understand and want to proceed with full analysis"):
                        st.stop()
                
                with st.spinner("Performing full file analysis..."):
                    st.session_state.chunk_analysis = analyze_with_chunking(content)
                    st.session_state.analysis = None
                    st.session_state.expert_report = None
                
                if not st.session_state.chunk_analysis.get('aborted', False):
                    st.success("✅ Full analysis complete!")
                    st.toast("Full analysis done!", icon="🎉")
                else:
                    st.info("Analysis stopped by user")
        
        # Show performance stats
        show_performance_stats()
        
        # Display analysis results
        if st.session_state.analysis:
            st.markdown("### 📊 Basic Analysis Results")
            
            # Check if this was from sampling
            if 'sample_info' in st.session_state.analysis:
                st.info(f"📍 Based on {st.session_state.analysis['sample_info']['count']} strategic samples")
            
            # Severity indicator with visual
            severity = st.session_state.analysis.get("severity", "Medium")
            severity_color = {
                "Critical": "🔴", "High": "🟠", 
                "Medium": "🟡", "Low": "🟢"
            }.get(severity, "⚪")
            
            # Main metrics
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Severity", f"{severity_color} {severity}")
            with col2:
                st.metric("Error Type", st.session_state.analysis.get("error_type", "Unknown"))
            with col3:
                st.metric("Location", st.session_state.analysis.get("error_location", "Unknown")[:30] + "...")
            
            # Editable analysis fields
            st.markdown("#### 📝 Analysis Details")
            col1, col2 = st.columns(2)
            
            with col1:
                st.session_state.analysis["root_cause"] = st.text_area(
                    "Root Cause",
                    value=st.session_state.analysis["root_cause"],
                    height=100
                )
                st.session_state.analysis["quick_fix"] = st.text_area(
                    "Quick Fix",
                    value=st.session_state.analysis["quick_fix"],
                    height=100
                )
                
            with col2:
                st.session_state.analysis["severity"] = st.selectbox(
                    "Severity",
                    ["Critical", "High", "Medium", "Low"],
                    index=["Critical", "High", "Medium", "Low"].index(severity)
                )
                st.session_state.analysis["prevention"] = st.text_area(
                    "Prevention Strategy",
                    value=st.session_state.analysis["prevention"],
                    height=100
                )
        
        if st.session_state.expert_report:
            st.markdown("### 📝 Expert Diagnostic Report")
            
            # Full report in expander
            with st.expander("View Full Expert Report", expanded=True):
                st.markdown(st.session_state.expert_report)
            
            # Extract and display any Mermaid diagrams
            diagrams = extract_mermaid_diagrams(st.session_state.expert_report)
            if diagrams:
                st.markdown("#### 📊 Visualizations")
                for i, diagram in enumerate(diagrams):
                    st.caption(f"Diagram {i+1}")
                    st.code(diagram, language="mermaid")
        
        if st.session_state.chunk_analysis:
            st.markdown("### 🧩 Full File Analysis Results")
            
            # Display metrics
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Total Errors", st.session_state.chunk_analysis.get("total_errors", 0))
            with col2:
                chunks_processed = st.session_state.chunk_analysis.get("chunks_processed", 0)
                chunks_failed = st.session_state.chunk_analysis.get("chunks_failed", 0)
                success_rate = ((chunks_processed - chunks_failed) / chunks_processed * 100) if chunks_processed > 0 else 0
                st.metric("Chunks Processed", chunks_processed, f"{success_rate:.0f}% success")
            with col3:
                st.metric("Patterns Found", st.session_state.chunk_analysis.get("patterns_found", 0))
            with col4:
                st.metric("Processing Time", f"{st.session_state.chunk_analysis.get('processing_time', 0):.1f}s")
            
            # Show failure info if there were failures
            if st.session_state.chunk_analysis.get("chunks_failed", 0) > 0:
                st.warning(f"⚠️ {chunks_failed} chunks failed to process. Using pattern matching for those chunks.")
            
            if st.session_state.chunk_analysis.get("stopped_early", False):
                st.error("❌ Processing stopped early due to too many consecutive failures.")
            
            # Show aggregated results
            st.markdown("#### 📊 Aggregated Analysis")
            
            # Severity indicator
            severity = st.session_state.chunk_analysis.get("severity", "Unknown")
            severity_color = {
                "Critical": "🔴", "High": "🟠", 
                "Medium": "🟡", "Low": "🟢"
            }.get(severity, "⚪")
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"**Severity:** {severity_color} {severity}")
                st.markdown(f"**Root Cause:** {st.session_state.chunk_analysis.get('root_cause', 'Not identified')}")
            with col2:
                st.markdown(f"**Error Types:** {st.session_state.chunk_analysis.get('error_type', 'Multiple types')}")
                st.markdown(f"**Locations:** {st.session_state.chunk_analysis.get('error_location', 'Multiple locations')}")
            
            # Show chunk summaries
            if st.session_state.chunk_analysis.get("chunk_summaries"):
                with st.expander("📋 Chunk-by-Chunk Analysis", expanded=False):
                    # Show first 10 and last 5 summaries
                    summaries = st.session_state.chunk_analysis["chunk_summaries"]
                    if len(summaries) > 15:
                        for summary in summaries[:10]:
                            st.write(f"- {summary}")
                        st.write("...")
                        for summary in summaries[-5:]:
                            st.write(f"- {summary}")
                    else:
                        for summary in summaries:
                            st.write(f"- {summary}")
        
        # Show similar crashes if analysis available
        if any([st.session_state.analysis, st.session_state.chunk_analysis]):
            analysis_data = st.session_state.analysis or st.session_state.chunk_analysis
            if analysis_data.get("error_type") and analysis_data["error_type"] != "Unknown":
                similar = find_similar_crashes(analysis_data["error_type"], limit=5)
                if similar:
                    st.markdown("### 🔗 Similar Previous Crashes")
                    for crash in similar:
                        severity_emoji = {
                            "Critical": "🔴", "High": "🟠",
                            "Medium": "🟡", "Low": "🟢"
                        }.get(crash['severity'], "⚪")
                        
                        col1, col2, col3 = st.columns([3, 1, 1])
                        with col1:
                            st.markdown(f"{severity_emoji} **{crash['filename']}**")
                            st.caption(f"Root cause: {crash['root_cause'][:80]}...")
                        with col2:
                            st.caption(f"By: {crash['validated_by']}")
                        with col3:
                            st.caption(crash['created_at'].strftime('%Y-%m-%d'))
        
        # Save section
        if any([st.session_state.analysis, st.session_state.expert_report, st.session_state.chunk_analysis]):
            st.divider()
            st.markdown("### 💾 Save to Knowledge Base")
            
            col1, col2 = st.columns([3, 1])
            
            with col1:
                validator_name = st.text_input(
                    "Your Name (required for validation)",
                    placeholder="Enter your name to save this analysis"
                )
            
            with col2:
                quality = st.number_input("Quality Rating", 1, 5, 3, help="Rate the analysis quality")
            
            include_expert = False
            if st.session_state.expert_report:
                include_expert = st.checkbox(
                    "Include expert report in knowledge base", 
                    value=True,
                    help="Expert reports provide valuable context for future reference"
                )
            
            col1, col2, col3 = st.columns([2, 1, 1])
            with col1:
                if st.button("💾 Save Validated Analysis", type="primary", use_container_width=True):
                    if not validator_name:
                        st.warning("⚠️ Please enter your name for validation")
                    else:
                        # Use whichever analysis is available
                        analysis_to_save = (st.session_state.analysis or 
                                          st.session_state.chunk_analysis or 
                                          {})
                        
                        if save_crash_analysis(
                            uploaded_file.name,
                            content_hash,
                            analysis_to_save,
                            st.session_state.expert_report,
                            validator_name,
                            include_expert
                        ):
                            st.success("✅ Analysis saved to knowledge base!")
                            st.balloons()
            
            with col2:
                # Export functionality
                if st.button("📄 Export Report", use_container_width=True):
                    analysis_to_export = (st.session_state.analysis or 
                                        st.session_state.chunk_analysis or 
                                        {})
                    report = export_crash_report(
                        uploaded_file.name,
                        analysis_to_export,
                        st.session_state.expert_report if include_expert else None
                    )
                    st.download_button(
                        label="Download",
                        data=report,
                        file_name=f"crash_report_{uploaded_file.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                        mime="text/markdown"
                    )
            
            with col3:
                # Quick navigation
                if st.button("📚 Knowledge Library", use_container_width=True):
                    st.switch_page("pages/knowledge_lib.py")
    
    # Recent analyses
    with st.expander("📋 Recent Crash Analyses", expanded=False):
        try:
            recent = db.fetch_all(
                """SELECT filename, analysis->>'severity' as severity, 
                   analysis->>'root_cause' as root_cause, 
                   validated_by, created_at,
                   CASE WHEN expert_report IS NOT NULL THEN TRUE ELSE FALSE END as has_expert
                   FROM crash_analysis 
                   ORDER BY created_at DESC LIMIT 10"""
            )
            
            if recent:
                for entry in recent:
                    severity_emoji = {
                        "Critical": "🔴", "High": "🟠", 
                        "Medium": "🟡", "Low": "🟢"
                    }.get(entry['severity'], "⚪")
                    
                    expert_badge = "📝" if entry['has_expert'] else ""
                    
                    col1, col2, col3 = st.columns([3, 1, 1])
                    with col1:
                        st.markdown(f"{severity_emoji} **{entry['filename']}** {expert_badge}")
                        st.caption(f"Root cause: {entry['root_cause'][:80]}...")
                    with col2:
                        st.caption(f"By: {entry['validated_by']}")
                    with col3:
                        st.caption(entry['created_at'].strftime('%Y-%m-%d %H:%M'))
            else:
                st.info("No crash analyses found yet")
        except:
            st.info("Initialize the database to see recent analyses")
    
    # Pattern analysis dashboard
    with st.expander("📊 Crash Statistics Dashboard", expanded=False):
        show_crash_statistics_dashboard()
    
    # Database setup
    with st.expander("🔧 Database Setup", expanded=False):
        st.markdown("### Initialize Crash Analysis Database")
        st.code("""
-- Enhanced table with expert report support
CREATE TABLE IF NOT EXISTS crash_analysis (
    id SERIAL PRIMARY KEY,
    filename TEXT NOT NULL,
    content_hash VARCHAR(32) UNIQUE,
    analysis JSONB NOT NULL,
    expert_report TEXT,
    validated_by TEXT NOT NULL,
    quality_rating INTEGER DEFAULT 3,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_crash_severity 
ON crash_analysis((analysis->>'severity'));

CREATE INDEX IF NOT EXISTS idx_crash_created 
ON crash_analysis(created_at DESC);

-- Text search indexes for pattern analysis
CREATE INDEX IF NOT EXISTS idx_crash_error_type_pattern 
ON crash_analysis USING gin(to_tsvector('english', analysis->>'error_type'));

CREATE INDEX IF NOT EXISTS idx_crash_root_cause_pattern
ON crash_analysis USING gin(to_tsvector('english', analysis->>'root_cause'));
        """, language="sql")
        
        if st.button("🚀 Initialize Database Tables"):
            try:
                db.execute("""
                    CREATE TABLE IF NOT EXISTS crash_analysis (
                        id SERIAL PRIMARY KEY,
                        filename TEXT NOT NULL,
                        content_hash VARCHAR(32) UNIQUE,
                        analysis JSONB NOT NULL,
                        expert_report TEXT,
                        validated_by TEXT NOT NULL,
                        quality_rating INTEGER DEFAULT 3,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                db.execute("""
                    CREATE INDEX IF NOT EXISTS idx_crash_severity 
                    ON crash_analysis((analysis->>'severity'))
                """)
                db.execute("""
                    CREATE INDEX IF NOT EXISTS idx_crash_created 
                    ON crash_analysis(created_at DESC)
                """)
                db.execute("""
                    CREATE INDEX IF NOT EXISTS idx_crash_error_type_pattern 
                    ON crash_analysis USING gin(to_tsvector('english', analysis->>'error_type'))
                """)
                db.execute("""
                    CREATE INDEX IF NOT EXISTS idx_crash_root_cause_pattern
                    ON crash_analysis USING gin(to_tsvector('english', analysis->>'root_cause'))
                """)
                st.success("✅ Database initialized successfully!")
            except Exception as e:
                st.error(f"Error: {str(e)}")

if __name__ == "__main__":
    show()

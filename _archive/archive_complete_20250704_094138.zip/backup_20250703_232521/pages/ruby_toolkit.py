"""
Consolidated Ruby Toolkit for TuoKit
Combines all Ruby development functionality into a unified interface
"""

import streamlit as st
from utils.ollama import OllamaToolBase
from utils.database import DatabaseManager
import re
import random

class UnifiedRubyToolkit(OllamaToolBase):
    """Comprehensive Ruby development toolkit combining all Ruby tools"""
    
    def __init__(self):
        super().__init__(
            tool_name="ruby_toolkit",
            default_model=st.session_state.get("selected_model", "deepseek-coder:6.7b")
        )
        self.coder_model = "deepseek-coder:6.7b"
        self.reasoning_model = "deepseek-r1:latest"
        
        # Common memory antipatterns
        self.memory_antipatterns = {
            "String Duplication": r"(\+=|<<)\s*['\"]",
            "Unbounded Growth": r"(@@|\$)[a-z]+\s*(\+|\-|\*|\/)\s*=",
            "N+1 Caching": r"Rails\.cache\.fetch[^{]*\{[^}]*\.each",
            "Leaky Constants": r"([A-Z][A-Z0-9_]+)\s*=\s*\[|\{",
            "Large Object Creation": r"\.times\s*\{.*new|\.map\s*\{.*new",
            "Memory Bloat": r"@\w+\s*<<.*\*\s*\d{3,}"
        }
        
        # Concurrency issue patterns
        self.concurrency_patterns = {
            "class_vars": (r'@@\w+', "Class variables detected - potential race condition"),
            "global_vars": (r'\$\w+', "Global variables detected - thread safety risk"),
            "instance_mutation": (r'@\w+\s*\+=|@\w+\s*<<', "Mutable instance variable modification - consider mutex")
        }
        
        # Kata configuration
        self.kata_topics = {
            "Algorithms": ["Sorting", "Searching", "Dynamic Programming", "Recursion"],
            "OOP": ["Inheritance", "Composition", "SOLID", "Design Patterns"],
            "Metaprogramming": ["define_method", "method_missing", "Class Macros", "DSLs"],
            "Functional": ["Blocks", "Procs", "Lambdas", "Enumerables"],
            "Rails Patterns": ["Scopes", "Callbacks", "Concerns", "Service Objects"],
            "Testing": ["Unit Tests", "Mocks", "Integration", "TDD"],
            "Data Structures": ["Arrays", "Hashes", "Trees", "Graphs"],
            "Refactoring": ["Extract Method", "Replace Conditional", "Simplify", "DRY"]
        }
    
    # Performance Profiling
    def analyze_performance(self, code: str) -> dict:
        """Comprehensive performance analysis with optimization suggestions"""
        # Complexity analysis
        complexity_prompt = f"""Analyze computational complexity:
```ruby
{code}
```

Identify time/space complexity (Big O), highlight bottlenecks, and suggest algorithmic improvements"""
        
        complexity_report = self.generate_with_logging(
            prompt=complexity_prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a performance expert. Analyze code complexity thoroughly."
        )
        
        # Optimization suggestions
        optimization_prompt = f"""Optimize performance of:
```ruby
{code}
```

Apply: Lazy loading, memoization, database batching, algorithmic improvements. Preserve functionality."""
        
        optimized_code = self.generate_with_logging(
            prompt=optimization_prompt,
            temperature=0.1,
            system="You are a Ruby optimization expert. Generate optimized code."
        )
        
        # Memory analysis
        memory_prompt = f"""Analyze memory usage:
```ruby
{code}
```

Identify object allocation hotspots, memory retention issues, and GC pressure points"""
        
        memory_report = self.generate_with_logging(
            prompt=memory_prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a memory optimization expert. Analyze memory usage patterns."
        )
        
        return {
            "complexity": complexity_report["response"],
            "optimized": optimized_code["response"],
            "memory": memory_report["response"],
            "error": complexity_report["error"] or optimized_code["error"] or memory_report["error"]
        }
    
    def estimate_complexity(self, code: str) -> str:
        """Quick complexity estimation using heuristics"""
        decisions = len(re.findall(r'\b(if|unless|case|while|until|for|&&|\|\|)\b', code))
        loops = len(re.findall(r'\b(each|map|select|reduce|times)\b', code))
        nested_blocks = len(re.findall(r'\bdo\b|\{', code))
        
        score = decisions + (loops * 2) + (nested_blocks * 3)
        
        if score < 10: return "O(1) - Constant"
        elif score < 30: return "O(n) - Linear"
        elif score < 60: return "O(n log n) - Log-linear"
        elif score < 100: return "O(n²) - Quadratic"
        return "O(n!) - Factorial (dangerous)"
    
    # Memory Optimization
    def analyze_memory(self, code: str) -> dict:
        """Comprehensive memory analysis with optimization suggestions"""
        report_prompt = f"""Analyze memory usage in:
```ruby
{code}
```

Identify:
- Object allocation hotspots
- Memory retention issues
- GC pressure points
- Potential memory leaks
Suggest specific optimizations with estimated impact"""
        
        report = self.generate_with_logging(
            prompt=report_prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a memory analysis expert. Provide detailed memory usage analysis."
        )
        
        optimize_prompt = f"""Optimize memory usage for:
```ruby
{code}
```

Apply:
- Lazy loading
- Object pooling
- Memory-efficient data structures
- String freezing
- GC tuning
Preserve functionality while reducing memory footprint"""
        
        optimized = self.generate_with_logging(
            prompt=optimize_prompt,
            temperature=0.1,
            system="You are a memory optimization expert. Generate memory-efficient code."
        )
        
        return {
            "report": report["response"],
            "optimized": optimized["response"],
            "error": report["error"] or optimized["error"]
        }
    
    def detect_memory_antipatterns(self, code: str) -> list:
        """Quick detection of common memory issues"""
        found = []
        for name, pattern in self.memory_antipatterns.items():
            if re.search(pattern, code, re.IGNORECASE):
                found.append(name)
        return found
    
    # Pattern Matching
    def explain_pattern_matching(self, code: str) -> dict:
        """Explain pattern matching with real-world examples"""
        prompt = f"""Explain pattern matching in:
```ruby
{code}
```

Provide 3 sections:
1. Pattern Deconstruction: How values are matched
2. Real-World Use Cases: Practical applications
3. Alternative Approaches: Equivalent non-pattern matching code
Use Ruby 3.1+ syntax with examples"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a Ruby pattern matching expert. Explain patterns clearly."
        )
        
        return {"explanation": result["response"], "error": result["error"]}
    
    def generate_pattern_example(self, description: str, complexity: str = "Intermediate",
                               pattern_types: list = None) -> dict:
        """Generate pattern matching examples"""
        pattern_types = pattern_types or ["Hash Patterns"]
        
        prompt = f"""Create pattern matching example for: {description}
Complexity: {complexity}
Pattern Types: {', '.join(pattern_types)}

Output working Ruby code with:
- Multiple case/in scenarios
- Variable binding
- Guard clauses
- Nested patterns
Include comments explaining each pattern"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            temperature=0.1,
            system="You are a Ruby expert. Generate clear pattern matching examples."
        )
        
        return {"code": result["response"], "error": result["error"]}
    
    # C Extensions
    def create_c_extension(self, description: str, memory_model: str = "TypedData",
                          thread_safe: bool = False, features: list = None) -> dict:
        """Generate safe Ruby C extension"""
        features = features or ["GC Marking", "Type Checking"]
        
        config = {
            "memory": memory_model,
            "thread_safe": thread_safe,
            "features": features
        }
        
        prompt = f"""Create C extension for: {description}
Config: {config}

Output complete implementation:
- extconf.rb
- C source file
- Ruby binding code
- Safety precautions
- Rakefile tasks
Include memory management and error handling"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            temperature=0.1,
            system="You are a C extension expert. Generate safe, performant native code."
        )
        
        return {"code": result["response"], "error": result["error"]}
    
    def generate_extension_benchmarks(self, description: str) -> dict:
        """Generate performance benchmarks for the extension"""
        prompt = f"""Generate benchmarks comparing Ruby vs C extension for: {description}

Use benchmark-ips to show performance improvement"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            temperature=0.1,
            system="You are a benchmarking expert. Generate comprehensive performance tests."
        )
        
        return {"benchmarks": result["response"], "error": result["error"]}
    
    # Ractors and Concurrency
    def generate_ractor_implementation(self, task: str, worker_count: int = 4,
                                     comms_model: str = "Message Passing",
                                     fault_tolerance: bool = True) -> dict:
        """Generate thread-safe Ractor implementation"""
        full_task = f"{task} | Workers: {worker_count} | Communication: {comms_model}"
        if fault_tolerance:
            full_task += " | With fault tolerance"
            
        prompt = f"""Implement Ractors for: {full_task}

Create complete solution with:
- Ractor initialization
- Message passing
- Error handling
- Resource sharing precautions
- Performance considerations
Use Ruby 3.1+ with comments explaining concurrency model"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            temperature=0.1,
            system="You are a concurrency expert. Generate robust Ractor implementations."
        )
        
        return {"code": result["response"], "error": result["error"]}
    
    def analyze_concurrency(self, code: str) -> dict:
        """Provide concurrency optimization advice"""
        prompt = f"""Optimize concurrency for:
```ruby
{code}
```

Suggest:
1. Where to use Ractors vs Threads
2. Thread safety improvements
3. Shared resource management
4. Alternative approaches (Fibers, Async)"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a concurrency expert. Provide practical optimization advice."
        )
        
        return {"advice": result["response"], "error": result["error"]}
    
    def detect_concurrency_issues(self, code: str) -> list:
        """Quick check for potential thread safety issues"""
        issues = []
        for name, (pattern, message) in self.concurrency_patterns.items():
            if re.search(pattern, code):
                issues.append(message)
        return issues
    
    # Katas and Training
    def generate_kata(self, level: str, topic: str, focus_area: str = None) -> dict:
        """Generate coding kata with tests"""
        kata_prompt = f"""Create {level} kata about {topic}""" + (f" focusing on {focus_area}" if focus_area else "")
        kata_prompt += """

Structure:
1. Problem Statement: Clear description
2. Requirements: Input/output specs
3. Examples: Test cases
4. Starter Code: With missing implementation
5. Tests: RSpec/minitest
Make it engaging and educational"""
        
        kata_result = self.generate_with_logging(
            prompt=kata_prompt,
            model=self.reasoning_model,
            temperature=0.3,
            system="You are a programming educator. Create engaging coding challenges."
        )
        
        if kata_result["error"]:
            return {"error": kata_result["error"]}
        
        # Generate solution
        solution_prompt = f"""Solution for kata: {kata_result['response']}

Implement solution with comments explaining approach and complexity"""
        
        solution_result = self.generate_with_logging(
            prompt=solution_prompt,
            temperature=0.1,
            system="You are a Ruby expert. Provide clear, idiomatic solutions."
        )
        
        # Generate hints
        hints_prompt = f"""Generate 3 progressive hints for kata: {kata_result['response']}

Hints should guide without revealing solution"""
        
        hints_result = self.generate_with_logging(
            prompt=hints_prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are an educator. Provide helpful hints without spoilers."
        )
        
        return {
            "kata": kata_result["response"],
            "solution": solution_result["response"],
            "hints": hints_result["response"].split('\n'),
            "error": kata_result["error"] or solution_result["error"] or hints_result["error"]
        }
    
    def analyze_kata_solution(self, kata: str, user_code: str) -> dict:
        """Analyze user's solution"""
        prompt = f"""Analyze this solution:
Kata: {kata}
Solution: {user_code}

Evaluate correctness, efficiency, style, and suggest improvements"""
        
        result = self.generate_with_logging(
            prompt=prompt,
            model=self.reasoning_model,
            temperature=0.2,
            system="You are a code reviewer. Provide constructive feedback."
        )
        
        return {"analysis": result["response"], "error": result["error"]}

def render_performance_profiler(toolkit):
    """Render Performance Profiler interface"""
    st.subheader("⚡ Ruby Performance Profiler")
    
    code = st.text_area("Paste Ruby Code", 
        height=300,
        placeholder="def process_data\n  Data.all.each do |d|\n    # ...\n  end\nend")
    
    # Quick analysis
    if st.button("Quick Analysis", type="secondary") and code:
        complexity = toolkit.estimate_complexity(code)
        st.metric("Estimated Complexity", complexity)
        
        if "Quadratic" in complexity or "Factorial" in complexity:
            st.warning("⚠️ Potential performance issues detected!")
    
    # Full analysis
    if st.button("Run Full Analysis", type="primary") and code:
        with st.spinner("Profiling code..."):
            result = toolkit.analyze_performance(code)
            
            if not result["error"]:
                tab1, tab2, tab3 = st.tabs(["Complexity Report", "Optimized Code", "Memory Analysis"])
                
                with tab1:
                    st.subheader("Performance Analysis")
                    st.markdown(result["complexity"])
                    
                with tab2:
                    st.subheader("Optimized Implementation")
                    st.code(result["optimized"], language="ruby")
                    st.download_button("📥 Download Optimized Code", 
                                     result["optimized"], "optimized.rb")
                    
                with tab3:
                    st.subheader("Memory Usage Report")
                    st.markdown(result["memory"])
                
                # Performance patterns
                with st.expander("🚀 Ruby Performance Patterns"):
                    st.markdown("""
                    **Common Optimizations:**
                    - N+1 Queries → Eager Loading
                    - Loop Inefficiencies → Map/Reduce
                    - Memory Bloat → Lazy Evaluation
                    - Algorithmic Bottlenecks → Better Data Structures
                    
                    **Tools:**
                    - `benchmark-ips` for microbenchmarks
                    - `memory_profiler` for memory analysis
                    - `stackprof` for flamegraphs
                    """)

def render_memory_optimizer(toolkit):
    """Render Memory Optimizer interface"""
    st.subheader("🧠 Ruby Memory Optimizer")
    
    code = st.text_area("Paste Ruby Code", 
        height=300,
        placeholder="def process_data\n  data = []; 10000.times { data << 'x' * 1024 }\nend")
    
    # Quick scan
    if st.button("Quick Scan", type="secondary") and code:
        antipatterns = toolkit.detect_memory_antipatterns(code)
        if antipatterns:
            st.warning("⚠️ Potential issues detected:")
            for pattern in antipatterns:
                st.caption(f"• {pattern}")
        else:
            st.success("✅ No common antipatterns detected")
    
    # Full optimization
    if st.button("Optimize Memory", type="primary") and code:
        with st.spinner("Analyzing memory usage..."):
            result = toolkit.analyze_memory(code)
            
            if not result["error"]:
                tab1, tab2, tab3 = st.tabs(["Analysis Report", "Optimized Code", "Best Practices"])
                
                with tab1:
                    st.subheader("Memory Usage Analysis")
                    st.markdown(result["report"])
                    
                with tab2:
                    st.subheader("Optimized Implementation")
                    st.code(result["optimized"], language="ruby")
                    st.download_button("📥 Download Optimized Code", 
                                     result["optimized"], "memory_optimized.rb")
                    
                with tab3:
                    st.markdown("""
                    **Memory Optimization Checklist:**
                    
                    ✅ **String Optimization**
                    - Use `String#freeze` for constants
                    - Prefer `<<` over `+=` for concatenation
                    - Use symbols for hash keys
                    
                    ✅ **Collection Management**
                    - Use `lazy` enumerators for large datasets
                    - Clear collections when done: `array.clear`
                    - Consider `Set` instead of `Array` for uniqueness
                    
                    ✅ **Object Pooling**
                    - Reuse objects instead of creating new ones
                    - Use connection pools for database/Redis
                    - Implement object factories with pooling
                    
                    ✅ **GC Tuning**
                    ```bash
                    export RUBY_GC_HEAP_GROWTH_FACTOR=1.1
                    export RUBY_GC_MALLOC_LIMIT=90000000
                    export RUBY_GC_OLDMALLOC_LIMIT=90000000
                    ```
                    """)

def render_pattern_matching(toolkit):
    """Render Pattern Matching Explorer interface"""
    st.subheader("🎯 Ruby Pattern Matching Explorer")
    
    analysis_type = st.radio("Explore Pattern Matching", 
        ["Analyze Existing Code", "Generate New Example"])
    
    if analysis_type == "Analyze Existing Code":
        code = st.text_area("Paste Ruby Code with Pattern Matching", 
            height=250,
            placeholder="case user\nin {name:, age: 18..}\n  # ...\nend")
        
        if st.button("Analyze Pattern", type="primary") and code:
            with st.spinner("Deconstructing patterns..."):
                result = toolkit.explain_pattern_matching(code)
                
                if not result["error"]:
                    st.subheader("Pattern Matching Breakdown")
                    st.markdown(result["explanation"])
                    
                    # Pattern matching concepts
                    with st.expander("🧩 Pattern Matching Fundamentals"):
                        st.markdown("""
                        **Key Features:**
                        - Value Deconstruction: `in [a, b, c]`
                        - Variable Binding: `in {name: n}`
                        - Guard Clauses: `in [x, y] if x > y`
                        - As Patterns: `in [x, y] => point`
                        - Alternative Patterns: `in 0 | 1 | 2`
                        
                        **Pattern Types:**
                        - **Array Patterns**: Match array structure and values
                        - **Hash Patterns**: Extract specific keys
                        - **Object Patterns**: Match by class and attributes
                        - **Find Patterns**: `in [*, x, *]` to find elements
                        """)
    
    else:
        description = st.text_input("Describe Use Case", 
            placeholder="e.g., Process API responses, handle different error types")
        complexity = st.select_slider("Complexity Level", ["Simple", "Intermediate", "Advanced"])
        
        pattern_types = st.multiselect("Include Pattern Types",
            ["Array Patterns", "Hash Patterns", "Object Patterns", 
             "Guard Clauses", "Alternative Patterns"],
            default=["Hash Patterns"])
        
        if st.button("Generate Example", type="primary") and description:
            with st.spinner("Creating pattern matching example..."):
                result = toolkit.generate_pattern_example(description, complexity, pattern_types)
                
                if not result["error"]:
                    st.subheader("Pattern Matching Implementation")
                    st.code(result["code"], language="ruby")
                    st.download_button("📥 Download Example", result["code"], "pattern_matching.rb")

def render_c_extensions(toolkit):
    """Render C Extension Assistant interface"""
    st.subheader("🛠️ Ruby C Extension Assistant")
    
    description = st.text_area("Describe Native Functionality", 
        height=150,
        placeholder="e.g., Fast matrix multiplication, image processing, cryptographic operations")
    
    # Configuration
    with st.expander("Extension Configuration"):
        col1, col2 = st.columns(2)
        with col1:
            memory_model = st.radio("Memory Management", ["Manual", "TypedData (Recommended)"])
            thread_safety = st.toggle("Thread-Safe Implementation", False)
        with col2:
            features = st.multiselect("Include Features",
                ["GC Marking", "Object Allocation", "Type Checking", 
                 "Debugging Support", "Profiling Hooks"],
                default=["GC Marking", "Type Checking"])
    
    if st.button("Generate Extension", type="primary") and description:
        with st.spinner("Compiling native bridge..."):
            result = toolkit.create_c_extension(
                description,
                memory_model=memory_model,
                thread_safe=thread_safety,
                features=features
            )
            
            if not result["error"]:
                st.success("✅ C Extension generated successfully!")
                
                tab1, tab2, tab3 = st.tabs(["C Source", "Benchmarks", "Documentation"])
                
                with tab1:
                    st.code(result["code"], language="c")
                    st.download_button("📥 Download extension.c", result["code"], "extension.c")
                
                with tab2:
                    benchmark_result = toolkit.generate_extension_benchmarks(description)
                    if not benchmark_result["error"]:
                        st.code(benchmark_result["benchmarks"], language="ruby")
                    
                    # Expected performance
                    st.info("Typical C extension performance improvements:")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Numeric Operations", "10-100x faster")
                    with col2:
                        st.metric("String Processing", "5-50x faster")
                    with col3:
                        st.metric("Memory Usage", "50-90% less")
                
                with tab3:
                    st.markdown("""
                    ### Build & Installation
                    
                    **1. Compile the extension:**
                    ```bash
                    ruby extconf.rb
                    make
                    ```
                    
                    **2. Run tests:**
                    ```bash
                    ruby -Ilib:test test_extension.rb
                    ```
                    
                    **3. Install:**
                    ```bash
                    rake install
                    ```
                    
                    ### Debugging
                    
                    **GDB debugging:**
                    ```bash
                    gdb ruby
                    (gdb) run -Ilib script.rb
                    ```
                    
                    **Valgrind memory check:**
                    ```bash
                    valgrind --leak-check=full ruby script.rb
                    ```
                    """)

def render_concurrency_advisor(toolkit):
    """Render Concurrency Advisor interface"""
    st.subheader("⚡ Ruby Concurrency Advisor")
    
    task_type = st.radio("Task Type", 
        ["Generate New Implementation", "Optimize Existing Code"])
    
    if task_type == "Generate New Implementation":
        task = st.text_area("Describe Parallel Task", 
            height=150,
            placeholder="e.g., Process 10,000 images in parallel")
        
        # Concurrency options
        col1, col2 = st.columns(2)
        with col1:
            worker_count = st.slider("Worker Count", 1, 16, 4)
            comms_model = st.radio("Communication", ["Message Passing", "Shared Channel"])
        with col2:
            fault_tolerance = st.toggle("Fault Tolerance", True)
        
        if st.button("Generate Ractor Code", type="primary") and task:
            with st.spinner("Building parallel solution..."):
                result = toolkit.generate_ractor_implementation(
                    task,
                    worker_count=worker_count,
                    comms_model=comms_model,
                    fault_tolerance=fault_tolerance
                )
                
                if not result["error"]:
                    st.subheader("Concurrent Implementation")
                    st.code(result["code"], language="ruby")
                    st.download_button("📥 Download Ractor Code", result["code"], "ractor_impl.rb")
                    
                    # Performance estimate
                    st.metric("Estimated Speedup", f"~{worker_count * 0.8:.1f}x", "vs sequential")
                    st.caption("Actual speedup depends on task parallelizability")
                    
                    # Concurrency concepts
                    with st.expander("🧠 Ractor Fundamentals"):
                        st.markdown("""
                        **Ractor Model:**
                        - Actor-based concurrency
                        - Isolated object spaces
                        - Copy/Move semantics for messages
                        - No GVL (Global VM Lock) contention
                        
                        **Best Practices:**
                        - Use for CPU-bound tasks
                        - Avoid sharing mutable state
                        - Prefer message passing over shared memory
                        - Handle Ractor::RemoteError exceptions
                        """)
    
    else:
        code = st.text_area("Paste Ruby Code", 
            height=300,
            placeholder="def process_data\n  # ...\nend")
        
        if code:
            # Quick safety check
            issues = toolkit.detect_concurrency_issues(code)
            if issues:
                st.warning("Potential concurrency issues detected:")
                for issue in issues:
                    st.caption(f"⚠️ {issue}")
        
        if st.button("Optimize Concurrency", type="primary") and code:
            with st.spinner("Analyzing concurrency..."):
                result = toolkit.analyze_concurrency(code)
                
                if not result["error"]:
                    st.subheader("Concurrency Recommendations")
                    st.markdown(result["advice"])

def render_kata_trainer(toolkit):
    """Render Kata Trainer interface"""
    st.subheader("🥋 Ruby Kata Trainer")
    
    # Initialize session state for kata tracking
    if 'completed_katas' not in st.session_state:
        st.session_state.completed_katas = 0
    if 'current_kata' not in st.session_state:
        st.session_state.current_kata = None
    if 'show_solution' not in st.session_state:
        st.session_state.show_solution = False
    if 'hints_shown' not in st.session_state:
        st.session_state.hints_shown = 0
    
    # Kata configuration
    col1, col2, col3 = st.columns(3)
    with col1:
        level = st.selectbox("Difficulty", ["Beginner", "Intermediate", "Advanced"])
    with col2:
        topic = st.selectbox("Topic", list(toolkit.kata_topics.keys()))
    with col3:
        focus_area = st.selectbox("Focus Area", toolkit.kata_topics.get(topic, ["General"]))
    
    # Generate kata
    if st.button("🎲 Generate New Challenge", type="primary"):
        st.session_state.show_solution = False
        st.session_state.hints_shown = 0
        with st.spinner("Creating kata..."):
            result = toolkit.generate_kata(level, topic, focus_area)
            
            if not result["error"]:
                st.session_state.current_kata = {
                    'kata': result['kata'],
                    'solution': result['solution'],
                    'hints': result['hints'],
                    'level': level,
                    'topic': topic
                }
    
    # Display current kata
    if st.session_state.current_kata:
        kata_data = st.session_state.current_kata
        
        # Kata header
        st.subheader(f"{kata_data['level']} {kata_data['topic']} Challenge")
        
        # Difficulty indicators
        difficulty_stars = {"Beginner": "⭐", "Intermediate": "⭐⭐", "Advanced": "⭐⭐⭐"}
        st.markdown(f"**Difficulty:** {difficulty_stars[kata_data['level']]}")
        
        # Display kata
        st.markdown(kata_data['kata'])
        
        # Hints system
        if st.session_state.hints_shown < len(kata_data['hints']):
            if st.button(f"💡 Show Hint ({st.session_state.hints_shown + 1}/{len(kata_data['hints'])})"):
                st.session_state.hints_shown += 1
        
        if st.session_state.hints_shown > 0:
            with st.expander("💡 Hints", expanded=True):
                for i in range(st.session_state.hints_shown):
                    st.info(f"Hint {i+1}: {kata_data['hints'][i]}")
        
        # Practice area
        st.subheader("Your Implementation")
        user_code = st.text_area("Write your solution here:", 
            height=400,
            help="Write your Ruby code to solve the kata")
        
        # Action buttons
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🧪 Analyze Solution", type="primary", disabled=not user_code):
                with st.spinner("Analyzing your code..."):
                    analysis_result = toolkit.analyze_kata_solution(kata_data['kata'], user_code)
                    
                    if not analysis_result["error"]:
                        st.subheader("Code Analysis")
                        st.markdown(analysis_result["analysis"])
                        
                        # Mark as completed if solution is correct
                        if "correct" in analysis_result["analysis"].lower() or "works" in analysis_result["analysis"].lower():
                            st.success("✅ Well done! Challenge completed!")
                            st.session_state.completed_katas += 1
        
        with col2:
            if st.button("👁️ Show Solution"):
                st.session_state.show_solution = not st.session_state.show_solution
        
        with col3:
            st.metric("Katas Completed", st.session_state.completed_katas)
        
        # Solution display
        if st.session_state.show_solution:
            with st.expander("🎯 Solution", expanded=True):
                st.code(kata_data['solution'], language="ruby")

def show():
    """Main page display function"""
    st.title("💎 Unified Ruby Toolkit")
    st.markdown("Comprehensive Ruby development suite with all tools in one place")
    
    # Initialize toolkit
    toolkit = UnifiedRubyToolkit()
    db = DatabaseManager()
    
    # Tool selection
    tool_category = st.selectbox("Select Tool", [
        "Performance Profiler",
        "Memory Optimizer",
        "Pattern Matching Explorer",
        "C Extension Assistant",
        "Concurrency Advisor",
        "Kata Trainer"
    ])
    
    st.divider()
    
    # Render selected tool
    if tool_category == "Performance Profiler":
        render_performance_profiler(toolkit)
    elif tool_category == "Memory Optimizer":
        render_memory_optimizer(toolkit)
    elif tool_category == "Pattern Matching Explorer":
        render_pattern_matching(toolkit)
    elif tool_category == "C Extension Assistant":
        render_c_extensions(toolkit)
    elif tool_category == "Concurrency Advisor":
        render_concurrency_advisor(toolkit)
    elif tool_category == "Kata Trainer":
        render_kata_trainer(toolkit)
    
    # Ruby Resources
    with st.sidebar:
        st.divider()
        st.subheader("📚 Ruby Resources")
        
        st.markdown("""
        **Official Documentation**
        - [Ruby Docs](https://ruby-doc.org/)
        - [Ruby API](https://rubyapi.org/)
        - [Ruby Style Guide](https://rubystyle.guide/)
        
        **Learning Resources**
        - [Ruby Koans](http://rubykoans.com/)
        - [Exercism Ruby](https://exercism.org/tracks/ruby)
        - [Ruby Tapas](https://www.rubytapas.com/)
        
        **Performance Tools**
        - [ruby-prof](https://github.com/ruby-prof/ruby-prof)
        - [memory_profiler](https://github.com/SamSaffron/memory_profiler)
        - [stackprof](https://github.com/tmm1/stackprof)
        
        **Concurrency**
        - [Ractor Guide](https://docs.ruby-lang.org/en/master/Ractor.html)
        - [Async Ruby](https://github.com/socketry/async)
        - [concurrent-ruby](https://github.com/ruby-concurrency/concurrent-ruby)
        """)
        
        st.divider()
        
        # Progress tracking
        if 'completed_katas' in st.session_state:
            st.subheader("📊 Your Progress")
            st.metric("Katas Completed", st.session_state.completed_katas)
            st.progress(min(st.session_state.completed_katas / 10, 1.0))
            if st.session_state.completed_katas >= 10:
                st.balloons()
                st.success("🎉 Ruby Master!")

# Entry point
if __name__ == "__main__":
    show()
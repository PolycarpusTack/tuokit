-- =====================================================
-- TuoKit Unified Database Setup Script
-- Version: 1.0.0
-- Description: Complete database setup with all migrations
-- =====================================================

-- Note: Run this as PostgreSQL superuser first to create the database and user
-- Then run the rest as the tuokit_user

-- =====================================================
-- PART 1: DATABASE AND USER SETUP (Run as superuser)
-- =====================================================

-- Note: Database and user creation should be done separately or via the Python script
-- This script assumes you're already connected to the tuokit_knowledge database

-- If running manually, first create database and user:
-- CREATE DATABASE tuokit_knowledge;
-- CREATE USER tuokit_user WITH PASSWORD 'your_secure_password';
-- GRANT ALL PRIVILEGES ON DATABASE tuokit_knowledge TO tuokit_user;
-- Then connect: \c tuokit_knowledge

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE tuokit_knowledge TO tuokit_user;
GRANT ALL PRIVILEGES ON SCHEMA public TO tuokit_user;

-- =====================================================
-- PART 2: CORE TABLES (From database_setup.sql)
-- =====================================================

-- Create queries table (core functionality)
CREATE TABLE IF NOT EXISTS queries (
    id SERIAL PRIMARY KEY,
    tool VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    user_prompt TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    metadata JSONB,
    complexity VARCHAR(50),  -- Added from ruby_tools migration
    category VARCHAR(50),    -- Added from ruby_tools migration
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create knowledge units table
CREATE TABLE IF NOT EXISTS knowledge_units (
    id SERIAL PRIMARY KEY,
    query_id INTEGER REFERENCES queries(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    tags TEXT[],  -- Added from setup_database.sql
    verified BOOLEAN DEFAULT FALSE,  -- From migration_v0.4.sql
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- PART 3: KNOWLEDGE COLLECTIONS (From knowledge_graph migration)
-- =====================================================

-- Create knowledge collections table
CREATE TABLE IF NOT EXISTS knowledge_collections (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert knowledge graph collection
INSERT INTO knowledge_collections (name, description)
VALUES ('knowledge_graph', 'SQL concepts and their relationships for educational features')
ON CONFLICT (name) DO NOTHING;

-- =====================================================
-- PART 4: AGENT SYSTEM TABLES (From agents migration)
-- =====================================================

-- Agent execution history
CREATE TABLE IF NOT EXISTS agent_executions (
    id BIGSERIAL PRIMARY KEY,
    goal TEXT NOT NULL,
    agent_name VARCHAR(64) NOT NULL,
    agent_type VARCHAR(32) NOT NULL, -- specialist, team, meta
    state_json JSONB NOT NULL, -- Complete AgentState serialized
    start_time TIMESTAMPTZ DEFAULT NOW(),
    end_time TIMESTAMPTZ,
    phase VARCHAR(32) NOT NULL, -- planning, execution, validation
    success BOOLEAN DEFAULT FALSE,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent performance metrics
CREATE TABLE IF NOT EXISTS agent_metrics (
    id BIGSERIAL PRIMARY KEY,
    agent_name VARCHAR(64) NOT NULL,
    execution_id BIGINT REFERENCES agent_executions(id),
    metric_name VARCHAR(64) NOT NULL,
    metric_value DECIMAL,
    measured_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agent collaboration records
CREATE TABLE IF NOT EXISTS agent_collaborations (
    id BIGSERIAL PRIMARY KEY,
    team_name VARCHAR(64) NOT NULL,
    execution_id BIGINT REFERENCES agent_executions(id),
    member_agent VARCHAR(64) NOT NULL,
    subtask TEXT NOT NULL,
    dependency_agents TEXT[], -- Array of agent names
    result_summary TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- PART 5: LITE AGENT PIPELINE TABLES (From lite_agents migration)
-- =====================================================

-- Pipeline storage table
CREATE TABLE IF NOT EXISTS pipelines (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    steps JSONB NOT NULL,
    results JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    created_by VARCHAR(100),
    execution_time_ms INTEGER,
    success BOOLEAN DEFAULT TRUE
);

-- Educational guidance history
CREATE TABLE IF NOT EXISTS educational_guidance (
    id SERIAL PRIMARY KEY,
    context TEXT NOT NULL,
    user_action VARCHAR(100) NOT NULL,
    guidance JSONB NOT NULL,
    helpful BOOLEAN,  -- User feedback on guidance quality
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pipeline templates for common workflows
CREATE TABLE IF NOT EXISTS pipeline_templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    category VARCHAR(50),
    steps JSONB NOT NULL,
    usage_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- PART 6: RUBY PERFORMANCE TABLES (From ruby_tools migration)
-- =====================================================

-- Performance specific table
CREATE TABLE IF NOT EXISTS performance_findings (
    id SERIAL PRIMARY KEY,
    query_id INTEGER REFERENCES queries(id) ON DELETE CASCADE,
    issue_type VARCHAR(50) NOT NULL,
    severity SMALLINT CHECK (severity IN (1, 2, 3)), -- 1=low, 2=medium, 3=high
    solution TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Testing table
CREATE TABLE IF NOT EXISTS test_cases (
    id SERIAL PRIMARY KEY,
    feature TEXT NOT NULL,
    framework VARCHAR(20) NOT NULL,
    coverage FLOAT CHECK (coverage >= 0 AND coverage <= 100),
    test_code TEXT,
    generated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- PART 7: ADVANCED RUBY TABLES (From advanced_ruby migration)
-- =====================================================

-- GraphQL specific table
CREATE TABLE IF NOT EXISTS graphql_apis (
    id SERIAL PRIMARY KEY,
    resource VARCHAR(100) NOT NULL,
    operations VARCHAR(100)[],
    types VARCHAR(50)[],
    authentication_method VARCHAR(50),
    pagination_type VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Concurrency patterns table
CREATE TABLE IF NOT EXISTS concurrency_patterns (
    id SERIAL PRIMARY KEY,
    pattern VARCHAR(50) NOT NULL UNIQUE,
    use_case TEXT,
    example TEXT,
    performance_characteristics JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pattern matching examples table
CREATE TABLE IF NOT EXISTS pattern_matching_examples (
    id SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    pattern_type VARCHAR(50),
    complexity VARCHAR(20),
    code TEXT,
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ractor implementations table
CREATE TABLE IF NOT EXISTS ractor_implementations (
    id SERIAL PRIMARY KEY,
    task_description TEXT,
    worker_count INTEGER,
    communication_model VARCHAR(50),
    estimated_speedup FLOAT,
    code TEXT,
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- PART 8: PROFESSIONAL RUBY TABLES (From professional_ruby migration)
-- =====================================================

-- Memory optimization patterns table
CREATE TABLE IF NOT EXISTS memory_patterns (
    pattern VARCHAR(50) PRIMARY KEY,
    solution TEXT NOT NULL,
    severity SMALLINT CHECK (severity BETWEEN 1 AND 5),
    example TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Katas library table
CREATE TABLE IF NOT EXISTS katas (
    id SERIAL PRIMARY KEY,
    level VARCHAR(20) NOT NULL CHECK (level IN ('Beginner', 'Intermediate', 'Advanced')),
    topic VARCHAR(50) NOT NULL,
    focus_area VARCHAR(50),
    problem TEXT NOT NULL,
    solution TEXT,
    hints TEXT[],
    estimated_minutes INTEGER,
    difficulty_score SMALLINT CHECK (difficulty_score BETWEEN 1 AND 10),
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- View components library
CREATE TABLE IF NOT EXISTS view_components (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    template_language VARCHAR(20) CHECK (template_language IN ('ERB', 'HAML', 'SLIM')),
    javascript_framework VARCHAR(50),
    features VARCHAR(50)[],
    component_code TEXT,
    tests TEXT,
    stimulus_controller TEXT,
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Rails upgrade plans
CREATE TABLE IF NOT EXISTS rails_upgrades (
    id SERIAL PRIMARY KEY,
    from_version VARCHAR(10) NOT NULL,
    to_version VARCHAR(10) NOT NULL,
    project_size VARCHAR(50),
    upgrade_plan TEXT,
    estimated_days_min INTEGER,
    estimated_days_max INTEGER,
    risk_level VARCHAR(20) CHECK (risk_level IN ('Low', 'Medium', 'High')),
    critical_gems TEXT[],
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- C extensions registry
CREATE TABLE IF NOT EXISTS c_extensions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    memory_model VARCHAR(50),
    thread_safe BOOLEAN DEFAULT FALSE,
    source_code TEXT,
    extconf_rb TEXT,
    benchmarks TEXT,
    query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Kata completion tracking
CREATE TABLE IF NOT EXISTS kata_completions (
    id SERIAL PRIMARY KEY,
    kata_id INTEGER REFERENCES katas(id) ON DELETE CASCADE,
    user_solution TEXT,
    completion_time_seconds INTEGER,
    passed BOOLEAN DEFAULT FALSE,
    score INTEGER CHECK (score BETWEEN 0 AND 100),
    completed_at TIMESTAMPTZ DEFAULT NOW()
);

-- Component usage analytics
CREATE TABLE IF NOT EXISTS component_usage (
    id SERIAL PRIMARY KEY,
    component_id INTEGER REFERENCES view_components(id) ON DELETE CASCADE,
    usage_count INTEGER DEFAULT 1,
    last_used TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================
-- PART 9: CREATE ALL INDEXES
-- =====================================================

-- Core indexes
CREATE INDEX IF NOT EXISTS idx_queries_tool ON queries(tool);
CREATE INDEX IF NOT EXISTS idx_queries_created_at ON queries(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_queries_category ON queries(category);
CREATE INDEX IF NOT EXISTS idx_queries_complexity ON queries(complexity);
CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_units(category);
CREATE INDEX IF NOT EXISTS idx_knowledge_title ON knowledge_units(title);
CREATE INDEX IF NOT EXISTS idx_knowledge_units_tags ON knowledge_units USING GIN(tags);

-- Agent indexes
CREATE INDEX IF NOT EXISTS idx_agent_executions_agent_name ON agent_executions(agent_name);
CREATE INDEX IF NOT EXISTS idx_agent_executions_created_at ON agent_executions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_metrics_agent_name ON agent_metrics(agent_name);
CREATE INDEX IF NOT EXISTS idx_agent_collaborations_team ON agent_collaborations(team_name);

-- Pipeline indexes
CREATE INDEX IF NOT EXISTS idx_pipelines_created_at ON pipelines(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_pipelines_name ON pipelines(name);

-- Ruby tool indexes
CREATE INDEX IF NOT EXISTS idx_performance_findings_query_id ON performance_findings(query_id);
CREATE INDEX IF NOT EXISTS idx_performance_findings_issue_type ON performance_findings(issue_type);
CREATE INDEX IF NOT EXISTS idx_test_cases_framework ON test_cases(framework);

-- Advanced Ruby indexes
CREATE INDEX IF NOT EXISTS idx_graphql_apis_resource ON graphql_apis(resource);
CREATE INDEX IF NOT EXISTS idx_pattern_matching_complexity ON pattern_matching_examples(complexity);
CREATE INDEX IF NOT EXISTS idx_pattern_matching_type ON pattern_matching_examples(pattern_type);
CREATE INDEX IF NOT EXISTS idx_ractor_worker_count ON ractor_implementations(worker_count);
CREATE INDEX IF NOT EXISTS idx_concurrency_pattern ON concurrency_patterns(pattern);

-- Professional Ruby indexes
CREATE INDEX IF NOT EXISTS idx_katas_level_topic ON katas(level, topic);
CREATE INDEX IF NOT EXISTS idx_katas_focus_area ON katas(focus_area);
CREATE INDEX IF NOT EXISTS idx_view_components_name ON view_components(name);
CREATE INDEX IF NOT EXISTS idx_view_components_template ON view_components(template_language);
CREATE INDEX IF NOT EXISTS idx_rails_upgrades_versions ON rails_upgrades(from_version, to_version);
CREATE INDEX IF NOT EXISTS idx_c_extensions_name ON c_extensions(name);
CREATE INDEX IF NOT EXISTS idx_kata_completions_kata_id ON kata_completions(kata_id);
CREATE INDEX IF NOT EXISTS idx_memory_patterns_severity ON memory_patterns(severity);

-- =====================================================
-- PART 10: CREATE VIEWS
-- =====================================================

-- Recent activity view (from core)
CREATE OR REPLACE VIEW recent_activity AS
SELECT 
    q.id,
    q.tool,
    q.model,
    q.user_prompt,
    q.created_at,
    COUNT(k.id) as knowledge_count
FROM queries q
LEFT JOIN knowledge_units k ON q.id = k.query_id
GROUP BY q.id, q.tool, q.model, q.user_prompt, q.created_at
ORDER BY q.created_at DESC
LIMIT 50;

-- Agent success rates view
CREATE OR REPLACE VIEW agent_success_rates AS
SELECT 
    agent_name,
    agent_type,
    COUNT(*) as total_executions,
    SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful_executions,
    ROUND(AVG(CASE WHEN success THEN 1 ELSE 0 END) * 100, 2) as success_rate,
    AVG(EXTRACT(EPOCH FROM (end_time - start_time))) as avg_duration_seconds
FROM agent_executions
WHERE end_time IS NOT NULL
GROUP BY agent_name, agent_type;

-- Recent agent activity view
CREATE OR REPLACE VIEW recent_agent_activity AS
SELECT 
    ae.id,
    ae.goal,
    ae.agent_name,
    ae.phase,
    ae.success,
    ae.created_at,
    COUNT(ac.id) as collaboration_count
FROM agent_executions ae
LEFT JOIN agent_collaborations ac ON ae.id = ac.execution_id
GROUP BY ae.id, ae.goal, ae.agent_name, ae.phase, ae.success, ae.created_at
ORDER BY ae.created_at DESC
LIMIT 20;

-- Pipeline analytics view
CREATE OR REPLACE VIEW pipeline_analytics AS
SELECT 
    DATE_TRUNC('day', created_at) as day,
    COUNT(*) as pipeline_runs,
    AVG(execution_time_ms) as avg_execution_time_ms,
    SUM(CASE WHEN success THEN 1 ELSE 0 END) as successful_runs,
    ROUND(AVG(CASE WHEN success THEN 1 ELSE 0 END) * 100, 2) as success_rate
FROM pipelines
GROUP BY DATE_TRUNC('day', created_at)
ORDER BY day DESC;

-- Popular tools view
CREATE OR REPLACE VIEW popular_tools AS
SELECT 
    tool,
    COUNT(*) as usage_count,
    ROUND(AVG(CASE WHEN success THEN 1 ELSE 0 END) * 100, 2) as success_rate
FROM (
    SELECT 
        jsonb_array_elements(steps)->>'tool' as tool,
        success
    FROM pipelines
) tool_usage
WHERE tool IS NOT NULL
GROUP BY tool
ORDER BY usage_count DESC;

-- =====================================================
-- PART 11: INSERT DEFAULT DATA
-- =====================================================

-- Insert default concurrency patterns
INSERT INTO concurrency_patterns (pattern, use_case, performance_characteristics) VALUES
('Ractor', 'CPU-bound parallel processing without shared state', '{"gvl_free": true, "memory": "isolated", "overhead": "high"}'::jsonb),
('Thread Pool', 'I/O-bound concurrent operations', '{"gvl_free": false, "memory": "shared", "overhead": "medium"}'::jsonb),
('Fiber', 'Lightweight cooperative multitasking', '{"gvl_free": false, "memory": "shared", "overhead": "low"}'::jsonb),
('Async', 'Non-blocking I/O operations', '{"gvl_free": false, "memory": "shared", "overhead": "low"}'::jsonb),
('Process', 'Complete isolation with high overhead', '{"gvl_free": true, "memory": "isolated", "overhead": "highest"}'::jsonb)
ON CONFLICT (pattern) DO NOTHING;

-- Insert default memory patterns
INSERT INTO memory_patterns (pattern, solution, severity, example) VALUES
('String Duplication', 'Use << instead of += for string concatenation', 3, 'str += ''text'' → str << ''text'''),
('Unbounded Growth', 'Implement pagination or lazy loading', 4, 'Limit array size or use lazy enumerators'),
('N+1 Caching', 'Cache entire collections instead of individual elements', 2, 'Cache the full result set'),
('Leaky Constants', 'Use class methods instead of top-level constants', 3, 'CACHE = [] → def self.cache; @cache ||= []; end'),
('Frozen String Missing', 'Add # frozen_string_literal: true', 1, 'Reduces string allocation overhead')
ON CONFLICT (pattern) DO NOTHING;

-- Insert pipeline templates
INSERT INTO pipeline_templates (name, description, category, steps) VALUES
(
    'Data Analysis Workflow',
    'Extract data from database, clean it, and generate summary',
    'analytics',
    '[
        {
            "name": "Extract Customer Data",
            "tool": "sql_generator",
            "params": {
                "query": "Get all customer orders from the last 30 days with product details",
                "dialect": "PostgreSQL"
            }
        },
        {
            "name": "Clean Email Addresses",
            "tool": "regex_generator",
            "params": {
                "description": "Extract and validate email addresses from customer data"
            }
        },
        {
            "name": "Generate Report",
            "tool": "doc_summarizer",
            "params": {
                "text": "{{previous_results}}",
                "length": 200
            }
        }
    ]'::jsonb
),
(
    'Code Migration Helper',
    'Analyze legacy code and generate modern equivalent',
    'development',
    '[
        {
            "name": "Analyze Legacy Code",
            "tool": "code_explainer",
            "params": {
                "code": "# Paste your legacy code here"
            }
        },
        {
            "name": "Generate Modern Version",
            "tool": "code_generator",
            "params": {
                "task": "Convert the analyzed code to use modern Python patterns and type hints"
            }
        }
    ]'::jsonb
),
(
    'Error Investigation Pipeline',
    'Decode error, analyze code context, and suggest fixes',
    'debugging',
    '[
        {
            "name": "Decode Error Message",
            "tool": "error_decoder",
            "params": {
                "error": "# Paste error message here"
            }
        },
        {
            "name": "Generate Fix",
            "tool": "code_generator",
            "params": {
                "task": "Generate corrected code based on the error analysis"
            }
        }
    ]'::jsonb
)
ON CONFLICT (name) DO NOTHING;

-- =====================================================
-- PART 12: GRANT ALL PERMISSIONS
-- =====================================================

-- Grant table permissions to user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO tuokit_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO tuokit_user;
-- Note: For PostgreSQL < 9.0, we need to grant view permissions individually
GRANT SELECT ON recent_activity TO tuokit_user;
GRANT SELECT ON agent_success_rates TO tuokit_user;
GRANT SELECT ON recent_agent_activity TO tuokit_user;
GRANT SELECT ON pipeline_analytics TO tuokit_user;
GRANT SELECT ON popular_tools TO tuokit_user;

-- =====================================================
-- PART 13: ADD COMMENTS FOR DOCUMENTATION
-- =====================================================

-- Core table comments
COMMENT ON TABLE queries IS 'Core table storing all AI tool queries and responses';
COMMENT ON TABLE knowledge_units IS 'Organized knowledge entries derived from queries';
COMMENT ON TABLE knowledge_collections IS 'Collections for organizing related knowledge';

-- Agent table comments
COMMENT ON TABLE agent_executions IS 'History of all agent executions with their state';
COMMENT ON TABLE agent_metrics IS 'Performance metrics for agent executions';
COMMENT ON TABLE agent_collaborations IS 'Records of multi-agent collaborations';

-- Pipeline table comments
COMMENT ON TABLE pipelines IS 'Executed pipeline workflows and their results';
COMMENT ON TABLE educational_guidance IS 'Contextual help and guidance for users';
COMMENT ON TABLE pipeline_templates IS 'Pre-built workflow templates';

-- Ruby table comments
COMMENT ON TABLE performance_findings IS 'Ruby performance issues detected during code analysis';
COMMENT ON TABLE test_cases IS 'Generated Rails system tests with metadata';
COMMENT ON TABLE graphql_apis IS 'Generated GraphQL API schemas and configurations';
COMMENT ON TABLE concurrency_patterns IS 'Ruby concurrency model reference and best practices';
COMMENT ON TABLE pattern_matching_examples IS 'Ruby 3+ pattern matching examples and use cases';
COMMENT ON TABLE ractor_implementations IS 'Generated Ractor-based parallel processing solutions';
COMMENT ON TABLE memory_patterns IS 'Ruby memory optimization patterns and antipatterns';
COMMENT ON TABLE katas IS 'Ruby programming challenges for skill development';
COMMENT ON TABLE view_components IS 'Rails ViewComponent library with tests and examples';
COMMENT ON TABLE rails_upgrades IS 'Rails version upgrade plans and documentation';
COMMENT ON TABLE c_extensions IS 'Ruby C extension implementations for performance';
COMMENT ON TABLE kata_completions IS 'Track user progress on kata challenges';
COMMENT ON TABLE component_usage IS 'Analytics for ViewComponent reuse';

-- Column comments
COMMENT ON COLUMN performance_findings.severity IS '1=low, 2=medium, 3=high severity';
COMMENT ON COLUMN test_cases.coverage IS 'Estimated test coverage percentage';
COMMENT ON COLUMN graphql_apis.operations IS 'Array of supported operations: Query, Mutation, Subscription';
COMMENT ON COLUMN ractor_implementations.estimated_speedup IS 'Estimated performance improvement vs sequential execution';
COMMENT ON COLUMN pattern_matching_examples.pattern_type IS 'Type: array, hash, guard, alternative, etc.';
COMMENT ON COLUMN katas.difficulty_score IS 'Score from 1-10 indicating challenge difficulty';
COMMENT ON COLUMN rails_upgrades.risk_level IS 'Risk assessment for the upgrade path';
COMMENT ON COLUMN c_extensions.thread_safe IS 'Whether the extension is thread-safe';
COMMENT ON COLUMN view_components.features IS 'Array of features like Slots, Variants, I18n';

-- =====================================================
-- PART 14: SUCCESS MESSAGE
-- =====================================================

SELECT 'TuoKit database setup completed successfully!' as status,
       COUNT(DISTINCT table_name) as tables_created
FROM information_schema.tables
WHERE table_schema = 'public' 
AND table_name NOT LIKE 'pg_%';
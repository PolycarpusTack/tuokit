#!/usr/bin/env python3
"""
Add feature toggle to app.py for safe migration
Step 3 of the migration process
"""
import os
import re
from datetime import datetime
from pathlib import Path

class FeatureToggleAdder:
    def __init__(self):
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.app_path = Path("app.py")
        
    def run(self):
        """Add feature toggle to app.py"""
        print("🎛️ Adding Feature Toggle to app.py")
        print("=" * 60)
        
        if not self.app_path.exists():
            print("❌ Error: app.py not found!")
            return False
        
        # Backup current app.py
        backup_path = f"app_backup_{self.timestamp}.py"
        with open(self.app_path, 'r', encoding='utf-8') as f:
            original_content = f.read()
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            f.write(original_content)
        print(f"✓ Created backup: {backup_path}")
        
        # Add feature toggle
        modified_content = self.add_toggle_to_sidebar(original_content)
        modified_content = self.update_navigation(modified_content)
        
        # Write modified content
        with open(self.app_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)
        
        print("✅ Feature toggle added successfully!")
        print("\n📋 Changes made:")
        print("  - Added experimental features toggle to sidebar")
        print("  - Updated navigation to show different tools based on toggle")
        print("  - Original navigation preserved when toggle is OFF")
        print("\n🎯 Next step: Run complete_unified_tools.py")
        
        return True
    
    def add_toggle_to_sidebar(self, content: str) -> str:
        """Add experimental features section to sidebar"""
        
        # Find where to insert (after navigation section)
        sidebar_pattern = r'(with st\.sidebar:.*?)(st\.divider\(\)|# Navigation|st\.subheader\("Tools Navigation"\))'
        
        toggle_code = '''
    # Experimental Features
    st.divider()
    st.subheader("🧪 Experimental Features")
    
    # Feature toggle with explanation
    use_next_gen = st.toggle(
        "Use Next-Gen Tools",
        key="use_next_gen_tools",
        value=False,  # Default OFF for safety
        help="Try the new unified tools (SQL Toolkit & Agent Next)"
    )
    
    if use_next_gen:
        st.success("✅ Using next-generation tools")
        st.caption("Please report any issues!")
    else:
        st.info("📌 Using stable tools")
    
    '''
        
        # Insert toggle code
        def replacer(match):
            return match.group(1) + toggle_code + match.group(2)
        
        modified = re.sub(sidebar_pattern, replacer, content, flags=re.DOTALL)
        
        # If pattern didn't match, try alternative insertion
        if modified == content:
            # Look for sidebar section
            if "with st.sidebar:" in content:
                lines = content.split('\n')
                for i, line in enumerate(lines):
                    if "with st.sidebar:" in line:
                        # Find indentation
                        indent = len(line) - len(line.lstrip())
                        # Insert after sidebar declaration
                        for j in range(i+1, len(lines)):
                            if lines[j].strip() and not lines[j].strip().startswith('#'):
                                lines.insert(j, toggle_code)
                                break
                        break
                modified = '\n'.join(lines)
        
        return modified
    
    def update_navigation(self, content: str) -> str:
        """Update navigation to be conditional based on toggle"""
        
        # Pattern to find SQL tool navigation
        sql_nav_pattern = r'(st\.page_link\("pages/sql_generator\.py".*?\n)(.*?)(st\.page_link\("pages/sql_optimizer\.py".*?\n)(.*?)(st\.page_link\("pages/sql_pipeline\.py".*?\n)'
        
        # Replacement with conditional
        conditional_sql_nav = r'''if st.session_state.get('use_next_gen_tools', False):
        st.page_link("pages/sql_toolkit_next.py", label="🚀 SQL Toolkit", icon="🚀")
    else:
        \1\2\3\4\5'''
        
        # Apply SQL navigation update
        modified = re.sub(sql_nav_pattern, conditional_sql_nav, content, flags=re.DOTALL)
        
        # Pattern to find agent navigation  
        agent_nav_pattern = r'(st\.page_link\("pages/agent_.*?\.py".*?\n)'
        
        # Count how many agent links there are
        agent_matches = re.findall(agent_nav_pattern, content)
        
        if agent_matches:
            # Replace first agent link with conditional
            first_agent_pattern = agent_matches[0].replace('(', r'\(').replace(')', r'\)')
            
            conditional_agent_nav = f'''if st.session_state.get('use_next_gen_tools', False):
        st.page_link("pages/agent_next.py", label="🚀 AI Agent", icon="🚀")
    else:
        {agent_matches[0]}'''
            
            modified = modified.replace(agent_matches[0], conditional_agent_nav, 1)
            
            # Comment out other agent links when using next-gen
            for agent_link in agent_matches[1:]:
                safe_pattern = agent_link.replace('(', r'\(').replace(')', r'\)')
                wrapped = f'''if not st.session_state.get('use_next_gen_tools', False):
        {agent_link}'''
                modified = modified.replace(agent_link, wrapped)
        
        # Add migration dashboard to navigation
        if "migration_dashboard.py" not in modified:
            # Find a good place to add it (after help guide or at end of navigation)
            help_pattern = r'(st\.page_link\("pages/help_guide\.py".*?\n)'
            
            migration_nav = r'''\1    
    # Migration Tools (Temporary)
    if st.session_state.get('use_next_gen_tools', False):
        st.page_link("pages/migration_dashboard.py", label="📊 Migration Dashboard", icon="📊")
'''
            
            modified = re.sub(help_pattern, migration_nav, modified)
        
        return modified


def main():
    """Add feature toggle to app.py"""
    adder = FeatureToggleAdder()
    success = adder.run()
    
    if not success:
        print("\n⚠️  Failed to add feature toggle")
        print("Please check that app.py exists and try again")


if __name__ == "__main__":
    main()

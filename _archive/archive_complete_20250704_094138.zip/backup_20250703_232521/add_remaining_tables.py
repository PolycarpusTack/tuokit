#!/usr/bin/env python3
"""
Add remaining TuoKit tables
Run this after quick_db_setup.py to add all additional tables
"""

import psycopg2
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def main():
    print("Adding remaining TuoKit tables...")
    print("=" * 40)
    
    # Connect to database
    conn = psycopg2.connect(
        host="localhost",
        port="5432",
        dbname="tuokit_knowledge",
        user="postgres",
        password="Th1s1s4Work"
    )
    conn.autocommit = True
    cur = conn.cursor()
    
    # Add missing columns to queries table
    print("\n1. Updating queries table...")
    try:
        cur.execute("ALTER TABLE queries ADD COLUMN IF NOT EXISTS complexity VARCHAR(50)")
        cur.execute("ALTER TABLE queries ADD COLUMN IF NOT EXISTS category VARCHAR(50)")
        print("✓ Updated queries table")
    except Exception as e:
        print(f"⚠️  {e}")
    
    # Knowledge collections
    print("\n2. Creating knowledge collections...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_collections (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) UNIQUE NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute("""
        INSERT INTO knowledge_collections (name, description)
        VALUES ('knowledge_graph', 'SQL concepts and their relationships for educational features')
        ON CONFLICT (name) DO NOTHING
    """)
    print("✓ Created knowledge_collections table")
    
    # Agent tables
    print("\n3. Creating agent system tables...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_executions (
            id BIGSERIAL PRIMARY KEY,
            goal TEXT NOT NULL,
            agent_name VARCHAR(64) NOT NULL,
            agent_type VARCHAR(32) NOT NULL,
            state_json JSONB NOT NULL,
            start_time TIMESTAMPTZ DEFAULT NOW(),
            end_time TIMESTAMPTZ,
            phase VARCHAR(32) NOT NULL,
            success BOOLEAN DEFAULT FALSE,
            error_message TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_metrics (
            id BIGSERIAL PRIMARY KEY,
            agent_name VARCHAR(64) NOT NULL,
            execution_id BIGINT REFERENCES agent_executions(id),
            metric_name VARCHAR(64) NOT NULL,
            metric_value DECIMAL,
            measured_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_collaborations (
            id BIGSERIAL PRIMARY KEY,
            team_name VARCHAR(64) NOT NULL,
            execution_id BIGINT REFERENCES agent_executions(id),
            member_agent VARCHAR(64) NOT NULL,
            subtask TEXT NOT NULL,
            dependency_agents TEXT[],
            result_summary TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    print("✓ Created agent tables")
    
    # Pipeline tables
    print("\n4. Creating pipeline tables...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pipelines (
            id SERIAL PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            steps JSONB NOT NULL,
            results JSONB NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            created_by VARCHAR(100),
            execution_time_ms INTEGER,
            success BOOLEAN DEFAULT TRUE
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pipeline_templates (
            id SERIAL PRIMARY KEY,
            name VARCHAR(200) NOT NULL UNIQUE,
            description TEXT,
            category VARCHAR(50),
            steps JSONB NOT NULL,
            usage_count INTEGER DEFAULT 0,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    print("✓ Created pipeline tables")
    
    # Ruby performance tables
    print("\n5. Creating Ruby development tables...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS performance_findings (
            id SERIAL PRIMARY KEY,
            query_id INTEGER REFERENCES queries(id) ON DELETE CASCADE,
            issue_type VARCHAR(50) NOT NULL,
            severity SMALLINT CHECK (severity IN (1, 2, 3)),
            solution TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS test_cases (
            id SERIAL PRIMARY KEY,
            feature TEXT NOT NULL,
            framework VARCHAR(20) NOT NULL,
            coverage FLOAT CHECK (coverage >= 0 AND coverage <= 100),
            test_code TEXT,
            generated_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    print("✓ Created Ruby performance tables")
    
    # Advanced Ruby tables
    print("\n6. Creating advanced Ruby tables...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS graphql_apis (
            id SERIAL PRIMARY KEY,
            resource VARCHAR(100) NOT NULL,
            operations VARCHAR(100)[],
            types VARCHAR(50)[],
            authentication_method VARCHAR(50),
            pagination_type VARCHAR(50),
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS concurrency_patterns (
            id SERIAL PRIMARY KEY,
            pattern VARCHAR(50) NOT NULL UNIQUE,
            use_case TEXT,
            example TEXT,
            performance_characteristics JSONB,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    print("✓ Created advanced Ruby tables")
    
    # Professional Ruby tables
    print("\n7. Creating professional Ruby tables...")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS memory_patterns (
            pattern VARCHAR(50) PRIMARY KEY,
            solution TEXT NOT NULL,
            severity SMALLINT CHECK (severity BETWEEN 1 AND 5),
            example TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS katas (
            id SERIAL PRIMARY KEY,
            level VARCHAR(20) NOT NULL CHECK (level IN ('Beginner', 'Intermediate', 'Advanced')),
            topic VARCHAR(50) NOT NULL,
            focus_area VARCHAR(50),
            problem TEXT NOT NULL,
            solution TEXT,
            hints TEXT[],
            estimated_minutes INTEGER,
            difficulty_score SMALLINT CHECK (difficulty_score BETWEEN 1 AND 10),
            query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS view_components (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            template_language VARCHAR(20) CHECK (template_language IN ('ERB', 'HAML', 'SLIM')),
            javascript_framework VARCHAR(50),
            features VARCHAR(50)[],
            component_code TEXT,
            tests TEXT,
            stimulus_controller TEXT,
            query_id INTEGER REFERENCES queries(id) ON DELETE SET NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)
    print("✓ Created professional Ruby tables")
    
    # Create all indexes
    print("\n8. Creating indexes...")
    indexes = [
        "CREATE INDEX IF NOT EXISTS idx_agent_executions_agent_name ON agent_executions(agent_name)",
        "CREATE INDEX IF NOT EXISTS idx_pipelines_created_at ON pipelines(created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_performance_findings_query_id ON performance_findings(query_id)",
        "CREATE INDEX IF NOT EXISTS idx_katas_level_topic ON katas(level, topic)",
        "CREATE INDEX IF NOT EXISTS idx_view_components_name ON view_components(name)",
    ]
    
    for idx in indexes:
        try:
            cur.execute(idx)
        except Exception as e:
            print(f"⚠️  Index error: {e}")
    print("✓ Created indexes")
    
    # Create views
    print("\n9. Creating views...")
    cur.execute("""
        CREATE OR REPLACE VIEW recent_activity AS
        SELECT 
            q.id,
            q.tool,
            q.model,
            q.user_prompt,
            q.created_at,
            COUNT(k.id) as knowledge_count
        FROM queries q
        LEFT JOIN knowledge_units k ON q.id = k.query_id
        GROUP BY q.id, q.tool, q.model, q.user_prompt, q.created_at
        ORDER BY q.created_at DESC
        LIMIT 50
    """)
    print("✓ Created views")
    
    # Add default data
    print("\n10. Adding default data...")
    
    # Concurrency patterns
    patterns = [
        ('Ractor', 'CPU-bound parallel processing without shared state', '{"gvl_free": true, "memory": "isolated", "overhead": "high"}'),
        ('Thread Pool', 'I/O-bound concurrent operations', '{"gvl_free": false, "memory": "shared", "overhead": "medium"}'),
        ('Fiber', 'Lightweight cooperative multitasking', '{"gvl_free": false, "memory": "shared", "overhead": "low"}'),
    ]
    
    for pattern, use_case, perf in patterns:
        try:
            cur.execute("""
                INSERT INTO concurrency_patterns (pattern, use_case, performance_characteristics)
                VALUES (%s, %s, %s)
                ON CONFLICT (pattern) DO NOTHING
            """, (pattern, use_case, perf))
        except Exception as e:
            print(f"⚠️  {e}")
    
    # Memory patterns
    mem_patterns = [
        ('String Duplication', 'Use << instead of += for string concatenation', 3, 'str += "text" → str << "text"'),
        ('Unbounded Growth', 'Implement pagination or lazy loading', 4, 'Limit array size or use lazy enumerators'),
    ]
    
    for pattern, solution, severity, example in mem_patterns:
        try:
            cur.execute("""
                INSERT INTO memory_patterns (pattern, solution, severity, example)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (pattern) DO NOTHING
            """, (pattern, solution, severity, example))
        except Exception as e:
            print(f"⚠️  {e}")
    
    print("✓ Added default data")
    
    # Grant permissions
    print("\n11. Granting permissions...")
    cur.execute("GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO tuokit_user")
    cur.execute("GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO tuokit_user")
    cur.execute("GRANT SELECT ON recent_activity TO tuokit_user")
    print("✓ Granted permissions")
    
    # Verify
    cur.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
        ORDER BY table_name
    """)
    
    tables = cur.fetchall()
    print(f"\n✅ Setup complete! Now have {len(tables)} tables:")
    for table in tables[:10]:  # Show first 10
        print(f"  - {table[0]}")
    if len(tables) > 10:
        print(f"  ... and {len(tables) - 10} more")
    
    cur.close()
    conn.close()
    
    print("\n🎉 TuoKit database is fully configured!")
    print("You can now use all features including:")
    print("  - Agent systems")
    print("  - Pipeline workflows") 
    print("  - Ruby development tools")
    print("  - Performance analysis")
    print("  - And more!")

if __name__ == "__main__":
    main()
"""
TuoKit Database Client
Handles connections to local or remote PostgreSQL databases
"""
import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2 import pool
from contextlib import contextmanager
from typing import List, Dict, Optional, Any
import streamlit as st
from config.connection_config import config
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabasePool:
    """Thread-safe connection pool for PostgreSQL"""
    
    def __init__(self, minconn: int = 1, maxconn: int = 10):
        """Initialize connection pool"""
        try:
            self.pool = psycopg2.pool.ThreadedConnectionPool(
                minconn,
                maxconn,
                host=config.postgres_host,
                port=config.postgres_port,
                database=config.postgres_db,
                user=config.postgres_user,
                password=config.postgres_password,
                # SSL configuration
                sslmode='require' if config.enable_ssl else 'prefer'
            )
            logger.info(f"Database pool created for {config.postgres_host}:{config.postgres_port}")
        except Exception as e:
            logger.error(f"Failed to create database pool: {str(e)}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get connection from pool"""
        conn = None
        try:
            conn = self.pool.getconn()
            yield conn
            conn.commit()
        except Exception as e:
            if conn:
                conn.rollback()
            logger.error(f"Database error: {str(e)}")
            raise
        finally:
            if conn:
                self.pool.putconn(conn)
    
    def close_all(self):
        """Close all connections in pool"""
        if hasattr(self, 'pool'):
            self.pool.closeall()

# Global connection pool
_db_pool = None

def get_db_pool() -> DatabasePool:
    """Get or create database connection pool"""
    global _db_pool
    if _db_pool is None:
        _db_pool = DatabasePool()
    return _db_pool

class TuoKitDB:
    """Database operations for TuoKit knowledge base"""
    
    def __init__(self):
        self.pool = get_db_pool()
    
    def initialize_schema(self):
        """Create database tables if they don't exist"""
        schema_sql = """
        -- Knowledge entries table
        CREATE TABLE IF NOT EXISTS knowledge_entries (
            id SERIAL PRIMARY KEY,
            tool_name VARCHAR(100) NOT NULL,
            prompt TEXT NOT NULL,
            response TEXT NOT NULL,
            model_used VARCHAR(100),
            context_data JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_id VARCHAR(100),
            session_id VARCHAR(100),
            quality_score FLOAT,
            tags TEXT[]
        );
        
        -- Code snippets table
        CREATE TABLE IF NOT EXISTS code_snippets (
            id SERIAL PRIMARY KEY,
            language VARCHAR(50) NOT NULL,
            code TEXT NOT NULL,
            explanation TEXT,
            usage_example TEXT,
            knowledge_entry_id INTEGER REFERENCES knowledge_entries(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Document analysis table
        CREATE TABLE IF NOT EXISTS document_analyses (
            id SERIAL PRIMARY KEY,
            document_name VARCHAR(255) NOT NULL,
            document_type VARCHAR(50),
            content_hash VARCHAR(64),
            summary TEXT,
            key_points TEXT[],
            knowledge_entry_id INTEGER REFERENCES knowledge_entries(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        -- Create indexes for better performance
        CREATE INDEX IF NOT EXISTS idx_knowledge_tool ON knowledge_entries(tool_name);
        CREATE INDEX IF NOT EXISTS idx_knowledge_created ON knowledge_entries(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_knowledge_tags ON knowledge_entries USING GIN(tags);
        CREATE INDEX IF NOT EXISTS idx_code_language ON code_snippets(language);
        
        -- Create full-text search index
        CREATE EXTENSION IF NOT EXISTS pg_trgm;
        CREATE INDEX IF NOT EXISTS idx_knowledge_prompt_trgm ON knowledge_entries USING gin(prompt gin_trgm_ops);
        CREATE INDEX IF NOT EXISTS idx_knowledge_response_trgm ON knowledge_entries USING gin(response gin_trgm_ops);
        """
        
        with self.pool.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(schema_sql)
        
        logger.info("Database schema initialized")
    
    def save_knowledge(self, tool_name: str, prompt: str, response: str,
                      model_used: str = None, context_data: Dict = None,
                      tags: List[str] = None) -> int:
        """Save knowledge entry to database"""
        sql = """
        INSERT INTO knowledge_entries 
        (tool_name, prompt, response, model_used, context_data, tags, user_id, session_id)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """
        
        with self.pool.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (
                    tool_name,
                    prompt,
                    response,
                    model_used,
                    psycopg2.extras.Json(context_data) if context_data else None,
                    tags or [],
                    st.session_state.get('user_id', 'anonymous'),
                    st.session_state.get('session_id', 'default')
                ))
                return cur.fetchone()[0]
    
    def search_knowledge(self, query: str, tool_name: str = None, 
                        limit: int = 10) -> List[Dict]:
        """Search knowledge base with full-text search"""
        sql = """
        SELECT 
            id, tool_name, prompt, response, model_used, 
            context_data, created_at, tags,
            similarity(prompt || ' ' || response, %s) as relevance
        FROM knowledge_entries
        WHERE 1=1
        """
        
        params = [query]
        
        if tool_name:
            sql += " AND tool_name = %s"
            params.append(tool_name)
        
        sql += """
        AND (prompt ILIKE %s OR response ILIKE %s 
             OR similarity(prompt || ' ' || response, %s) > 0.1)
        ORDER BY relevance DESC, created_at DESC
        LIMIT %s
        """
        
        params.extend([f'%{query}%', f'%{query}%', query, limit])
        
        with self.pool.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(sql, params)
                return cur.fetchall()
    
    def get_recent_entries(self, tool_name: str = None, limit: int = 20) -> List[Dict]:
        """Get recent knowledge entries"""
        sql = """
        SELECT * FROM knowledge_entries
        WHERE 1=1
        """
        
        params = []
        if tool_name:
            sql += " AND tool_name = %s"
            params.append(tool_name)
        
        sql += " ORDER BY created_at DESC LIMIT %s"
        params.append(limit)
        
        with self.pool.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(sql, params)
                return cur.fetchall()
    
    def save_code_snippet(self, language: str, code: str, 
                         explanation: str = None, usage_example: str = None,
                         knowledge_entry_id: int = None) -> int:
        """Save code snippet to database"""
        sql = """
        INSERT INTO code_snippets 
        (language, code, explanation, usage_example, knowledge_entry_id)
        VALUES (%s, %s, %s, %s, %s)
        RETURNING id
        """
        
        with self.pool.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (language, code, explanation, usage_example, knowledge_entry_id))
                return cur.fetchone()[0]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get database statistics"""
        sql = """
        SELECT 
            COUNT(*) as total_entries,
            COUNT(DISTINCT tool_name) as unique_tools,
            COUNT(DISTINCT DATE(created_at)) as active_days,
            array_agg(DISTINCT tool_name) as tools_list
        FROM knowledge_entries;
        """
        
        with self.pool.get_connection() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(sql)
                return cur.fetchone()

# Convenience functions
def test_database_connection() -> bool:
    """Test if database connection is properly configured"""
    try:
        db = TuoKitDB()
        stats = db.get_statistics()
        st.success(f"✅ Connected to PostgreSQL at {config.postgres_host}")
        st.info(f"Database contains {stats['total_entries']} knowledge entries")
        return True
    except Exception as e:
        st.error(f"❌ Database connection failed: {str(e)}")
        return False

def save_to_knowledge_base(tool: str, prompt: str, response: str, 
                          model: str = "deepseek-r1", context: Any = None) -> None:
    """Quick function to save to knowledge base"""
    try:
        db = TuoKitDB()
        
        # Convert context to dict if needed
        context_data = {}
        if context:
            if isinstance(context, str):
                context_data = {"description": context}
            elif isinstance(context, dict):
                context_data = context
            else:
                context_data = {"data": str(context)}
        
        entry_id = db.save_knowledge(
            tool_name=tool,
            prompt=prompt,
            response=response,
            model_used=model,
            context_data=context_data
        )
        
        logger.info(f"Saved knowledge entry {entry_id} for tool {tool}")
        
    except Exception as e:
        logger.error(f"Failed to save to knowledge base: {str(e)}")
        # Don't break the application flow if saving fails

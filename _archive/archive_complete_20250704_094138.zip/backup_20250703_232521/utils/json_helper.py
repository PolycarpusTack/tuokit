"""
Alternative fix for format parameter - Add JSON instruction to prompt
This approach works even if the model doesn't support format parameter
"""
import streamlit as st
import json
import re

def ensure_json_response(prompt: str, add_json_instruction: bool = True) -> str:
    """
    Ensures the prompt will generate a JSON response
    by adding explicit JSON instructions if needed
    """
    if add_json_instruction and "json" in prompt.lower():
        # Add explicit JSON instruction at the end
        json_instruction = """

IMPORTANT: Respond ONLY with valid JSON. No additional text before or after the JSON.
Start your response with { and end with }"""
        return prompt + json_instruction
    return prompt

def extract_json_from_response(response_text: str) -> dict:
    """
    Extract JSON from response text, handling cases where
    the model adds extra text around the JSON
    """
    # Try direct parsing first
    try:
        return json.loads(response_text)
    except json.JSONDecodeError:
        pass
    
    # Try to find JSON in the response
    # Look for content between first { and last }
    match = re.search(r'\{.*\}', response_text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass
    
    # If all fails, return a default structure
    return {
        "error": "Failed to parse JSON response",
        "raw_response": response_text[:200]
    }

# Example usage in crash analyzer:
def safe_json_analysis(content, model, prompt):
    """
    Safely get JSON response from LLM, with fallback handling
    """
    # Ensure prompt asks for JSON
    enhanced_prompt = ensure_json_response(prompt)
    
    # Get response
    response = safe_ollama_generate(
        model=model,
        prompt=enhanced_prompt,
        temperature=0.3  # Lower temperature for more consistent JSON
    )
    
    if response.get('error'):
        return {"error": "LLM request failed", "details": response.get('response')}
    
    # Extract JSON from response
    response_text = response.get('response', '{}')
    return extract_json_from_response(response_text)

# Alternative approach - use a more explicit template
JSON_TEMPLATE = """
{
    "errors_found": ["error1", "error2"],
    "error_types": ["type1", "type2"],
    "severity": "Critical|High|Medium|Low",
    "root_cause_hints": "description",
    "error_locations": ["location1", "location2"],
    "summary": "brief summary"
}
"""

def get_structured_analysis(content, chunk_info=""):
    """Get structured analysis with explicit JSON template"""
    prompt = f"""
Analyze this crash dump section{chunk_info}.

CRASH CONTENT:
{content}

You must respond with JSON matching this exact structure:
{JSON_TEMPLATE}

Fill in the actual values based on the crash content.
Respond ONLY with the JSON, no other text.
"""
    
    return safe_json_analysis(content, st.session_state.get("selected_model", "deepseek-r1:latest"), prompt)

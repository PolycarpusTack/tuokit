#!/usr/bin/env python3
"""
TuoKit Database Setup Script
Run this to create the necessary database tables
"""

import psycopg2
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database configuration
DB_CONFIG = {
    "dbname": os.getenv("DB_NAME", "ollama_knowledge"),
    "user": os.getenv("DB_USER", "ollama_user"),
    "password": os.getenv("DB_PASSWORD", "secure_password"),
    "host": os.getenv("DB_HOST", "localhost")
}

def setup_database():
    """Create database tables and indexes"""
    try:
        # Connect to database
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        print("Connected to database successfully")
        
        # Create queries table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS queries (
                id SERIAL PRIMARY KEY,
                tool VARCHAR(100) NOT NULL,
                model VARCHAR(100) NOT NULL,
                user_prompt TEXT NOT NULL,
                ai_response TEXT NOT NULL,
                metadata JSONB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✓ Created queries table")
        
        # Create knowledge_units table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS knowledge_units (
                id SERIAL PRIMARY KEY,
                query_id INTEGER REFERENCES queries(id),
                title VARCHAR(255) NOT NULL,
                content TEXT NOT NULL,
                category VARCHAR(100) NOT NULL,
                tags TEXT[],
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        print("✓ Created knowledge_units table")
        
        # Create indexes
        indexes = [
            ("idx_queries_tool", "queries(tool)"),
            ("idx_queries_created_at", "queries(created_at DESC)"),
            ("idx_knowledge_units_category", "knowledge_units(category)"),
        ]
        
        for index_name, index_def in indexes:
            cur.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {index_def}")
            print(f"✓ Created index {index_name}")
        
        # Create GIN index for tags
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_knowledge_units_tags 
            ON knowledge_units USING GIN(tags)
        """)
        print("✓ Created GIN index for tags")
        
        # Commit changes
        conn.commit()
        print("\n✅ Database setup completed successfully!")
        
        # Test the connection
        cur.execute("SELECT COUNT(*) FROM queries")
        count = cur.fetchone()[0]
        print(f"📊 Current queries in database: {count}")
        
        cur.close()
        conn.close()
        
    except psycopg2.Error as e:
        print(f"\n❌ Database setup failed: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure PostgreSQL is installed and running")
        print("2. Create the database: CREATE DATABASE ollama_knowledge;")
        print("3. Create the user: CREATE USER ollama_user WITH PASSWORD 'secure_password';")
        print("4. Grant privileges: GRANT ALL PRIVILEGES ON DATABASE ollama_knowledge TO ollama_user;")
        print("5. Update your .env file with correct database credentials")
        return False
    
    return True

if __name__ == "__main__":
    print("TuoKit Database Setup")
    print("=" * 50)
    print(f"Database: {DB_CONFIG['dbname']}")
    print(f"Host: {DB_CONFIG['host']}")
    print(f"User: {DB_CONFIG['user']}")
    print("=" * 50)
    print()
    
    setup_database()
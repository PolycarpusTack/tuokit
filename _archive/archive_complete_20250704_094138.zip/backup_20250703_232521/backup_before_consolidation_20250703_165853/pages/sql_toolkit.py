"""
Unified SQL Toolkit for TuoKit
Consolidates sql_generator, sql_optimizer, and sql_pipeline into one tool
"""

import streamlit as st
from utils.ollama import OllamaToolBase
from utils.database import DatabaseManager
import re

class SQLToolkit(OllamaToolBase):
    """Single source of truth for all SQL operations"""
    
    def __init__(self):
        super().__init__("sql_toolkit", "deepseek-coder:6.7b")
        self.db = DatabaseManager()
    
    def generate(self, query: str, dialect: str = "postgresql", 
                schema_info: dict = None, include_optimizations: bool = True) -> dict:
        """Generate SQL from natural language with best practices"""
        
        # Build comprehensive prompt
        prompt = f"""Convert this request to {dialect} SQL:
{query}

{f'Database Schema:\n{self._format_schema(schema_info)}' if schema_info else ''}

Requirements:
- Use proper JOIN syntax instead of WHERE clauses for relationships
- Include appropriate indexes in comments
- Follow {dialect} naming conventions
- Add helpful comments for complex logic
{f'- Include query optimization hints' if include_optimizations else ''}

Return ONLY the SQL code, no explanations."""

        result = self.generate_with_logging(prompt)
        
        # Extract just the SQL from response
        sql = self._extract_sql(result['response'])
        
        return {
            'sql': sql,
            'dialect': dialect,
            'optimized': include_optimizations,
            'error': result.get('error', False)
        }
    
    def optimize(self, sql: str, explain_plan: str = None, 
                target_improvement: str = "performance") -> dict:
        """Optimize existing SQL query"""
        
        prompt = f"""Optimize this {target_improvement} SQL query:

```sql
{sql}
```

{f'Current EXPLAIN ANALYZE output:\n{explain_plan}' if explain_plan else ''}

Focus on:
- {'Query execution speed' if target_improvement == 'performance' else ''}
- {'Memory usage and temp file reduction' if target_improvement == 'memory' else ''}  
- {'Code clarity and maintainability' if target_improvement == 'readability' else ''}
- Index recommendations
- JOIN optimization
- Subquery elimination where beneficial

Provide:
1. Optimized SQL
2. Brief explanation of changes
3. Recommended indexes (as CREATE INDEX statements)"""

        result = self.generate_with_logging(prompt)
        
        # Parse response into structured format
        response_text = result['response']
        optimized_sql = self._extract_sql(response_text)
        indexes = self._extract_indexes(response_text)
        explanation = self._extract_explanation(response_text)
        
        return {
            'original_sql': sql,
            'optimized_sql': optimized_sql,
            'indexes': indexes,
            'explanation': explanation,
            'improvement_type': target_improvement,
            'error': result.get('error', False)
        }
    
    def explain(self, sql: str, technical_level: str = "beginner") -> str:
        """Explain SQL in plain English"""
        
        level_prompts = {
            "beginner": "Explain like I'm new to databases",
            "intermediate": "Explain with some technical details", 
            "expert": "Provide deep technical analysis"
        }
        
        prompt = f"""Explain this SQL query:

```sql
{sql}
```

{level_prompts.get(technical_level, level_prompts['beginner'])}:
- What data is being retrieved
- Which tables are involved
- How they're connected
- Any filters or conditions
- The expected output

Keep it clear and concise."""

        result = self.generate_with_logging(prompt)
        return result['response']
    
    def validate(self, sql: str, dialect: str = "postgresql") -> dict:
        """Validate SQL syntax and identify potential issues"""
        
        prompt = f"""Analyze this {dialect} SQL for issues:

```sql
{sql}
```

Check for:
1. Syntax errors
2. Performance problems  
3. Security vulnerabilities (SQL injection risks)
4. Best practice violations
5. Missing indexes

Format response as:
- Status: VALID or INVALID
- Issues: List any problems found
- Suggestions: How to fix them"""

        result = self.generate_with_logging(prompt)
        
        # Parse structured response
        response = result['response']
        is_valid = "VALID" in response.upper() and "INVALID" not in response.upper()
        
        return {
            'valid': is_valid,
            'analysis': response,
            'dialect': dialect,
            'error': result.get('error', False)
        }
    
    # Helper methods
    def _extract_sql(self, text: str) -> str:
        """Extract SQL code from response"""
        # Look for code blocks
        sql_match = re.search(r'```sql\n(.*?)\n```', text, re.DOTALL)
        if sql_match:
            return sql_match.group(1).strip()
        
        # Fallback: look for SELECT/INSERT/UPDATE/DELETE/CREATE
        lines = text.split('\n')
        sql_lines = []
        in_sql = False
        
        for line in lines:
            if re.match(r'^\s*(SELECT|INSERT|UPDATE|DELETE|CREATE|WITH|ALTER)', line, re.IGNORECASE):
                in_sql = True
            if in_sql and line.strip():
                sql_lines.append(line)
            elif in_sql and not line.strip() and sql_lines:
                break
                
        return '\n'.join(sql_lines) if sql_lines else text
    
    def _extract_indexes(self, text: str) -> list:
        """Extract CREATE INDEX statements"""
        indexes = []
        for match in re.finditer(r'CREATE\s+(?:UNIQUE\s+)?INDEX.*?;', text, re.IGNORECASE | re.DOTALL):
            indexes.append(match.group(0).strip())
        return indexes
    
    def _extract_explanation(self, text: str) -> str:
        """Extract explanation text, removing SQL code"""
        # Remove SQL blocks
        text = re.sub(r'```sql.*?```', '', text, flags=re.DOTALL)
        text = re.sub(r'CREATE\s+(?:UNIQUE\s+)?INDEX.*?;', '', text, flags=re.IGNORECASE | re.DOTALL)
        
        # Clean up
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        return '\n'.join(lines)
    
    def _format_schema(self, schema_info: dict) -> str:
        """Format schema information for prompt"""
        if not schema_info:
            return ""
            
        formatted = []
        for table, columns in schema_info.items():
            formatted.append(f"Table: {table}")
            for col in columns:
                formatted.append(f"  - {col}")
        
        return '\n'.join(formatted)


def main():
    st.set_page_config(
        page_title="SQL Toolkit",
        page_icon="🛢️",
        layout="wide"
    )
    
    st.title("🛢️ Unified SQL Toolkit")
    st.caption("Generate, optimize, explain, and validate SQL - all in one place")
    
    # Initialize toolkit
    toolkit = SQLToolkit()
    
    # Create tabs for different operations
    tab_generate, tab_optimize, tab_explain, tab_validate = st.tabs([
        "🚀 Generate SQL",
        "⚡ Optimize SQL", 
        "📖 Explain SQL",
        "✅ Validate SQL"
    ])
    
    # Generate SQL Tab
    with tab_generate:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            query = st.text_area(
                "Describe what you want in plain English",
                placeholder="Find all customers who made purchases over $100 in the last 30 days",
                height=100
            )
        
        with col2:
            dialect = st.selectbox("SQL Dialect", ["postgresql", "mysql", "sqlite", "sqlserver"])
            include_opts = st.checkbox("Include optimization hints", value=True)
            
        if st.button("Generate SQL", type="primary", use_container_width=True):
            if query:
                with st.spinner("Generating SQL..."):
                    result = toolkit.generate(query, dialect, include_optimizations=include_opts)
                    
                    if not result['error']:
                        st.success("SQL generated successfully!")
                        st.code(result['sql'], language='sql')
                        
                        # Copy button
                        st.button("📋 Copy SQL", help="Copy to clipboard")
                    else:
                        st.error("Failed to generate SQL")
    
    # Optimize SQL Tab  
    with tab_optimize:
        sql_input = st.text_area(
            "Paste your SQL query here",
            height=200,
            placeholder="SELECT * FROM orders WHERE customer_id IN (SELECT id FROM customers WHERE country = 'USA')"
        )
        
        col1, col2 = st.columns(2)
        with col1:
            improvement_type = st.selectbox(
                "Optimization Goal",
                ["performance", "memory", "readability"]
            )
        
        with col2:
            has_explain = st.checkbox("I have EXPLAIN ANALYZE output")
            
        if has_explain:
            explain_input = st.text_area("Paste EXPLAIN ANALYZE output", height=150)
        else:
            explain_input = None
            
        if st.button("Optimize SQL", type="primary", use_container_width=True):
            if sql_input:
                with st.spinner("Analyzing and optimizing..."):
                    result = toolkit.optimize(
                        sql_input, 
                        explain_input,
                        improvement_type
                    )
                    
                    if not result['error']:
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.subheader("Original SQL")
                            st.code(result['original_sql'], language='sql')
                            
                        with col2:
                            st.subheader("Optimized SQL")
                            st.code(result['optimized_sql'], language='sql')
                        
                        if result['indexes']:
                            st.subheader("Recommended Indexes")
                            for idx in result['indexes']:
                                st.code(idx, language='sql')
                        
                        if result['explanation']:
                            st.subheader("Optimization Explanation")
                            st.write(result['explanation'])
                    else:
                        st.error("Failed to optimize SQL")
    
    # Explain SQL Tab
    with tab_explain:
        sql_explain = st.text_area(
            "Paste SQL to explain",
            height=200,
            placeholder="SELECT c.name, COUNT(o.id) as order_count\nFROM customers c\nLEFT JOIN orders o ON c.id = o.customer_id\nGROUP BY c.id, c.name\nHAVING COUNT(o.id) > 5"
        )
        
        level = st.radio(
            "Explanation Level",
            ["beginner", "intermediate", "expert"],
            horizontal=True
        )
        
        if st.button("Explain SQL", type="primary", use_container_width=True):
            if sql_explain:
                with st.spinner("Analyzing query..."):
                    explanation = toolkit.explain(sql_explain, level)
                    
                    st.subheader("Explanation")
                    st.write(explanation)
    
    # Validate SQL Tab
    with tab_validate:
        sql_validate = st.text_area(
            "Paste SQL to validate",
            height=200
        )
        
        val_dialect = st.selectbox("SQL Dialect", ["postgresql", "mysql", "sqlite", "sqlserver"], key="val_dialect")
        
        if st.button("Validate SQL", type="primary", use_container_width=True):
            if sql_validate:
                with st.spinner("Validating SQL..."):
                    result = toolkit.validate(sql_validate, val_dialect)
                    
                    if result['valid']:
                        st.success("✅ SQL is valid!")
                    else:
                        st.error("❌ SQL has issues")
                    
                    st.subheader("Analysis")
                    st.write(result['analysis'])
    
    # Sidebar info
    with st.sidebar:
        st.subheader("📊 SQL Toolkit Stats")
        if toolkit.db and toolkit.db.connected:
            count = toolkit.db.get_tool_usage_count("sql_toolkit")
            st.metric("Queries Processed", count)
        
        st.divider()
        
        st.subheader("💡 Tips")
        st.write("""
        - **Generate**: Describe your data needs in plain English
        - **Optimize**: Include EXPLAIN output for better suggestions
        - **Explain**: Great for learning or code reviews
        - **Validate**: Check syntax before running on production
        """)
        
        st.divider()
        
        if st.button("📚 View SQL Knowledge Base"):
            st.switch_page("pages/knowledge_lib.py")


if __name__ == "__main__":
    main()

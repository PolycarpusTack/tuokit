-- TuoKit Database Schema Setup
-- Run this script to create the necessary tables for TuoKit

-- Create queries table
CREATE TABLE IF NOT EXISTS queries (
    id SERIAL PRIMARY KEY,
    tool VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    user_prompt TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create knowledge_units table
CREATE TABLE IF NOT EXISTS knowledge_units (
    id SERIAL PRIMARY KEY,
    query_id INTEGER REFERENCES queries(id),
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(100) NOT NULL,
    tags TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_queries_tool ON queries(tool);
CREATE INDEX IF NOT EXISTS idx_queries_created_at ON queries(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_knowledge_units_category ON knowledge_units(category);
CREATE INDEX IF NOT EXISTS idx_knowledge_units_tags ON knowledge_units USING GIN(tags);

-- Create a view for recent activity
CREATE OR REPLACE VIEW recent_activity AS
SELECT 
    q.id,
    q.tool,
    q.model,
    q.user_prompt,
    q.created_at,
    COUNT(ku.id) as knowledge_count
FROM queries q
LEFT JOIN knowledge_units ku ON q.id = ku.query_id
GROUP BY q.id, q.tool, q.model, q.user_prompt, q.created_at
ORDER BY q.created_at DESC
LIMIT 50;

-- Grant permissions (adjust user as needed)
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ollama_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO ollama_user;
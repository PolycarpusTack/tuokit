"""
TuoKit - Diagnostic Toolkit (Consolidated Edition)
Comprehensive diagnostics and auto-fix capabilities for TuoKit
"""

import os
import sys
import json
import subprocess
import shutil
import platform
import time
import requests
import psutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
import streamlit as st
from packaging import version

# ============== CONFIGURATION ==============
DIAGNOSTIC_CONFIG = {
    "timeout": 2.0,
    "test_hosts": [
        "http://localhost:11434",
        "http://127.0.0.1:11434",
        "http://host.docker.internal:11434"
    ],
    "recommended_models": [
        "deepseek-r1:latest",
        "deepseek-coder:6.7b", 
        "deepseek-r1:1.5b",
        "qwen2.5-coder:latest",
        "llama3.2:latest"
    ],
    "required_packages": [
        "streamlit>=1.28.0",
        "pandas>=1.5.3",
        "psycopg2-binary>=2.9.9",
        "ollama>=0.1.7",
        "python-dotenv>=1.0.0",
        "requests>=2.31.0",
        "beautifulsoup4>=4.12.2"
    ],
    "migration_scripts": [
        "migrate_tuokit.py",
        "extract_unique_features.py",
        "smart_cleanup.py",
        "add_feature_toggle.py",
        "complete_unified_tools.py",
        "test_unified_tools.py",
        "archive_old_tools.py"
    ],
    "min_python_version": "3.8",
    "min_disk_space_gb": 2.0
}

# ============== CORE DIAGNOSTIC FUNCTIONS ==============

class DiagnosticResult:
    """Container for diagnostic results"""
    def __init__(self, name: str):
        self.name = name
        self.status = "pending"  # pending, success, warning, error
        self.message = ""
        self.details = []
        self.fix_available = False
        self.fix_command = None
        
    def set_success(self, message: str, details: List[str] = None):
        self.status = "success"
        self.message = message
        if details:
            self.details = details
            
    def set_warning(self, message: str, details: List[str] = None):
        self.status = "warning"
        self.message = message
        if details:
            self.details = details
            
    def set_error(self, message: str, details: List[str] = None, fix_command: str = None):
        self.status = "error"
        self.message = message
        if details:
            self.details = details
        if fix_command:
            self.fix_available = True
            self.fix_command = fix_command

# ============== OLLAMA DIAGNOSTICS ==============

def test_ollama_connection(url: str, timeout: float = DIAGNOSTIC_CONFIG["timeout"]) -> Tuple[bool, str]:
    """Test Ollama connection at specified URL"""
    try:
        response = requests.get(f"{url}/api/tags", timeout=timeout)
        if response.status_code == 200:
            data = response.json()
            model_count = len(data.get('models', []))
            return True, f"Connected successfully ({model_count} models)"
        else:
            return False, f"HTTP {response.status_code}"
    except requests.exceptions.Timeout:
        return False, "Connection timeout"
    except requests.exceptions.ConnectionError:
        return False, "Connection refused"
    except Exception as e:
        return False, str(e)

def detect_ollama_host() -> DiagnosticResult:
    """Detect the best Ollama host configuration"""
    result = DiagnosticResult("Ollama Host Detection")
    
    # Check current configuration
    current_host = os.getenv('TUOKIT_OLLAMA_HOST', 'http://localhost:11434')
    
    # Test current host first
    success, message = test_ollama_connection(current_host)
    if success:
        result.set_success(f"Current host working: {current_host}", [message])
        return result
    
    # Auto-discovery
    working_hosts = []
    test_hosts = DIAGNOSTIC_CONFIG["test_hosts"].copy()
    
    # Add WSL-specific host if in WSL
    if is_wsl():
        wsl_host = get_windows_host_ip()
        if wsl_host:
            test_hosts.insert(0, f"http://{wsl_host}:11434")
    
    for host in test_hosts:
        if host != current_host:  # Skip already tested
            success, message = test_ollama_connection(host)
            if success:
                working_hosts.append((host, message))
    
    if working_hosts:
        best_host = working_hosts[0][0]
        result.set_warning(
            f"Current host not working. Found alternative: {best_host}",
            [f"{host}: {msg}" for host, msg in working_hosts],
        )
        result.fix_available = True
        result.fix_command = f"update_ollama_host('{best_host}')"
    else:
        result.set_error(
            "No working Ollama host found",
            [
                "Ollama may not be running",
                "Try: ollama serve",
                "Check firewall settings",
                f"Current config: {current_host}"
            ]
        )
    
    return result

def check_ollama_models() -> DiagnosticResult:
    """Check available Ollama models"""
    result = DiagnosticResult("Ollama Models")
    
    # Get current host
    host = os.getenv('TUOKIT_OLLAMA_HOST', 'http://localhost:11434')
    
    try:
        response = requests.get(f"{host}/api/tags", timeout=DIAGNOSTIC_CONFIG["timeout"])
        if response.status_code == 200:
            data = response.json()
            models = data.get('models', [])
            model_names = [m['name'] for m in models]
            
            # Check recommended models
            missing_recommended = []
            found_recommended = []
            
            for rec_model in DIAGNOSTIC_CONFIG["recommended_models"]:
                if any(rec_model in name for name in model_names):
                    found_recommended.append(rec_model)
                else:
                    missing_recommended.append(rec_model)
            
            details = [f"Total models: {len(models)}"]
            details.extend([f"✅ {m}" for m in found_recommended])
            details.extend([f"❌ {m} (run: ollama pull {m})" for m in missing_recommended])
            
            if missing_recommended:
                result.set_warning(
                    f"Found {len(models)} models, {len(missing_recommended)} recommended missing",
                    details
                )
            else:
                result.set_success(
                    f"All recommended models available ({len(models)} total)",
                    details
                )
        else:
            result.set_error(f"API returned status {response.status_code}")
            
    except Exception as e:
        result.set_error(f"Failed to check models: {str(e)}")
    
    return result

def test_ollama_generation() -> DiagnosticResult:
    """Test actual text generation with Ollama"""
    result = DiagnosticResult("Ollama Generation Test")
    
    host = os.getenv('TUOKIT_OLLAMA_HOST', 'http://localhost:11434')
    
    # Get available models first
    try:
        response = requests.get(f"{host}/api/tags", timeout=DIAGNOSTIC_CONFIG["timeout"])
        if response.status_code != 200:
            result.set_error("Cannot get model list")
            return result
            
        models = response.json().get('models', [])
        if not models:
            result.set_error("No models available")
            return result
        
        # Use first available model
        test_model = models[0]['name']
        
        # Test generation
        test_prompt = "Say 'Hello, TuoKit diagnostics working!' in exactly those words."
        
        generation_response = requests.post(
            f"{host}/api/generate",
            json={
                "model": test_model,
                "prompt": test_prompt,
                "stream": False
            },
            timeout=10
        )
        
        if generation_response.status_code == 200:
            response_text = generation_response.json().get('response', '')
            result.set_success(
                f"Generation successful with {test_model}",
                [f"Response: {response_text[:100]}..."]
            )
        else:
            result.set_error(f"Generation failed: HTTP {generation_response.status_code}")
            
    except requests.exceptions.Timeout:
        result.set_error("Generation timeout (model may be loading)")
    except Exception as e:
        result.set_error(f"Generation error: {str(e)}")
    
    return result

# ============== SYSTEM DIAGNOSTICS ==============

def check_python_version() -> DiagnosticResult:
    """Check Python version compatibility"""
    result = DiagnosticResult("Python Version")
    
    current_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    min_version = DIAGNOSTIC_CONFIG["min_python_version"]
    
    if sys.version_info >= tuple(map(int, min_version.split('.'))):
        result.set_success(f"Python {current_version} (>= {min_version})")
    else:
        result.set_error(
            f"Python {current_version} is below minimum {min_version}",
            ["Please upgrade Python to continue"]
        )
    
    return result

def check_required_packages() -> DiagnosticResult:
    """Check if required packages are installed"""
    result = DiagnosticResult("Required Packages")
    
    missing_packages = []
    installed_packages = []
    version_mismatches = []
    
    for package_spec in DIAGNOSTIC_CONFIG["required_packages"]:
        # Parse package name and version
        if '>=' in package_spec:
            package_name, min_version_str = package_spec.split('>=')
        else:
            package_name = package_spec
            min_version_str = None
        
        try:
            module = __import__(package_name.replace('-', '_'))
            
            # Check version if specified
            if min_version_str and hasattr(module, '__version__'):
                if version.parse(module.__version__) < version.parse(min_version_str):
                    version_mismatches.append(
                        f"{package_name} {module.__version__} (need >= {min_version_str})"
                    )
                else:
                    installed_packages.append(f"{package_name} {module.__version__}")
            else:
                installed_packages.append(package_name)
                
        except ImportError:
            missing_packages.append(package_spec)
    
    details = []
    if installed_packages:
        details.extend([f"✅ {pkg}" for pkg in installed_packages])
    if missing_packages:
        details.extend([f"❌ {pkg}" for pkg in missing_packages])
    if version_mismatches:
        details.extend([f"⚠️ {pkg}" for pkg in version_mismatches])
    
    if missing_packages:
        result.set_error(
            f"{len(missing_packages)} packages missing",
            details,
            f"pip install {' '.join(missing_packages)}"
        )
    elif version_mismatches:
        result.set_warning(
            f"{len(version_mismatches)} packages need updating",
            details
        )
    else:
        result.set_success(
            f"All {len(installed_packages)} required packages installed",
            details[:5]  # Show first 5
        )
    
    return result

def check_disk_space() -> DiagnosticResult:
    """Check available disk space"""
    result = DiagnosticResult("Disk Space")
    
    try:
        stats = shutil.disk_usage(".")
        free_gb = stats.free / (1024**3)
        total_gb = stats.total / (1024**3)
        used_percent = (stats.used / stats.total) * 100
        
        details = [
            f"Free: {free_gb:.1f} GB",
            f"Total: {total_gb:.1f} GB", 
            f"Used: {used_percent:.1f}%"
        ]
        
        if free_gb < DIAGNOSTIC_CONFIG["min_disk_space_gb"]:
            result.set_warning(
                f"Low disk space: {free_gb:.1f} GB free",
                details
            )
        else:
            result.set_success(
                f"Sufficient disk space: {free_gb:.1f} GB free",
                details
            )
            
    except Exception as e:
        result.set_error(f"Failed to check disk space: {str(e)}")
    
    return result

def check_database_connection() -> DiagnosticResult:
    """Check database connectivity"""
    result = DiagnosticResult("Database Connection")
    
    db_type = os.getenv('TUOKIT_DB_TYPE', 'postgresql')
    
    if db_type == 'postgresql':
        try:
            import psycopg2
            
            config = {
                "host": os.getenv('TUOKIT_PG_HOST', 'localhost'),
                "port": os.getenv('TUOKIT_PG_PORT', '5432'),
                "dbname": os.getenv('TUOKIT_PG_DB', 'tuokit_knowledge'),
                "user": os.getenv('TUOKIT_PG_USER', 'tuokit_user'),
                "password": os.getenv('TUOKIT_PG_PASSWORD', 'your_secure_password')
            }
            
            conn = psycopg2.connect(**config)
            
            # Test query
            cur = conn.cursor()
            cur.execute("SELECT version()")
            version_info = cur.fetchone()[0]
            
            cur.close()
            conn.close()
            
            result.set_success(
                f"PostgreSQL connected successfully",
                [f"Version: {version_info.split(',')[0]}"]
            )
            
        except ImportError:
            result.set_error("psycopg2 not installed", fix_command="pip install psycopg2-binary")
        except psycopg2.OperationalError as e:
            error_msg = str(e)
            if "password authentication failed" in error_msg:
                result.set_error("Authentication failed", ["Check database credentials in .env"])
            elif "could not connect to server" in error_msg:
                result.set_error("Database server not reachable", ["Check if PostgreSQL is running"])
            else:
                result.set_error(f"Connection failed: {error_msg}")
        except Exception as e:
            result.set_error(f"Unexpected error: {str(e)}")
            
    elif db_type == 'sqlite':
        try:
            import sqlite3
            db_path = os.getenv('TUOKIT_SQLITE_PATH', 'tuokit.db')
            
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                conn.close()
                result.set_success(f"SQLite database found: {db_path}")
            else:
                result.set_warning(f"SQLite database not found: {db_path}", 
                                 ["Run setup_database.py to create"])
                
        except Exception as e:
            result.set_error(f"SQLite error: {str(e)}")
    
    return result

def check_file_permissions() -> DiagnosticResult:
    """Check file and directory permissions"""
    result = DiagnosticResult("File Permissions")
    
    issues = []
    checked = []
    
    # Check critical directories/files
    paths_to_check = [
        (".", "Current directory", True, True),
        (".env", "Environment file", True, True),
        ("backups", "Backup directory", True, True),
        ("app.py", "Main application", True, False),
    ]
    
    for path, description, need_read, need_write in paths_to_check:
        if os.path.exists(path):
            can_read = os.access(path, os.R_OK)
            can_write = os.access(path, os.W_OK)
            
            status = []
            if need_read and not can_read:
                issues.append(f"{description}: No read permission")
            else:
                status.append("R")
                
            if need_write and not can_write:
                issues.append(f"{description}: No write permission")
            else:
                status.append("W")
                
            checked.append(f"{description}: {''.join(status)}")
        else:
            if path not in [".env", "backups"]:  # These are optional
                issues.append(f"{description}: Not found")
    
    if issues:
        result.set_error(
            f"{len(issues)} permission issues found",
            issues + ["---"] + checked
        )
    else:
        result.set_success(
            "All file permissions OK",
            checked
        )
    
    return result

# ============== MIGRATION DIAGNOSTICS ==============

def check_migration_readiness() -> DiagnosticResult:
    """Check if system is ready for migration"""
    result = DiagnosticResult("Migration Readiness")
    
    missing_scripts = []
    found_scripts = []
    
    for script in DIAGNOSTIC_CONFIG["migration_scripts"]:
        if os.path.exists(script):
            found_scripts.append(script)
        else:
            missing_scripts.append(script)
    
    # Check target files
    target_patterns = ["pages/*.py", "utils/*.py", "*.py"]
    total_files = 0
    
    for pattern in target_patterns:
        files = list(Path(".").glob(pattern))
        total_files += len(files)
    
    details = [
        f"Migration scripts: {len(found_scripts)}/{len(DIAGNOSTIC_CONFIG['migration_scripts'])}",
        f"Target files found: {total_files}"
    ]
    
    if missing_scripts:
        details.extend([f"❌ Missing: {script}" for script in missing_scripts])
        result.set_error(
            f"{len(missing_scripts)} migration scripts missing",
            details
        )
    else:
        details.extend([f"✅ {script}" for script in found_scripts[:3]])
        details.append("...")
        result.set_success(
            f"All migration scripts present ({total_files} files to process)",
            details
        )
    
    return result

# ============== PLATFORM DETECTION ==============

def is_wsl() -> bool:
    """Check if running in WSL"""
    return 'microsoft-standard' in platform.uname().release.lower()

def get_windows_host_ip() -> Optional[str]:
    """Get Windows host IP from WSL"""
    if not is_wsl():
        return None
    
    # Method 1: From /etc/resolv.conf
    try:
        with open('/etc/resolv.conf', 'r') as f:
            for line in f:
                if line.startswith('nameserver') and not line.startswith('nameserver 127'):
                    return line.split()[1]
    except:
        pass
    
    # Method 2: From ip route
    try:
        result = subprocess.run(['ip', 'route'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'default via' in line:
                return line.split()[2]
    except:
        pass
    
    return None

# ============== AUTO-FIX FUNCTIONS ==============

def update_ollama_host(new_host: str) -> bool:
    """Update Ollama host in .env file"""
    try:
        # Backup current .env
        if os.path.exists('.env'):
            backup_path = f".env.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2('.env', backup_path)
        
        # Read current .env
        env_lines = []
        if os.path.exists('.env'):
            with open('.env', 'r') as f:
                env_lines = f.readlines()
        
        # Update or add TUOKIT_OLLAMA_HOST
        updated = False
        for i, line in enumerate(env_lines):
            if line.strip().startswith('TUOKIT_OLLAMA_HOST'):
                env_lines[i] = f'TUOKIT_OLLAMA_HOST={new_host}\n'
                updated = True
                break
        
        if not updated:
            env_lines.append(f'\n# Auto-detected by diagnostic toolkit\n')
            env_lines.append(f'TUOKIT_OLLAMA_HOST={new_host}\n')
        
        # Write updated .env
        with open('.env', 'w') as f:
            f.writelines(env_lines)
        
        return True
        
    except Exception as e:
        print(f"Failed to update .env: {e}")
        return False

def fix_model_references() -> DiagnosticResult:
    """Fix hardcoded model references in code"""
    result = DiagnosticResult("Fix Model References")
    
    files_to_fix = list(Path("pages").glob("*.py")) + [Path("app.py")]
    fixed_files = []
    errors = []
    
    replacements = [
        ('model="deepseek-r1:latest"', 
         'model=st.session_state.get("selected_model", "deepseek-r1:latest")'),
        ('model="deepseek-coder:latest"',
         'model=st.session_state.get("selected_model", "deepseek-coder:6.7b")'),
        ('model="deepseek-coder:6.7b"',
         'model=st.session_state.get("selected_model", "deepseek-coder:6.7b")'),
    ]
    
    for file_path in files_to_fix:
        try:
            content = file_path.read_text()
            original_content = content
            
            for old, new in replacements:
                content = content.replace(old, new)
            
            if content != original_content:
                file_path.write_text(content)
                fixed_files.append(str(file_path))
                
        except Exception as e:
            errors.append(f"{file_path}: {str(e)}")
    
    if errors:
        result.set_warning(
            f"Fixed {len(fixed_files)} files with {len(errors)} errors",
            fixed_files[:5] + ["..."] + errors
        )
    elif fixed_files:
        result.set_success(
            f"Fixed {len(fixed_files)} files",
            fixed_files[:10]
        )
    else:
        result.set_success("No hardcoded models found")
    
    return result

def clear_streamlit_cache() -> DiagnosticResult:
    """Clear Streamlit cache to fix stuck states"""
    result = DiagnosticResult("Clear Streamlit Cache")
    
    try:
        # Clear session state cache
        if 'ollama_status' in st.session_state:
            del st.session_state['ollama_status']
        
        # Clear disk cache
        cache_dir = Path.home() / ".streamlit" / "cache"
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
            result.set_success("Streamlit cache cleared successfully")
        else:
            result.set_success("No cache to clear")
            
    except Exception as e:
        result.set_error(f"Failed to clear cache: {str(e)}")
    
    return result

# ============== UI COMPONENTS ==============

def show_diagnostic_summary(results: List[DiagnosticResult]):
    """Display diagnostic results summary"""
    # Count by status
    status_counts = {"success": 0, "warning": 0, "error": 0}
    for result in results:
        status_counts[result.status] += 1
    
    # Summary metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("✅ Passed", status_counts["success"])
    with col2:
        st.metric("⚠️ Warnings", status_counts["warning"])
    with col3:
        st.metric("❌ Errors", status_counts["error"])
    
    # Detailed results
    for result in results:
        icon = {"success": "✅", "warning": "⚠️", "error": "❌"}.get(result.status, "❓")
        
        with st.expander(f"{icon} {result.name} - {result.message}"):
            if result.details:
                for detail in result.details:
                    st.write(detail)
            
            if result.fix_available and result.fix_command:
                st.warning("Fix available:")
                if st.button(f"Apply Fix: {result.fix_command}", key=result.name):
                    # Execute fix
                    try:
                        if result.fix_command.startswith("update_ollama_host"):
                            # Extract host from command
                            host = result.fix_command.split("'")[1]
                            if update_ollama_host(host):
                                st.success("Fix applied! Please restart TuoKit.")
                            else:
                                st.error("Fix failed")
                        elif result.fix_command.startswith("pip install"):
                            st.code(result.fix_command)
                            st.info("Run this command in your terminal")
                        else:
                            st.info(f"Manual fix required: {result.fix_command}")
                    except Exception as e:
                        st.error(f"Error applying fix: {e}")

def run_diagnostics(categories: List[str]) -> List[DiagnosticResult]:
    """Run selected diagnostic categories"""
    results = []
    
    # Define diagnostic functions by category
    diagnostics_map = {
        "Ollama": [
            detect_ollama_host,
            check_ollama_models,
            test_ollama_generation
        ],
        "System": [
            check_python_version,
            check_required_packages,
            check_disk_space,
            check_file_permissions
        ],
        "Database": [
            check_database_connection
        ],
        "Migration": [
            check_migration_readiness
        ]
    }
    
    # Run diagnostics
    for category in categories:
        if category in diagnostics_map:
            for diagnostic_func in diagnostics_map[category]:
                with st.spinner(f"Running {diagnostic_func.__name__}..."):
                    try:
                        result = diagnostic_func()
                        results.append(result)
                    except Exception as e:
                        error_result = DiagnosticResult(diagnostic_func.__name__)
                        error_result.set_error(f"Diagnostic failed: {str(e)}")
                        results.append(error_result)
    
    return results

# ============== MAIN APPLICATION ==============

def main(standalone=True):
    # Only set page config if running standalone (not from unified app)
    if standalone:
        try:
            st.set_page_config(
                page_title="TuoKit Diagnostic Toolkit",
                page_icon="🔧",
                layout="wide",
                initial_sidebar_state="expanded"
            )
        except:
            # Page config already set (running from unified app)
            pass
    
    # Custom CSS
    st.markdown("""
    <style>
        .diagnostic-card {
            background-color: #1e1e1e;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
        }
        .success { color: #4CAF50; }
        .warning { color: #FFA726; }
        .error { color: #EF5350; }
        .stButton > button {
            width: 100%;
        }
    </style>
    """, unsafe_allow_html=True)
    
    st.title("🔧 TuoKit Diagnostic Toolkit")
    st.caption("Comprehensive system diagnostics and auto-fix capabilities")
    
    # Sidebar controls
    with st.sidebar:
        st.header("Diagnostic Options")
        
        # Quick actions
        st.subheader("🚀 Quick Actions")
        
        if st.button("🔍 Run All Diagnostics", type="primary"):
            st.session_state.run_all = True
            
        if st.button("🛠️ Auto-Fix All Issues"):
            st.session_state.auto_fix = True
            
        if st.button("🗑️ Clear Caches"):
            result = clear_streamlit_cache()
            if result.status == "success":
                st.success(result.message)
            else:
                st.error(result.message)
        
        st.divider()
        
        # Diagnostic categories
        st.subheader("📋 Select Categories")
        
        categories = st.multiselect(
            "Choose diagnostic categories",
            ["Ollama", "System", "Database", "Migration"],
            default=["Ollama", "System"]
        )
        
        # Platform info
        st.divider()
        st.subheader("📊 System Info")
        st.caption(f"**OS:** {platform.system()}")
        st.caption(f"**Python:** {sys.version.split()[0]}")
        st.caption(f"**WSL:** {'Yes' if is_wsl() else 'No'}")
        
        if is_wsl():
            win_ip = get_windows_host_ip()
            if win_ip:
                st.caption(f"**Windows Host:** {win_ip}")
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.header("Diagnostic Results")
        
        # Run diagnostics if requested
        if st.session_state.get('run_all') or st.button("🔍 Run Selected Diagnostics"):
            st.session_state.run_all = False
            
            if st.session_state.get('run_all'):
                categories = ["Ollama", "System", "Database", "Migration"]
            
            with st.spinner("Running diagnostics..."):
                results = run_diagnostics(categories)
                st.session_state.diagnostic_results = results
        
        # Display results
        if 'diagnostic_results' in st.session_state:
            show_diagnostic_summary(st.session_state.diagnostic_results)
        else:
            st.info("Select categories and click 'Run Selected Diagnostics' to begin")
    
    with col2:
        st.header("Quick Fixes")
        
        # Common fixes
        with st.expander("🔧 Fix Ollama Connection"):
            st.write("Common Ollama fixes:")
            st.code("# Start Ollama service\nollama serve")
            st.code("# Pull recommended model\nollama pull deepseek-r1:latest")
            
            if st.button("Auto-detect Ollama Host"):
                result = detect_ollama_host()
                if result.fix_available:
                    st.warning(f"Found working host: {result.message}")
                    if st.button("Apply this configuration"):
                        # Extract host from message
                        host = result.message.split(": ")[1]
                        if update_ollama_host(host):
                            st.success("Configuration updated!")
                        else:
                            st.error("Update failed")
        
        with st.expander("📦 Fix Missing Packages"):
            st.write("Install all required packages:")
            requirements = "\n".join(DIAGNOSTIC_CONFIG["required_packages"])
            st.code(f"pip install {' '.join(pkg.split('>=')[0] for pkg in DIAGNOSTIC_CONFIG['required_packages'])}")
            
            if st.button("Generate requirements.txt"):
                st.download_button(
                    "Download requirements.txt",
                    requirements,
                    file_name="requirements_diagnostic.txt",
                    mime="text/plain"
                )
        
        with st.expander("🗃️ Fix Database Issues"):
            st.write("Database setup commands:")
            st.code("# PostgreSQL setup\npython setup_database.py")
            st.code("# Quick setup\npython quick_db_setup.py")
            
            env_template = """TUOKIT_PG_HOST=localhost
TUOKIT_PG_PORT=5432
TUOKIT_PG_DB=tuokit_knowledge
TUOKIT_PG_USER=tuokit_user
TUOKIT_PG_PASSWORD=your_secure_password"""
            
            st.download_button(
                "Download .env template",
                env_template,
                file_name=".env.template",
                mime="text/plain"
            )
    
    # Export diagnostics report
    st.divider()
    
    if 'diagnostic_results' in st.session_state:
        if st.button("📄 Export Diagnostic Report"):
            report = generate_diagnostic_report(st.session_state.diagnostic_results)
            
            st.download_button(
                "Download Report",
                report,
                file_name=f"tuokit_diagnostics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                mime="text/markdown"
            )

def generate_diagnostic_report(results: List[DiagnosticResult]) -> str:
    """Generate markdown diagnostic report"""
    report = f"""# TuoKit Diagnostic Report

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Summary

- Total Checks: {len(results)}
- ✅ Passed: {sum(1 for r in results if r.status == 'success')}
- ⚠️ Warnings: {sum(1 for r in results if r.status == 'warning')}
- ❌ Errors: {sum(1 for r in results if r.status == 'error')}

## Detailed Results

"""
    
    for result in results:
        icon = {"success": "✅", "warning": "⚠️", "error": "❌"}.get(result.status, "❓")
        report += f"### {icon} {result.name}\n\n"
        report += f"**Status:** {result.status.upper()}\n"
        report += f"**Message:** {result.message}\n\n"
        
        if result.details:
            report += "**Details:**\n"
            for detail in result.details:
                report += f"- {detail}\n"
            report += "\n"
        
        if result.fix_available:
            report += f"**Fix Available:** `{result.fix_command}`\n\n"
        
        report += "---\n\n"
    
    # Add platform info
    report += f"""## System Information

- **Operating System:** {platform.system()} {platform.release()}
- **Python Version:** {sys.version.split()[0]}
- **WSL Environment:** {'Yes' if is_wsl() else 'No'}
- **Current Directory:** {os.getcwd()}
"""
    
    return report

if __name__ == "__main__":
    # Check if running from command line
    if len(sys.argv) > 1:
        # Command line mode
        print("TuoKit Diagnostic Toolkit - Command Line Mode")
        print("=" * 50)
        
        # Run all diagnostics
        categories = ["Ollama", "System", "Database", "Migration"]
        results = []
        
        for category in categories:
            print(f"\n{category} Diagnostics:")
            print("-" * 30)
            
            diagnostics_map = {
                "Ollama": [detect_ollama_host, check_ollama_models, test_ollama_generation],
                "System": [check_python_version, check_required_packages, check_disk_space, check_file_permissions],
                "Database": [check_database_connection],
                "Migration": [check_migration_readiness]
            }
            
            for diagnostic_func in diagnostics_map.get(category, []):
                try:
                    result = diagnostic_func()
                    icon = {"success": "✅", "warning": "⚠️", "error": "❌"}.get(result.status, "❓")
                    print(f"{icon} {result.name}: {result.message}")
                    
                    if result.details and result.status != "success":
                        for detail in result.details:
                            print(f"   {detail}")
                    
                    results.append(result)
                except Exception as e:
                    print(f"❌ {diagnostic_func.__name__}: Failed - {str(e)}")
        
        # Summary
        print("\n" + "=" * 50)
        print("SUMMARY:")
        print(f"Total: {len(results)}")
        print(f"✅ Passed: {sum(1 for r in results if r.status == 'success')}")
        print(f"⚠️ Warnings: {sum(1 for r in results if r.status == 'warning')}")
        print(f"❌ Errors: {sum(1 for r in results if r.status == 'error')}")
        
        # Save report
        report = generate_diagnostic_report(results)
        report_file = f"diagnostic_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        with open(report_file, 'w') as f:
            f.write(report)
        print(f"\nReport saved to: {report_file}")
    else:
        # Streamlit UI mode
        main()
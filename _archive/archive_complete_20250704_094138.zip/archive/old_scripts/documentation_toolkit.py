"""
TuoKit - Documentation Toolkit (Consolidated Edition)
Combines Document Tools, Knowledge Library, and Help Guide
"""

import streamlit as st
import json
import hashlib
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import pandas as pd
from pathlib import Path
import PyPDF2
from io import BytesIO
from utils import (
    DatabaseManager,
    safe_ollama_generate,
    capture_knowledge,
    get_available_models,
    extract_text_from_file
)

# Initialize database
db = DatabaseManager()

# ============== CONFIGURATION ==============
DOC_CONFIG = {
    "default_model": "deepseek-r1:latest",
    "temperature": 0.3,
    "max_tokens": 4000,
    "chunk_size": 2000,
    "overlap": 200,
    "supported_formats": ['pdf', 'txt', 'docx', 'md'],
    "enable_source_tracking": True
}

# Knowledge categories
KNOWLEDGE_CATEGORIES = {
    "code_snippet": {"icon": "💻", "description": "Reusable code examples"},
    "algorithm": {"icon": "🧮", "description": "Algorithm implementations"},
    "error_solution": {"icon": "🐛", "description": "Error fixes and solutions"},
    "utility_function": {"icon": "🔧", "description": "Helper functions"},
    "document_summary": {"icon": "📄", "description": "Document summaries"},
    "research_findings": {"icon": "🔬", "description": "Research insights"},
    "meeting_notes": {"icon": "📝", "description": "Meeting records"},
    "technical_documentation": {"icon": "📚", "description": "Technical docs"},
    "best_practices": {"icon": "⭐", "description": "Best practice guidelines"},
    "troubleshooting": {"icon": "🔍", "description": "Troubleshooting guides"}
}

# Help topics structure
HELP_TOPICS = {
    "getting_started": {
        "title": "🚀 Getting Started",
        "icon": "🚀",
        "sections": {
            "requirements": {
                "title": "System Requirements",
                "content": """
### System Requirements

**Minimum Requirements:**
- Python 3.8 or higher
- 4GB RAM
- 2GB free disk space
- Internet connection for AI models

**Recommended:**
- Python 3.10+
- 8GB RAM
- SSD storage
- GPU for faster model inference

**Supported Operating Systems:**
- Windows 10/11
- macOS 10.15+
- Linux (Ubuntu 20.04+, Debian 10+)
                """
            },
            "installation": {
                "title": "Installation Guide",
                "content": """
### Installation Steps

1. **Clone the repository:**
   ```bash
   git clone https://github.com/yourusername/tuokit.git
   cd tuokit
   ```

2. **Create virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\\Scripts\\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up database:**
   ```bash
   python setup_database.py
   ```

5. **Configure environment:**
   - Copy `.env.example` to `.env`
   - Update database credentials
   - Set Ollama host if needed

6. **Start the application:**
   ```bash
   streamlit run app.py
   ```
                """
            },
            "first_steps": {
                "title": "First Steps",
                "content": """
### Your First Steps with TuoKit

1. **Select a Tool:**
   - Browse available tools in the sidebar
   - Start with Code Explainer for code analysis
   - Try Document Q&A for PDF processing

2. **Configure AI Model:**
   - Select your preferred model
   - Adjust temperature for creativity
   - Enable/disable features as needed

3. **Process Your First Item:**
   - Paste code or upload a document
   - Click the action button
   - Review and save results

4. **Explore Knowledge Library:**
   - All results are automatically saved
   - Search and filter your knowledge
   - Export for external use
                """
            }
        }
    },
    "document_tools": {
        "title": "📄 Document Tools",
        "icon": "📄",
        "sections": {
            "overview": {
                "title": "Document Processing Overview",
                "content": """
### Document Processing Capabilities

TuoKit can process various document formats:
- **PDF**: Full text extraction with layout preservation
- **TXT**: Plain text analysis
- **DOCX**: Word document processing (coming soon)
- **MD**: Markdown file analysis

**Key Features:**
- Question answering based on document content
- Automatic summarization
- Knowledge extraction
- Source citation tracking
                """
            },
            "qa_usage": {
                "title": "Document Q&A",
                "content": """
### Using Document Q&A

1. **Upload Document:**
   - Click "Choose File" button
   - Select PDF or TXT file
   - Wait for processing confirmation

2. **Ask Questions:**
   - Type natural language questions
   - Be specific for better results
   - Reference document sections if needed

3. **Review Answers:**
   - Answers include source references
   - Confidence scores when available
   - Related context snippets

**Tips:**
- Ask one question at a time
- Use document terminology
- Verify critical information
                """
            },
            "extraction": {
                "title": "Knowledge Extraction",
                "content": """
### Extracting Structured Knowledge

The extraction tool identifies:
- **Key Topics**: Main themes and subjects
- **Important Dates**: Deadlines, milestones
- **Decisions**: Recorded decisions and rationale
- **Action Items**: Tasks with owners and due dates
- **Technical Terms**: Domain-specific vocabulary

**Best Practices:**
- Use with meeting notes for action tracking
- Process technical specs for key requirements
- Extract learning points from articles
                """
            }
        }
    },
    "knowledge_library": {
        "title": "📚 Knowledge Library",
        "icon": "📚",
        "sections": {
            "overview": {
                "title": "Knowledge Management",
                "content": """
### Your Personal Knowledge Base

The Knowledge Library stores all AI-generated insights:
- Code explanations and fixes
- Document summaries
- SQL queries
- Learning materials
- Custom notes

**Features:**
- Full-text search
- Category filtering
- In-place editing
- Version tracking
- Bulk export
                """
            },
            "search_tips": {
                "title": "Search Techniques",
                "content": """
### Effective Search Strategies

1. **Keyword Search:**
   - Use specific terms
   - Combine multiple keywords
   - Search in titles or content

2. **Category Filtering:**
   - Select relevant categories
   - Combine with search terms
   - Use multiple categories

3. **Date Filtering:**
   - Sort by newest/oldest
   - Filter by date range
   - Find recent updates

**Advanced Tips:**
- Use quotes for exact phrases
- Exclude terms with minus sign
- Search by tool name
                """
            },
            "organization": {
                "title": "Organizing Knowledge",
                "content": """
### Knowledge Organization Best Practices

1. **Use Clear Titles:**
   - Descriptive and searchable
   - Include key terms
   - Avoid generic names

2. **Choose Appropriate Categories:**
   - Match content type
   - Consider future searches
   - Use consistent categorization

3. **Add Tags and Metadata:**
   - Include relevant tags
   - Note source documents
   - Add version information

4. **Regular Maintenance:**
   - Review and update old entries
   - Remove duplicates
   - Consolidate related items
                """
            }
        }
    },
    "troubleshooting": {
        "title": "🔧 Troubleshooting",
        "icon": "🔧",
        "sections": {
            "common_issues": {
                "title": "Common Issues",
                "content": """
### Common Issues and Solutions

**1. Model Not Responding:**
- Check Ollama is running: `ollama serve`
- Verify model is pulled: `ollama list`
- Check network connectivity
- Restart Ollama service

**2. Database Connection Failed:**
- Verify PostgreSQL is running
- Check credentials in .env file
- Test connection: `psql -U your_user -d your_db`
- Run setup script again

**3. File Upload Errors:**
- Check file size limits
- Verify file format support
- Ensure file isn't corrupted
- Try different browser

**4. Slow Performance:**
- Check system resources
- Use smaller models
- Reduce chunk sizes
- Enable caching
                """
            },
            "error_messages": {
                "title": "Error Message Guide",
                "content": """
### Understanding Error Messages

**"Connection refused" errors:**
- Service not running
- Wrong port/host
- Firewall blocking

**"Out of memory" errors:**
- Model too large
- Batch size too high
- System RAM insufficient

**"Invalid format" errors:**
- Unsupported file type
- Corrupted file
- Encoding issues

**"Permission denied" errors:**
- File access rights
- Database permissions
- Directory write access
                """
            },
            "performance": {
                "title": "Performance Optimization",
                "content": """
### Optimizing Performance

**1. Model Selection:**
- Use appropriate model size
- Consider quantized models
- Balance quality vs speed

**2. System Optimization:**
- Close unnecessary applications
- Increase system swap
- Use SSD for temp files

**3. Configuration Tuning:**
- Adjust chunk sizes
- Modify batch processing
- Enable result caching

**4. Database Optimization:**
- Regular vacuuming
- Index optimization
- Connection pooling
                """
            }
        }
    },
    "best_practices": {
        "title": "⭐ Best Practices",
        "icon": "⭐",
        "sections": {
            "security": {
                "title": "Security Guidelines",
                "content": """
### Security Best Practices

**1. Data Protection:**
- Never process sensitive data
- Use local models for confidential content
- Regularly backup database
- Encrypt stored credentials

**2. Access Control:**
- Use strong passwords
- Limit database access
- Monitor usage logs
- Regular security updates

**3. Model Security:**
- Verify model sources
- Use official models only
- Monitor model behavior
- Sandbox execution environment
                """
            },
            "workflow": {
                "title": "Workflow Optimization",
                "content": """
### Efficient Workflows

**1. Document Processing Pipeline:**
   - Batch similar documents
   - Create templates for common tasks
   - Use consistent naming
   - Automate repetitive steps

**2. Knowledge Building:**
   - Process → Review → Refine → Save
   - Link related knowledge
   - Create topic hierarchies
   - Regular knowledge audits

**3. Tool Integration:**
   - Combine tools for complex tasks
   - Export/import between tools
   - Create tool chains
   - Document workflows
                """
            }
        }
    },
    "api_reference": {
        "title": "🔌 API Reference",
        "icon": "🔌",
        "sections": {
            "overview": {
                "title": "API Overview",
                "content": """
### TuoKit API Reference

**Core Functions:**
- `safe_ollama_generate()`: AI text generation
- `capture_knowledge()`: Save to knowledge base
- `extract_text_from_file()`: File processing
- `DatabaseManager`: Database operations

**Utilities:**
- Text processing helpers
- File format converters
- Validation functions
- Caching mechanisms
                """
            },
            "examples": {
                "title": "API Examples",
                "content": """
### API Usage Examples

**Generate Text:**
```python
response = safe_ollama_generate(
    model="deepseek-r1:latest",
    prompt="Explain this code: print('Hello')",
    temperature=0.3
)
```

**Save Knowledge:**
```python
capture_knowledge(
    tool_name="doc_qa",
    query="What is machine learning?",
    response="ML is a subset of AI...",
    metadata={"source": "ml_guide.pdf"}
)
```

**Process Document:**
```python
text = extract_text_from_file(uploaded_file)
if text:
    # Process extracted text
    summary = summarize_document(text)
```
                """
            }
        }
    }
}

# ============== CORE FUNCTIONS ==============

def extract_text_from_pdf(file_content: bytes) -> str:
    """Extract text from PDF bytes"""
    try:
        pdf_reader = PyPDF2.PdfReader(BytesIO(file_content))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text.strip()
    except Exception as e:
        st.error(f"Error extracting PDF text: {e}")
        return ""

def chunk_document(text: str, chunk_size: int = DOC_CONFIG["chunk_size"], 
                  overlap: int = DOC_CONFIG["overlap"]) -> List[Dict[str, Any]]:
    """Split document into overlapping chunks"""
    chunks = []
    start = 0
    chunk_id = 0
    
    while start < len(text):
        end = start + chunk_size
        chunk_text = text[start:end]
        
        # Find sentence boundary
        if end < len(text):
            last_period = chunk_text.rfind('.')
            if last_period > chunk_size * 0.8:
                end = start + last_period + 1
                chunk_text = text[start:end]
        
        chunks.append({
            "id": chunk_id,
            "text": chunk_text,
            "start": start,
            "end": end
        })
        
        start = end - overlap
        chunk_id += 1
    
    return chunks

def answer_document_question(document_text: str, question: str, 
                           model: str = DOC_CONFIG["default_model"]) -> Dict[str, Any]:
    """Answer question based on document content"""
    
    # Chunk document if too large
    if len(document_text) > DOC_CONFIG["chunk_size"] * 2:
        chunks = chunk_document(document_text)
        
        # Find relevant chunks
        relevant_chunks = []
        for chunk in chunks:
            prompt = f"""
            Does this text contain information relevant to answering: "{question}"?
            
            Text:
            {chunk['text'][:500]}...
            
            Respond with just YES or NO.
            """
            
            response = safe_ollama_generate(model, prompt, temperature=0.1)
            if isinstance(response, dict):
                answer = response.get('response', '').strip().upper()
            else:
                answer = str(response).strip().upper()
            
            if "YES" in answer:
                relevant_chunks.append(chunk)
        
        # Combine relevant chunks
        context = "\n\n".join([c['text'] for c in relevant_chunks[:3]])
    else:
        context = document_text
    
    # Generate answer
    prompt = f"""
    Based on the following document content, answer this question:
    
    Question: {question}
    
    Document:
    {context}
    
    Provide a clear, accurate answer based only on the information in the document.
    If the answer is not in the document, say so.
    Include relevant quotes or references when possible.
    """
    
    response = safe_ollama_generate(model, prompt, temperature=DOC_CONFIG["temperature"])
    
    if isinstance(response, dict):
        answer = response.get('response', 'Unable to generate answer')
    else:
        answer = str(response)
    
    # Extract source references
    sources = []
    if DOC_CONFIG["enable_source_tracking"]:
        # Simple source extraction - look for quoted text
        quotes = re.findall(r'"([^"]+)"', answer)
        for quote in quotes[:3]:  # Limit to 3 sources
            # Find quote in original text
            quote_pos = document_text.find(quote)
            if quote_pos >= 0:
                sources.append({
                    "quote": quote,
                    "position": quote_pos,
                    "context": document_text[max(0, quote_pos-50):quote_pos+len(quote)+50]
                })
    
    return {
        "answer": answer,
        "sources": sources,
        "chunks_searched": len(relevant_chunks) if 'relevant_chunks' in locals() else 1
    }

def summarize_document(text: str, model: str = DOC_CONFIG["default_model"]) -> Dict[str, Any]:
    """Generate document summary"""
    
    prompt = f"""
    Create a comprehensive summary of this document:
    
    {text[:DOC_CONFIG["chunk_size"] * 2]}
    
    Include:
    1. Main Topic (1 sentence)
    2. Key Points (3-5 bullet points)
    3. Important Details (relevant facts, figures, dates)
    4. Conclusions or Recommendations
    5. Action Items (if any)
    
    Format as structured text with clear sections.
    """
    
    response = safe_ollama_generate(model, prompt, temperature=DOC_CONFIG["temperature"])
    
    if isinstance(response, dict):
        summary = response.get('response', 'Unable to generate summary')
    else:
        summary = str(response)
    
    # Extract structured elements
    key_points = []
    action_items = []
    
    # Simple extraction
    lines = summary.split('\n')
    in_key_points = False
    in_action_items = False
    
    for line in lines:
        if 'key point' in line.lower():
            in_key_points = True
            in_action_items = False
        elif 'action item' in line.lower():
            in_action_items = True
            in_key_points = False
        elif line.strip().startswith(('•', '-', '*', '1', '2', '3', '4', '5')):
            if in_key_points:
                key_points.append(line.strip().lstrip('•-*123456789. '))
            elif in_action_items:
                action_items.append(line.strip().lstrip('•-*123456789. '))
    
    return {
        "summary": summary,
        "key_points": key_points,
        "action_items": action_items,
        "word_count": len(text.split()),
        "estimated_reading_time": f"{len(text.split()) // 200} minutes"
    }

def extract_knowledge(text: str, model: str = DOC_CONFIG["default_model"]) -> Dict[str, Any]:
    """Extract structured knowledge from document"""
    
    prompt = f"""
    Extract structured information from this document:
    
    {text[:DOC_CONFIG["chunk_size"] * 2]}
    
    Return as JSON with these fields:
    {{
        "key_topics": ["main topics discussed"],
        "important_dates": ["YYYY-MM-DD format dates mentioned"],
        "decisions_made": ["decisions or conclusions reached"],
        "action_items": [
            {{"task": "description", "owner": "assigned person", "due_date": "YYYY-MM-DD"}}
        ],
        "technical_terms": ["specialized terms or acronyms"],
        "people_mentioned": ["names of people referenced"],
        "organizations": ["companies or organizations mentioned"]
    }}
    """
    
    response = safe_ollama_generate(model, prompt, format="json")
    
    try:
        if isinstance(response, dict):
            extracted = json.loads(response.get('response', '{}'))
        else:
            extracted = json.loads(str(response))
        
        # Ensure all fields exist
        default_structure = {
            "key_topics": [],
            "important_dates": [],
            "decisions_made": [],
            "action_items": [],
            "technical_terms": [],
            "people_mentioned": [],
            "organizations": []
        }
        
        for key in default_structure:
            if key not in extracted:
                extracted[key] = default_structure[key]
        
        return extracted
        
    except json.JSONDecodeError:
        return {
            "key_topics": [],
            "important_dates": [],
            "decisions_made": [],
            "action_items": [],
            "technical_terms": [],
            "people_mentioned": [],
            "organizations": [],
            "error": "Failed to parse extraction"
        }

def search_knowledge(search_term: str, category: Optional[str] = None, 
                    limit: int = 20) -> List[Dict[str, Any]]:
    """Search knowledge library"""
    
    try:
        # Build query
        query = """
            SELECT 
                k.id, k.title, k.content, k.category, k.tags,
                k.created_at, k.updated_at, k.query_id,
                q.tool, q.model, q.user_prompt
            FROM knowledge_units k
            LEFT JOIN queries q ON k.query_id = q.id
            WHERE 1=1
        """
        
        params = []
        
        # Add search condition
        if search_term:
            query += " AND (k.title ILIKE %s OR k.content ILIKE %s)"
            search_pattern = f"%{search_term}%"
            params.extend([search_pattern, search_pattern])
        
        # Add category filter
        if category and category != "All":
            query += " AND k.category = %s"
            params.append(category)
        
        query += " ORDER BY k.updated_at DESC LIMIT %s"
        params.append(limit)
        
        results = db.execute_query(query, params)
        
        return results if results else []
        
    except Exception as e:
        st.error(f"Search error: {e}")
        return []

def update_knowledge(knowledge_id: int, title: str, content: str, 
                    category: str, tags: List[str]) -> bool:
    """Update knowledge entry"""
    
    try:
        db.execute_query("""
            UPDATE knowledge_units
            SET title = %s, content = %s, category = %s, 
                tags = %s, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (title, content, category, tags, knowledge_id))
        
        return True
        
    except Exception as e:
        st.error(f"Update error: {e}")
        return False

def export_knowledge(knowledge_ids: List[int], format: str = "json") -> str:
    """Export knowledge entries"""
    
    try:
        # Fetch knowledge entries
        placeholders = ','.join(['%s'] * len(knowledge_ids))
        query = f"""
            SELECT * FROM knowledge_units 
            WHERE id IN ({placeholders})
        """
        
        results = db.execute_query(query, knowledge_ids)
        
        if not results:
            return ""
        
        if format == "json":
            # Convert datetime objects to strings
            for item in results:
                for key, value in item.items():
                    if isinstance(value, datetime):
                        item[key] = value.isoformat()
            
            return json.dumps(results, indent=2)
            
        elif format == "markdown":
            md_content = "# Knowledge Export\n\n"
            
            for item in results:
                md_content += f"## {item['title']}\n\n"
                md_content += f"**Category:** {item['category']}\n"
                md_content += f"**Created:** {item['created_at']}\n"
                if item.get('tags'):
                    md_content += f"**Tags:** {', '.join(item['tags'])}\n"
                md_content += f"\n{item['content']}\n\n---\n\n"
            
            return md_content
            
        else:
            # Plain text
            text_content = ""
            for item in results:
                text_content += f"{item['title']}\n"
                text_content += "=" * len(item['title']) + "\n\n"
                text_content += f"{item['content']}\n\n"
                text_content += "-" * 40 + "\n\n"
            
            return text_content
            
    except Exception as e:
        st.error(f"Export error: {e}")
        return ""

# ============== UI COMPONENTS ==============

def show_document_tools():
    """Document Tools UI"""
    st.header("📄 Document Tools")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Choose a document",
        type=DOC_CONFIG["supported_formats"],
        help=f"Supported formats: {', '.join(DOC_CONFIG['supported_formats'])}"
    )
    
    if uploaded_file:
        # Process file
        with st.spinner("Processing document..."):
            if uploaded_file.type == "application/pdf":
                document_text = extract_text_from_pdf(uploaded_file.read())
            else:
                document_text = extract_text_from_file(uploaded_file)
            
            if document_text:
                st.success(f"Processed {len(document_text)} characters from {uploaded_file.name}")
                st.session_state.document_text = document_text
                st.session_state.document_name = uploaded_file.name
            else:
                st.error("Failed to extract text from document")
                return
    
    # Tool selection
    if 'document_text' in st.session_state:
        tool_tabs = st.tabs(["❓ Q&A", "📝 Summarize", "🔍 Extract Knowledge"])
        
        with tool_tabs[0]:
            st.subheader("Document Q&A")
            
            # Question input
            question = st.text_input(
                "Ask a question about the document",
                placeholder="What is the main topic of this document?"
            )
            
            if st.button("🔍 Get Answer", disabled=not question):
                with st.spinner("Finding answer..."):
                    result = answer_document_question(
                        st.session_state.document_text,
                        question,
                        st.session_state.get("selected_model", DOC_CONFIG["default_model"])
                    )
                    
                    # Display answer
                    st.subheader("Answer")
                    st.write(result["answer"])
                    
                    # Show sources if available
                    if result["sources"]:
                        with st.expander(f"📌 Sources ({len(result['sources'])})"):
                            for i, source in enumerate(result["sources"]):
                                st.info(f"**Quote {i+1}:** \"{source['quote']}\"")
                                st.caption(f"Context: ...{source['context']}...")
                    
                    # Save to knowledge base
                    if st.button("💾 Save Answer"):
                        capture_knowledge(
                            tool_name="document_qa",
                            query=question,
                            response=result["answer"],
                            metadata={
                                "document": st.session_state.document_name,
                                "sources": len(result["sources"])
                            }
                        )
                        st.success("Answer saved to knowledge library!")
        
        with tool_tabs[1]:
            st.subheader("Document Summary")
            
            if st.button("📝 Generate Summary"):
                with st.spinner("Creating summary..."):
                    result = summarize_document(
                        st.session_state.document_text,
                        st.session_state.get("selected_model", DOC_CONFIG["default_model"])
                    )
                    
                    # Display summary
                    st.markdown(result["summary"])
                    
                    # Metrics
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Word Count", f"{result['word_count']:,}")
                    with col2:
                        st.metric("Reading Time", result["estimated_reading_time"])
                    
                    # Key points and action items
                    if result["key_points"]:
                        st.subheader("🔑 Key Points")
                        for point in result["key_points"]:
                            st.write(f"• {point}")
                    
                    if result["action_items"]:
                        st.subheader("✅ Action Items")
                        for item in result["action_items"]:
                            st.write(f"• {item}")
                    
                    # Save option
                    if st.button("💾 Save Summary"):
                        capture_knowledge(
                            tool_name="document_summary",
                            query=f"Summary of {st.session_state.document_name}",
                            response=result["summary"],
                            metadata={
                                "document": st.session_state.document_name,
                                "word_count": result["word_count"],
                                "key_points": len(result["key_points"])
                            }
                        )
                        st.success("Summary saved!")
        
        with tool_tabs[2]:
            st.subheader("Knowledge Extraction")
            
            if st.button("🔍 Extract Knowledge"):
                with st.spinner("Extracting structured information..."):
                    result = extract_knowledge(
                        st.session_state.document_text,
                        st.session_state.get("selected_model", DOC_CONFIG["default_model"])
                    )
                    
                    # Display extracted data
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        if result.get("key_topics"):
                            st.subheader("🏷️ Key Topics")
                            for topic in result["key_topics"]:
                                st.write(f"• {topic}")
                        
                        if result.get("technical_terms"):
                            st.subheader("🔧 Technical Terms")
                            for term in result["technical_terms"]:
                                st.write(f"• {term}")
                        
                        if result.get("people_mentioned"):
                            st.subheader("👥 People")
                            for person in result["people_mentioned"]:
                                st.write(f"• {person}")
                    
                    with col2:
                        if result.get("important_dates"):
                            st.subheader("📅 Important Dates")
                            for date in result["important_dates"]:
                                st.write(f"• {date}")
                        
                        if result.get("decisions_made"):
                            st.subheader("✓ Decisions")
                            for decision in result["decisions_made"]:
                                st.write(f"• {decision}")
                        
                        if result.get("organizations"):
                            st.subheader("🏢 Organizations")
                            for org in result["organizations"]:
                                st.write(f"• {org}")
                    
                    # Action items table
                    if result.get("action_items") and len(result["action_items"]) > 0:
                        st.subheader("📋 Action Items")
                        action_df = pd.DataFrame(result["action_items"])
                        st.dataframe(action_df, hide_index=True)
                    
                    # Export options
                    st.divider()
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.download_button(
                            "📥 Download as JSON",
                            json.dumps(result, indent=2),
                            file_name=f"extracted_{st.session_state.document_name}.json",
                            mime="application/json"
                        )
                    
                    with col2:
                        if st.button("💾 Save Extraction"):
                            capture_knowledge(
                                tool_name="knowledge_extraction",
                                query=f"Extraction from {st.session_state.document_name}",
                                response=json.dumps(result, indent=2),
                                metadata={
                                    "document": st.session_state.document_name,
                                    "topics": len(result.get("key_topics", [])),
                                    "action_items": len(result.get("action_items", []))
                                }
                            )
                            st.success("Extraction saved!")

def show_knowledge_library():
    """Knowledge Library UI"""
    st.header("📚 Knowledge Library")
    
    # Search and filters
    col1, col2, col3 = st.columns([3, 2, 1])
    
    with col1:
        search_term = st.text_input(
            "Search knowledge",
            placeholder="Search titles and content..."
        )
    
    with col2:
        categories = ["All"] + [info["icon"] + " " + cat.replace("_", " ").title() 
                               for cat in KNOWLEDGE_CATEGORIES.keys()]
        selected_category = st.selectbox("Category", categories)
        
        # Extract actual category from selection
        if selected_category != "All":
            actual_category = selected_category.split(" ", 1)[1].lower().replace(" ", "_")
        else:
            actual_category = None
    
    with col3:
        sort_order = st.selectbox("Sort by", ["Newest", "Oldest", "Title"])
    
    # Search button
    if st.button("🔍 Search", type="primary"):
        st.session_state.search_results = search_knowledge(search_term, actual_category)
    
    # Display results
    if 'search_results' not in st.session_state:
        # Default search on load
        st.session_state.search_results = search_knowledge("", None, 20)
    
    if st.session_state.search_results:
        st.info(f"Found {len(st.session_state.search_results)} items")
        
        # Bulk actions
        if st.checkbox("Enable bulk selection"):
            selected_items = []
            select_all = st.checkbox("Select all")
        
        # Display each knowledge item
        for item in st.session_state.search_results:
            # Category icon
            cat_info = KNOWLEDGE_CATEGORIES.get(item['category'], 
                                              {"icon": "📄", "description": ""})
            
            with st.expander(f"{cat_info['icon']} {item['title']}"):
                # Metadata
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.caption(f"Created: {item['created_at'].strftime('%Y-%m-%d %H:%M')}")
                    if item['updated_at'] != item['created_at']:
                        st.caption(f"Updated: {item['updated_at'].strftime('%Y-%m-%d %H:%M')}")
                    if item.get('tool'):
                        st.caption(f"Tool: {item['tool']}")
                
                with col2:
                    st.caption(f"Category: {item['category']}")
                
                # Content with proper formatting
                if item['category'] in ['code_snippet', 'algorithm', 'utility_function']:
                    st.code(item['content'], language="python")
                else:
                    st.markdown(item['content'])
                
                # Tags
                if item.get('tags'):
                    st.write("**Tags:**", ", ".join(item['tags']))
                
                # Actions
                action_cols = st.columns(6)
                
                with action_cols[0]:
                    if st.button("📋 Copy", key=f"copy_{item['id']}"):
                        st.toast("Copied to clipboard!", icon="✅")
                
                with action_cols[1]:
                    if st.button("✏️ Edit", key=f"edit_{item['id']}"):
                        st.session_state.editing_item = item
                
                with action_cols[2]:
                    if st.button("📥 Export", key=f"export_{item['id']}"):
                        content = export_knowledge([item['id']], "markdown")
                        st.download_button(
                            "Download",
                            content,
                            file_name=f"{item['title'].replace(' ', '_')}.md",
                            mime="text/markdown",
                            key=f"download_{item['id']}"
                        )
                
                with action_cols[3]:
                    if st.button("🔗 Share", key=f"share_{item['id']}"):
                        st.info(f"Share link: /knowledge/{item['id']}")
                
                with action_cols[4]:
                    if st.button("🏷️ Tag", key=f"tag_{item['id']}"):
                        st.session_state.tagging_item = item
                
                with action_cols[5]:
                    if st.button("🗑️ Delete", key=f"delete_{item['id']}", type="secondary"):
                        if st.checkbox(f"Confirm delete", key=f"confirm_{item['id']}"):
                            try:
                                db.execute_query(
                                    "DELETE FROM knowledge_units WHERE id = %s",
                                    (item['id'],)
                                )
                                st.success("Item deleted")
                                st.rerun()
                            except Exception as e:
                                st.error(f"Delete failed: {e}")
                
                # Bulk selection checkbox
                if 'selected_items' in locals():
                    if st.checkbox("Select", key=f"select_{item['id']}", value=select_all):
                        selected_items.append(item['id'])
        
        # Bulk actions
        if 'selected_items' in locals() and selected_items:
            st.divider()
            st.subheader(f"Bulk Actions ({len(selected_items)} items)")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("📥 Export Selected"):
                    content = export_knowledge(selected_items, "json")
                    st.download_button(
                        "Download JSON",
                        content,
                        file_name=f"knowledge_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json"
                    )
            
            with col2:
                new_category = st.selectbox(
                    "Change category to",
                    list(KNOWLEDGE_CATEGORIES.keys())
                )
                if st.button("🏷️ Update Category"):
                    try:
                        placeholders = ','.join(['%s'] * len(selected_items))
                        db.execute_query(
                            f"UPDATE knowledge_units SET category = %s WHERE id IN ({placeholders})",
                            [new_category] + selected_items
                        )
                        st.success(f"Updated {len(selected_items)} items")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Update failed: {e}")
            
            with col3:
                if st.button("🗑️ Delete Selected", type="secondary"):
                    if st.checkbox("Confirm bulk delete"):
                        try:
                            placeholders = ','.join(['%s'] * len(selected_items))
                            db.execute_query(
                                f"DELETE FROM knowledge_units WHERE id IN ({placeholders})",
                                selected_items
                            )
                            st.success(f"Deleted {len(selected_items)} items")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Delete failed: {e}")
    else:
        st.info("No knowledge items found. Start using TuoKit tools to build your library!")
    
    # Edit modal
    if 'editing_item' in st.session_state:
        item = st.session_state.editing_item
        
        with st.form("edit_form"):
            st.subheader(f"Edit: {item['title']}")
            
            new_title = st.text_input("Title", value=item['title'])
            new_category = st.selectbox(
                "Category",
                list(KNOWLEDGE_CATEGORIES.keys()),
                index=list(KNOWLEDGE_CATEGORIES.keys()).index(item['category'])
            )
            new_content = st.text_area("Content", value=item['content'], height=300)
            
            current_tags = item.get('tags', [])
            new_tags = st.text_input(
                "Tags (comma separated)",
                value=", ".join(current_tags) if current_tags else ""
            )
            
            col1, col2 = st.columns(2)
            
            with col1:
                if st.form_submit_button("💾 Save Changes", type="primary"):
                    tags_list = [t.strip() for t in new_tags.split(",") if t.strip()]
                    
                    if update_knowledge(
                        item['id'],
                        new_title,
                        new_content,
                        new_category,
                        tags_list
                    ):
                        st.success("Changes saved!")
                        del st.session_state.editing_item
                        st.rerun()
            
            with col2:
                if st.form_submit_button("Cancel"):
                    del st.session_state.editing_item
                    st.rerun()

def show_help_guide():
    """Help Guide UI"""
    st.header("❓ Help Guide")
    
    # Topic navigation
    col1, col2 = st.columns([1, 3])
    
    with col1:
        st.subheader("Topics")
        selected_topic = st.radio(
            "Select a topic",
            list(HELP_TOPICS.keys()),
            format_func=lambda x: HELP_TOPICS[x]["title"],
            label_visibility="collapsed"
        )
    
    with col2:
        if selected_topic:
            topic = HELP_TOPICS[selected_topic]
            
            st.title(topic["title"])
            
            # Section tabs
            sections = list(topic["sections"].keys())
            tabs = st.tabs([topic["sections"][s]["title"] for s in sections])
            
            for i, (section_key, tab) in enumerate(zip(sections, tabs)):
                with tab:
                    section = topic["sections"][section_key]
                    st.markdown(section["content"])
                    
                    # Additional features for specific sections
                    if section_key == "requirements" and selected_topic == "getting_started":
                        if st.button("🔍 Check System"):
                            with st.spinner("Checking system requirements..."):
                                # Check Python version
                                import sys
                                py_version = f"{sys.version_info.major}.{sys.version_info.minor}"
                                
                                # Check RAM (approximate)
                                import psutil
                                ram_gb = psutil.virtual_memory().total / (1024**3)
                                
                                col1, col2 = st.columns(2)
                                with col1:
                                    st.metric("Python Version", py_version)
                                    st.metric("RAM", f"{ram_gb:.1f} GB")
                                
                                with col2:
                                    st.metric("OS", sys.platform)
                                    
                                    # Check disk space
                                    disk_usage = psutil.disk_usage('/')
                                    free_gb = disk_usage.free / (1024**3)
                                    st.metric("Free Disk", f"{free_gb:.1f} GB")
    
    # Quick search
    st.divider()
    st.subheader("🔍 Quick Search")
    
    help_search = st.text_input(
        "Search help topics",
        placeholder="Enter keywords..."
    )
    
    if help_search:
        st.write("### Search Results")
        
        found = False
        for topic_key, topic in HELP_TOPICS.items():
            for section_key, section in topic["sections"].items():
                if (help_search.lower() in section["title"].lower() or 
                    help_search.lower() in section["content"].lower()):
                    
                    found = True
                    with st.expander(f"{topic['title']} > {section['title']}"):
                        # Highlight search term
                        content = section["content"]
                        highlighted = content.replace(
                            help_search,
                            f"**{help_search}**"
                        )
                        st.markdown(highlighted)
        
        if not found:
            st.info("No results found. Try different keywords.")
    
    # Feedback section
    st.divider()
    st.subheader("📧 Feedback")
    
    feedback_type = st.selectbox(
        "Feedback Type",
        ["Question", "Bug Report", "Feature Request", "Documentation Issue"]
    )
    
    feedback_text = st.text_area(
        "Your feedback",
        placeholder="Describe your issue or suggestion..."
    )
    
    if st.button("📤 Send Feedback", disabled=not feedback_text):
        # In a real app, this would send to a feedback system
        st.success("Thank you for your feedback! We'll review it soon.")
        
        # Save feedback locally
        feedback_data = {
            "type": feedback_type,
            "content": feedback_text,
            "timestamp": datetime.now().isoformat()
        }
        
        # You could save this to database or file
        st.json(feedback_data)

# ============== MAIN APPLICATION ==============

def main(standalone=True):
    # Only set page config if running standalone (not from unified app)
    if standalone:
        try:
            st.set_page_config(
                page_title="Documentation Toolkit",
                page_icon="📚",
                layout="wide",
                initial_sidebar_state="expanded"
            )
        except:
            # Page config already set (running from unified app)
            pass
    
    # Custom CSS
    st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
            background-color: #2196F3;
        }
        .doc-card {
            background-color: #1e1e1e;
            padding: 1.5rem;
            border-radius: 0.5rem;
            border: 1px solid #333;
            margin-bottom: 1rem;
        }
        .help-section {
            border-left: 4px solid #2196F3;
            padding-left: 1rem;
            margin-bottom: 1rem;
        }
        pre {
            background-color: #0d1117;
            padding: 1rem;
            border-radius: 0.5rem;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.title("📚 Documentation Toolkit")
        
        # Tool selection
        tool = st.radio(
            "Select Tool",
            ["Document Tools", "Knowledge Library", "Help Guide"],
            help="Choose your documentation tool"
        )
        
        st.divider()
        
        # Model selection
        st.subheader("⚙️ Settings")
        models = get_available_models()
        if models:
            selected_model = st.selectbox("AI Model", models)
            st.session_state.selected_model = selected_model
        else:
            st.error("No models available")
        
        # Configuration
        st.subheader("📋 Configuration")
        
        chunk_size = st.slider(
            "Chunk Size",
            1000, 5000, DOC_CONFIG["chunk_size"],
            step=500,
            help="Size of document chunks for processing"
        )
        DOC_CONFIG["chunk_size"] = chunk_size
        
        enable_source = st.checkbox(
            "Enable source tracking",
            value=DOC_CONFIG["enable_source_tracking"]
        )
        DOC_CONFIG["enable_source_tracking"] = enable_source
        
        # Stats
        st.divider()
        st.subheader("📊 Statistics")
        
        try:
            # Knowledge count
            count_result = db.execute_query(
                "SELECT COUNT(*) as count FROM knowledge_units"
            )
            if count_result:
                st.metric("Knowledge Items", count_result[0]['count'])
            
            # Recent activity
            recent = db.execute_query("""
                SELECT tool, COUNT(*) as count
                FROM queries
                WHERE created_at > CURRENT_TIMESTAMP - INTERVAL '7 days'
                GROUP BY tool
                ORDER BY count DESC
                LIMIT 3
            """)
            
            if recent:
                st.caption("**Recent Activity:**")
                for item in recent:
                    st.caption(f"{item['tool']}: {item['count']} uses")
                    
        except Exception as e:
            st.error(f"Error loading stats: {e}")
        
        # Links
        st.divider()
        st.subheader("🔗 Quick Links")
        st.markdown("""
        - [Documentation](https://github.com/yourusername/tuokit/wiki)
        - [API Reference](#api_reference)
        - [Report Issue](https://github.com/yourusername/tuokit/issues)
        """)
    
    # Main content
    if tool == "Document Tools":
        show_document_tools()
    elif tool == "Knowledge Library":
        show_knowledge_library()
    elif tool == "Help Guide":
        show_help_guide()
    
    # Footer
    st.divider()
    st.caption("Documentation Toolkit v2.0 - Knowledge Management System")

if __name__ == "__main__":
    main()
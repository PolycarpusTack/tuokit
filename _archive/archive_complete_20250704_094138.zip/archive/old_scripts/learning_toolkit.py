"""
TuoKit - Learning Toolkit (Consolidated Edition)
Combines EduMind, Study Guide Generator, and SQL Academy
"""

import streamlit as st
import json
import hashlib
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Set
import pandas as pd
from pathlib import Path
import plotly.express as px
import plotly.graph_objects as go
from utils import (
    DatabaseManager,
    safe_ollama_generate,
    capture_knowledge,
    extract_text_from_file,
    extract_text_from_url,
    get_available_models
)

# Initialize database
db = DatabaseManager()

# ============== CONFIGURATION ==============
LEARNING_CONFIG = {
    "default_model": "deepseek-r1:latest",
    "temperature": 0.3,
    "max_tokens": 4000,
    "spaced_intervals": [1, 3, 7, 14, 30, 60],  # Days
    "difficulty_levels": ["Beginner", "Intermediate", "Advanced"],
    "learning_objectives": ["Quick Review", "Deep Understanding", "Exam Preparation"],
    "enable_validation": True
}

# ============== DATA STRUCTURES ==============

# SQL Concepts Library
SQL_CONCEPTS = {
    "basic_select": {
        "name": "Basic SELECT Queries",
        "description": "Retrieving data from single tables using SELECT statements",
        "difficulty": "Beginner",
        "category": "Query",
        "prerequisites": [],
        "examples": [
            "SELECT * FROM users;",
            "SELECT name, email FROM users WHERE age > 18;",
            "SELECT DISTINCT city FROM users;"
        ],
        "resources": [
            {"title": "W3Schools SQL SELECT", "url": "https://www.w3schools.com/sql/sql_select.asp"}
        ]
    },
    "joins": {
        "name": "SQL Joins",
        "description": "Combining data from multiple tables using various join types",
        "difficulty": "Intermediate",
        "category": "Query",
        "prerequisites": ["basic_select"],
        "examples": [
            "SELECT u.name, o.total FROM users u INNER JOIN orders o ON u.id = o.user_id;",
            "SELECT * FROM users LEFT JOIN orders ON users.id = orders.user_id;"
        ],
        "resources": [
            {"title": "Visual Guide to SQL Joins", "url": "https://blog.codinghorror.com/a-visual-explanation-of-sql-joins/"}
        ]
    },
    "aggregation": {
        "name": "Aggregation Functions",
        "description": "Using COUNT, SUM, AVG, MAX, MIN with GROUP BY and HAVING",
        "difficulty": "Intermediate",
        "category": "Query",
        "prerequisites": ["basic_select"],
        "examples": [
            "SELECT city, COUNT(*) FROM users GROUP BY city;",
            "SELECT department, AVG(salary) FROM employees GROUP BY department HAVING AVG(salary) > 50000;"
        ],
        "resources": []
    },
    "subqueries": {
        "name": "Subqueries",
        "description": "Nested queries for complex data retrieval",
        "difficulty": "Advanced",
        "category": "Query",
        "prerequisites": ["basic_select", "joins"],
        "examples": [
            "SELECT name FROM users WHERE id IN (SELECT user_id FROM orders WHERE total > 100);",
            "SELECT * FROM products WHERE price > (SELECT AVG(price) FROM products);"
        ],
        "resources": []
    },
    "indexes": {
        "name": "Database Indexes",
        "description": "Creating and using indexes for query optimization",
        "difficulty": "Advanced",
        "category": "Performance",
        "prerequisites": ["basic_select"],
        "examples": [
            "CREATE INDEX idx_users_email ON users(email);",
            "CREATE UNIQUE INDEX idx_username ON users(username);",
            "EXPLAIN SELECT * FROM users WHERE email = 'test@example.com';"
        ],
        "resources": []
    },
    "transactions": {
        "name": "Transactions",
        "description": "Managing data consistency with BEGIN, COMMIT, and ROLLBACK",
        "difficulty": "Advanced",
        "category": "Data Integrity",
        "prerequisites": ["basic_select"],
        "examples": [
            "BEGIN; UPDATE accounts SET balance = balance - 100 WHERE id = 1; UPDATE accounts SET balance = balance + 100 WHERE id = 2; COMMIT;"
        ],
        "resources": []
    }
}

# Study Material Categories
STUDY_CATEGORIES = {
    "summary": {"icon": "📝", "description": "Key points and overview"},
    "flashcards": {"icon": "🎴", "description": "Question-answer pairs for memorization"},
    "quiz": {"icon": "❓", "description": "Multiple choice questions"},
    "key_terms": {"icon": "📖", "description": "Important terminology"},
    "practice": {"icon": "💪", "description": "Hands-on exercises"}
}

# ============== CORE FUNCTIONS ==============

def knowledge_assistant(content: str, mode: str, difficulty: str = "Intermediate", 
                       objective: str = "Deep Understanding", model: str = LEARNING_CONFIG["default_model"]) -> str:
    """Unified educational content generator"""
    
    modes = {
        "study_guide": f"""Create a comprehensive study guide for {difficulty} level with objective: {objective}.
Include:
1. Executive summary (3-5 key points)
2. Detailed explanations with examples
3. Common misconceptions
4. Practice exercises
5. Review checklist""",
        
        "practice_quiz": f"""Generate 5 {difficulty} level multiple-choice questions.
For each question include:
- Clear question text
- 4 answer options (A, B, C, D)
- Correct answer
- Detailed explanation of why each option is correct/incorrect""",
        
        "concept_explanation": f"""Explain this concept for {difficulty} level learners.
Structure:
1. Simple explanation (ELI5 style)
2. Technical explanation with proper terminology
3. Real-world applications
4. Common pitfalls
5. Related concepts""",
        
        "flashcards": f"""Create 10 flashcards for {difficulty} level.
Format each as:
FRONT: [Question or prompt]
BACK: [Answer with brief explanation]""",
        
        "learning_path": f"""Design a learning path for mastering this topic at {difficulty} level.
Include:
1. Prerequisites
2. Learning sequence (ordered topics)
3. Time estimates
4. Milestones
5. Assessment checkpoints"""
    }
    
    prompt = f"""
{modes.get(mode, modes['study_guide'])}

Content to process:
{content}
"""
    
    response = safe_ollama_generate(model, prompt, temperature=LEARNING_CONFIG["temperature"])
    
    if isinstance(response, dict):
        return response.get('response', 'Generation failed')
    return str(response)

def validate_accuracy(generated_content: str, source_content: str, model: str = LEARNING_CONFIG["default_model"]) -> Dict[str, Any]:
    """Validate generated content against source material"""
    
    prompt = f"""
Compare the generated educational content with the source material and evaluate:

1. Factual accuracy (0-100%)
2. Completeness (0-100%)
3. Any inaccuracies or missing important information

Source Material:
{source_content[:2000]}...

Generated Content:
{generated_content[:2000]}...

Respond in JSON format:
{{
    "accuracy_score": 0-100,
    "completeness_score": 0-100,
    "issues": ["list of any issues found"],
    "missing_topics": ["important topics not covered"]
}}
"""
    
    response = safe_ollama_generate(model, prompt, format="json")
    
    try:
        if isinstance(response, dict):
            result = json.loads(response.get('response', '{}'))
        else:
            result = json.loads(str(response))
        
        return {
            "accuracy_score": result.get("accuracy_score", 85),
            "completeness_score": result.get("completeness_score", 80),
            "issues": result.get("issues", []),
            "missing_topics": result.get("missing_topics", [])
        }
    except:
        return {
            "accuracy_score": 85,
            "completeness_score": 80,
            "issues": [],
            "missing_topics": []
        }

def parse_study_materials(response: str, material_type: str) -> List[Dict[str, Any]]:
    """Parse AI response into structured study materials"""
    
    materials = []
    
    if material_type == "flashcards":
        # Parse flashcard format
        pattern = r'FRONT:\s*(.+?)\s*BACK:\s*(.+?)(?=FRONT:|$)'
        matches = re.findall(pattern, response, re.DOTALL | re.IGNORECASE)
        
        for front, back in matches:
            materials.append({
                "front": front.strip(),
                "back": back.strip()
            })
    
    elif material_type == "quiz":
        # Parse quiz questions
        questions = re.split(r'\n\s*\d+[\.\)]\s*', response)
        
        for q in questions[1:]:  # Skip first empty split
            lines = q.strip().split('\n')
            if len(lines) >= 5:
                question_text = lines[0]
                options = []
                correct = None
                explanation = ""
                
                for line in lines[1:]:
                    if re.match(r'^[A-D][\.\)]\s*', line):
                        options.append(line)
                    elif 'correct' in line.lower() or 'answer' in line.lower():
                        # Extract correct answer
                        correct_match = re.search(r'[A-D]', line)
                        if correct_match:
                            correct = correct_match.group()
                    elif 'explanation' in line.lower() or 'because' in line.lower():
                        explanation = line
                
                if question_text and len(options) >= 2:
                    materials.append({
                        "question": question_text,
                        "options": options,
                        "correct": correct or "A",
                        "explanation": explanation
                    })
    
    elif material_type == "key_terms":
        # Parse key terms
        pattern = r'(?:^|\n)([^:]+):\s*([^\n]+(?:\n(?!\w+:)[^\n]+)*)'
        matches = re.findall(pattern, response, re.MULTILINE)
        
        for term, definition in matches:
            term = term.strip('- •*')
            if term and definition:
                materials.append({
                    "term": term.strip(),
                    "definition": definition.strip()
                })
    
    return materials

def calculate_spaced_repetition(last_review: datetime, interval_index: int, 
                               performance: float = 1.0) -> Tuple[datetime, int]:
    """Calculate next review date using spaced repetition algorithm"""
    
    intervals = LEARNING_CONFIG["spaced_intervals"]
    
    # Adjust interval based on performance
    if performance >= 0.8:
        # Good performance - proceed to next interval
        next_interval_index = min(interval_index + 1, len(intervals) - 1)
    elif performance >= 0.6:
        # OK performance - repeat current interval
        next_interval_index = interval_index
    else:
        # Poor performance - go back one interval
        next_interval_index = max(interval_index - 1, 0)
    
    days_until_next = intervals[next_interval_index]
    next_review = last_review + timedelta(days=days_until_next)
    
    return next_review, next_interval_index

def analyze_sql_query(query: str) -> List[str]:
    """Analyze SQL query and identify concepts used"""
    
    query_upper = query.upper()
    concepts_found = []
    
    # Check for each concept
    concept_patterns = {
        "basic_select": [r'\bSELECT\b', r'\bFROM\b', r'\bWHERE\b'],
        "joins": [r'\bJOIN\b', r'\bINNER\s+JOIN\b', r'\bLEFT\s+JOIN\b', r'\bRIGHT\s+JOIN\b'],
        "aggregation": [r'\bCOUNT\b', r'\bSUM\b', r'\bAVG\b', r'\bGROUP\s+BY\b', r'\bHAVING\b'],
        "subqueries": [r'\bIN\s*\(SELECT\b', r'\bEXISTS\s*\(', r'\(\s*SELECT\b'],
        "indexes": [r'\bCREATE\s+INDEX\b', r'\bDROP\s+INDEX\b', r'\bEXPLAIN\b'],
        "transactions": [r'\bBEGIN\b', r'\bCOMMIT\b', r'\bROLLBACK\b', r'\bSTART\s+TRANSACTION\b']
    }
    
    for concept_id, patterns in concept_patterns.items():
        for pattern in patterns:
            if re.search(pattern, query_upper):
                concepts_found.append(concept_id)
                break
    
    return list(set(concepts_found))

def generate_learning_path(target_concept: str, current_knowledge: Set[str] = None) -> List[Dict[str, Any]]:
    """Generate personalized learning path to reach target concept"""
    
    if current_knowledge is None:
        current_knowledge = set()
    
    path = []
    to_learn = set()
    
    # Recursive function to find all prerequisites
    def add_prerequisites(concept_id):
        if concept_id not in SQL_CONCEPTS:
            return
        
        concept = SQL_CONCEPTS[concept_id]
        for prereq in concept["prerequisites"]:
            if prereq not in current_knowledge and prereq not in to_learn:
                add_prerequisites(prereq)
                to_learn.add(prereq)
    
    # Add target and its prerequisites
    add_prerequisites(target_concept)
    to_learn.add(target_concept)
    
    # Sort by difficulty
    difficulty_order = {"Beginner": 0, "Intermediate": 1, "Advanced": 2}
    sorted_concepts = sorted(
        to_learn,
        key=lambda x: difficulty_order.get(SQL_CONCEPTS[x]["difficulty"], 0)
    )
    
    # Build path
    for concept_id in sorted_concepts:
        if concept_id in SQL_CONCEPTS:
            concept = SQL_CONCEPTS[concept_id]
            path.append({
                "id": concept_id,
                "name": concept["name"],
                "difficulty": concept["difficulty"],
                "estimated_time": "30-60 minutes",
                "prerequisites_met": all(p in current_knowledge for p in concept["prerequisites"])
            })
    
    return path

def track_learning_progress(user_id: str, topic: str, score: float, 
                          material_type: str = "quiz") -> Dict[str, Any]:
    """Track user's learning progress"""
    
    try:
        # Record progress
        db.execute_query("""
            INSERT INTO learning_progress 
            (user_id, topic, score, material_type, timestamp)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, topic, score, material_type, datetime.now()))
        
        # Calculate streak
        recent_days = db.execute_query("""
            SELECT DISTINCT DATE(timestamp) as day
            FROM learning_progress
            WHERE user_id = %s
            ORDER BY day DESC
            LIMIT 30
        """, (user_id,))
        
        streak = 0
        if recent_days:
            # Count consecutive days
            last_date = None
            for row in recent_days:
                current_date = row['day']
                if last_date is None:
                    streak = 1
                elif (last_date - current_date).days == 1:
                    streak += 1
                else:
                    break
                last_date = current_date
        
        # Get overall stats
        stats = db.execute_query("""
            SELECT 
                COUNT(*) as total_sessions,
                AVG(score) as avg_score,
                COUNT(DISTINCT topic) as topics_studied
            FROM learning_progress
            WHERE user_id = %s
        """, (user_id,))
        
        return {
            "streak": streak,
            "total_sessions": stats[0]['total_sessions'] if stats else 0,
            "avg_score": stats[0]['avg_score'] if stats else 0,
            "topics_studied": stats[0]['topics_studied'] if stats else 0
        }
        
    except Exception as e:
        st.error(f"Error tracking progress: {e}")
        return {"streak": 0, "total_sessions": 0, "avg_score": 0, "topics_studied": 0}

# ============== UI COMPONENTS ==============

def show_edumind():
    """EduMind Adaptive Learning UI"""
    st.header("🧠 EduMind Adaptive Learning")
    
    # Learning configuration
    col1, col2, col3 = st.columns(3)
    with col1:
        mode = st.selectbox(
            "Learning Mode",
            ["study_guide", "practice_quiz", "concept_explanation", "flashcards", "learning_path"],
            format_func=lambda x: x.replace("_", " ").title()
        )
    
    with col2:
        difficulty = st.selectbox("Difficulty", LEARNING_CONFIG["difficulty_levels"])
    
    with col3:
        objective = st.selectbox("Learning Objective", LEARNING_CONFIG["learning_objectives"])
    
    # Input methods
    with st.expander("📥 Input Learning Materials", expanded=True):
        input_method = st.radio("Source", ["Text", "URL", "Upload"], horizontal=True)
        
        content = None
        
        if input_method == "Text":
            content = st.text_area(
                "Enter your learning material",
                height=200,
                placeholder="Paste text, code, or concepts you want to learn..."
            )
        
        elif input_method == "URL":
            url = st.text_input("Enter URL", placeholder="https://example.com/article")
            if url and st.button("🔗 Extract Content"):
                with st.spinner("Extracting content..."):
                    content = extract_text_from_url(url)
                    if content:
                        st.success(f"Extracted {len(content)} characters")
                    else:
                        st.error("Failed to extract content")
        
        elif input_method == "Upload":
            uploaded_file = st.file_uploader(
                "Choose a file",
                type=['pdf', 'txt', 'docx'],
                help="Upload a document to create learning materials"
            )
            if uploaded_file:
                with st.spinner("Processing file..."):
                    content = extract_text_from_file(uploaded_file)
                    if content:
                        st.success(f"Processed {len(content)} characters")
    
    # Generate learning materials
    if content and st.button("🚀 Generate Learning Materials", type="primary"):
        with st.spinner(f"Creating {mode.replace('_', ' ')}..."):
            # Generate content
            result = knowledge_assistant(content, mode, difficulty, objective)
            
            # Validate if enabled
            validation = None
            if LEARNING_CONFIG["enable_validation"] and mode != "learning_path":
                validation = validate_accuracy(result, content)
            
            # Store results
            st.session_state.learning_result = result
            st.session_state.learning_validation = validation
            st.session_state.source_content = content
            
            # Track progress
            if 'user_id' not in st.session_state:
                st.session_state.user_id = hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]
            
            # Save to knowledge base
            capture_knowledge(
                tool_name="edumind",
                query=content[:200] + "...",
                response=result,
                metadata={
                    "mode": mode,
                    "difficulty": difficulty,
                    "objective": objective,
                    "validation": validation
                }
            )
    
    # Display results
    if 'learning_result' in st.session_state:
        st.divider()
        
        # Validation metrics
        if st.session_state.learning_validation:
            val = st.session_state.learning_validation
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Accuracy", f"{val['accuracy_score']}%")
            with col2:
                st.metric("Completeness", f"{val['completeness_score']}%")
            with col3:
                issues_count = len(val['issues']) + len(val['missing_topics'])
                st.metric("Issues", issues_count)
            
            if issues_count > 0:
                with st.expander("⚠️ Validation Issues"):
                    if val['issues']:
                        st.warning("**Potential Inaccuracies:**")
                        for issue in val['issues']:
                            st.write(f"- {issue}")
                    if val['missing_topics']:
                        st.info("**Missing Topics:**")
                        for topic in val['missing_topics']:
                            st.write(f"- {topic}")
        
        # Display content based on mode
        st.subheader("📚 Generated Learning Materials")
        
        if 'learning_result' in st.session_state:
            result = st.session_state.learning_result
            
            # Parse and display based on type
            if mode == "flashcards":
                flashcards = parse_study_materials(result, "flashcards")
                if flashcards:
                    for i, card in enumerate(flashcards):
                        with st.expander(f"Card {i+1}: {card['front'][:50]}..."):
                            st.info(f"**Front:** {card['front']}")
                            st.success(f"**Back:** {card['back']}")
                else:
                    st.markdown(result)
            
            elif mode == "practice_quiz":
                quiz_questions = parse_study_materials(result, "quiz")
                if quiz_questions:
                    score = 0
                    for i, q in enumerate(quiz_questions):
                        st.subheader(f"Question {i+1}")
                        st.write(q['question'])
                        
                        user_answer = st.radio(
                            "Select your answer:",
                            q['options'],
                            key=f"quiz_{i}"
                        )
                        
                        if st.button(f"Check Answer", key=f"check_{i}"):
                            if user_answer and user_answer[0] == q['correct']:
                                st.success("✅ Correct!")
                                score += 1
                            else:
                                st.error(f"❌ Incorrect. The correct answer is {q['correct']}")
                            
                            st.info(f"**Explanation:** {q['explanation']}")
                    
                    if st.button("📊 View Score"):
                        st.metric("Your Score", f"{score}/{len(quiz_questions)}")
                        track_learning_progress(
                            st.session_state.user_id,
                            "quiz",
                            score / len(quiz_questions)
                        )
                else:
                    st.markdown(result)
            
            else:
                st.markdown(result)
            
            # Export options
            st.divider()
            col1, col2 = st.columns(2)
            with col1:
                st.download_button(
                    "📥 Download as Text",
                    result,
                    file_name=f"{mode}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )
            
            with col2:
                if st.button("🔄 Schedule Review"):
                    next_review, _ = calculate_spaced_repetition(datetime.now(), 0)
                    st.info(f"Next review scheduled for: {next_review.strftime('%Y-%m-%d')}")

def show_study_guide_generator():
    """Study Guide Generator UI"""
    st.header("📖 Study Guide Generator")
    
    # Content input
    content = st.text_area(
        "Enter content to study",
        height=200,
        placeholder="Paste your learning material, lecture notes, or article text..."
    )
    
    # Configuration
    col1, col2 = st.columns(2)
    with col1:
        difficulty = st.selectbox("Difficulty Level", LEARNING_CONFIG["difficulty_levels"])
    with col2:
        include_practice = st.checkbox("Include practice problems", value=True)
    
    # Material types to generate
    st.subheader("📋 Select Materials to Generate")
    material_cols = st.columns(4)
    materials_to_generate = {}
    
    for i, (key, info) in enumerate(STUDY_CATEGORIES.items()):
        with material_cols[i % 4]:
            materials_to_generate[key] = st.checkbox(
                f"{info['icon']} {key.title()}",
                value=True,
                help=info['description']
            )
    
    # Generate button
    if st.button("📚 Generate Study Guide", type="primary", disabled=not content):
        with st.spinner("Creating comprehensive study materials..."):
            generated_materials = {}
            
            # Generate each requested material type
            for material_type, should_generate in materials_to_generate.items():
                if should_generate:
                    if material_type == "summary":
                        result = knowledge_assistant(content, "study_guide", difficulty)
                    elif material_type == "flashcards":
                        result = knowledge_assistant(content, "flashcards", difficulty)
                    elif material_type == "quiz":
                        result = knowledge_assistant(content, "practice_quiz", difficulty)
                    elif material_type == "key_terms":
                        result = knowledge_assistant(content, "concept_explanation", difficulty)
                    else:
                        result = knowledge_assistant(content, "study_guide", difficulty)
                    
                    generated_materials[material_type] = {
                        "raw": result,
                        "parsed": parse_study_materials(result, material_type)
                    }
            
            st.session_state.study_materials = generated_materials
            
            # Save to knowledge base
            capture_knowledge(
                tool_name="study_guide_generator",
                query=content[:200] + "...",
                response=json.dumps({
                    "materials": list(generated_materials.keys()),
                    "difficulty": difficulty
                }),
                metadata={
                    "difficulty": difficulty,
                    "material_count": len(generated_materials)
                }
            )
    
    # Display generated materials
    if 'study_materials' in st.session_state:
        st.divider()
        st.subheader("📚 Your Study Guide")
        
        # Create tabs for different materials
        available_materials = list(st.session_state.study_materials.keys())
        if available_materials:
            tabs = st.tabs([STUDY_CATEGORIES[m]["icon"] + " " + m.title() for m in available_materials])
            
            for i, (material_type, tab) in enumerate(zip(available_materials, tabs)):
                with tab:
                    material_data = st.session_state.study_materials[material_type]
                    
                    if material_type == "flashcards" and material_data["parsed"]:
                        # Display flashcards
                        st.subheader("🎴 Flashcards")
                        for j, card in enumerate(material_data["parsed"]):
                            with st.expander(f"Card {j+1}"):
                                st.info(f"**Q:** {card['front']}")
                                st.success(f"**A:** {card['back']}")
                    
                    elif material_type == "quiz" and material_data["parsed"]:
                        # Display quiz
                        st.subheader("❓ Practice Quiz")
                        for j, q in enumerate(material_data["parsed"]):
                            st.write(f"**{j+1}.** {q['question']}")
                            for option in q['options']:
                                st.write(f"   {option}")
                            
                            with st.expander("Show Answer"):
                                st.success(f"Correct: {q['correct']}")
                                st.info(q['explanation'])
                    
                    elif material_type == "key_terms" and material_data["parsed"]:
                        # Display key terms
                        st.subheader("📖 Key Terms")
                        for term_data in material_data["parsed"]:
                            st.markdown(f"**{term_data['term']}**: {term_data['definition']}")
                    
                    else:
                        # Display raw content
                        st.markdown(material_data["raw"])
            
            # Export options
            st.divider()
            export_cols = st.columns(3)
            
            with export_cols[0]:
                # Export as text
                all_content = "\n\n".join([
                    f"=== {m.upper()} ===\n{data['raw']}"
                    for m, data in st.session_state.study_materials.items()
                ])
                st.download_button(
                    "📄 Export as Text",
                    all_content,
                    file_name=f"study_guide_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
                    mime="text/plain"
                )
            
            with export_cols[1]:
                # Export as JSON
                export_data = {
                    "generated_at": datetime.now().isoformat(),
                    "difficulty": difficulty,
                    "materials": {
                        m: data["parsed"] if data["parsed"] else data["raw"]
                        for m, data in st.session_state.study_materials.items()
                    }
                }
                st.download_button(
                    "📊 Export as JSON",
                    json.dumps(export_data, indent=2),
                    file_name=f"study_guide_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json"
                )
            
            with export_cols[2]:
                # Schedule review
                if st.button("📅 Add to Review Schedule"):
                    st.success("Added to your spaced repetition schedule!")
                    next_review, _ = calculate_spaced_repetition(datetime.now(), 0)
                    st.info(f"First review: {next_review.strftime('%Y-%m-%d')}")

def show_sql_academy():
    """SQL Academy Learning Platform UI"""
    st.header("🎓 SQL Academy")
    
    # Main tabs
    tab_learn, tab_analyze, tab_quiz, tab_path, tab_progress = st.tabs([
        "📖 Learn Concepts",
        "🔍 Analyze Query",
        "🧩 Practice Quiz",
        "🗺️ Learning Path",
        "📊 Progress"
    ])
    
    with tab_learn:
        st.subheader("📚 SQL Concepts Library")
        
        # Filter concepts
        col1, col2 = st.columns(2)
        with col1:
            difficulty_filter = st.multiselect(
                "Difficulty",
                ["Beginner", "Intermediate", "Advanced"],
                default=["Beginner", "Intermediate"]
            )
        with col2:
            category_filter = st.multiselect(
                "Category",
                ["Query", "Performance", "Data Integrity", "Security"],
                default=["Query"]
            )
        
        # Display concepts
        for concept_id, concept in SQL_CONCEPTS.items():
            if (concept["difficulty"] in difficulty_filter and 
                concept["category"] in category_filter):
                
                # Difficulty color
                diff_colors = {
                    "Beginner": "🟢",
                    "Intermediate": "🟡",
                    "Advanced": "🔴"
                }
                
                with st.expander(
                    f"{diff_colors[concept['difficulty']]} {concept['name']} ({concept['category']})"
                ):
                    st.markdown(f"**Description:** {concept['description']}")
                    
                    if concept["prerequisites"]:
                        st.info(f"**Prerequisites:** {', '.join(concept['prerequisites'])}")
                    
                    st.subheader("Examples:")
                    for example in concept["examples"]:
                        st.code(example, language="sql")
                    
                    if concept["resources"]:
                        st.subheader("Resources:")
                        for resource in concept["resources"]:
                            st.markdown(f"- [{resource['title']}]({resource['url']})")
                    
                    # Practice button
                    if st.button(f"Practice {concept['name']}", key=f"practice_{concept_id}"):
                        st.session_state.practice_concept = concept_id
                        st.info("Go to the Practice Quiz tab to test your knowledge!")
    
    with tab_analyze:
        st.subheader("🔍 Query Analyzer")
        
        query_input = st.text_area(
            "Enter your SQL query",
            height=150,
            placeholder="SELECT * FROM users WHERE age > 18..."
        )
        
        if st.button("🔍 Analyze Query", disabled=not query_input):
            # Analyze concepts
            concepts_found = analyze_sql_query(query_input)
            
            if concepts_found:
                st.success(f"Found {len(concepts_found)} SQL concepts in your query:")
                
                for concept_id in concepts_found:
                    if concept_id in SQL_CONCEPTS:
                        concept = SQL_CONCEPTS[concept_id]
                        st.info(f"**{concept['name']}** ({concept['difficulty']})")
                        st.write(concept['description'])
                
                # Generate explanation
                with st.spinner("Generating detailed explanation..."):
                    explanation = safe_ollama_generate(
                        st.session_state.get("selected_model", LEARNING_CONFIG["default_model"]),
                        f"""Explain this SQL query in detail, focusing on the concepts used:
                        
                        {query_input}
                        
                        Cover:
                        1. What the query does
                        2. SQL concepts demonstrated
                        3. Performance considerations
                        4. Best practices
                        """,
                        temperature=0.3
                    )
                    
                    st.subheader("📝 Detailed Explanation")
                    if isinstance(explanation, dict):
                        st.markdown(explanation.get('response', ''))
                    else:
                        st.markdown(str(explanation))
            else:
                st.warning("No specific SQL concepts detected. Try a more complex query!")
    
    with tab_quiz:
        st.subheader("🧩 SQL Practice Quiz")
        
        # Select concept to practice
        if 'practice_concept' in st.session_state:
            selected_concept = st.session_state.practice_concept
        else:
            selected_concept = st.selectbox(
                "Choose a concept to practice",
                list(SQL_CONCEPTS.keys()),
                format_func=lambda x: SQL_CONCEPTS[x]["name"]
            )
        
        if selected_concept and st.button("Generate Quiz Questions"):
            concept = SQL_CONCEPTS[selected_concept]
            
            with st.spinner(f"Creating quiz for {concept['name']}..."):
                # Generate quiz
                quiz_prompt = f"""
                Create 5 multiple-choice questions about {concept['name']}.
                Focus on: {concept['description']}
                
                Use these examples as reference:
                {chr(10).join(concept['examples'])}
                
                Format each question as:
                1. [Question]
                A) [Option A]
                B) [Option B]
                C) [Option C]
                D) [Option D]
                Correct: [Letter]
                Explanation: [Why this is correct]
                """
                
                quiz_response = safe_ollama_generate(
                    st.session_state.get("selected_model", LEARNING_CONFIG["default_model"]),
                    quiz_prompt
                )
                
                if isinstance(quiz_response, dict):
                    quiz_text = quiz_response.get('response', '')
                else:
                    quiz_text = str(quiz_response)
                
                # Parse and display quiz
                quiz_questions = parse_study_materials(quiz_text, "quiz")
                
                if quiz_questions:
                    st.session_state.sql_quiz = quiz_questions
                    st.session_state.quiz_answers = {}
                else:
                    st.warning("Failed to parse quiz questions. Showing raw response:")
                    st.text(quiz_text)
        
        # Display quiz if available
        if 'sql_quiz' in st.session_state:
            quiz_score = 0
            total_questions = len(st.session_state.sql_quiz)
            
            for i, q in enumerate(st.session_state.sql_quiz):
                st.write(f"**Question {i+1}:** {q['question']}")
                
                answer = st.radio(
                    "Your answer:",
                    q['options'],
                    key=f"sql_quiz_{i}"
                )
                
                if answer:
                    st.session_state.quiz_answers[i] = answer[0]
            
            if st.button("Submit Quiz"):
                st.divider()
                st.subheader("Quiz Results")
                
                for i, q in enumerate(st.session_state.sql_quiz):
                    user_answer = st.session_state.quiz_answers.get(i, 'X')
                    correct = user_answer == q['correct']
                    
                    if correct:
                        st.success(f"✅ Question {i+1}: Correct!")
                        quiz_score += 1
                    else:
                        st.error(f"❌ Question {i+1}: Incorrect (Your answer: {user_answer}, Correct: {q['correct']})")
                    
                    with st.expander(f"Explanation for Question {i+1}"):
                        st.info(q.get('explanation', 'No explanation provided'))
                
                # Show final score
                score_percentage = (quiz_score / total_questions) * 100
                st.metric("Final Score", f"{quiz_score}/{total_questions} ({score_percentage:.0f}%)")
                
                # Track progress
                if 'user_id' in st.session_state:
                    progress = track_learning_progress(
                        st.session_state.user_id,
                        selected_concept,
                        score_percentage / 100,
                        "sql_quiz"
                    )
                    
                    if progress['streak'] > 0:
                        st.success(f"🔥 Learning streak: {progress['streak']} days!")
    
    with tab_path:
        st.subheader("🗺️ Personalized Learning Path")
        
        # Select target concept
        target = st.selectbox(
            "What do you want to learn?",
            list(SQL_CONCEPTS.keys()),
            format_func=lambda x: f"{SQL_CONCEPTS[x]['name']} ({SQL_CONCEPTS[x]['difficulty']})"
        )
        
        # Current knowledge
        st.write("**Select concepts you already know:**")
        current_knowledge = set()
        
        knowledge_cols = st.columns(3)
        for i, (concept_id, concept) in enumerate(SQL_CONCEPTS.items()):
            with knowledge_cols[i % 3]:
                if st.checkbox(concept['name'], key=f"know_{concept_id}"):
                    current_knowledge.add(concept_id)
        
        if st.button("Generate Learning Path"):
            path = generate_learning_path(target, current_knowledge)
            
            if path:
                st.success(f"Learning path created with {len(path)} steps!")
                
                # Display path
                for i, step in enumerate(path):
                    icon = "✅" if step["prerequisites_met"] else "⚠️"
                    
                    with st.expander(f"{icon} Step {i+1}: {step['name']}"):
                        st.write(f"**Difficulty:** {step['difficulty']}")
                        st.write(f"**Estimated Time:** {step['estimated_time']}")
                        
                        if not step["prerequisites_met"]:
                            st.warning("Prerequisites not met! Complete earlier steps first.")
                        
                        if st.button(f"Start Learning", key=f"start_{step['id']}"):
                            st.session_state.practice_concept = step['id']
                            st.info("Check the Learn Concepts tab to begin!")
            else:
                st.info("You already know everything needed for this concept!")
    
    with tab_progress:
        st.subheader("📊 Your Learning Progress")
        
        if 'user_id' not in st.session_state:
            st.session_state.user_id = hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]
        
        # Get user stats
        try:
            # Overall stats
            stats = db.execute_query("""
                SELECT 
                    COUNT(DISTINCT topic) as topics_learned,
                    COUNT(*) as total_quizzes,
                    AVG(score) as avg_score,
                    MAX(timestamp) as last_activity
                FROM learning_progress
                WHERE user_id = %s
            """, (st.session_state.user_id,))
            
            if stats and stats[0]['total_quizzes'] > 0:
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Topics Learned", stats[0]['topics_learned'])
                with col2:
                    st.metric("Quizzes Taken", stats[0]['total_quizzes'])
                with col3:
                    st.metric("Average Score", f"{stats[0]['avg_score']*100:.0f}%")
                with col4:
                    days_ago = (datetime.now() - stats[0]['last_activity']).days
                    st.metric("Last Active", f"{days_ago} days ago")
                
                # Progress chart
                progress_data = db.execute_query("""
                    SELECT 
                        DATE(timestamp) as date,
                        AVG(score) as avg_score,
                        COUNT(*) as activities
                    FROM learning_progress
                    WHERE user_id = %s
                    GROUP BY DATE(timestamp)
                    ORDER BY date DESC
                    LIMIT 30
                """, (st.session_state.user_id,))
                
                if progress_data:
                    df = pd.DataFrame(progress_data)
                    
                    # Create chart
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=df['date'],
                        y=df['avg_score'] * 100,
                        mode='lines+markers',
                        name='Average Score',
                        line=dict(color='#4CAF50', width=2)
                    ))
                    
                    fig.update_layout(
                        title="Learning Progress (Last 30 Days)",
                        xaxis_title="Date",
                        yaxis_title="Average Score (%)",
                        yaxis_range=[0, 100],
                        template="plotly_dark"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                # Topic breakdown
                topic_stats = db.execute_query("""
                    SELECT 
                        topic,
                        COUNT(*) as attempts,
                        AVG(score) as avg_score,
                        MAX(score) as best_score
                    FROM learning_progress
                    WHERE user_id = %s
                    GROUP BY topic
                    ORDER BY attempts DESC
                """, (st.session_state.user_id,))
                
                if topic_stats:
                    st.subheader("📊 Performance by Topic")
                    
                    topic_df = pd.DataFrame(topic_stats)
                    topic_df['avg_score'] = topic_df['avg_score'] * 100
                    topic_df['best_score'] = topic_df['best_score'] * 100
                    
                    # Format topic names
                    topic_df['topic_name'] = topic_df['topic'].apply(
                        lambda x: SQL_CONCEPTS.get(x, {}).get('name', x)
                    )
                    
                    # Display table
                    st.dataframe(
                        topic_df[['topic_name', 'attempts', 'avg_score', 'best_score']].rename(columns={
                            'topic_name': 'Topic',
                            'attempts': 'Attempts',
                            'avg_score': 'Avg Score (%)',
                            'best_score': 'Best Score (%)'
                        }),
                        hide_index=True
                    )
            else:
                st.info("No learning progress yet. Take a quiz to start tracking!")
                
        except Exception as e:
            st.error(f"Error loading progress: {e}")
            st.info("Start learning to build your progress history!")

# ============== MAIN APPLICATION ==============

def main(standalone=True):
    # Only set page config if running standalone (not from unified app)
    if standalone:
        try:
            st.set_page_config(
                page_title="Learning Toolkit",
                page_icon="🎓",
                layout="wide",
                initial_sidebar_state="expanded"
            )
        except:
            # Page config already set (running from unified app)
            pass
    
    # Custom CSS
    st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
            background-color: #4CAF50;
        }
        .learning-card {
            background-color: #1e1e1e;
            padding: 1.5rem;
            border-radius: 0.5rem;
            border: 1px solid #333;
            margin-bottom: 1rem;
        }
        .concept-card {
            border-left: 4px solid #4CAF50;
            padding-left: 1rem;
            margin-bottom: 0.5rem;
        }
        .quiz-option {
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 0.25rem;
            background-color: #2e2e2e;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.title("🎓 Learning Toolkit")
        
        # Tool selection
        tool = st.radio(
            "Select Tool",
            ["EduMind", "Study Guide Generator", "SQL Academy"],
            help="Choose your learning tool"
        )
        
        st.divider()
        
        # Model selection
        st.subheader("⚙️ Settings")
        models = get_available_models()
        if models:
            selected_model = st.selectbox("AI Model", models)
            st.session_state.selected_model = selected_model
        else:
            st.error("No models available")
        
        # Learning preferences
        st.subheader("📚 Learning Preferences")
        
        preferred_difficulty = st.select_slider(
            "Preferred Difficulty",
            options=LEARNING_CONFIG["difficulty_levels"],
            value="Intermediate"
        )
        
        enable_validation = st.checkbox(
            "Enable content validation",
            value=LEARNING_CONFIG["enable_validation"]
        )
        LEARNING_CONFIG["enable_validation"] = enable_validation
        
        # Recent activity
        st.divider()
        st.subheader("🕒 Recent Activity")
        
        try:
            recent = db.execute_query("""
                SELECT tool, created_at
                FROM queries
                WHERE tool LIKE 'edumind%' OR tool LIKE 'study%' OR tool LIKE 'sql_academy%'
                ORDER BY created_at DESC
                LIMIT 5
            """)
            
            if recent:
                for item in recent:
                    tool_name = item['tool'].replace('_', ' ').title()
                    time_ago = (datetime.now() - item['created_at']).days
                    st.caption(f"{tool_name} - {time_ago}d ago")
            else:
                st.info("No recent activity")
                
        except Exception as e:
            st.error(f"Error loading activity: {e}")
        
        # Resources
        st.divider()
        st.subheader("📖 Resources")
        st.markdown("""
        - [Study Techniques](https://www.learningscientists.org/downloadable-materials)
        - [SQL Tutorial](https://www.w3schools.com/sql/)
        - [Spaced Repetition](https://en.wikipedia.org/wiki/Spaced_repetition)
        """)
    
    # Main content
    if tool == "EduMind":
        show_edumind()
    elif tool == "Study Guide Generator":
        show_study_guide_generator()
    elif tool == "SQL Academy":
        show_sql_academy()
    
    # Footer
    st.divider()
    st.caption("Learning Toolkit v2.0 - Adaptive Learning Platform")

if __name__ == "__main__":
    main()
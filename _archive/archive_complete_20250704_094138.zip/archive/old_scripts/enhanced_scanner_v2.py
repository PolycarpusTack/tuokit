"""
TuoKit Enhanced Code Scanner v2.0 - Professional Edition
Comprehensive code analysis tool with security scanning, dependency analysis,
technology detection, and external tool integration
"""
import streamlit as st
import os
import ast
import re
import json
import subprocess
import shutil
import traceback
import sys
import time
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from typing import Dict, List, Tuple, Optional, Any
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Add tools directory to path for imports
sys.path.append(str(Path(__file__).parent))
try:
    from clipboard_utils import display_prompt_with_copy
except ImportError:
    # Fallback if clipboard_utils is not available
    def display_prompt_with_copy(prompt, title="", key_prefix=""):
        st.text_area(title, prompt, height=400, key=f"{key_prefix}_prompt")

# Configuration
SCAN_EXTENSIONS = ['.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.cs', '.go', '.rs', '.rb', '.php']
IGNORE_DIRS = ['__pycache__', '.git', 'venv', 'env', 'node_modules', 'vendor', 'target', 'bin', 'obj', 'dist', 'build']
MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB
BACKUP_DIR = "C:/Projects/Tuokit/backups/enhanced_scanner_v2"

# Security patterns
SECURITY_PATTERNS = {
    'API Keys': {
        'generic_api_key': {
            'pattern': r'(?i)api[_-]?key\s*[:=]\s*["\']?[a-zA-Z0-9]{20,}["\']?',
            'severity': 'high',
            'description': 'Potential API key in plaintext'
        },
        'aws_access_key': {
            'pattern': r'AKIA[0-9A-Z]{16}',
            'severity': 'critical',
            'description': 'AWS Access Key ID detected'
        },
        'github_token': {
            'pattern': r'ghp_[0-9a-zA-Z]{36}',
            'severity': 'high',
            'description': 'GitHub Personal Access Token'
        },
        'google_api': {
            'pattern': r'AIza[0-9A-Za-z\-_]{35}',
            'severity': 'high',
            'description': 'Google API Key'
        }
    },
    'Credentials': {
        'password_in_code': {
            'pattern': r'(?i)(password|pwd|passwd)\s*[:=]\s*["\'][^"\']{4,}["\']',
            'severity': 'high',
            'description': 'Hardcoded password detected'
        },
        'jwt_token': {
            'pattern': r'eyJ[A-Za-z0-9_-]*\.eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*',
            'severity': 'medium',
            'description': 'JWT token detected'
        },
        'private_key': {
            'pattern': r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----',
            'severity': 'critical',
            'description': 'Private cryptographic key'
        }
    },
    'Security Issues': {
        'sql_injection': {
            'pattern': r'(query|execute)\s*\(.*\+.*["\'].*["\'].*\)',
            'severity': 'high',
            'description': 'Potential SQL injection vulnerability'
        },
        'weak_crypto': {
            'pattern': r'\b(MD5|SHA1|DES|RC4)\s*\(',
            'severity': 'medium',
            'description': 'Weak cryptographic algorithm'
        },
        'eval_usage': {
            'pattern': r'\b(eval|exec)\s*\(',
            'severity': 'high',
            'description': 'Dynamic code execution detected'
        }
    }
}

# Performance patterns
PERFORMANCE_PATTERNS = {
    'nested_loops': {
        'pattern': r'for\s+.*:\s*\n\s*for\s+.*:',
        'severity': 'medium',
        'description': 'Nested loops detected - potential O(n²) complexity'
    },
    'multiple_db_calls': {
        'pattern': r'(for|while)\s+.*:\s*\n.*\.(find|query|select|execute)\(',
        'severity': 'high',
        'description': 'Database operations inside loop - N+1 query problem'
    },
    'large_list_comp': {
        'pattern': r'\[[^\]]{200,}\]',
        'severity': 'low',
        'description': 'Large list comprehension - consider generator'
    },
    'sync_file_ops': {
        'pattern': r'open\([^)]+\)(?!.*async)',
        'severity': 'low',
        'description': 'Synchronous file operation'
    }
}

class TechnologyDetector:
    """Detect technology stack of the project"""
    
    def __init__(self):
        self.detectors = {
            'Python': {
                'files': ['requirements.txt', 'Pipfile', 'setup.py', 'pyproject.toml', '*.py'],
                'dirs': ['__pycache__', '.pytest_cache'],
                'confidence_boost': ['django', 'flask', 'fastapi']
            },
            'JavaScript/TypeScript': {
                'files': ['package.json', '*.js', '*.ts', '*.jsx', '*.tsx'],
                'dirs': ['node_modules', '.next', '.nuxt'],
                'confidence_boost': ['react', 'vue', 'angular']
            },
            'Java': {
                'files': ['pom.xml', 'build.gradle', '*.java'],
                'dirs': ['target', 'build', '.gradle'],
                'confidence_boost': ['spring', 'maven', 'gradle']
            },
            'C#/.NET': {
                'files': ['*.sln', '*.csproj', '*.cs'],
                'dirs': ['bin', 'obj', '.vs'],
                'confidence_boost': ['aspnet', 'dotnet', 'xamarin']
            },
            'Go': {
                'files': ['go.mod', 'go.sum', '*.go'],
                'dirs': ['vendor'],
                'confidence_boost': ['gin', 'echo', 'fiber']
            },
            'Rust': {
                'files': ['Cargo.toml', 'Cargo.lock', '*.rs'],
                'dirs': ['target'],
                'confidence_boost': ['tokio', 'actix', 'rocket']
            },
            'Ruby': {
                'files': ['Gemfile', 'Gemfile.lock', '*.rb'],
                'dirs': ['.bundle'],
                'confidence_boost': ['rails', 'sinatra']
            },
            'PHP': {
                'files': ['composer.json', '*.php'],
                'dirs': ['vendor'],
                'confidence_boost': ['laravel', 'symfony', 'wordpress']
            }
        }
    
    def detect(self, project_path: Path) -> Dict[str, Any]:
        """Detect technologies used in the project"""
        detected = {}
        
        for tech, indicators in self.detectors.items():
            confidence = 0
            evidence = []
            
            # Check for files
            for pattern in indicators['files']:
                if '*' in pattern:
                    files = list(project_path.rglob(pattern))
                    if files:
                        confidence += min(len(files) * 10, 40)
                        evidence.append(f"Found {len(files)} {pattern} files")
                else:
                    if (project_path / pattern).exists():
                        confidence += 30
                        evidence.append(f"Found {pattern}")
            
            # Check for directories
            for dir_name in indicators['dirs']:
                if any(project_path.rglob(dir_name)):
                    confidence += 20
                    evidence.append(f"Found {dir_name} directory")
            
            # Check for framework indicators
            for framework in indicators.get('confidence_boost', []):
                if any(project_path.rglob(f'*{framework}*')):
                    confidence += 10
                    evidence.append(f"Found {framework} references")
            
            if confidence > 0:
                detected[tech] = {
                    'confidence': min(confidence, 100),
                    'evidence': evidence
                }
        
        return detected

class DependencyAnalyzer:
    """Analyze project dependencies and check for vulnerabilities"""
    
    def __init__(self):
        self.package_managers = {
            'npm': {
                'files': ['package.json', 'package-lock.json'],
                'lock_file': 'package-lock.json',
                'audit_command': ['npm', 'audit', '--json'],
                'list_command': ['npm', 'list', '--json', '--depth=0']
            },
            'pip': {
                'files': ['requirements.txt', 'Pipfile', 'poetry.lock'],
                'lock_file': 'Pipfile.lock',
                'audit_command': ['safety', 'check', '--json'],
                'list_command': ['pip', 'list', '--format=json']
            },
            'maven': {
                'files': ['pom.xml'],
                'lock_file': None,
                'audit_command': ['mvn', 'dependency:analyze'],
                'list_command': ['mvn', 'dependency:list']
            },
            'gradle': {
                'files': ['build.gradle', 'build.gradle.kts'],
                'lock_file': 'gradle.lockfile',
                'audit_command': ['gradle', 'dependencyCheckAnalyze'],
                'list_command': ['gradle', 'dependencies']
            },
            'cargo': {
                'files': ['Cargo.toml'],
                'lock_file': 'Cargo.lock',
                'audit_command': ['cargo', 'audit', '--json'],
                'list_command': ['cargo', 'tree']
            },
            'composer': {
                'files': ['composer.json'],
                'lock_file': 'composer.lock',
                'audit_command': ['composer', 'audit'],
                'list_command': ['composer', 'show']
            }
        }
    
    def analyze(self, project_path: Path) -> Dict[str, Any]:
        """Analyze dependencies for all detected package managers"""
        results = {
            'package_managers': {},
            'total_dependencies': 0,
            'vulnerabilities': [],
            'outdated': [],
            'missing_lock_files': []
        }
        
        for pm_name, pm_config in self.package_managers.items():
            # Check if package manager is used
            pm_files = []
            for file_pattern in pm_config['files']:
                pm_files.extend(project_path.glob(file_pattern))
            
            if pm_files:
                pm_result = {
                    'detected': True,
                    'files': [str(f.relative_to(project_path)) for f in pm_files],
                    'has_lock_file': False,
                    'dependencies': [],
                    'vulnerabilities': []
                }
                
                # Check for lock file
                if pm_config['lock_file']:
                    lock_path = project_path / pm_config['lock_file']
                    pm_result['has_lock_file'] = lock_path.exists()
                    if not lock_path.exists():
                        results['missing_lock_files'].append(pm_name)
                
                # Try to get dependency list
                deps = self._get_dependencies(project_path, pm_name, pm_config)
                if deps:
                    pm_result['dependencies'] = deps
                    results['total_dependencies'] += len(deps)
                
                # Try to run security audit
                vulns = self._check_vulnerabilities(project_path, pm_name, pm_config)
                if vulns:
                    pm_result['vulnerabilities'] = vulns
                    results['vulnerabilities'].extend(vulns)
                
                results['package_managers'][pm_name] = pm_result
        
        return results
    
    def _get_dependencies(self, project_path: Path, pm_name: str, pm_config: dict) -> List[dict]:
        """Get list of dependencies for a package manager"""
        if pm_name == 'pip':
            # Parse requirements.txt
            req_file = project_path / 'requirements.txt'
            if req_file.exists():
                deps = []
                with open(req_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            # Parse package name and version
                            match = re.match(r'([^=<>]+)([=<>]+)(.+)?', line)
                            if match:
                                deps.append({
                                    'name': match.group(1).strip(),
                                    'version': match.group(3).strip() if match.group(3) else 'any'
                                })
                return deps
        
        elif pm_name == 'npm':
            # Parse package.json
            pkg_file = project_path / 'package.json'
            if pkg_file.exists():
                try:
                    with open(pkg_file, 'r') as f:
                        pkg_data = json.load(f)
                    
                    deps = []
                    for dep_type in ['dependencies', 'devDependencies']:
                        if dep_type in pkg_data:
                            for name, version in pkg_data[dep_type].items():
                                deps.append({
                                    'name': name,
                                    'version': version,
                                    'type': dep_type
                                })
                    return deps
                except:
                    pass
        
        return []
    
    def _check_vulnerabilities(self, project_path: Path, pm_name: str, pm_config: dict) -> List[dict]:
        """Check for known vulnerabilities in dependencies"""
        # This is a simplified version - in production, you'd run actual security tools
        # For now, we'll check against some known vulnerable versions
        vulnerable_packages = {
            'npm': {
                'lodash': ['< 4.17.21', 'CVE-2021-23337'],
                'minimist': ['< 1.2.6', 'CVE-2021-44906'],
                'axios': ['< 0.21.2', 'CVE-2021-3749']
            },
            'pip': {
                'django': ['< 3.2.13', 'CVE-2022-28346'],
                'pillow': ['< 9.0.1', 'CVE-2022-22817'],
                'numpy': ['< 1.21.0', 'CVE-2021-33430']
            }
        }
        
        vulns = []
        if pm_name in vulnerable_packages:
            deps = self._get_dependencies(project_path, pm_name, pm_config)
            for dep in deps:
                if dep['name'].lower() in vulnerable_packages[pm_name]:
                    vuln_version, cve = vulnerable_packages[pm_name][dep['name'].lower()]
                    vulns.append({
                        'package': dep['name'],
                        'current_version': dep['version'],
                        'vulnerability': cve,
                        'severity': 'high',
                        'fix': f'Update to version {vuln_version.replace("< ", ">= ")}'
                    })
        
        return vulns

class ExternalToolRunner:
    """Run external analysis tools"""
    
    def __init__(self):
        self.tools = {
            'flake8': {
                'command': ['flake8', '.', '--format=json', '--output-file={output}'],
                'language': 'Python',
                'check_command': ['flake8', '--version'],
                'install': 'pip install flake8',
                'parser': self._parse_flake8
            },
            'pylint': {
                'command': ['pylint', '.', '--output-format=json'],
                'language': 'Python',
                'check_command': ['pylint', '--version'],
                'install': 'pip install pylint',
                'parser': self._parse_pylint
            },
            'eslint': {
                'command': ['eslint', '.', '--format=json', '--output={output}'],
                'language': 'JavaScript',
                'check_command': ['eslint', '--version'],
                'install': 'npm install -g eslint',
                'parser': self._parse_eslint
            },
            'bandit': {
                'command': ['bandit', '-r', '.', '-f', 'json', '-o', '{output}'],
                'language': 'Python',
                'check_command': ['bandit', '--version'],
                'install': 'pip install bandit',
                'parser': self._parse_bandit
            }
        }
        
        self.available_tools = {}
        self._check_available_tools()
    
    def _check_available_tools(self):
        """Check which tools are available on the system"""
        for tool_name, config in self.tools.items():
            try:
                result = subprocess.run(
                    config['check_command'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                self.available_tools[tool_name] = result.returncode == 0
            except:
                self.available_tools[tool_name] = False
    
    def run_tool(self, tool_name: str, project_path: Path, output_dir: Path) -> Optional[dict]:
        """Run an external tool and parse its output"""
        if tool_name not in self.tools:
            return None
        
        if not self.available_tools.get(tool_name, False):
            return {
                'tool': tool_name,
                'status': 'not_available',
                'install_command': self.tools[tool_name]['install']
            }
        
        config = self.tools[tool_name]
        output_file = output_dir / f'{tool_name}_output.json'
        
        # Prepare command
        command = []
        for part in config['command']:
            if '{output}' in part:
                command.append(part.replace('{output}', str(output_file)))
            else:
                command.append(part)
        
        try:
            # Run the tool
            result = subprocess.run(
                command,
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            # Parse output
            if output_file.exists():
                with open(output_file, 'r') as f:
                    raw_output = f.read()
                parsed = config['parser'](raw_output)
            else:
                parsed = config['parser'](result.stdout)
            
            return {
                'tool': tool_name,
                'status': 'success',
                'issues': parsed,
                'summary': {
                    'total': len(parsed),
                    'by_severity': self._count_by_severity(parsed)
                }
            }
            
        except subprocess.TimeoutExpired:
            return {
                'tool': tool_name,
                'status': 'timeout',
                'error': 'Tool execution timed out after 5 minutes'
            }
        except Exception as e:
            return {
                'tool': tool_name,
                'status': 'error',
                'error': str(e)
            }
    
    def _parse_flake8(self, output: str) -> List[dict]:
        """Parse Flake8 JSON output"""
        try:
            data = json.loads(output)
            issues = []
            for file_path, file_issues in data.items():
                for issue in file_issues:
                    issues.append({
                        'file': file_path,
                        'line': issue['line'],
                        'column': issue['column'],
                        'code': issue['code'],
                        'message': issue['message'],
                        'severity': 'medium' if issue['code'].startswith('W') else 'high'
                    })
            return issues
        except:
            return []
    
    def _parse_pylint(self, output: str) -> List[dict]:
        """Parse Pylint JSON output"""
        try:
            data = json.loads(output)
            issues = []
            for issue in data:
                severity = 'low'
                if issue['type'] in ['error', 'fatal']:
                    severity = 'high'
                elif issue['type'] == 'warning':
                    severity = 'medium'
                
                issues.append({
                    'file': issue['path'],
                    'line': issue['line'],
                    'column': issue['column'],
                    'code': issue['message-id'],
                    'message': issue['message'],
                    'severity': severity
                })
            return issues
        except:
            return []
    
    def _parse_eslint(self, output: str) -> List[dict]:
        """Parse ESLint JSON output"""
        try:
            data = json.loads(output)
            issues = []
            for file_data in data:
                for message in file_data.get('messages', []):
                    severity = 'high' if message['severity'] == 2 else 'medium'
                    issues.append({
                        'file': file_data['filePath'],
                        'line': message.get('line', 0),
                        'column': message.get('column', 0),
                        'code': message.get('ruleId', 'unknown'),
                        'message': message['message'],
                        'severity': severity
                    })
            return issues
        except:
            return []
    
    def _parse_bandit(self, output: str) -> List[dict]:
        """Parse Bandit JSON output"""
        try:
            data = json.loads(output)
            issues = []
            for result in data.get('results', []):
                severity_map = {
                    'LOW': 'low',
                    'MEDIUM': 'medium',
                    'HIGH': 'high'
                }
                issues.append({
                    'file': result['filename'],
                    'line': result['line_number'],
                    'column': 0,
                    'code': result['test_id'],
                    'message': result['issue_text'],
                    'severity': severity_map.get(result['issue_severity'], 'medium')
                })
            return issues
        except:
            return []
    
    def _count_by_severity(self, issues: List[dict]) -> dict:
        """Count issues by severity"""
        counts = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}
        for issue in issues:
            severity = issue.get('severity', 'medium')
            counts[severity] = counts.get(severity, 0) + 1
        return counts

class ScanProfile:
    """Predefined and custom scan profiles"""
    
    def __init__(self):
        self.profiles = {
            'quick': {
                'name': 'Quick Scan',
                'description': 'Fast scan focusing on critical issues',
                'max_files': 200,
                'scan_security': True,
                'scan_dependencies': False,
                'external_tools': [],
                'file_size_limit': 500 * 1024  # 500KB
            },
            'security': {
                'name': 'Security Focus',
                'description': 'Deep security analysis',
                'max_files': 1000,
                'scan_security': True,
                'scan_dependencies': True,
                'external_tools': ['bandit'],
                'file_size_limit': 2 * 1024 * 1024  # 2MB
            },
            'quality': {
                'name': 'Code Quality',
                'description': 'Comprehensive quality analysis',
                'max_files': 500,
                'scan_security': False,
                'scan_dependencies': False,
                'external_tools': ['flake8', 'pylint', 'eslint'],
                'file_size_limit': 1024 * 1024  # 1MB
            },
            'full': {
                'name': 'Full Analysis',
                'description': 'Complete analysis with all features',
                'max_files': -1,  # No limit
                'scan_security': True,
                'scan_dependencies': True,
                'external_tools': ['flake8', 'pylint', 'eslint', 'bandit'],
                'file_size_limit': 5 * 1024 * 1024  # 5MB
            }
        }
    
    def get_profile(self, name: str) -> dict:
        """Get a scan profile by name"""
        return self.profiles.get(name, self.profiles['quick'])
    
    def save_custom_profile(self, name: str, config: dict):
        """Save a custom profile"""
        self.profiles[name] = config
        # In a real app, persist to database or file

class EnhancedCodeScannerV2:
    """Enhanced scanner with security, dependencies, and external tools"""
    
    def __init__(self, root_path: Path, profile: dict):
        self.root_path = Path(root_path)
        self.profile = profile
        self.issues = defaultdict(list)
        self.metrics = {
            'total_files': 0,
            'total_lines': 0,
            'languages': defaultdict(int),
            'scan_duration': 0,
            'technologies': {},
            'dependencies': {},
            'security_score': 100,
            'quality_score': 100,
            'performance_score': 100
        }
        self.file_cache = {}
        self.tech_detector = TechnologyDetector()
        self.dep_analyzer = DependencyAnalyzer()
        self.tool_runner = ExternalToolRunner()
    
    def scan_directory(self) -> List[Path]:
        """Scan directory and return files to analyze"""
        files_to_scan = []
        
        for ext in SCAN_EXTENSIONS:
            for file_path in self.root_path.rglob(f'*{ext}'):
                # Skip ignored directories
                if any(ignored in str(file_path) for ignored in IGNORE_DIRS):
                    continue
                
                # Skip large files based on profile
                try:
                    if file_path.stat().st_size > self.profile['file_size_limit']:
                        self.issues['large_files'].append({
                            'file': str(file_path.relative_to(self.root_path)),
                            'size': file_path.stat().st_size
                        })
                        continue
                except:
                    continue
                
                files_to_scan.append(file_path)
                
                # Track language metrics
                lang = self._get_language_from_ext(ext)
                self.metrics['languages'][lang] += 1
        
        # Apply max files limit
        if self.profile['max_files'] > 0:
            files_to_scan = files_to_scan[:self.profile['max_files']]
        
        self.metrics['total_files'] = len(files_to_scan)
        return files_to_scan
    
    def analyze_security(self, file_path: Path, content: str):
        """Analyze file for security issues"""
        if not self.profile['scan_security']:
            return
        
        for category, patterns in SECURITY_PATTERNS.items():
            for pattern_name, pattern_info in patterns.items():
                matches = re.finditer(pattern_info['pattern'], content, re.MULTILINE | re.IGNORECASE)
                for match in matches:
                    line_num = content[:match.start()].count('\n') + 1
                    
                    self.issues['security'].append({
                        'file': str(file_path.relative_to(self.root_path)),
                        'line': line_num,
                        'category': category,
                        'type': pattern_name,
                        'severity': pattern_info['severity'],
                        'description': pattern_info['description'],
                        'match': match.group(0)[:100] + '...' if len(match.group(0)) > 100 else match.group(0)
                    })
    
    def analyze_performance(self, file_path: Path, content: str):
        """Analyze file for performance issues"""
        for pattern_name, pattern_info in PERFORMANCE_PATTERNS.items():
            matches = re.finditer(pattern_info['pattern'], content, re.MULTILINE)
            for match in matches:
                line_num = content[:match.start()].count('\n') + 1
                
                self.issues['performance'].append({
                    'file': str(file_path.relative_to(self.root_path)),
                    'line': line_num,
                    'type': pattern_name,
                    'severity': pattern_info['severity'],
                    'description': pattern_info['description']
                })
    
    def analyze_file(self, file_path: Path):
        """Analyze a single file for all issue types"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                self.file_cache[str(file_path)] = content
            
            lines = content.splitlines()
            self.metrics['total_lines'] += len(lines)
            
            # Security analysis
            self.analyze_security(file_path, content)
            
            # Performance analysis
            self.analyze_performance(file_path, content)
            
            # Existing analyses (syntax, TODOs, etc.)
            # Check syntax for Python files
            if file_path.suffix == '.py':
                try:
                    ast.parse(content)
                except SyntaxError as e:
                    self.issues['syntax_errors'].append({
                        'file': str(file_path.relative_to(self.root_path)),
                        'line': e.lineno,
                        'message': str(e.msg),
                        'severity': 'critical'
                    })
            
            # Check for TODOs and technical debt
            todo_patterns = [
                (r'#\s*TODO\s*:?\s*(.+)', 'todo'),
                (r'#\s*FIXME\s*:?\s*(.+)', 'fixme'),
                (r'#\s*HACK\s*:?\s*(.+)', 'hack'),
                (r'#\s*XXX\s*:?\s*(.+)', 'xxx'),
            ]
            
            for line_num, line in enumerate(lines, 1):
                for pattern, debt_type in todo_patterns:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        self.issues['technical_debt'].append({
                            'file': str(file_path.relative_to(self.root_path)),
                            'line': line_num,
                            'type': debt_type,
                            'message': match.group(1).strip() if match.groups() else line.strip(),
                            'severity': 'low'
                        })
            
        except Exception as e:
            self.issues['scan_errors'].append({
                'file': str(file_path.relative_to(self.root_path)),
                'error': str(e)
            })
    
    def calculate_scores(self):
        """Calculate security, quality, and performance scores"""
        # Security score
        security_issues = len(self.issues.get('security', []))
        critical_security = len([i for i in self.issues.get('security', []) if i['severity'] == 'critical'])
        high_security = len([i for i in self.issues.get('security', []) if i['severity'] == 'high'])
        
        self.metrics['security_score'] = max(0, 100 - (critical_security * 20) - (high_security * 10) - (security_issues * 2))
        
        # Quality score
        syntax_errors = len(self.issues.get('syntax_errors', []))
        tech_debt = len(self.issues.get('technical_debt', []))
        
        self.metrics['quality_score'] = max(0, 100 - (syntax_errors * 15) - (tech_debt * 0.5))
        
        # Performance score
        perf_issues = len(self.issues.get('performance', []))
        high_perf = len([i for i in self.issues.get('performance', []) if i['severity'] == 'high'])
        
        self.metrics['performance_score'] = max(0, 100 - (high_perf * 15) - (perf_issues * 3))
        
        # Overall health score
        self.metrics['health_score'] = round(
            (self.metrics['security_score'] * 0.4) +
            (self.metrics['quality_score'] * 0.35) +
            (self.metrics['performance_score'] * 0.25)
        )
    
    def _get_language_from_ext(self, ext: str) -> str:
        """Map file extension to language"""
        lang_map = {
            '.py': 'Python',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.java': 'Java',
            '.cs': 'C#',
            '.go': 'Go',
            '.rs': 'Rust',
            '.rb': 'Ruby',
            '.php': 'PHP',
            '.jsx': 'JavaScript',
            '.tsx': 'TypeScript'
        }
        return lang_map.get(ext, 'Other')

class SARIFExporter:
    """Export results in SARIF format for CI/CD integration"""
    
    @staticmethod
    def export(scanner: EnhancedCodeScannerV2, output_path: Path):
        """Export scan results to SARIF format"""
        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "TuoKit Enhanced Scanner",
                        "version": "2.0",
                        "informationUri": "https://github.com/tuokit/scanner",
                        "rules": []
                    }
                },
                "results": []
            }]
        }
        
        # Add rules for each issue type
        rule_id = 1
        rule_map = {}
        
        for issue_type in ['security', 'performance', 'syntax_errors', 'technical_debt']:
            if issue_type in scanner.issues:
                for issue in scanner.issues[issue_type]:
                    rule_key = f"{issue_type}_{issue.get('type', 'generic')}"
                    if rule_key not in rule_map:
                        rule_map[rule_key] = f"TK{rule_id:04d}"
                        sarif['runs'][0]['tool']['driver']['rules'].append({
                            "id": rule_map[rule_key],
                            "name": issue.get('type', issue_type),
                            "shortDescription": {
                                "text": issue.get('description', f'{issue_type} issue')
                            },
                            "defaultConfiguration": {
                                "level": SARIFExporter._severity_to_level(issue.get('severity', 'medium'))
                            }
                        })
                        rule_id += 1
                    
                    # Add result
                    sarif['runs'][0]['results'].append({
                        "ruleId": rule_map[rule_key],
                        "message": {
                            "text": issue.get('description', issue.get('message', 'Issue detected'))
                        },
                        "locations": [{
                            "physicalLocation": {
                                "artifactLocation": {
                                    "uri": issue['file']
                                },
                                "region": {
                                    "startLine": issue.get('line', 1)
                                }
                            }
                        }]
                    })
        
        with open(output_path, 'w') as f:
            json.dump(sarif, f, indent=2)
    
    @staticmethod
    def _severity_to_level(severity: str) -> str:
        """Convert severity to SARIF level"""
        mapping = {
            'critical': 'error',
            'high': 'error',
            'medium': 'warning',
            'low': 'note'
        }
        return mapping.get(severity, 'warning')

def create_visual_dashboard(scanner: EnhancedCodeScannerV2):
    """Create visual dashboard with charts"""
    
    # Create subplots
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Health Score', 'Issue Distribution', 'Language Distribution', 'Severity Breakdown'),
        specs=[[{'type': 'indicator'}, {'type': 'bar'}],
               [{'type': 'pie'}, {'type': 'bar'}]]
    )
    
    # Health Score Gauge
    fig.add_trace(
        go.Indicator(
            mode="gauge+number",
            value=scanner.metrics['health_score'],
            domain={'x': [0, 1], 'y': [0, 1]},
            title={'text': "Overall Health"},
            gauge={
                'axis': {'range': [None, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 50], 'color': "lightgray"},
                    {'range': [50, 80], 'color': "gray"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 90
                }
            }
        ),
        row=1, col=1
    )
    
    # Issue Distribution
    issue_types = []
    issue_counts = []
    for issue_type, issues in scanner.issues.items():
        if issues:
            issue_types.append(issue_type.replace('_', ' ').title())
            issue_counts.append(len(issues))
    
    fig.add_trace(
        go.Bar(x=issue_types, y=issue_counts, name="Issues"),
        row=1, col=2
    )
    
    # Language Distribution
    languages = list(scanner.metrics['languages'].keys())
    lang_counts = list(scanner.metrics['languages'].values())
    
    fig.add_trace(
        go.Pie(labels=languages, values=lang_counts, name="Languages"),
        row=2, col=1
    )
    
    # Severity Breakdown
    severities = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}
    for issue_list in scanner.issues.values():
        for issue in issue_list:
            sev = issue.get('severity', 'medium')
            severities[sev] = severities.get(sev, 0) + 1
    
    fig.add_trace(
        go.Bar(
            x=list(severities.keys()),
            y=list(severities.values()),
            marker_color=['green', 'yellow', 'orange', 'red']
        ),
        row=2, col=2
    )
    
    fig.update_layout(height=800, showlegend=False)
    return fig

class EnhancedFixEngine:
    """Enhanced fix engine with automatic code fixing capabilities"""
    def __init__(self, backup_dir=BACKUP_DIR):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.applied_fixes = []
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    def _get_context(self, file_path: Path, line_num: int, context_size: int = 10) -> str:
        """Get code context around a line"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start = max(0, line_num - context_size - 1)
            end = min(len(lines), line_num + context_size)
            
            context = []
            for i in range(start, end):
                marker = ">>>" if i == line_num - 1 else "   "
                context.append(f"{marker} {i+1}: {lines[i].rstrip()}")
            
            return '\n'.join(context)
            
        except Exception:
            return "Could not read context"
    
    def fix_syntax_error(self, file_path: Path, error: dict) -> tuple[bool, str]:
        """Fix a syntax error"""
        try:
            # Simple placeholder implementation
            return False, "Auto-fix not implemented for this error type"
        except Exception as e:
            return False, f"Fix failed: {e}"
    
    def fix_security_issue(self, file_path: Path, issue: dict) -> tuple[bool, str]:
        """Fix a security issue"""
        try:
            # Simple placeholder implementation
            return False, "Auto-fix not implemented for this security issue"
        except Exception as e:
            return False, f"Fix failed: {e}"

def generate_issue_summary(issue: dict, issue_type: str) -> str:
    """Generate a basic summary of an issue"""
    if issue_type == 'security':
        return f"""## Security Issue
**Type**: {issue.get('type', 'Unknown')}
**Severity**: {issue.get('severity', 'Unknown')}
**File**: {issue.get('file', 'Unknown')}
**Line**: {issue.get('line', 'Unknown')}
**Description**: {issue.get('description', 'No description available')}
"""
    elif issue_type == 'syntax_error':
        return f"""## Syntax Error
**Message**: {issue.get('message', 'Unknown error')}
**File**: {issue.get('file', 'Unknown')}
**Line**: {issue.get('line', 'Unknown')}
"""
    elif issue_type == 'performance':
        return f"""## Performance Issue
**Type**: {issue.get('type', 'Unknown')}
**Severity**: {issue.get('severity', 'Unknown')}
**File**: {issue.get('file', 'Unknown')}
**Line**: {issue.get('line', 'Unknown')}
**Description**: {issue.get('description', 'No description available')}
"""
    else:  # technical_debt
        return f"""## Technical Debt
**Type**: {issue.get('type', 'Unknown')}
**File**: {issue.get('file', 'Unknown')}
**Line**: {issue.get('line', 'Unknown')}
**Message**: {issue.get('message', 'No message available')}
"""

def main():
    st.set_page_config(
        page_title="TuoKit Scanner v2.0 - Professional Edition",
        page_icon="🔍",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session state
    if 'scanner' not in st.session_state:
        st.session_state.scanner = None
    if 'scan_complete' not in st.session_state:
        st.session_state.scan_complete = False
    if 'scan_results' not in st.session_state:
        st.session_state.scan_results = {}
    if 'selected_profile' not in st.session_state:
        st.session_state.selected_profile = 'quick'
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    if 'fixed_issues' not in st.session_state:
        st.session_state.fixed_issues = []
    
    # Header
    st.title("🔍 TuoKit Code Scanner v2.0")
    st.markdown("""
    **Professional code analysis** with security scanning, dependency analysis, and external tool integration
    
    ✨ Technology detection | 🔒 Security analysis | 📦 Dependency scanning | 🛠️ External tools
    """)
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Scan Configuration")
        
        project_path = st.text_input(
            "Project Path",
            value="C:/Projects/Tuokit",
            help="Root directory to scan"
        )
        
        # Profile selection
        profile_manager = ScanProfile()
        profile_names = list(profile_manager.profiles.keys())
        
        selected_profile = st.selectbox(
            "Scan Profile",
            options=profile_names,
            index=profile_names.index(st.session_state.selected_profile),
            help="Choose a predefined scan profile"
        )
        
        profile = profile_manager.get_profile(selected_profile)
        st.session_state.selected_profile = selected_profile
        
        # Display profile details
        with st.expander("Profile Details", expanded=True):
            st.write(f"**{profile['name']}**")
            st.write(profile['description'])
            st.write(f"Max files: {profile['max_files'] if profile['max_files'] > 0 else 'Unlimited'}")
            st.write(f"Security scan: {'✅' if profile['scan_security'] else '❌'}")
            st.write(f"Dependency scan: {'✅' if profile['scan_dependencies'] else '❌'}")
            if profile['external_tools']:
                st.write(f"Tools: {', '.join(profile['external_tools'])}")
        
        # Advanced options
        with st.expander("Advanced Options"):
            custom_max_files = st.number_input(
                "Override max files",
                min_value=0,
                value=profile['max_files'] if profile['max_files'] > 0 else 1000,
                help="0 for unlimited"
            )
            
            export_sarif = st.checkbox("Export SARIF for CI/CD", value=True)
            run_external_tools = st.checkbox("Run external tools", value=bool(profile['external_tools']))
        
        st.divider()
        
        # Available tools status
        st.subheader("🛠️ Available Tools")
        tool_runner = ExternalToolRunner()
        for tool_name, available in tool_runner.available_tools.items():
            if available:
                st.success(f"✅ {tool_name}")
            else:
                st.warning(f"❌ {tool_name} - {tool_runner.tools[tool_name]['install']}")
        
        # Fix summary if any fixes applied
        if st.session_state.fixed_issues:
            st.divider()
            st.success(f"✅ {len(st.session_state.fixed_issues)} fixes applied")
            
            with st.expander("View applied fixes"):
                for fix in st.session_state.fixed_issues:
                    st.text(f"• {fix.get('file', 'unknown')}:{fix.get('line', '?')} - {fix.get('type', 'fix')}")
        
        st.divider()
        
        # Scan button
        if st.button("🚀 Start Scan", type="primary", disabled=st.session_state.scan_complete):
            run_comprehensive_scan(project_path, profile, export_sarif, run_external_tools)
        
        if st.session_state.scan_complete:
            if st.button("🔄 New Scan"):
                st.session_state.scanner = None
                st.session_state.scan_complete = False
                st.session_state.scan_results = {}
                st.rerun()
    
    # Main content area
    if st.session_state.scanner and st.session_state.scan_complete:
        display_results()
    elif st.session_state.scanner:
        # Show progress
        display_scan_progress()
    else:
        # Welcome screen
        display_welcome_screen()

def display_welcome_screen():
    """Display welcome screen with feature highlights"""
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        ### 🔍 Technology Detection
        - Auto-detect tech stack
        - Framework identification
        - Language statistics
        - Build tool detection
        """)
    
    with col2:
        st.markdown("""
        ### 🔒 Security Analysis
        - Secret detection
        - Vulnerability scanning
        - Crypto weaknesses
        - Injection risks
        """)
    
    with col3:
        st.markdown("""
        ### 📦 Dependencies
        - Package managers
        - Vulnerability checks
        - Outdated packages
        - Lock file validation
        """)
    
    with col4:
        st.markdown("""
        ### 🛠️ External Tools
        - ESLint integration
        - Flake8 & Pylint
        - Bandit security
        - SARIF export
        """)
    
    st.info("👈 Configure scan settings and click 'Start Scan' to begin analysis")

def display_scan_progress():
    """Display real-time scan progress"""
    progress_container = st.container()
    
    with progress_container:
        st.header("🔄 Scan in Progress")
        
        # Progress metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            files_scanned = st.empty()
            files_scanned.metric("Files Scanned", "0")
        
        with col2:
            issues_found = st.empty()
            issues_found.metric("Issues Found", "0")
        
        with col3:
            time_elapsed = st.empty()
            time_elapsed.metric("Time Elapsed", "0:00")
        
        with col4:
            current_phase = st.empty()
            current_phase.metric("Current Phase", "Initializing")
        
        # Progress bar
        progress_bar = st.progress(0)
        
        # Activity log
        st.subheader("Activity Log")
        log_container = st.empty()

def run_comprehensive_scan(project_path: str, profile: dict, export_sarif: bool, run_external_tools: bool):
    """Run comprehensive code scan with all features"""
    start_time = time.time()
    
    # Initialize scanner
    scanner = EnhancedCodeScannerV2(Path(project_path), profile)
    st.session_state.scanner = scanner
    
    # Phase 1: Technology Detection
    with st.spinner("🔍 Detecting technologies..."):
        technologies = scanner.tech_detector.detect(scanner.root_path)
        scanner.metrics['technologies'] = technologies
        st.session_state.scan_results['technologies'] = technologies
    
    # Phase 2: File Discovery
    with st.spinner("📁 Discovering files..."):
        files = scanner.scan_directory()
        st.session_state.scan_results['total_files'] = len(files)
    
    # Phase 3: Code Analysis
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for i, file_path in enumerate(files):
        progress = (i + 1) / len(files)
        progress_bar.progress(progress)
        status_text.text(f"Analyzing: {file_path.name} ({i+1}/{len(files)})")
        
        scanner.analyze_file(file_path)
    
    progress_bar.empty()
    status_text.empty()
    
    # Phase 4: Dependency Analysis
    if profile['scan_dependencies']:
        with st.spinner("📦 Analyzing dependencies..."):
            dependencies = scanner.dep_analyzer.analyze(scanner.root_path)
            scanner.metrics['dependencies'] = dependencies
            st.session_state.scan_results['dependencies'] = dependencies
    
    # Phase 5: External Tools
    if run_external_tools and profile['external_tools']:
        st.write("🛠️ Running external tools...")
        tool_results = {}
        
        for tool_name in profile['external_tools']:
            if tool_name in scanner.tool_runner.available_tools:
                with st.spinner(f"Running {tool_name}..."):
                    result = scanner.tool_runner.run_tool(
                        tool_name,
                        scanner.root_path,
                        Path(BACKUP_DIR) / datetime.now().strftime("%Y%m%d_%H%M%S")
                    )
                    tool_results[tool_name] = result
                    
                    # Add issues to scanner
                    if result and result['status'] == 'success':
                        scanner.issues[f'tool_{tool_name}'] = result['issues']
        
        st.session_state.scan_results['tool_results'] = tool_results
    
    # Calculate scores
    scanner.calculate_scores()
    
    # Export SARIF if requested
    if export_sarif:
        sarif_path = scanner.root_path / 'tuokit_scan_results.sarif'
        SARIFExporter.export(scanner, sarif_path)
        st.session_state.scan_results['sarif_path'] = str(sarif_path)
    
    # Record scan duration
    scanner.metrics['scan_duration'] = time.time() - start_time
    
    st.session_state.scan_complete = True
    st.success(f"✅ Scan complete! Analyzed {len(files)} files in {scanner.metrics['scan_duration']:.1f} seconds")
    st.rerun()

def display_results():
    """Display comprehensive scan results"""
    scanner = st.session_state.scanner
    
    # Dashboard
    st.header("📊 Scan Results Dashboard")
    
    # Visual dashboard
    fig = create_visual_dashboard(scanner)
    st.plotly_chart(fig, use_container_width=True)
    
    # Score cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Overall Health",
            f"{scanner.metrics['health_score']}%",
            delta=None,
            help="Weighted average of all scores"
        )
    
    with col2:
        st.metric(
            "Security Score",
            f"{scanner.metrics['security_score']}%",
            delta=None,
            help="Based on security vulnerabilities found"
        )
    
    with col3:
        st.metric(
            "Quality Score",
            f"{scanner.metrics['quality_score']}%",
            delta=None,
            help="Based on code quality issues"
        )
    
    with col4:
        st.metric(
            "Performance Score",
            f"{scanner.metrics['performance_score']}%",
            delta=None,
            help="Based on performance patterns"
        )
    
    # Technology detection results
    if scanner.metrics['technologies']:
        st.header("🔧 Detected Technologies")
        
        tech_cols = st.columns(len(scanner.metrics['technologies']))
        for idx, (tech, info) in enumerate(scanner.metrics['technologies'].items()):
            with tech_cols[idx]:
                st.metric(tech, f"{info['confidence']}% confidence")
                with st.expander("Evidence"):
                    for evidence in info['evidence']:
                        st.write(f"• {evidence}")
    
    # Issue tabs
    tabs = st.tabs([
        "🔒 Security",
        "📈 Quality",
        "⚡ Performance",
        "📦 Dependencies",
        "🛠️ Tool Results",
        "📊 Summary"
    ])
    
    with tabs[0]:  # Security
        display_security_issues(scanner)
    
    with tabs[1]:  # Quality
        display_quality_issues(scanner)
    
    with tabs[2]:  # Performance
        display_performance_issues(scanner)
    
    with tabs[3]:  # Dependencies
        display_dependency_analysis(scanner)
    
    with tabs[4]:  # Tool Results
        display_tool_results()
    
    with tabs[5]:  # Summary
        display_summary(scanner)

def display_security_issues(scanner):
    """Display security issues with grouping and actions"""
    st.subheader("🔒 Security Analysis")
    
    security_issues = scanner.issues.get('security', [])
    
    if not security_issues:
        st.success("✅ No security issues detected!")
        return
    
    # Initialize fix engine in session state if needed
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    
    # Group by severity
    severity_groups = defaultdict(list)
    for issue in security_issues:
        severity_groups[issue['severity']].append(issue)
    
    # Display by severity
    for severity in ['critical', 'high', 'medium', 'low']:
        if severity in severity_groups:
            issues = severity_groups[severity]
            
            severity_color = {
                'critical': '🔴',
                'high': '🟠',
                'medium': '🟡',
                'low': '🟢'
            }
            
            st.write(f"{severity_color[severity]} **{severity.upper()} Severity** ({len(issues)} issues)")
            
            # Group by type
            type_groups = defaultdict(list)
            for issue in issues:
                type_groups[issue['type']].append(issue)
            
            for issue_type, type_issues in type_groups.items():
                with st.expander(f"{issue_type.replace('_', ' ').title()} ({len(type_issues)} occurrences)"):
                    for idx, issue in enumerate(type_issues[:5]):  # Show first 5
                        st.write(f"**{issue['file']}** (line {issue['line']})")
                        st.code(issue['match'], language='text')
                        st.caption(issue['description'])
                        
                        # Action buttons
                        col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
                        with col1:
                            if st.button("📋 Summary", key=f"summary_sec_{severity}_{issue_type}_{idx}"):
                                st.session_state[f'show_summary_sec_{severity}_{issue_type}_{idx}'] = True
                        with col2:
                            if st.button("🔍 Context", key=f"ctx_sec_{severity}_{issue_type}_{idx}"):
                                st.session_state[f'show_context_sec_{severity}_{issue_type}_{idx}'] = True
                        with col3:
                            if st.button("🤖 AI Fix", key=f"ai_sec_{severity}_{issue_type}_{idx}"):
                                st.session_state[f'show_ai_sec_{severity}_{issue_type}_{idx}'] = True
                        with col4:
                            if st.button("💻 Dev Fix", key=f"dev_sec_{severity}_{issue_type}_{idx}"):
                                st.session_state[f'show_dev_sec_{severity}_{issue_type}_{idx}'] = True
                        
                        # Show summary if requested
                        if st.session_state.get(f'show_summary_sec_{severity}_{issue_type}_{idx}', False):
                            with st.container():
                                st.markdown("---")
                                summary = generate_issue_summary(issue, 'security')
                                st.markdown(summary)
                                if st.button("Close Summary", key=f"close_summary_sec_{severity}_{issue_type}_{idx}"):
                                    st.session_state[f'show_summary_sec_{severity}_{issue_type}_{idx}'] = False
                                    st.rerun()
                        
                        # Show context if requested
                        if st.session_state.get(f'show_context_sec_{severity}_{issue_type}_{idx}', False):
                            with st.container():
                                st.markdown("---")
                                st.subheader("Code Context")
                                context = st.session_state.fixer._get_context(
                                    scanner.root_path / issue['file'], 
                                    issue['line'], 
                                    15
                                )
                                st.code(context, language='python')
                                if st.button("Close Context", key=f"close_ctx_sec_{severity}_{issue_type}_{idx}"):
                                    st.session_state[f'show_context_sec_{severity}_{issue_type}_{idx}'] = False
                                    st.rerun()
                        
                        # Show AI prompt if requested
                        if st.session_state.get(f'show_ai_sec_{severity}_{issue_type}_{idx}', False):
                            with st.container():
                                st.markdown("---")
                                prompt = f"""Fix this security vulnerability:

Issue Type: {issue['type']}
Severity: {issue['severity']}
Description: {issue['description']}
File: {issue['file']}
Line: {issue['line']}

Vulnerable Code:
```
{issue['match']}
```

Provide a secure fix that:
1. Completely eliminates the security risk
2. Follows security best practices
3. Maintains the original functionality
4. Includes comments explaining the fix
"""
                                display_prompt_with_copy(prompt, "Security Fix AI Prompt", f"ai_sec_{severity}_{issue_type}_{idx}")
                        
                        # Show dev prompt if requested
                        if st.session_state.get(f'show_dev_sec_{severity}_{issue_type}_{idx}', False):
                            with st.container():
                                st.markdown("---")
                                dev_prompt = st.session_state.fixer.generate_dev_prompt(issue)
                                st.text_area("Developer Fix Prompt", dev_prompt, height=200, key=f"dev_prompt_sec_{severity}_{issue_type}_{idx}")
                    
                    if len(type_issues) > 5:
                        st.info(f"... and {len(type_issues) - 5} more {issue_type} issues")

def display_quality_issues(scanner):
    """Display code quality issues"""
    st.subheader("📈 Code Quality Analysis")
    
    # Initialize fix engine in session state if needed
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    
    # Syntax errors section
    syntax_errors = scanner.issues.get('syntax_errors', [])
    if syntax_errors:
        st.error(f"🚨 {len(syntax_errors)} syntax errors found - Code will not run!")
        
        for idx, error in enumerate(syntax_errors):
            with st.expander(f"{error['file']} - Line {error['line']}", expanded=idx < 3):
                st.error(f"**Error**: {error['message']}")
                
                # Get code context
                file_path = scanner.root_path / error['file']
                context = st.session_state.fixer._get_context(file_path, error['line'], 5)
                st.code(context, language='python')
                
                # Action buttons
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    if st.button("🔧 Auto Fix", key=f"autofix_syntax_{idx}"):
                        success, message = st.session_state.fixer.fix_syntax_error(file_path, error)
                        if success:
                            st.success(f"✅ {message}")
                            # Rerun to refresh
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error(f"❌ {message}")
                
                with col2:
                    if st.button("👀 Preview", key=f"preview_syntax_{idx}"):
                        preview = st.session_state.fixer.preview_fix(file_path, error)
                        st.text_area("Fix Preview", preview, height=150, key=f"preview_area_{idx}")
                
                with col3:
                    if st.button("🤖 AI Prompt", key=f"ai_syntax_{idx}"):
                        st.session_state[f'show_ai_syntax_{idx}'] = True
                
                with col4:
                    if st.button("📋 Summary", key=f"summary_syntax_{idx}"):
                        st.session_state[f'show_summary_syntax_{idx}'] = True
                
                # Show AI prompt if requested
                if st.session_state.get(f'show_ai_syntax_{idx}', False):
                    st.markdown("---")
                    prompt = st.session_state.fixer.generate_syntax_error_prompt(error)
                    display_prompt_with_copy(prompt, "Syntax Error Fix Prompt", f"ai_syntax_{idx}")
                
                # Show summary if requested
                if st.session_state.get(f'show_summary_syntax_{idx}', False):
                    st.markdown("---")
                    summary = generate_issue_summary(error, 'syntax_error')
                    st.markdown(summary)
    else:
        st.success("✅ No syntax errors found!")
    
    st.markdown("---")
    
    # Technical debt section (TODOs, FIXMEs, etc.)
    tech_debt = scanner.issues.get('technical_debt', [])
    if tech_debt:
        st.warning(f"💭 {len(tech_debt)} technical debt items found")
        
        # Group by type
        debt_types = defaultdict(list)
        for item in tech_debt:
            debt_types[item['type']].append(item)
        
        # Display each type
        for debt_type, items in debt_types.items():
            st.write(f"### {debt_type.upper()} ({len(items)} items)")
            
            # Create a unique key for each file to avoid duplicates
            seen_items = set()
            
            for idx, item in enumerate(items[:20]):  # Limit display
                # Create unique identifier
                item_id = f"{item['file']}_{item['line']}_{item['type']}"
                if item_id in seen_items:
                    continue
                seen_items.add(item_id)
                
                with st.expander(f"{item['file']}:{item['line']} - {item.get('message', '')[:50]}..."):
                    # Display the TODO/FIXME content
                    st.code(item.get('message', item.get('content', '')), language='text')
                    st.caption(f"Line {item['line']} in {item['file']}")
                    
                    # Three-button interface
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        if st.button("🗑️ Remove", key=f"remove_{debt_type}_{idx}",
                                   help="Remove this TODO from the code"):
                            file_path = scanner.root_path / item['file']
                            success, message = st.session_state.fixer.remove_todo(file_path, item)
                            if success:
                                st.success(f"✅ {message}")
                                time.sleep(1)
                                st.rerun()
                            else:
                                st.error(f"❌ {message}")
                    
                    with col2:
                        if st.button("✅ Keep", key=f"keep_{debt_type}_{idx}",
                                   help="Mark as important - keep in code"):
                            st.info("Marked as important to keep")
                            # In a real implementation, this could update a tracking file
                    
                    with col3:
                        if st.button("🤖 AI Prompt", key=f"ai_{debt_type}_{idx}",
                                   help="Generate implementation prompt"):
                            st.session_state[f'show_ai_{debt_type}_{idx}'] = True
                    
                    with col4:
                        if st.button("📋 Summary", key=f"summary_{debt_type}_{idx}",
                                   help="View detailed analysis"):
                            st.session_state[f'show_summary_{debt_type}_{idx}'] = True
                    
                    # Show AI prompt if requested
                    if st.session_state.get(f'show_ai_{debt_type}_{idx}', False):
                        st.markdown("---")
                        prompt = st.session_state.fixer.generate_todo_prompt(item)
                        display_prompt_with_copy(prompt, "TODO Implementation Prompt", f"ai_{debt_type}_{idx}")
                    
                    # Show summary if requested
                    if st.session_state.get(f'show_summary_{debt_type}_{idx}', False):
                        st.markdown("---")
                        summary = generate_issue_summary(item, 'technical_debt')
                        st.markdown(summary)
            
            if len(items) > 20:
                st.info(f"... and {len(items) - 20} more {debt_type.upper()} items")
    else:
        st.success("✅ No technical debt found!")
    
    # Add master prompt generation button
    st.markdown("---")
    if st.button("🤖 Generate Master AI Prompt for All Issues", key="master_prompt_btn"):
        st.session_state.show_master_prompt = True
    
    if st.session_state.get('show_master_prompt', False):
        st.subheader("Master AI Prompt")
        master_prompt = generate_master_prompt(scanner)
        display_prompt_with_copy(master_prompt, "Master Prompt for All Issues", "master_prompt")

def display_performance_issues(scanner):
    """Display performance issues"""
    st.subheader("⚡ Performance Analysis")
    
    perf_issues = scanner.issues.get('performance', [])
    
    if not perf_issues:
        st.success("✅ No performance issues detected!")
        return
    
    # Initialize fix engine if needed
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    
    # Group by type
    type_groups = defaultdict(list)
    for issue in perf_issues:
        type_groups[issue['type']].append(issue)
    
    for issue_type, issues in type_groups.items():
        with st.expander(f"{issue_type.replace('_', ' ').title()} ({len(issues)} occurrences)"):
            st.write(f"**Issue**: {issues[0]['description']}")
            st.write(f"**Severity**: {issues[0]['severity']}")
            
            # Show sample issues
            st.write("**Affected locations**:")
            for idx, issue in enumerate(issues[:5]):
                st.write(f"• {issue['file']}:{issue['line']}")
                
                # Action buttons for each issue
                col1, col2, col3 = st.columns(3)
                with col1:
                    if st.button("📋 Summary", key=f"summary_perf_{issue_type}_{idx}"):
                        st.session_state[f'show_summary_perf_{issue_type}_{idx}'] = True
                with col2:
                    if st.button("🔍 Context", key=f"ctx_perf_{issue_type}_{idx}"):
                        st.session_state[f'show_context_perf_{issue_type}_{idx}'] = True
                with col3:
                    if st.button("🤖 AI Fix", key=f"ai_perf_{issue_type}_{idx}"):
                        st.session_state[f'show_ai_perf_{issue_type}_{idx}'] = True
                
                # Show summary if requested
                if st.session_state.get(f'show_summary_perf_{issue_type}_{idx}', False):
                    st.markdown("---")
                    summary = generate_issue_summary(issue, 'performance')
                    st.markdown(summary)
                
                # Show context if requested
                if st.session_state.get(f'show_context_perf_{issue_type}_{idx}', False):
                    st.markdown("---")
                    context = st.session_state.fixer._get_context(
                        scanner.root_path / issue['file'],
                        issue['line'],
                        10
                    )
                    st.code(context, language='python')
                
                # Show AI prompt if requested
                if st.session_state.get(f'show_ai_perf_{issue_type}_{idx}', False):
                    st.markdown("---")
                    prompt = f"""Optimize this performance issue:

Pattern: {issue['type']}
Description: {issue['description']}
File: {issue['file']}
Line: {issue['line']}

Requirements:
1. Improve algorithmic complexity if possible
2. Reduce resource usage
3. Maintain the same functionality
4. Add comments explaining the optimization
5. Consider edge cases

Provide an optimized solution with explanation of the performance improvement."""
                    display_prompt_with_copy(prompt, "Performance Optimization Prompt", f"ai_perf_{issue_type}_{idx}")
            
            if len(issues) > 5:
                st.caption(f"... and {len(issues) - 5} more occurrences")
            
            # Optimization tips
            st.info(get_performance_tip(issue_type))

def display_dependency_analysis(scanner):
    """Display dependency analysis results"""
    st.subheader("📦 Dependency Analysis")
    
    deps = scanner.metrics.get('dependencies', {})
    
    if not deps or not deps.get('package_managers'):
        st.info("No package managers detected in this project")
        return
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Dependencies", deps['total_dependencies'])
    
    with col2:
        st.metric("Package Managers", len([pm for pm in deps['package_managers'].values() if pm['detected']]))
    
    with col3:
        st.metric("Vulnerabilities", len(deps.get('vulnerabilities', [])))
    
    with col4:
        missing_locks = len(deps.get('missing_lock_files', []))
        st.metric("Missing Lock Files", missing_locks)
    
    # Package manager details
    for pm_name, pm_info in deps['package_managers'].items():
        if pm_info['detected']:
            with st.expander(f"{pm_name} - {len(pm_info['dependencies'])} dependencies"):
                
                # Lock file status
                if pm_info['has_lock_file']:
                    st.success("✅ Lock file present")
                else:
                    st.error("❌ Lock file missing - reproducible builds at risk")
                
                # Vulnerabilities
                if pm_info['vulnerabilities']:
                    st.error(f"🚨 {len(pm_info['vulnerabilities'])} vulnerabilities found")
                    for vuln in pm_info['vulnerabilities']:
                        st.write(f"• **{vuln['package']}** - {vuln['vulnerability']}")
                        st.write(f"  Current: {vuln['current_version']} | Fix: {vuln['fix']}")
                
                # Sample dependencies
                if pm_info['dependencies']:
                    st.write("**Sample dependencies:**")
                    for dep in pm_info['dependencies'][:10]:
                        st.write(f"• {dep['name']} @ {dep['version']}")
                    
                    if len(pm_info['dependencies']) > 10:
                        st.caption(f"... and {len(pm_info['dependencies']) - 10} more")

def display_tool_results():
    """Display external tool results"""
    st.subheader("🛠️ External Tool Results")
    
    tool_results = st.session_state.scan_results.get('tool_results', {})
    
    if not tool_results:
        st.info("No external tools were run")
        return
    
    for tool_name, result in tool_results.items():
        if result['status'] == 'success':
            with st.expander(f"{tool_name} - {result['summary']['total']} issues"):
                # Summary by severity
                st.write("**Issues by severity:**")
                for sev, count in result['summary']['by_severity'].items():
                    if count > 0:
                        st.write(f"• {sev}: {count}")
                
                # Sample issues
                if result['issues']:
                    st.write("**Sample issues:**")
                    for issue in result['issues'][:5]:
                        st.write(f"• {issue['file']}:{issue['line']} - {issue['message']}")
                    
                    if len(result['issues']) > 5:
                        st.caption(f"... and {len(result['issues']) - 5} more issues")
        
        elif result['status'] == 'not_available':
            st.warning(f"{tool_name} not installed - run: `{result['install_command']}`")
        
        else:
            st.error(f"{tool_name} failed: {result.get('error', 'Unknown error')}")

def display_summary(scanner):
    """Display comprehensive summary and exports"""
    st.subheader("📊 Analysis Summary")
    
    # Scan metrics
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("### Scan Metrics")
        st.write(f"• **Files analyzed**: {scanner.metrics['total_files']}")
        st.write(f"• **Lines of code**: {scanner.metrics['total_lines']:,}")
        st.write(f"• **Scan duration**: {scanner.metrics['scan_duration']:.1f} seconds")
        st.write(f"• **Issues found**: {sum(len(issues) for issues in scanner.issues.values())}")
        
        st.write("### Languages")
        for lang, count in scanner.metrics['languages'].items():
            st.write(f"• {lang}: {count} files")
    
    with col2:
        st.write("### Issue Summary")
        for issue_type, issues in scanner.issues.items():
            if issues:
                st.write(f"• **{issue_type.replace('_', ' ').title()}**: {len(issues)}")
        
        # Export options
        st.write("### Export Options")
        
        if st.button("📄 Export Full Report (Markdown)"):
            export_markdown_report(scanner)
        
        if st.button("📊 Export Metrics (JSON)"):
            export_json_metrics(scanner)
        
        if 'sarif_path' in st.session_state.scan_results:
            st.success(f"✅ SARIF report exported to: {st.session_state.scan_results['sarif_path']}")



def get_performance_tip(issue_type: str) -> str:
    """Get performance optimization tip"""
    tips = {
        'nested_loops': "Consider using vectorized operations, hash maps, or algorithmic improvements to reduce complexity.",
        'multiple_db_calls': "Use batch queries, eager loading, or caching to avoid N+1 query problems.",
        'large_list_comp': "Replace with generator expressions for memory efficiency.",
        'sync_file_ops': "Use async I/O operations for better performance in I/O-bound applications."
    }
    return tips.get(issue_type, "Consider optimizing this code pattern for better performance.")

def export_markdown_report(scanner):
    """Export comprehensive markdown report"""
    report = f"""# Code Analysis Report

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Summary
- Overall Health Score: {scanner.metrics['health_score']}%
- Security Score: {scanner.metrics['security_score']}%
- Quality Score: {scanner.metrics['quality_score']}%
- Performance Score: {scanner.metrics['performance_score']}%

## Technologies Detected
{chr(10).join(f"- {tech}: {info['confidence']}% confidence" for tech, info in scanner.metrics['technologies'].items())}

## Issues Found
Total: {sum(len(issues) for issues in scanner.issues.values())}

### By Category
{chr(10).join(f"- {issue_type}: {len(issues)}" for issue_type, issues in scanner.issues.items() if issues)}
"""
    
    report_path = scanner.root_path / f"analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
    with open(report_path, 'w') as f:
        f.write(report)
    
    st.success(f"Report exported to: {report_path}")

def export_json_metrics(scanner):
    """Export metrics as JSON"""
    metrics_data = {
        'scan_date': datetime.now().isoformat(),
        'metrics': scanner.metrics,
        'issue_counts': {k: len(v) for k, v in scanner.issues.items()},
        'technologies': scanner.metrics.get('technologies', {}),
        'dependencies': scanner.metrics.get('dependencies', {})
    }
    
    json_path = scanner.root_path / f"metrics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(json_path, 'w') as f:
        json.dump(metrics_data, f, indent=2)
    
    st.success(f"Metrics exported to: {json_path}")

if __name__ == "__main__":
    main()
# Additional imports for enhanced features
import hashlib
import tempfile

class EnhancedFixEngine:
    """Apply fixes with full backup and rollback support"""
    
    def __init__(self, backup_dir=BACKUP_DIR):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.applied_fixes = []
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def create_backup(self, file_path):
        """Create timestamped backup with session tracking"""
        file_path = Path(file_path)
        backup_name = f"{file_path.stem}_{self.session_id}{file_path.suffix}"
        backup_path = self.backup_dir / backup_name
        
        shutil.copy2(file_path, backup_path)
        
        # Track in session log
        session_log = self.backup_dir / f"session_{self.session_id}.json"
        log_data = []
        if session_log.exists():
            with open(session_log, 'r') as f:
                log_data = json.load(f)
        
        log_data.append({
            'timestamp': datetime.now().isoformat(),
            'original': str(file_path),
            'backup': str(backup_path)
        })
        
        with open(session_log, 'w') as f:
            json.dump(log_data, f, indent=2)
            
        return backup_path
    
    def fix_syntax_error(self, file_path: Path, issue: dict):
        """Fix specific syntax error patterns"""
        line_num = issue.get('line', 0)
        
        try:
            # Create backup first
            backup = self.create_backup(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num > 0 and line_num <= len(lines):
                line = lines[line_num - 1]
                original_line = line
                fixed = False
                
                # Common Python syntax error patterns
                patterns = [
                    # Multiple statements on one line
                    (r'(\s*else\s*:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*elif\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*if\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*try\s*:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*except.*:)\s+(\S.*)', r'\1\n    \2'),
                    # Missing colons
                    (r'^\s*(if|elif|else|try|except|finally|with|for|while|def|class)\s+[^:]+$', r'\g<0>:'),
                    # Unterminated strings (basic fix)
                    (r'^([^"\']*["\'])([^"\']*)$', r'\1\2\1'),
                ]
                
                for pattern, replacement in patterns:
                    if re.match(pattern, line):
                        lines[line_num - 1] = re.sub(pattern, replacement, line)
                        fixed = True
                        break
                
                if fixed:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(lines)
                    
                    self.applied_fixes.append({
                        'file': str(file_path),
                        'line': line_num,
                        'type': 'syntax_error',
                        'original': original_line.strip(),
                        'fixed': lines[line_num - 1].strip(),
                        'backup': str(backup)
                    })
                    
                    return True, f"Fixed syntax error at line {line_num}"
                else:
                    return False, "Could not auto-fix this pattern"
            
            return False, "Invalid line number"
            
        except Exception as e:
            return False, f"Error applying fix: {str(e)}"
    
    def preview_fix(self, file_path: Path, issue: dict) -> str:
        """Preview what the fix would look like"""
        line_num = issue.get('line', 0)
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num > 0 and line_num <= len(lines):
                original = lines[line_num - 1]
                
                # Apply patterns without saving
                for pattern, replacement in [
                    (r'(\s*else\s*:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*elif\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                    (r'(\s*if\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                ]:
                    if re.match(pattern, original):
                        preview = re.sub(pattern, replacement, original)
                        return f"Original:\n{original}\nFixed:\n{preview}"
                
                return "No automatic fix available for this pattern"
        except:
            return "Could not generate preview"
    
    def remove_todo(self, file_path: Path, issue: dict):
        """Remove TODO/FIXME/HACK from code"""
        line_num = issue['line']
        
        try:
            backup = self.create_backup(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num <= len(lines):
                line = lines[line_num - 1]
                original = line
                
                # Remove TODO comment patterns
                patterns = [
                    r'#\s*TODO\s*:?\s*',
                    r'#\s*FIXME\s*:?\s*',
                    r'#\s*HACK\s*:?\s*',
                    r'#\s*XXX\s*:?\s*'
                ]
                
                for pattern in patterns:
                    line = re.sub(pattern, '# ', line, flags=re.IGNORECASE)
                
                # If line is now just empty comment, remove entire line
                if line.strip() in ['#', '# ']:
                    lines.pop(line_num - 1)
                    action = "Removed entire TODO line"
                else:
                    lines[line_num - 1] = line
                    action = "Removed TODO marker, kept comment"
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                
                self.applied_fixes.append({
                    'file': str(file_path),
                    'line': line_num,
                    'type': 'remove_todo',
                    'original': original.strip(),
                    'action': action,
                    'backup': str(backup)
                })
                
                return True, action
                
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def generate_todo_prompt(self, issue: dict) -> str:
        """Generate surgical AI prompt for TODO implementation"""
        context = self._get_context(Path(issue['file']), issue['line'], 10)
        
        prompt = f"""Please implement the following {issue['type'].upper()} item:

📍 **Location**: `{issue['file']}` line {issue['line']}
📝 **Task**: {issue.get('message', issue.get('content', ''))}

**Context (surrounding code):**
```python
{context}
```

**Requirements:**
1. ✅ Implement ONLY what the {issue['type'].upper()} describes
2. 🎯 Keep the solution minimal and focused
3. 🎨 Match the surrounding code style exactly
4. 🛡️ Include appropriate error handling
5. 💬 Add a brief comment explaining the implementation
6. 🚫 Do not modify any other parts of the code

**Expected Solution Format:**
```python
# Line {issue['line']} - Replace the {issue['type'].upper()} line with:
<your implementation here>
```"""
        
        return prompt
    
    def generate_syntax_error_prompt(self, issue: dict) -> str:
        """Generate AI prompt for fixing syntax errors"""
        context = self._get_context(Path(issue['file']), issue.get('line', 0), 10)
        
        prompt = f"""Please fix the following syntax error in Python code:

📍 **Location**: `{issue['file']}` line {issue.get('line', 0)}
❌ **Error**: {issue.get('message', 'syntax error')}

**Context (surrounding code):**
```python
{context}
```

**Requirements:**
1. ✅ Fix ONLY the syntax error on line {issue.get('line', 0)}
2. 🎯 Make the minimal change necessary
3. 🎨 Preserve the original indentation
4. 💡 Maintain the intended logic
5. 🚫 Do not modify any other lines

**Expected Output Format:**
```python
# Line {issue.get('line', 0)} - Fixed version:
<corrected line here>
```

**Explanation:**
<Brief explanation of what was wrong and what you changed>"""
        
        return prompt
    
    def generate_dev_prompt(self, issue: dict) -> str:
        """Generate developer-friendly implementation prompt"""
        issue_type = issue.get('type', 'issue')
        
        prompt = f"""Developer Task: {issue_type.upper()}

File: {issue['file']}
Line: {issue['line']}
{f"Message: {issue.get('message', '')}" if issue.get('message') else ""}

Quick implementation needed. Keep it simple and follow existing patterns in the codebase.
Focus on functionality over perfection - we can refactor later if needed.

Current code context:
{self._get_context(Path(issue['file']), issue['line'], 5)}

Just show the replacement code, no extra explanation needed."""
        
        return prompt
    
    def _get_context(self, file_path: Path, line_num: int, context_size: int = 10) -> str:
        """Get code context around a line"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start = max(0, line_num - context_size - 1)
            end = min(len(lines), line_num + context_size)
            
            context = []
            for i in range(start, end):
                marker = ">>>" if i == line_num - 1 else "   "
                context.append(f"{marker} {i+1}: {lines[i].rstrip()}")
            
            return '\n'.join(context)
            
        except Exception:
            return "Could not read context"
    
    def rollback_fix(self, fix_record: dict):
        """Rollback a specific fix using backup"""
        try:
            backup_path = Path(fix_record['backup'])
            original_path = Path(fix_record['file'])
            
            if backup_path.exists():
                shutil.copy2(backup_path, original_path)
                return True, "Successfully rolled back"
        except Exception as e:
            return False, f"Rollback failed: {e}"
        
        return False, "Backup not found"

def generate_issue_summary(issue: dict, issue_type: str) -> str:
    """Generate a comprehensive summary of an issue with analysis"""
    
    if issue_type == 'security':
        severity_emoji = {'critical': '🔴', 'high': '🟠', 'medium': '🟡', 'low': '🟢'}
        
        summary = f"""## Security Issue Summary

**Type**: {issue['type'].replace('_', ' ').title()}
**Severity**: {severity_emoji.get(issue['severity'], '⚪')} {issue['severity'].upper()}
**File**: `{issue['file']}`
**Line**: {issue['line']}

### Description
{issue['description']}

### Code Sample
```
{issue.get('match', 'N/A')}
```

### Risk Analysis
- **Immediate Risk**: {_get_risk_level(issue['severity'])}
- **Potential Impact**: {_get_impact_description(issue['type'])}
- **Exploitation Difficulty**: {_get_exploitation_difficulty(issue['type'])}

### Remediation Steps
{_get_remediation_steps(issue['type'])}

### Additional Context
- **Category**: {issue.get('category', 'General')}
- **Pattern**: {issue['type']}
- **Detection Confidence**: High
"""
    
    elif issue_type == 'performance':
        summary = f"""## Performance Issue Summary

**Pattern**: {issue['type'].replace('_', ' ').title()}
**Severity**: {issue['severity'].upper()}
**File**: `{issue['file']}`
**Line**: {issue['line']}

### Description
{issue['description']}

### Performance Impact
- **Complexity**: {_get_complexity_impact(issue['type'])}
- **Resource Usage**: {_get_resource_impact(issue['type'])}
- **Scalability Concern**: {_get_scalability_concern(issue['type'])}

### Optimization Strategy
{_get_optimization_strategy(issue['type'])}

### Best Practices
{_get_performance_best_practices(issue['type'])}
"""
    
    elif issue_type == 'syntax_error':
        summary = f"""## Syntax Error Summary

**Error**: {issue['message']}
**File**: `{issue['file']}`
**Line**: {issue['line']}
**Severity**: CRITICAL (Blocks Execution)

### Error Analysis
This syntax error prevents the code from running. Common causes:
{_analyze_syntax_error(issue['message'])}

### Quick Fixes
1. Check for missing colons after control statements
2. Verify proper indentation (4 spaces)
3. Ensure all brackets and quotes are closed
4. Look for multiple statements on one line

### Prevention Tips
- Use an IDE with syntax highlighting
- Enable linting in your editor
- Run code frequently during development
"""
    
    else:  # technical_debt
        summary = f"""## Technical Debt Summary

**Type**: {issue['type'].upper()}
**File**: `{issue['file']}`
**Line**: {issue['line']}
**Message**: {issue.get('message', 'No message provided')}

### Debt Analysis
- **Priority**: {_get_debt_priority(issue['type'])}
- **Effort Estimate**: {_get_effort_estimate(issue['type'])}
- **Risk if Ignored**: {_get_debt_risk(issue['type'])}

### Implementation Guidance
{_get_implementation_guidance(issue['type'], issue.get('message', ''))}

### Related Best Practices
- Document why the debt exists
- Set a timeline for resolution
- Consider the impact on maintainability
"""
    
    return summary

# Helper functions for summary generation
def _get_risk_level(severity):
    levels = {
        'critical': 'Immediate threat - could lead to system compromise',
        'high': 'Significant risk - should be addressed within 24 hours',
        'medium': 'Moderate risk - plan remediation within a week',
        'low': 'Minor risk - include in next maintenance cycle'
    }
    return levels.get(severity, 'Unknown risk level')

def _get_impact_description(issue_type):
    impacts = {
        'aws_access_key': 'Full AWS account compromise, potential data breach and financial loss',
        'private_key': 'Complete system access, identity theft, encrypted data compromise',
        'password_in_code': 'Unauthorized access to systems and data',
        'api_key': 'Third-party service abuse, data access, potential billing issues',
        'sql_injection': 'Database compromise, data theft, data manipulation',
        'eval_usage': 'Remote code execution, complete system compromise'
    }
    return impacts.get(issue_type, 'Potential security breach')

def _get_exploitation_difficulty(issue_type):
    difficulty = {
        'aws_access_key': 'Trivial - automated scanners constantly search for these',
        'private_key': 'Easy - standard tools can utilize exposed keys',
        'password_in_code': 'Easy - simple grep searches reveal these',
        'sql_injection': 'Moderate - requires some SQL knowledge',
        'eval_usage': 'Moderate - requires crafting malicious input'
    }
    return difficulty.get(issue_type, 'Varies based on implementation')

def _get_remediation_steps(issue_type):
    steps = {
        'aws_access_key': """1. Immediately rotate the exposed AWS access key
2. Audit AWS CloudTrail for any unauthorized access
3. Use environment variables or AWS Secrets Manager
4. Never commit credentials to version control""",
        'password_in_code': """1. Remove the hardcoded password immediately
2. Use environment variables for sensitive data
3. Implement a secure configuration management system
4. Consider using a secrets vault solution""",
        'sql_injection': """1. Use parameterized queries or prepared statements
2. Validate and sanitize all user input
3. Apply the principle of least privilege to database users
4. Implement input validation on both client and server side"""
    }
    return steps.get(issue_type, "1. Remove the security vulnerability\n2. Implement secure alternative\n3. Review similar code for patterns")

def _get_complexity_impact(pattern_type):
    complexity = {
        'nested_loops': 'O(n²) or higher - exponential slowdown with data growth',
        'multiple_db_calls': 'O(n) database roundtrips - severe latency issues',
        'large_list_comp': 'High memory usage - potential out of memory errors',
        'sync_file_ops': 'Blocking I/O - thread starvation in concurrent systems'
    }
    return complexity.get(pattern_type, 'Performance degradation under load')

def _get_resource_impact(pattern_type):
    return {
        'nested_loops': 'High CPU usage',
        'multiple_db_calls': 'Network bandwidth and connection pool exhaustion',
        'large_list_comp': 'Memory pressure and GC overhead',
        'sync_file_ops': 'Thread blocking and reduced throughput'
    }.get(pattern_type, 'Increased resource consumption')

def _get_scalability_concern(pattern_type):
    return {
        'nested_loops': 'Critical - will not scale with data growth',
        'multiple_db_calls': 'High - database becomes bottleneck',
        'large_list_comp': 'Medium - memory limits scalability',
        'sync_file_ops': 'Medium - limits concurrent request handling'
    }.get(pattern_type, 'May limit application scalability')

def _get_optimization_strategy(pattern_type):
    strategies = {
        'nested_loops': """- Use hash maps for O(1) lookups instead of inner loops
- Consider sorting and binary search for O(n log n)
- Evaluate if the algorithm can be redesigned
- Use built-in optimized functions when possible""",
        'multiple_db_calls': """- Implement eager loading or JOIN queries
- Use batch operations for bulk updates
- Cache frequently accessed data
- Consider database views or stored procedures"""
    }
    return strategies.get(pattern_type, "Profile the code to identify bottlenecks and optimize accordingly")

def _get_performance_best_practices(pattern_type):
    return """- Measure before and after optimization
- Focus on algorithmic improvements over micro-optimizations
- Consider caching strategies
- Use profiling tools to identify real bottlenecks
- Document performance-critical sections"""

def _analyze_syntax_error(error_msg):
    error_lower = error_msg.lower()
    if 'invalid syntax' in error_lower:
        return """- Missing or misplaced punctuation (colons, commas, brackets)
- Keywords used as variable names
- Incomplete statements"""
    elif 'indentation' in error_lower:
        return """- Inconsistent indentation (mixing tabs and spaces)
- Incorrect indentation level
- Missing indentation after colon"""
    else:
        return """- Check the line mentioned in the error
- Look at the line before for unclosed brackets
- Verify all quotes and parentheses are matched"""

def _get_debt_priority(debt_type):
    priorities = {
        'fixme': 'High - indicates broken functionality',
        'hack': 'Medium - temporary solution that needs proper implementation',
        'todo': 'Medium - missing functionality',
        'xxx': 'Low - marker for future consideration'
    }
    return priorities.get(debt_type, 'Medium')

def _get_effort_estimate(debt_type):
    estimates = {
        'fixme': '2-4 hours - usually requires fixing broken logic',
        'hack': '4-8 hours - needs proper design and implementation',
        'todo': '1-4 hours - depends on complexity',
        'xxx': '1-2 hours - usually minor improvements'
    }
    return estimates.get(debt_type, 'Varies based on context')

def _get_debt_risk(debt_type):
    risks = {
        'fixme': 'High - may cause bugs or system failures',
        'hack': 'Medium - technical debt accumulation, harder maintenance',
        'todo': 'Low-Medium - missing features or optimizations',
        'xxx': 'Low - usually performance or clarity issues'
    }
    return risks.get(debt_type, 'Potential maintenance burden')

def _get_implementation_guidance(debt_type, message):
    base_guidance = {
        'fixme': "Address the root cause of the issue, not just symptoms",
        'hack': "Refactor to use proper design patterns and clean code principles",
        'todo': "Implement the missing functionality with proper tests",
        'xxx': "Review if this is still needed or can be removed"
    }
    
    guidance = base_guidance.get(debt_type, "Analyze the requirement and implement properly")
    
    # Add context-specific guidance based on message keywords
    if message:
        message_lower = message.lower()
        if 'performance' in message_lower:
            guidance += "\n- Profile before optimizing\n- Consider caching or algorithmic improvements"
        elif 'security' in message_lower:
            guidance += "\n- Follow security best practices\n- Consider threat modeling"
        elif 'error' in message_lower or 'exception' in message_lower:
            guidance += "\n- Implement proper error handling\n- Add logging for debugging"
    
    return guidance

def generate_master_prompt(scanner) -> str:
    """Generate comprehensive AI prompt for all issues"""
    all_issues = []
    
    # Collect all issues with their types
    for issue_type, issues in scanner.issues.items():
        for issue in issues:
            all_issues.append((issue_type, issue))
    
    # Sort by severity
    severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
    all_issues.sort(key=lambda x: severity_order.get(x[1].get('severity', 'medium'), 2))
    
    prompt = f"""# Comprehensive Code Analysis - Fix Request

## Project Overview
- **Total Files Analyzed**: {scanner.metrics['total_files']}
- **Total Lines**: {scanner.metrics['total_lines']:,}
- **Health Score**: {scanner.metrics['health_score']}%
- **Languages**: {', '.join(scanner.metrics['languages'].keys())}

## Critical Issues Summary
- **Security Score**: {scanner.metrics['security_score']}%
- **Quality Score**: {scanner.metrics['quality_score']}%
- **Performance Score**: {scanner.metrics['performance_score']}%

## Issues to Fix (Priority Order)

"""
    
    # Group by severity
    current_severity = None
    issue_count = 0
    
    for issue_type, issue in all_issues[:30]:  # Limit to top 30 issues
        issue_severity = issue.get('severity', 'medium')
        
        if issue_severity != current_severity:
            if current_severity is not None:
                prompt += "\n"
            prompt += f"### {issue_severity.upper()} Priority Issues\n\n"
            current_severity = issue_severity
        
        issue_count += 1
        prompt += f"**{issue_count}. {issue_type.replace('_', ' ').title()}**\n"
        prompt += f"- File: `{issue.get('file', 'unknown')}`\n"
        prompt += f"- Line: {issue.get('line', 'unknown')}\n"
        
        if issue_type == 'security':
            prompt += f"- Type: {issue.get('type', 'unknown')}\n"
            prompt += f"- Description: {issue.get('description', 'Security vulnerability')}\n"
        elif issue_type == 'syntax_errors':
            prompt += f"- Error: {issue.get('message', 'Syntax error')}\n"
        elif issue_type == 'technical_debt':
            prompt += f"- Type: {issue.get('type', 'TODO').upper()}\n"
            prompt += f"- Message: {issue.get('message', 'No message')}\n"
        elif issue_type == 'performance':
            prompt += f"- Pattern: {issue.get('type', 'unknown')}\n"
            prompt += f"- Description: {issue.get('description', 'Performance issue')}\n"
        
        prompt += "\n"
    
    if len(all_issues) > 30:
        prompt += f"\n... and {len(all_issues) - 30} more issues\n"
    
    prompt += """
## Fix Requirements

1. **For Security Issues**: 
   - Remove all hardcoded secrets
   - Use environment variables or secure vaults
   - Fix injection vulnerabilities with parameterized queries

2. **For Syntax Errors**:
   - Fix syntax while preserving logic
   - Ensure code runs without errors
   - Follow PEP 8 style guidelines

3. **For Performance Issues**:
   - Optimize algorithms (reduce complexity)
   - Implement caching where appropriate
   - Use async operations for I/O

4. **For Technical Debt**:
   - Implement TODOs with production-ready code
   - Remove HACKs with proper solutions
   - Fix FIXMEs with permanent solutions

## Output Format

For each fix, provide:
```
File: [filename]
Line: [line number]
Issue: [brief description]
Fix:
```[fixed code]```
Explanation: [what was changed and why]
```

Start with the highest priority issues first."""
    
    return prompt

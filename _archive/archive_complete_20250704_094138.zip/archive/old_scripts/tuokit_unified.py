"""
TuoKit Unified - Single Entry Point for All TuoKit Applications
Consolidates app.py, app_modern.py, main.py, and all toolkits
"""

import streamlit as st

# MUST BE FIRST - Set page config before any other st commands
st.set_page_config(
    page_title="TuoKit Unified",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

import os
import sys
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List, Optional, Any

# Add pages directory to path for imports
sys.path.append(str(Path(__file__).parent))
sys.path.append(str(Path(__file__).parent / "pages"))

# Import database and utilities
from utils import DatabaseManager, get_available_models, safe_ollama_generate

# Import consolidated toolkits
toolkit_import_errors = []
try:
    from learning_toolkit import main as learning_main
except ImportError as e:
    toolkit_import_errors.append(f"Learning Toolkit: {e}")
    learning_main = None

try:
    from documentation_toolkit import main as documentation_main
except ImportError as e:
    toolkit_import_errors.append(f"Documentation Toolkit: {e}")
    documentation_main = None

try:
    from smalltalk_toolkit import main as smalltalk_main
except ImportError as e:
    toolkit_import_errors.append(f"SmallTalk Toolkit: {e}")
    smalltalk_main = None

try:
    from error_analysis_toolkit import main as error_analysis_main
except ImportError as e:
    toolkit_import_errors.append(f"Error Analysis Toolkit: {e}")
    error_analysis_main = None

try:
    from diagnostic_toolkit import main as diagnostic_main
except ImportError as e:
    toolkit_import_errors.append(f"Diagnostic Toolkit: {e}")
    diagnostic_main = None

# Initialize database
db = DatabaseManager()

# ============== CONFIGURATION ==============
UNIFIED_CONFIG = {
    "app_name": "TuoKit Unified",
    "version": "3.0",
    "default_model": "deepseek-r1:latest",
    "enable_analytics": True,
    "enable_experimental": False
}

# Tool registry with categories and metadata
TOOL_REGISTRY = {
    "dashboards": {
        "name": "📊 Dashboards",
        "description": "Analytics and overview",
        "tools": {
            "home": {
                "name": "Home Dashboard",
                "icon": "🏠",
                "description": "Overview and quick stats",
                "type": "internal",
                "function": "show_home_dashboard"
            },
            "analytics": {
                "name": "Analytics",
                "icon": "📈",
                "description": "Usage analytics and insights",
                "type": "internal",
                "function": "show_analytics"
            },
            "activity": {
                "name": "Activity Feed",
                "icon": "📋",
                "description": "Recent activity across all tools",
                "type": "internal",
                "function": "show_activity_feed"
            }
        }
    },
    "code_tools": {
        "name": "💻 Code Intelligence",
        "description": "Code analysis and generation tools",
        "tools": {
            "code_explainer": {
                "name": "Code Explainer",
                "icon": "🔍",
                "description": "Explain code in any language",
                "type": "page",
                "page": "pages/code_explainer.py"
            },
            "code_scanner": {
                "name": "Code Scanner",
                "icon": "🔬",
                "description": "Deep code analysis with metrics",
                "type": "page",
                "page": "pages/enhanced_scanner_v2.py"
            },
            "code_debugger": {
                "name": "Code Debugger",
                "icon": "🐛",
                "description": "Debug code with AI assistance",
                "type": "page",
                "page": "pages/code_debugger.py"
            },
            "code_generator": {
                "name": "Code Generator",
                "icon": "🤖",
                "description": "Generate code from descriptions",
                "type": "page",
                "page": "pages/code_generator.py"
            },
            "code_formatter": {
                "name": "Code Formatter",
                "icon": "🎨",
                "description": "Format and beautify code",
                "type": "page",
                "page": "pages/code_formatter.py"
            }
        }
    },
    "sql_tools": {
        "name": "🗄️ SQL & Data",
        "description": "SQL and database tools",
        "tools": {
            "sql_toolkit": {
                "name": "SQL Toolkit",
                "icon": "🗄️",
                "description": "Unified SQL tools (Generator, Optimizer, Pipeline)",
                "type": "page",
                "page": "pages/sql_toolkit.py"
            },
            "sql_academy": {
                "name": "SQL Academy",
                "icon": "🎓",
                "description": "Learn SQL interactively",
                "type": "page",
                "page": "pages/sql_academy.py"
            }
        }
    },
    "error_tools": {
        "name": "🔧 Error & Debug",
        "description": "Error analysis and debugging",
        "tools": {
            "error_analysis": {
                "name": "Error Analysis Toolkit",
                "icon": "🔍",
                "description": "Comprehensive error analysis suite",
                "type": "toolkit",
                "function": "error_analysis_main"
            },
            "crash_analyzer": {
                "name": "Crash Analyzer",
                "icon": "🚨",
                "description": "Analyze crash dumps and logs",
                "type": "page",
                "page": "pages/crash_analyzer.py"
            }
        }
    },
    "learning_tools": {
        "name": "📚 Learning & Docs",
        "description": "Learning and documentation tools",
        "tools": {
            "learning_toolkit": {
                "name": "Learning Toolkit",
                "icon": "🎓",
                "description": "EduMind, Study Guides, SQL Academy",
                "type": "toolkit",
                "function": "learning_main"
            },
            "documentation_toolkit": {
                "name": "Documentation Toolkit",
                "icon": "📚",
                "description": "Doc Tools, Knowledge Library, Help",
                "type": "toolkit",
                "function": "documentation_main"
            }
        }
    },
    "ruby_rails": {
        "name": "💎 Ruby & Rails",
        "description": "Ruby and Rails development tools",
        "tools": {
            "rails_toolkit": {
                "name": "Rails Toolkit",
                "icon": "🚂",
                "description": "Unified Rails development tools",
                "type": "page",
                "page": "pages/rails_toolkit.py"
            },
            "ruby_toolkit": {
                "name": "Ruby Toolkit",
                "icon": "💎",
                "description": "Ruby development suite",
                "type": "page",
                "page": "pages/ruby_toolkit.py"
            }
        }
    },
    "smalltalk_tools": {
        "name": "🦆 SmallTalk",
        "description": "SmallTalk development tools",
        "tools": {
            "smalltalk_toolkit": {
                "name": "SmallTalk Toolkit",
                "icon": "🦆",
                "description": "Complete SmallTalk development suite",
                "type": "toolkit",
                "function": "smalltalk_main"
            }
        }
    },
    "agent_systems": {
        "name": "🤖 Agent Systems",
        "description": "AI agent and automation tools",
        "tools": {
            "agent_hub": {
                "name": "Agent Hub",
                "icon": "🤖",
                "description": "Unified agent management system",
                "type": "page",
                "page": "pages/agent_hub.py"
            }
        }
    },
    "system_tools": {
        "name": "⚙️ System & Config",
        "description": "System management and configuration",
        "tools": {
            "diagnostics": {
                "name": "Diagnostic Toolkit",
                "icon": "🔧",
                "description": "System diagnostics and fixes",
                "type": "toolkit",
                "function": "diagnostic_main"
            },
            "migration_dashboard": {
                "name": "Migration Dashboard",
                "icon": "📊",
                "description": "Monitor tool migrations",
                "type": "page",
                "page": "pages/migration_dashboard.py"
            },
            "settings": {
                "name": "Settings",
                "icon": "⚙️",
                "description": "Configure TuoKit",
                "type": "internal",
                "function": "show_settings"
            }
        }
    }
}

# ============== CORE FUNCTIONS ==============

def get_tool_stats() -> Dict[str, Any]:
    """Get usage statistics for all tools"""
    try:
        # Get usage counts by tool
        tool_stats = db.execute_query("""
            SELECT tool, COUNT(*) as usage_count, 
                   MAX(created_at) as last_used
            FROM queries
            WHERE created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
            GROUP BY tool
            ORDER BY usage_count DESC
            LIMIT 10
        """)
        
        # Get total queries
        total = db.execute_query("""
            SELECT COUNT(*) as total,
                   COUNT(DISTINCT tool) as unique_tools
            FROM queries
            WHERE created_at > CURRENT_TIMESTAMP - INTERVAL '30 days'
        """)
        
        # Get knowledge items
        knowledge = db.execute_query("""
            SELECT COUNT(*) as total,
                   COUNT(DISTINCT category) as categories
            FROM knowledge_units
        """)
        
        return {
            "tool_usage": tool_stats or [],
            "total_queries": total[0]['total'] if total else 0,
            "unique_tools": total[0]['unique_tools'] if total else 0,
            "knowledge_items": knowledge[0]['total'] if knowledge else 0,
            "knowledge_categories": knowledge[0]['categories'] if knowledge else 0
        }
    except Exception as e:
        st.error(f"Error getting stats: {e}")
        return {
            "tool_usage": [],
            "total_queries": 0,
            "unique_tools": 0,
            "knowledge_items": 0,
            "knowledge_categories": 0
        }

def show_home_dashboard():
    """Display home dashboard"""
    st.title("🏠 TuoKit Unified Dashboard")
    st.caption(f"Version {UNIFIED_CONFIG['version']} - All tools in one place")
    
    # Get statistics
    stats = get_tool_stats()
    
    # Metrics row
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Queries (30d)", f"{stats['total_queries']:,}")
    with col2:
        st.metric("Active Tools", stats['unique_tools'])
    with col3:
        st.metric("Knowledge Items", f"{stats['knowledge_items']:,}")
    with col4:
        st.metric("Categories", stats['knowledge_categories'])
    
    # Two column layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Tool categories overview
        st.subheader("🧰 Tool Categories")
        
        for category_id, category in TOOL_REGISTRY.items():
            if category_id not in ["dashboards"]:  # Skip dashboard category
                with st.expander(f"{category['name']} ({len(category['tools'])} tools)"):
                    st.write(category['description'])
                    
                    tool_cols = st.columns(2)
                    for i, (tool_id, tool) in enumerate(category['tools'].items()):
                        with tool_cols[i % 2]:
                            if st.button(
                                f"{tool['icon']} {tool['name']}",
                                key=f"home_{tool_id}",
                                help=tool['description'],
                                use_container_width=True
                            ):
                                st.session_state.selected_tool = tool_id
                                st.session_state.selected_category = category_id
                                st.rerun()
    
    with col2:
        # Recent activity
        st.subheader("🕒 Recent Activity")
        
        if stats['tool_usage']:
            for item in stats['tool_usage'][:5]:
                tool_name = item['tool'].replace('_', ' ').title()
                st.caption(f"**{tool_name}**: {item['usage_count']} uses")
        else:
            st.info("No recent activity")
        
        # Quick actions
        st.subheader("⚡ Quick Actions")
        
        if st.button("🔧 Run Diagnostics", use_container_width=True):
            st.session_state.selected_tool = "diagnostics"
            st.session_state.selected_category = "system_tools"
            st.rerun()
        
        if st.button("📚 Browse Knowledge", use_container_width=True):
            st.session_state.selected_tool = "documentation_toolkit"
            st.session_state.selected_category = "learning_tools"
            st.rerun()
        
        if st.button("🎓 Start Learning", use_container_width=True):
            st.session_state.selected_tool = "learning_toolkit"
            st.session_state.selected_category = "learning_tools"
            st.rerun()

def show_analytics():
    """Display analytics dashboard"""
    st.title("📈 Analytics Dashboard")
    
    # Date range selector
    col1, col2 = st.columns([3, 1])
    with col1:
        date_range = st.selectbox(
            "Time Period",
            ["Last 7 days", "Last 30 days", "Last 90 days", "All time"],
            index=1
        )
    
    # Convert to days
    days_map = {
        "Last 7 days": 7,
        "Last 30 days": 30,
        "Last 90 days": 90,
        "All time": 9999
    }
    days = days_map[date_range]
    
    try:
        # Usage over time
        usage_data = db.execute_query("""
            SELECT DATE(created_at) as date, COUNT(*) as queries
            FROM queries
            WHERE created_at > CURRENT_TIMESTAMP - INTERVAL %s
            GROUP BY DATE(created_at)
            ORDER BY date
        """, (f"{days} days",))
        
        if usage_data:
            df = pd.DataFrame(usage_data)
            
            fig = px.line(
                df, x='date', y='queries',
                title="Daily Usage Trend",
                labels={'queries': 'Number of Queries', 'date': 'Date'}
            )
            fig.update_layout(template="plotly_dark")
            st.plotly_chart(fig, use_container_width=True)
        
        # Tool popularity
        col1, col2 = st.columns(2)
        
        with col1:
            tool_usage = db.execute_query("""
                SELECT tool, COUNT(*) as count
                FROM queries
                WHERE created_at > CURRENT_TIMESTAMP - INTERVAL %s
                GROUP BY tool
                ORDER BY count DESC
                LIMIT 10
            """, (f"{days} days",))
            
            if tool_usage:
                df_tools = pd.DataFrame(tool_usage)
                df_tools['tool'] = df_tools['tool'].apply(lambda x: x.replace('_', ' ').title())
                
                fig = px.bar(
                    df_tools, x='count', y='tool',
                    orientation='h',
                    title="Top 10 Most Used Tools",
                    labels={'count': 'Usage Count', 'tool': 'Tool'}
                )
                fig.update_layout(template="plotly_dark", yaxis={'categoryorder': 'total ascending'})
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Model usage
            model_usage = db.execute_query("""
                SELECT model, COUNT(*) as count
                FROM queries
                WHERE created_at > CURRENT_TIMESTAMP - INTERVAL %s
                GROUP BY model
                ORDER BY count DESC
                LIMIT 5
            """, (f"{days} days",))
            
            if model_usage:
                df_models = pd.DataFrame(model_usage)
                
                fig = px.pie(
                    df_models, values='count', names='model',
                    title="Model Usage Distribution"
                )
                fig.update_layout(template="plotly_dark")
                st.plotly_chart(fig, use_container_width=True)
        
        # Knowledge growth
        knowledge_growth = db.execute_query("""
            SELECT DATE(created_at) as date, COUNT(*) as items
            FROM knowledge_units
            WHERE created_at > CURRENT_TIMESTAMP - INTERVAL %s
            GROUP BY DATE(created_at)
            ORDER BY date
        """, (f"{days} days",))
        
        if knowledge_growth:
            df_knowledge = pd.DataFrame(knowledge_growth)
            
            fig = px.area(
                df_knowledge, x='date', y='items',
                title="Knowledge Base Growth",
                labels={'items': 'New Knowledge Items', 'date': 'Date'}
            )
            fig.update_layout(template="plotly_dark")
            st.plotly_chart(fig, use_container_width=True)
            
    except Exception as e:
        st.error(f"Error loading analytics: {e}")

def show_activity_feed():
    """Display recent activity feed"""
    st.title("📋 Activity Feed")
    
    try:
        # Get recent queries with details
        recent_activity = db.execute_query("""
            SELECT 
                q.tool,
                q.model,
                q.user_prompt,
                q.created_at,
                k.title as knowledge_title,
                k.category as knowledge_category
            FROM queries q
            LEFT JOIN knowledge_units k ON k.query_id = q.id
            ORDER BY q.created_at DESC
            LIMIT 50
        """)
        
        if recent_activity:
            # Group by date
            activity_by_date = {}
            for item in recent_activity:
                date = item['created_at'].date()
                if date not in activity_by_date:
                    activity_by_date[date] = []
                activity_by_date[date].append(item)
            
            # Display by date
            for date, activities in activity_by_date.items():
                st.subheader(f"📅 {date.strftime('%B %d, %Y')}")
                
                for activity in activities:
                    tool_name = activity['tool'].replace('_', ' ').title()
                    time_str = activity['created_at'].strftime('%H:%M')
                    
                    col1, col2 = st.columns([1, 4])
                    with col1:
                        st.caption(f"**{time_str}**")
                    with col2:
                        st.write(f"**{tool_name}** - {activity['model']}")
                        
                        # Show prompt preview
                        prompt_preview = activity['user_prompt'][:100] + "..." if len(activity['user_prompt']) > 100 else activity['user_prompt']
                        st.caption(f"Query: {prompt_preview}")
                        
                        # Show if knowledge was saved
                        if activity['knowledge_title']:
                            st.success(f"💾 Saved: {activity['knowledge_title']} ({activity['knowledge_category']})")
                    
                    st.divider()
        else:
            st.info("No recent activity")
            
    except Exception as e:
        st.error(f"Error loading activity: {e}")

def show_settings():
    """Display settings page"""
    st.title("⚙️ Settings")
    
    # Model configuration
    st.subheader("🤖 Model Configuration")
    
    models = get_available_models()
    if models:
        default_model = st.selectbox(
            "Default Model",
            models,
            index=models.index(UNIFIED_CONFIG["default_model"]) if UNIFIED_CONFIG["default_model"] in models else 0
        )
        
        if st.button("Save Model Settings"):
            UNIFIED_CONFIG["default_model"] = default_model
            st.success("Model settings saved!")
    
    # Feature toggles
    st.subheader("🎛️ Feature Toggles")
    
    col1, col2 = st.columns(2)
    with col1:
        enable_analytics = st.checkbox(
            "Enable Analytics",
            value=UNIFIED_CONFIG["enable_analytics"],
            help="Track usage statistics"
        )
    
    with col2:
        enable_experimental = st.checkbox(
            "Enable Experimental Features",
            value=UNIFIED_CONFIG["enable_experimental"],
            help="Show experimental tools"
        )
    
    if st.button("Save Feature Settings"):
        UNIFIED_CONFIG["enable_analytics"] = enable_analytics
        UNIFIED_CONFIG["enable_experimental"] = enable_experimental
        st.success("Feature settings saved!")
    
    # Database info
    st.subheader("🗄️ Database Information")
    
    try:
        # Get database stats
        db_stats = db.execute_query("""
            SELECT 
                (SELECT COUNT(*) FROM queries) as total_queries,
                (SELECT COUNT(*) FROM knowledge_units) as total_knowledge,
                (SELECT pg_size_pretty(pg_database_size(current_database()))) as db_size
        """)
        
        if db_stats:
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Queries", f"{db_stats[0]['total_queries']:,}")
            with col2:
                st.metric("Knowledge Items", f"{db_stats[0]['total_knowledge']:,}")
            with col3:
                st.metric("Database Size", db_stats[0]['db_size'])
    except:
        st.info("Database statistics unavailable")
    
    # Export/Import
    st.subheader("📦 Data Management")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Export Knowledge Base", use_container_width=True):
            st.info("Export functionality coming soon")
    
    with col2:
        if st.button("Backup Database", use_container_width=True):
            st.info("Backup functionality coming soon")
    
    # About
    st.subheader("ℹ️ About TuoKit")
    st.info(f"""
    **TuoKit Unified** v{UNIFIED_CONFIG['version']}
    
    A comprehensive AI-powered toolkit for developers, combining:
    - Code analysis and generation
    - SQL and database tools
    - Error analysis and debugging
    - Learning and documentation
    - SmallTalk and Ruby development
    - Agent systems and automation
    
    Built with Streamlit, Ollama, and PostgreSQL.
    """)

def load_tool(tool_info: Dict[str, Any]):
    """Load and display the selected tool"""
    tool_type = tool_info.get('type')
    
    if tool_type == 'internal':
        # Internal function
        func_name = tool_info.get('function')
        if func_name in globals():
            globals()[func_name]()
        else:
            st.error(f"Function {func_name} not found")
    
    elif tool_type == 'page':
        # External page file
        page_path = tool_info.get('page')
        if page_path and Path(page_path).exists():
            # Import and run the page
            try:
                import importlib.util
                spec = importlib.util.spec_from_file_location("tool_page", page_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Call main() if it exists
                if hasattr(module, 'main'):
                    module.main()
                else:
                    st.error(f"No main() function in {page_path}")
            except Exception as e:
                st.error(f"Error loading page: {e}")
        else:
            st.error(f"Page not found: {page_path}")
    
    elif tool_type == 'toolkit':
        # Consolidated toolkit
        func_name = tool_info.get('function')
        if func_name in globals() and globals()[func_name] is not None:
            # Call toolkit with standalone=False to avoid page config conflicts
            toolkit_func = globals()[func_name]
            try:
                # Try calling with standalone parameter
                toolkit_func(standalone=False)
            except TypeError:
                # If toolkit doesn't accept standalone parameter, call without it
                toolkit_func()
        else:
            st.error(f"Toolkit function {func_name} not found or failed to import. Please check the installation.")
    
    else:
        st.error(f"Unknown tool type: {tool_type}")

# ============== MAIN APPLICATION ==============

def main():
    # Display any import errors at the top
    if toolkit_import_errors:
        with st.expander("⚠️ Import Warnings", expanded=False):
            for error in toolkit_import_errors:
                st.warning(error)
    
    # Custom CSS for modern look
    st.markdown("""
    <style>
        /* Modern dark theme */
        .stApp {
            background-color: #0e1117;
        }
        
        /* Sidebar styling */
        .css-1d391kg {
            background-color: #1a1d24;
        }
        
        /* Metrics styling */
        [data-testid="metric-container"] {
            background-color: #1a1d24;
            border: 1px solid #30363d;
            padding: 1rem;
            border-radius: 0.5rem;
        }
        
        /* Expander styling */
        .streamlit-expanderHeader {
            background-color: #1a1d24;
            border-radius: 0.5rem;
        }
        
        /* Button styling */
        .stButton > button {
            background-color: #238636;
            color: white;
            border: none;
            transition: all 0.3s;
        }
        
        .stButton > button:hover {
            background-color: #2ea043;
            transform: translateY(-2px);
        }
        
        /* Tab styling */
        .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
            background-color: #238636;
        }
        
        /* Category cards */
        .category-card {
            background-color: #1a1d24;
            padding: 1.5rem;
            border-radius: 0.5rem;
            border: 1px solid #30363d;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .category-card:hover {
            border-color: #238636;
            transform: translateY(-2px);
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Initialize session state
    if 'selected_category' not in st.session_state:
        st.session_state.selected_category = 'dashboards'
    if 'selected_tool' not in st.session_state:
        st.session_state.selected_tool = 'home'
    
    # Sidebar navigation
    with st.sidebar:
        st.title("🚀 TuoKit Unified")
        st.caption(f"v{UNIFIED_CONFIG['version']} - All-in-One Toolkit")
        
        st.divider()
        
        # Category navigation
        for category_id, category in TOOL_REGISTRY.items():
            if st.button(
                category['name'],
                key=f"cat_{category_id}",
                use_container_width=True,
                type="primary" if st.session_state.selected_category == category_id else "secondary"
            ):
                st.session_state.selected_category = category_id
                # Select first tool in category
                if category['tools']:
                    st.session_state.selected_tool = list(category['tools'].keys())[0]
                st.rerun()
        
        st.divider()
        
        # Tool selection within category
        if st.session_state.selected_category in TOOL_REGISTRY:
            category = TOOL_REGISTRY[st.session_state.selected_category]
            st.subheader(category['name'])
            
            for tool_id, tool in category['tools'].items():
                if st.button(
                    f"{tool['icon']} {tool['name']}",
                    key=f"tool_{tool_id}",
                    use_container_width=True,
                    help=tool['description'],
                    type="primary" if st.session_state.selected_tool == tool_id else "secondary"
                ):
                    st.session_state.selected_tool = tool_id
                    st.rerun()
        
        # Model selection
        st.divider()
        st.subheader("🤖 Model")
        
        models = get_available_models()
        if models:
            selected_model = st.selectbox(
                "Select Model",
                models,
                index=models.index(UNIFIED_CONFIG["default_model"]) if UNIFIED_CONFIG["default_model"] in models else 0,
                label_visibility="collapsed"
            )
            st.session_state.selected_model = selected_model
        
        # Quick stats
        st.divider()
        st.subheader("📊 Quick Stats")
        
        try:
            # Today's usage
            today_stats = db.execute_query("""
                SELECT COUNT(*) as queries_today
                FROM queries
                WHERE DATE(created_at) = CURRENT_DATE
            """)
            
            if today_stats:
                st.metric("Today's Queries", today_stats[0]['queries_today'])
        except:
            pass
    
    # Main content area
    if st.session_state.selected_tool and st.session_state.selected_category in TOOL_REGISTRY:
        category = TOOL_REGISTRY[st.session_state.selected_category]
        if st.session_state.selected_tool in category['tools']:
            tool_info = category['tools'][st.session_state.selected_tool]
            
            # Load the selected tool
            load_tool(tool_info)
        else:
            st.error(f"Tool {st.session_state.selected_tool} not found")
    else:
        # Show home dashboard by default
        show_home_dashboard()

if __name__ == "__main__":
    main()
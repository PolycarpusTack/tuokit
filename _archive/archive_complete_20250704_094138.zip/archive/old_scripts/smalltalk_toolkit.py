"""
TuoKit - Smalltalk Development Toolkit (Consolidated Edition)
Combines all Smalltalk development tools into a comprehensive suite
"""

import streamlit as st
import json
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any
from pathlib import Path
from utils import (
    DatabaseManager,
    safe_ollama_generate,
    capture_knowledge,
    get_recent_items
)

# Initialize database
db = DatabaseManager()

# ============== CONFIGURATION ==============
SMALLTALK_CONFIG = {
    "default_model": "deepseek-r1:latest",
    "temperature": 0.3,
    "max_tokens": 4000,
    "supported_dialects": ["VisualWorks", "Pharo", "Squeak", "GemStone"],
    "enable_caching": True
}

# ============== PATTERN DATABASES ==============

# Class generation patterns
CLASS_PATTERNS = {
    "Singleton": {
        "description": "Ensures only one instance exists",
        "template": """
Object subclass: #Singleton
    instanceVariableNames: ''
    classVariableNames: 'UniqueInstance'
    poolDictionaries: ''
    category: 'Patterns-Creational'

Singleton class >> default
    UniqueInstance ifNil: [UniqueInstance := super new].
    ^UniqueInstance

Singleton class >> new
    self error: 'Use #default to get the unique instance'
        """
    },
    "Factory": {
        "description": "Creates objects without specifying exact classes",
        "template": """
Object subclass: #AbstractFactory
    instanceVariableNames: ''
    classVariableNames: ''
    poolDictionaries: ''
    category: 'Patterns-Creational'

AbstractFactory >> createProduct
    self subclassResponsibility
        """
    },
    "Observer": {
        "description": "Notifies dependents of state changes",
        "template": """
Object subclass: #Subject
    instanceVariableNames: 'observers'
    classVariableNames: ''
    poolDictionaries: ''
    category: 'Patterns-Behavioral'

Subject >> initialize
    super initialize.
    observers := OrderedCollection new.

Subject >> attach: anObserver
    observers add: anObserver

Subject >> notifyObservers
    observers do: [:each | each update: self]
        """
    }
}

# Refactoring techniques
REFACTORING_TECHNIQUES = {
    "Extract Method": {
        "description": "Extract code into a new method",
        "example": """
"Before:"
processOrder
    | total |
    total := 0.
    items do: [:item | 
        total := total + (item price * item quantity).
        total > 1000 ifTrue: [total := total * 0.9]].
    ^total

"After:"
processOrder
    ^self calculateTotal

calculateTotal
    | total |
    total := 0.
    items do: [:item | 
        total := total + (item price * item quantity).
        total := self applyDiscount: total].
    ^total

applyDiscount: amount
    ^amount > 1000 ifTrue: [amount * 0.9] ifFalse: [amount]
        """
    },
    "Rename Method": {
        "description": "Change method name to better express intent",
        "example": """
"Before:"
calc: x

"After:"
calculateTotalPrice: anOrder
        """
    },
    "Move Method": {
        "description": "Move method to more appropriate class",
        "example": """
"Before (in Order):"
calculateTax
    ^self total * TaxCalculator taxRate

"After (in TaxCalculator):"
calculateTaxFor: anOrder
    ^anOrder total * self taxRate
        """
    },
    "Extract Class": {
        "description": "Create new class from subset of features",
        "example": """
"Before:"
Person with instance variables: name address city zipCode phone email

"After:"
Person with instance variables: name phone email contactInfo
ContactInfo with instance variables: address city zipCode
        """
    },
    "Inline Method": {
        "description": "Replace method call with method body",
        "example": """
"Before:"
moreThanFiveItems
    ^items size > 5

isSpecialOrder
    ^self moreThanFiveItems

"After:"
isSpecialOrder
    ^items size > 5
        """
    }
}

# Snippet categories
SNIPPET_CATEGORIES = {
    "Collections": {
        "icon": "📚",
        "description": "Collection manipulation and iteration",
        "subcategories": ["Creating", "Iterating", "Filtering", "Transforming"],
        "examples": {
            "Basic Collection": """
"Creating collections"
array := #(1 2 3 4 5).
orderedCollection := OrderedCollection new.
set := Set new.
dictionary := Dictionary new.

"Adding elements"
orderedCollection add: 'first'.
orderedCollection addAll: #('second' 'third').
set add: 42.
dictionary at: 'key' put: 'value'.

"Iterating"
array do: [:each | Transcript show: each; cr].
dictionary keysAndValuesDo: [:key :value | 
    Transcript show: key, ' -> ', value; cr].
            """,
            "Collection Operations": """
"Filtering"
evens := #(1 2 3 4 5 6) select: [:n | n even].
odds := #(1 2 3 4 5 6) reject: [:n | n even].

"Transforming"
squared := #(1 2 3 4 5) collect: [:n | n squared].
sum := #(1 2 3 4 5) inject: 0 into: [:total :n | total + n].

"Searching"
firstEven := #(1 3 5 6 7 8) detect: [:n | n even].
hasNegative := #(1 2 3) anySatisfy: [:n | n negative].
allPositive := #(1 2 3) allSatisfy: [:n | n positive].
            """
        }
    },
    "Control Flow": {
        "icon": "🔀",
        "description": "Conditionals, loops, and blocks",
        "subcategories": ["Conditionals", "Loops", "Blocks", "Exceptions"],
        "examples": {
            "Conditionals": """
"Basic if/then/else"
x > 0 
    ifTrue: [Transcript show: 'Positive']
    ifFalse: [Transcript show: 'Non-positive'].

"Nested conditionals"
age < 18
    ifTrue: [category := 'Minor']
    ifFalse: [
        age < 65
            ifTrue: [category := 'Adult']
            ifFalse: [category := 'Senior']].

"Case-like structure"
dayNumber caseOf: {
    [1] -> ['Monday'].
    [2] -> ['Tuesday'].
    [3] -> ['Wednesday']
} otherwise: ['Other day'].
            """,
            "Loops": """
"Times repeat"
5 timesRepeat: [Transcript show: 'Hello'; cr].

"While loops"
[x < 100] whileTrue: [x := x * 2].
[self hasMore] whileFalse: [self waitForMore].

"To:do: loops"
1 to: 10 do: [:i | Transcript show: i squared; cr].
10 to: 1 by: -1 do: [:i | Transcript show: i; cr].
            """
        }
    },
    "Classes": {
        "icon": "🏗️",
        "description": "Class definition and object creation",
        "subcategories": ["Definition", "Instantiation", "Inheritance", "Traits"],
        "examples": {
            "Class Definition": """
"Basic class definition"
Object subclass: #Person
    instanceVariableNames: 'name age'
    classVariableNames: ''
    poolDictionaries: ''
    category: 'MyApp-Model'

"Methods"
Person >> name
    ^name

Person >> name: aString
    name := aString

Person >> age
    ^age

Person >> age: aNumber
    age := aNumber

"Initialization"
Person >> initialize
    super initialize.
    age := 0
            """,
            "Class Methods": """
"Class-side methods"
Person class >> example
    ^self new
        name: 'John Doe';
        age: 30;
        yourself

Person class >> fromDictionary: aDictionary
    ^self new
        name: (aDictionary at: 'name');
        age: (aDictionary at: 'age');
        yourself
            """
        }
    }
}

# Metaprogramming tasks
METAPROGRAMMING_TASKS = {
    "Add logging to all methods": {
        "description": "Wrap methods with logging",
        "template": """
"Add logging to all methods in a class"
MyClass methodsDo: [:method |
    | originalMethod wrapper |
    originalMethod := method.
    wrapper := [:args |
        Transcript show: 'Calling ', method selector; cr.
        result := originalMethod valueWithReceiver: self arguments: args.
        Transcript show: 'Result: ', result printString; cr.
        result].
    MyClass compile: method selector, ' ', wrapper sourceCode]
        """
    },
    "Create getter/setter methods": {
        "description": "Generate accessors for instance variables",
        "template": """
"Generate getters and setters"
MyClass instVarNames do: [:varName |
    "Getter"
    MyClass compile: varName, '
        ^', varName.
    
    "Setter"
    MyClass compile: varName, ': anObject
        ', varName, ' := anObject']
        """
    },
    "Method aliasing": {
        "description": "Create method aliases",
        "template": """
"Create alias for existing method"
MyClass compile: 'newMethodName
    ^self originalMethodName'
        """
    }
}

# Seaside component templates
SEASIDE_TEMPLATES = {
    "User Registration Form": {
        "description": "Complete registration component",
        "code": """
WAComponent subclass: #UserRegistrationForm
    instanceVariableNames: 'username email password confirmPassword'
    classVariableNames: ''
    poolDictionaries: ''
    category: 'MyApp-Components'

UserRegistrationForm >> renderContentOn: html
    html heading: 'User Registration'.
    html form: [
        html div class: 'form-group'; with: [
            html label: 'Username:'.
            html textInput
                class: 'form-control';
                on: #username of: self].
        
        html div class: 'form-group'; with: [
            html label: 'Email:'.
            html emailInput
                class: 'form-control';
                on: #email of: self].
        
        html div class: 'form-group'; with: [
            html label: 'Password:'.
            html passwordInput
                class: 'form-control';
                on: #password of: self].
        
        html div class: 'form-group'; with: [
            html label: 'Confirm Password:'.
            html passwordInput
                class: 'form-control';
                on: #confirmPassword of: self].
        
        html submitButton
            class: 'btn btn-primary';
            callback: [self register];
            text: 'Register']

UserRegistrationForm >> register
    self validateForm.
    User new
        username: username;
        email: email;
        password: (self hashPassword: password);
        save.
    self inform: 'Registration successful!'

UserRegistrationForm >> validateForm
    username isEmpty ifTrue: [
        self error: 'Username is required'].
    password ~= confirmPassword ifTrue: [
        self error: 'Passwords do not match'].
    password size < 8 ifTrue: [
        self error: 'Password must be at least 8 characters']
        """
    },
    "Data Table Component": {
        "description": "Paginated table with sorting",
        "code": """
WAComponent subclass: #DataTableComponent
    instanceVariableNames: 'items currentPage pageSize sortColumn sortAscending'
    classVariableNames: ''
    poolDictionaries: ''
    category: 'MyApp-Components'

DataTableComponent >> initialize
    super initialize.
    currentPage := 1.
    pageSize := 10.
    sortColumn := #name.
    sortAscending := true

DataTableComponent >> renderContentOn: html
    | sortedItems pagedItems |
    sortedItems := self sortItems: items.
    pagedItems := self pageItems: sortedItems.
    
    html table class: 'table table-striped'; with: [
        html tableHead: [
            html tableRow: [
                self renderHeadersOn: html]].
        html tableBody: [
            pagedItems do: [:item |
                html tableRow: [
                    self renderItem: item on: html]]]].
    
    self renderPaginationOn: html

DataTableComponent >> renderHeadersOn: html
    #(('Name' name) ('Email' email) ('Created' createdAt)) do: [:spec |
        html tableHeading: [
            html anchor
                callback: [self sortBy: spec second];
                with: [
                    html text: spec first.
                    sortColumn = spec second ifTrue: [
                        html space.
                        html span class: (sortAscending 
                            ifTrue: ['arrow-up'] 
                            ifFalse: ['arrow-down'])]]]]
        """
    }
}

# Ruby-Smalltalk conversion patterns
CONVERSION_PATTERNS = {
    "smalltalk_to_ruby": {
        "Collections": {
            "original": "#(1 2 3) collect: [:n | n * 2]",
            "converted": "[1, 2, 3].map { |n| n * 2 }"
        },
        "Classes": {
            "original": """
Object subclass: #Person
    instanceVariableNames: 'name age'

Person >> name
    ^name
            """,
            "converted": """
class Person
  attr_reader :name, :age
  
  def initialize
    @name = nil
    @age = nil
  end
end
            """
        },
        "Blocks": {
            "original": "[:x :y | x + y] value: 3 value: 4",
            "converted": "lambda { |x, y| x + y }.call(3, 4)"
        }
    },
    "ruby_to_smalltalk": {
        "Collections": {
            "original": "[1, 2, 3].select { |n| n.even? }",
            "converted": "#(1 2 3) select: [:n | n even]"
        },
        "Classes": {
            "original": """
class Person
  def initialize(name)
    @name = name
  end
  
  def greet
    puts "Hello, I'm #{@name}"
  end
end
            """,
            "converted": """
Object subclass: #Person
    instanceVariableNames: 'name'

Person class >> newWithName: aString
    ^self new name: aString; yourself

Person >> greet
    Transcript show: 'Hello, I''m ', name; cr
            """
        }
    }
}

# ============== CORE FUNCTIONS ==============

def parse_class_structure(code: str) -> Dict[str, Any]:
    """Parse Smalltalk class definition structure"""
    structure = {
        "className": None,
        "superclass": None,
        "instanceVariables": [],
        "classVariables": [],
        "methods": []
    }
    
    # Parse class definition
    class_match = re.search(r'(\w+)\s+subclass:\s+#(\w+)', code)
    if class_match:
        structure["superclass"] = class_match.group(1)
        structure["className"] = class_match.group(2)
    
    # Parse instance variables
    inst_var_match = re.search(r"instanceVariableNames:\s+'([^']*)'", code)
    if inst_var_match:
        vars = inst_var_match.group(1).strip()
        if vars:
            structure["instanceVariables"] = vars.split()
    
    # Parse class variables
    class_var_match = re.search(r"classVariableNames:\s+'([^']*)'", code)
    if class_var_match:
        vars = class_var_match.group(1).strip()
        if vars:
            structure["classVariables"] = vars.split()
    
    # Parse methods
    method_pattern = r'(\w+)\s*>>\s*(\w+[:\w]*)'
    for match in re.finditer(method_pattern, code):
        structure["methods"].append({
            "class": match.group(1),
            "selector": match.group(2)
        })
    
    return structure

def generate_class(prompt: str, pattern: Optional[str] = None, include_tests: bool = False, 
                  include_examples: bool = False, model: str = SMALLTALK_CONFIG["default_model"]) -> str:
    """Generate Smalltalk class with AI"""
    
    full_prompt = f"""
Generate a VisualWorks Smalltalk class based on this description:
{prompt}

Requirements:
1. Use proper Smalltalk syntax
2. Include instance/class variables as needed
3. Add initialization methods
4. Follow Smalltalk naming conventions
5. Include method categories
    """
    
    if pattern:
        full_prompt += f"\nImplement using the {pattern} design pattern."
    
    if include_tests:
        full_prompt += "\nInclude SUnit test class with comprehensive tests."
    
    if include_examples:
        full_prompt += "\nInclude usage examples in class-side methods."
    
    response = safe_ollama_generate(model, full_prompt, temperature=SMALLTALK_CONFIG["temperature"])
    
    if isinstance(response, dict):
        return response.get('response', 'Generation failed')
    return str(response)

def explain_code(code: str, detail_level: str = "Detailed", include_optimization: bool = False,
                include_comparison: bool = False, model: str = SMALLTALK_CONFIG["default_model"]) -> str:
    """Explain Smalltalk code with AI"""
    
    prompt = f"""
Explain this Smalltalk code at a {detail_level} level:

{code}

Focus on:
1. What the code does
2. How it works
3. Smalltalk-specific concepts used
4. Message passing and object interactions
    """
    
    if include_optimization:
        prompt += "\n5. Optimization suggestions and performance considerations"
    
    if include_comparison:
        prompt += "\n6. Comparison with how this would be done in other OOP languages"
    
    response = safe_ollama_generate(model, prompt, temperature=0.3)
    
    if isinstance(response, dict):
        return response.get('response', 'Explanation failed')
    return str(response)

def generate_metaprogramming(task: str, custom_input: str = "", model: str = SMALLTALK_CONFIG["default_model"]) -> str:
    """Generate metaprogramming code"""
    
    if task in METAPROGRAMMING_TASKS:
        base_template = METAPROGRAMMING_TASKS[task]["template"]
        prompt = f"""
Based on this metaprogramming pattern:
{base_template}

Generate a complete, working implementation for:
{custom_input if custom_input else task}

Include:
1. Complete code with error handling
2. Usage examples
3. Explanation of how it works
4. Safety considerations
        """
    else:
        prompt = f"""
Generate Smalltalk metaprogramming code for:
{custom_input}

Include reflection, runtime code generation, or dynamic behavior modification as appropriate.
        """
    
    response = safe_ollama_generate(model, prompt)
    
    if isinstance(response, dict):
        return response.get('response', 'Generation failed')
    return str(response)

def refactor_code(code: str, technique: str, preserve_behavior: bool = True, 
                 show_diff: bool = True, model: str = SMALLTALK_CONFIG["default_model"]) -> Dict[str, Any]:
    """Refactor Smalltalk code"""
    
    prompt = f"""
Refactor this Smalltalk code using the {technique} technique:

{code}

Requirements:
1. Apply {technique} refactoring
2. {"Preserve exact behavior" if preserve_behavior else "Improve behavior if possible"}
3. Follow Smalltalk best practices
4. Add comments explaining changes
    """
    
    if show_diff:
        prompt += "\n5. Clearly mark what changed"
    
    response = safe_ollama_generate(model, prompt)
    
    if isinstance(response, dict):
        result_text = response.get('response', 'Refactoring failed')
    else:
        result_text = str(response)
    
    # Extract metrics
    original_lines = len(code.strip().split('\n'))
    
    return {
        "refactored_code": result_text,
        "technique": technique,
        "original_lines": original_lines,
        "analysis": f"Applied {technique} refactoring"
    }

def convert_code(code: str, direction: str, preserve_style: bool = True,
                include_explanation: bool = True, model: str = SMALLTALK_CONFIG["default_model"]) -> Dict[str, Any]:
    """Convert between Smalltalk and Ruby"""
    
    if direction == "smalltalk_to_ruby":
        prompt = f"""
Convert this Smalltalk code to Ruby:

{code}

Requirements:
1. Preserve semantics exactly
2. Use idiomatic Ruby style
3. Handle blocks and closures properly
4. Convert message passing to method calls
        """
    else:  # ruby_to_smalltalk
        prompt = f"""
Convert this Ruby code to Smalltalk:

{code}

Requirements:
1. Preserve semantics exactly
2. Use idiomatic Smalltalk style
3. Convert Ruby blocks to Smalltalk blocks
4. Handle instance variables properly
        """
    
    if preserve_style:
        prompt += "\n5. Preserve original formatting style where possible"
    
    if include_explanation:
        prompt += "\n6. Explain key differences and conversion decisions"
    
    response = safe_ollama_generate(model, prompt)
    
    if isinstance(response, dict):
        result_text = response.get('response', 'Conversion failed')
    else:
        result_text = str(response)
    
    return {
        "converted_code": result_text,
        "direction": direction,
        "preserved_style": preserve_style
    }

def generate_snippet(category: str, task: str, complexity: str = "Intermediate",
                   model: str = SMALLTALK_CONFIG["default_model"]) -> str:
    """Generate code snippet"""
    
    prompt = f"""
Generate a Smalltalk code snippet for:
Category: {category}
Task: {task}
Complexity: {complexity}

Requirements:
1. Complete, runnable code
2. Include comments explaining each part
3. Follow Smalltalk best practices
4. Show proper error handling where appropriate
    """
    
    if category in SNIPPET_CATEGORIES:
        prompt += f"\n5. Focus on {SNIPPET_CATEGORIES[category]['description']}"
    
    response = safe_ollama_generate(model, prompt)
    
    if isinstance(response, dict):
        return response.get('response', 'Generation failed')
    return str(response)

def generate_seaside_component(component_type: str, features: List[str], ajax_enabled: bool = False,
                             use_magritte: bool = False, model: str = SMALLTALK_CONFIG["default_model"]) -> Dict[str, Any]:
    """Generate Seaside web component"""
    
    prompt = f"""
Generate a Seaside {component_type} component with these features:
{', '.join(features)}

Requirements:
1. Complete component class definition
2. Proper rendering methods
3. Callback handling
4. CSS styling hooks
    """
    
    if ajax_enabled:
        prompt += "\n5. Include AJAX/jQuery functionality"
    
    if use_magritte:
        prompt += "\n6. Include Magritte descriptions for automatic form generation"
    
    response = safe_ollama_generate(model, prompt)
    
    if isinstance(response, dict):
        result_text = response.get('response', 'Generation failed')
    else:
        result_text = str(response)
    
    # Generate registration code
    registration = f"""
"Register the component"
WAAdmin register: {component_type}Component asApplicationAt: '{component_type.lower()}'.
    """
    
    return {
        "component_code": result_text,
        "registration": registration,
        "component_type": component_type,
        "features": features
    }

# ============== UI COMPONENTS ==============

def show_class_generator():
    """Class Generator UI"""
    st.header("🏗️ Class Generator")
    
    # Configuration
    col1, col2 = st.columns(2)
    with col1:
        include_tests = st.checkbox("Include SUnit tests", value=True)
    with col2:
        include_examples = st.checkbox("Include usage examples", value=True)
    
    # Design pattern selection
    patterns = ["None"] + list(CLASS_PATTERNS.keys())
    selected_pattern = st.selectbox("Design Pattern", patterns)
    
    if selected_pattern != "None":
        st.info(CLASS_PATTERNS[selected_pattern]["description"])
    
    # Class description
    class_description = st.text_area(
        "Class Description",
        placeholder="Describe the class you want to generate...",
        height=150
    )
    
    # Quick templates
    st.subheader("Quick Templates")
    template_cols = st.columns(4)
    templates = [
        ("Domain Model", "Create a Person class with name, age, address"),
        ("Collection", "Create a specialized OrderedSet that maintains insertion order without duplicates"),
        ("Service", "Create a DatabaseConnection class with connection pooling"),
        ("UI Component", "Create a custom Button class with icon support")
    ]
    
    for i, (name, description) in enumerate(templates):
        with template_cols[i % 4]:
            if st.button(name, key=f"template_{name}"):
                st.session_state.class_description = description
                st.rerun()
    
    # Load from session state
    if 'class_description' in st.session_state:
        class_description = st.session_state.class_description
        del st.session_state.class_description
    
    # Generate button
    if st.button("🚀 Generate Class", type="primary", disabled=not class_description):
        with st.spinner("Generating class..."):
            result = generate_class(
                class_description,
                selected_pattern if selected_pattern != "None" else None,
                include_tests,
                include_examples
            )
            
            st.session_state.generated_class = result
            
            # Parse structure
            structure = parse_class_structure(result)
            st.session_state.class_structure = structure
    
    # Display results
    if 'generated_class' in st.session_state:
        tabs = st.tabs(["Class Code", "Structure", "Save"])
        
        with tabs[0]:
            st.code(st.session_state.generated_class, language="smalltalk")
            
            # Download button
            st.download_button(
                "📥 Download as .st file",
                st.session_state.generated_class,
                file_name=f"{st.session_state.class_structure.get('className', 'Generated')}.st",
                mime="text/plain"
            )
        
        with tabs[1]:
            if st.session_state.class_structure:
                structure = st.session_state.class_structure
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Class Name", structure.get("className", "Unknown"))
                    st.metric("Superclass", structure.get("superclass", "Object"))
                with col2:
                    st.metric("Instance Variables", len(structure.get("instanceVariables", [])))
                    st.metric("Methods", len(structure.get("methods", [])))
                
                # Variable lists
                if structure.get("instanceVariables"):
                    st.subheader("Instance Variables")
                    for var in structure["instanceVariables"]:
                        st.write(f"- {var}")
                
                if structure.get("methods"):
                    st.subheader("Methods")
                    for method in structure["methods"][:10]:  # Show first 10
                        st.write(f"- {method['class']} >> {method['selector']}")
        
        with tabs[2]:
            if st.button("💾 Save to Knowledge Library"):
                capture_knowledge(
                    tool_name="smalltalk_class_generator",
                    query=class_description,
                    response=st.session_state.generated_class,
                    metadata={
                        "pattern": selected_pattern,
                        "include_tests": include_tests,
                        "class_name": st.session_state.class_structure.get("className")
                    }
                )
                st.success("Class saved to knowledge library!")

def show_code_explainer():
    """Code Explainer UI"""
    st.header("🔍 Code Explainer")
    
    # Configuration
    col1, col2 = st.columns(2)
    with col1:
        detail_level = st.select_slider(
            "Detail Level",
            options=["Basic", "Detailed", "Advanced"],
            value="Detailed"
        )
    with col2:
        include_optimization = st.checkbox("Include optimization tips")
        include_comparison = st.checkbox("Compare with other languages")
    
    # Code input
    code_to_explain = st.text_area(
        "Smalltalk Code to Explain",
        height=200,
        placeholder="Paste your Smalltalk code here..."
    )
    
    # Example buttons
    st.subheader("Example Code")
    example_cols = st.columns(3)
    examples = [
        ("Collection", "#(1 2 3 4 5) select: [:n | n odd] thenCollect: [:n | n * n]"),
        ("Class", """
Object subclass: #Counter
    instanceVariableNames: 'count'
    
Counter >> increment
    count := count + 1.
    ^count
        """),
        ("Block", "[:x :y | (x squared + y squared) sqrt] value: 3 value: 4")
    ]
    
    for i, (name, code) in enumerate(examples):
        with example_cols[i]:
            if st.button(name, key=f"example_{name}"):
                st.session_state.code_to_explain = code
                st.rerun()
    
    # Load from session state
    if 'code_to_explain' in st.session_state:
        code_to_explain = st.session_state.code_to_explain
        del st.session_state.code_to_explain
    
    # Explain button
    if st.button("🔍 Explain Code", type="primary", disabled=not code_to_explain):
        with st.spinner("Analyzing code..."):
            explanation = explain_code(
                code_to_explain,
                detail_level,
                include_optimization,
                include_comparison
            )
            
            st.session_state.explanation = explanation
    
    # Display explanation
    if 'explanation' in st.session_state:
        st.subheader("📖 Explanation")
        st.markdown(st.session_state.explanation)
        
        # Save button
        if st.button("💾 Save Explanation"):
            capture_knowledge(
                tool_name="smalltalk_explainer",
                query=code_to_explain,
                response=st.session_state.explanation,
                metadata={
                    "detail_level": detail_level,
                    "include_optimization": include_optimization
                }
            )
            st.success("Explanation saved!")

def show_metaprogramming():
    """Metaprogramming Tools UI"""
    st.header("🔮 Metaprogramming Tools")
    
    # Task selection
    tasks = list(METAPROGRAMMING_TASKS.keys()) + ["Custom"]
    selected_task = st.selectbox("Select Task", tasks)
    
    if selected_task != "Custom" and selected_task in METAPROGRAMMING_TASKS:
        st.info(METAPROGRAMMING_TASKS[selected_task]["description"])
        
        # Show template
        with st.expander("View Template"):
            st.code(METAPROGRAMMING_TASKS[selected_task]["template"], language="smalltalk")
    
    # Custom input
    custom_input = st.text_area(
        "Custom Requirements" if selected_task != "Custom" else "Describe your metaprogramming task",
        placeholder="Add specific requirements or describe what you want to achieve...",
        height=100
    )
    
    # Options
    col1, col2 = st.columns(2)
    with col1:
        include_safety = st.checkbox("Include safety checks", value=True)
    with col2:
        include_tests = st.checkbox("Include test examples", value=True)
    
    # Generate button
    if st.button("🔮 Generate Metaprogramming Code", type="primary"):
        with st.spinner("Generating metaprogramming code..."):
            result = generate_metaprogramming(selected_task, custom_input)
            st.session_state.metaprogramming_result = result
    
    # Display result
    if 'metaprogramming_result' in st.session_state:
        st.subheader("Generated Code")
        st.code(st.session_state.metaprogramming_result, language="smalltalk")
        
        # Quick reference
        with st.expander("🔧 Metaprogramming Quick Reference"):
            st.markdown("""
            ### Core Metaprogramming APIs
            
            **Compilation:**
            - `Compiler evaluate: aString` - Evaluate code string
            - `MyClass compile: sourceString` - Add method to class
            - `MyClass removeSelector: #methodName` - Remove method
            
            **Reflection:**
            - `anObject class` - Get object's class
            - `MyClass instVarNames` - Instance variable names
            - `MyClass methodDict` - Dictionary of methods
            - `MyClass allInstances` - All instances of class
            
            **Method Manipulation:**
            - `MyClass >> #methodName` - Get compiled method
            - `method sourceCode` - Get method source
            - `thisContext` - Current execution context
            """)

def show_refactoring():
    """Refactoring Tools UI"""
    st.header("♻️ Refactoring Assistant")
    
    # Technique selection
    techniques = list(REFACTORING_TECHNIQUES.keys())
    selected_technique = st.selectbox("Refactoring Technique", techniques)
    
    if selected_technique in REFACTORING_TECHNIQUES:
        st.info(REFACTORING_TECHNIQUES[selected_technique]["description"])
        
        # Show example
        with st.expander("View Example"):
            st.code(REFACTORING_TECHNIQUES[selected_technique]["example"], language="smalltalk")
    
    # Code input
    code_to_refactor = st.text_area(
        "Code to Refactor",
        height=200,
        placeholder="Paste your Smalltalk code here..."
    )
    
    # Options
    col1, col2 = st.columns(2)
    with col1:
        preserve_behavior = st.checkbox("Preserve exact behavior", value=True)
        analyze_smells = st.checkbox("Analyze code smells", value=True)
    with col2:
        show_diff = st.checkbox("Show before/after diff", value=True)
        generate_plan = st.checkbox("Generate refactoring plan", value=True)
    
    # Refactor button
    if st.button("♻️ Refactor Code", type="primary", disabled=not code_to_refactor):
        with st.spinner("Refactoring code..."):
            result = refactor_code(
                code_to_refactor,
                selected_technique,
                preserve_behavior,
                show_diff
            )
            
            st.session_state.refactoring_result = result
    
    # Display results
    if 'refactoring_result' in st.session_state:
        result = st.session_state.refactoring_result
        
        tabs = st.tabs(["Refactored Code", "Analysis", "Save"])
        
        with tabs[0]:
            st.code(result["refactored_code"], language="smalltalk")
            
            # Metrics
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Original Lines", result["original_lines"])
            with col2:
                st.metric("Technique", result["technique"])
        
        with tabs[1]:
            st.markdown(result["analysis"])
            
            if analyze_smells:
                st.subheader("🔍 Code Smell Analysis")
                st.info("Analyzing code for common smells...")
        
        with tabs[2]:
            if st.button("💾 Save Refactoring"):
                capture_knowledge(
                    tool_name="smalltalk_refactorer",
                    query=f"{selected_technique}: {code_to_refactor[:100]}...",
                    response=result["refactored_code"],
                    metadata={
                        "technique": selected_technique,
                        "preserve_behavior": preserve_behavior
                    }
                )
                st.success("Refactoring saved!")

def show_ruby_converter():
    """Ruby Converter UI"""
    st.header("💎 Ruby ↔️ Smalltalk Converter")
    
    # Direction selection with visual indicator
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        direction = st.radio(
            "Conversion Direction",
            ["smalltalk_to_ruby", "ruby_to_smalltalk"],
            format_func=lambda x: "Smalltalk → Ruby" if x == "smalltalk_to_ruby" else "Ruby → Smalltalk",
            horizontal=True
        )
    
    # Options
    col1, col2 = st.columns(2)
    with col1:
        preserve_style = st.checkbox("Preserve code style", value=True)
    with col2:
        include_explanation = st.checkbox("Include conversion notes", value=True)
    
    # Code input
    source_language = "Smalltalk" if direction == "smalltalk_to_ruby" else "Ruby"
    code_to_convert = st.text_area(
        f"{source_language} Code",
        height=200,
        placeholder=f"Paste your {source_language} code here..."
    )
    
    # Pattern examples
    with st.expander("📚 Conversion Patterns"):
        patterns = CONVERSION_PATTERNS[direction]
        for category, pattern in patterns.items():
            st.subheader(category)
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("**Original:**")
                st.code(pattern["original"], language=source_language.lower())
            with col2:
                st.markdown("**Converted:**")
                target_lang = "ruby" if direction == "smalltalk_to_ruby" else "smalltalk"
                st.code(pattern["converted"], language=target_lang)
    
    # Convert button
    if st.button("🔄 Convert Code", type="primary", disabled=not code_to_convert):
        with st.spinner("Converting code..."):
            result = convert_code(
                code_to_convert,
                direction,
                preserve_style,
                include_explanation
            )
            
            st.session_state.conversion_result = result
    
    # Display results
    if 'conversion_result' in st.session_state:
        result = st.session_state.conversion_result
        
        st.subheader("📝 Converted Code")
        target_language = "ruby" if direction == "smalltalk_to_ruby" else "smalltalk"
        st.code(result["converted_code"], language=target_language)
        
        # Paradigm comparison
        with st.expander("🔍 Language Paradigm Comparison"):
            st.markdown("""
            ### Key Differences
            
            | Aspect | Smalltalk | Ruby |
            |--------|-----------|------|
            | Message Syntax | `object message: arg` | `object.message(arg)` |
            | Blocks | `[:x | x + 1]` | `{ |x| x + 1 }` |
            | Instance Vars | `instVar` | `@inst_var` |
            | Class Definition | `subclass:` | `class Name < Super` |
            | Return | `^value` | `return value` or implicit |
            | nil/null | `nil` | `nil` |
            | Boolean | `true/false` | `true/false` |
            | Arrays | `#(1 2 3)` | `[1, 2, 3]` |
            """)

def show_snippet_library():
    """Snippet Library UI"""
    st.header("📚 Code Snippet Library")
    
    # Category selection
    categories = list(SNIPPET_CATEGORIES.keys())
    selected_category = st.selectbox(
        "Category",
        categories,
        format_func=lambda x: f"{SNIPPET_CATEGORIES[x]['icon']} {x}"
    )
    
    if selected_category in SNIPPET_CATEGORIES:
        st.info(SNIPPET_CATEGORIES[selected_category]["description"])
    
    # Task input
    task_description = st.text_input(
        "What do you want to do?",
        placeholder="E.g., 'Sort a collection by multiple criteria'"
    )
    
    # Complexity
    complexity = st.select_slider(
        "Complexity Level",
        options=["Beginner", "Intermediate", "Advanced"],
        value="Intermediate"
    )
    
    # Generate snippet
    if st.button("🎯 Generate Snippet", type="primary", disabled=not task_description):
        with st.spinner("Generating snippet..."):
            snippet = generate_snippet(
                selected_category,
                task_description,
                complexity
            )
            
            st.session_state.generated_snippet = snippet
    
    # Display snippet
    if 'generated_snippet' in st.session_state:
        st.subheader("Generated Code")
        st.code(st.session_state.generated_snippet, language="smalltalk")
        
        # Copy button
        if st.button("📋 Copy to Clipboard"):
            st.toast("Code copied to clipboard!", icon="✅")
    
    # Show category examples
    if selected_category in SNIPPET_CATEGORIES and "examples" in SNIPPET_CATEGORIES[selected_category]:
        st.subheader("📖 Category Examples")
        examples = SNIPPET_CATEGORIES[selected_category]["examples"]
        
        tabs = st.tabs(list(examples.keys()))
        for i, (name, code) in enumerate(examples.items()):
            with tabs[i]:
                st.code(code, language="smalltalk")

def show_seaside_generator():
    """Seaside Generator UI"""
    st.header("🌊 Seaside Component Generator")
    
    # Component type
    component_types = ["Basic Component", "Form Component", "Report Component", 
                      "Navigation Component", "Dashboard Component"]
    component_type = st.selectbox("Component Type", component_types)
    
    # Component features
    st.subheader("Component Features")
    feature_cols = st.columns(3)
    features = []
    
    with feature_cols[0]:
        if st.checkbox("Authentication"):
            features.append("Authentication")
        if st.checkbox("Pagination"):
            features.append("Pagination")
    
    with feature_cols[1]:
        if st.checkbox("Sorting"):
            features.append("Sorting")
        if st.checkbox("Filtering"):
            features.append("Filtering")
    
    with feature_cols[2]:
        if st.checkbox("Export"):
            features.append("Export (CSV/Excel)")
        if st.checkbox("File Upload"):
            features.append("File Upload")
    
    # Advanced options
    with st.expander("Advanced Options"):
        ajax_enabled = st.checkbox("Enable AJAX/jQuery", value=True)
        use_magritte = st.checkbox("Use Magritte descriptions", value=False)
        include_css = st.checkbox("Include CSS framework", value=True)
    
    # Template selection
    st.subheader("Quick Templates")
    template_cols = st.columns(3)
    templates = list(SEASIDE_TEMPLATES.keys())
    
    for i, template in enumerate(templates):
        with template_cols[i % 3]:
            if st.button(template, key=f"template_{template}"):
                st.session_state.seaside_template = SEASIDE_TEMPLATES[template]["code"]
                st.rerun()
    
    # Generate button
    if st.button("🌊 Generate Component", type="primary"):
        with st.spinner("Generating Seaside component..."):
            result = generate_seaside_component(
                component_type,
                features,
                ajax_enabled,
                use_magritte
            )
            
            st.session_state.seaside_result = result
    
    # Display template if selected
    if 'seaside_template' in st.session_state:
        st.subheader("Template Code")
        st.code(st.session_state.seaside_template, language="smalltalk")
        del st.session_state.seaside_template
    
    # Display generated component
    if 'seaside_result' in st.session_state:
        result = st.session_state.seaside_result
        
        tabs = st.tabs(["Component Code", "Registration", "Deployment Guide"])
        
        with tabs[0]:
            st.code(result["component_code"], language="smalltalk")
        
        with tabs[1]:
            st.code(result["registration"], language="smalltalk")
            
            st.info("""
            ### Registration Steps:
            1. File in the component code
            2. Execute the registration code in a workspace
            3. Navigate to http://localhost:8080/{}
            """.format(result["component_type"].lower()))
        
        with tabs[2]:
            st.markdown("""
            ### Seaside Deployment Guide
            
            1. **Development Setup:**
               ```smalltalk
               "Start Seaside"
               ZnZincServerAdaptor startOn: 8080.
               
               "Configure development"
               WAAdmin applicationDefaults
                   removeParent: WADevelopmentConfiguration instance
               ```
            
            2. **Production Setup:**
               ```smalltalk
               "Configure for production"
               WAAdmin applicationDefaults
                   addParent: WAProductionConfiguration instance.
               
               "Set error handling"
               WAAdmin defaultErrorHandler: WAHtmlErrorHandler.
               ```
            
            3. **Nginx Configuration:**
               ```nginx
               location / {
                   proxy_pass http://localhost:8080;
                   proxy_set_header X-Real-IP $remote_addr;
               }
               ```
            """)

# ============== MAIN APPLICATION ==============

def main(standalone=True):
    # Only set page config if running standalone (not from unified app)
    if standalone:
        try:
            st.set_page_config(
                page_title="Smalltalk Development Toolkit",
                page_icon="🦆",
                layout="wide",
                initial_sidebar_state="expanded"
            )
        except:
            # Page config already set (running from unified app)
            pass
    
    # Custom CSS
    st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
            background-color: #FF6B6B;
        }
        .tool-card {
            background-color: #1e1e1e;
            padding: 1.5rem;
            border-radius: 0.5rem;
            border: 1px solid #333;
            margin-bottom: 1rem;
        }
        .code-block {
            background-color: #0d1117;
            border: 1px solid #30363d;
            border-radius: 6px;
            padding: 1rem;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.title("🦆 Smalltalk Toolkit")
        
        # Tool selection
        tools = {
            "Class Generator": "🏗️",
            "Code Explainer": "🔍",
            "Metaprogramming": "🔮",
            "Refactoring": "♻️",
            "Ruby Converter": "💎",
            "Snippet Library": "📚",
            "Seaside Generator": "🌊"
        }
        
        selected_tool = st.radio(
            "Select Tool",
            list(tools.keys()),
            format_func=lambda x: f"{tools[x]} {x}"
        )
        
        st.divider()
        
        # Settings
        st.subheader("⚙️ Settings")
        
        # Model selection
        models = ["deepseek-r1:latest", "qwen2.5-coder:latest", "llama3.2:latest"]
        selected_model = st.selectbox("AI Model", models)
        st.session_state.selected_model = selected_model
        
        # Temperature
        temperature = st.slider("Temperature", 0.0, 1.0, SMALLTALK_CONFIG["temperature"])
        
        # Dialect
        dialect = st.selectbox("Smalltalk Dialect", SMALLTALK_CONFIG["supported_dialects"])
        
        st.divider()
        
        # Resources
        st.subheader("📚 Resources")
        st.markdown("""
        - [Pharo](https://pharo.org)
        - [Squeak](https://squeak.org)
        - [GNU Smalltalk](http://smalltalk.gnu.org)
        - [Seaside](https://seaside.st)
        """)
        
        # Recent items
        st.divider()
        st.subheader("🕒 Recent")
        recent = get_recent_items("smalltalk%", limit=5)
        
        if recent:
            for item in recent:
                tool = item['tool'].replace('smalltalk_', '').replace('_', ' ').title()
                st.caption(f"{tool}: {item['created_at']}")
        else:
            st.info("No recent items")
    
    # Main content area
    if selected_tool == "Class Generator":
        show_class_generator()
    elif selected_tool == "Code Explainer":
        show_code_explainer()
    elif selected_tool == "Metaprogramming":
        show_metaprogramming()
    elif selected_tool == "Refactoring":
        show_refactoring()
    elif selected_tool == "Ruby Converter":
        show_ruby_converter()
    elif selected_tool == "Snippet Library":
        show_snippet_library()
    elif selected_tool == "Seaside Generator":
        show_seaside_generator()
    
    # Footer
    st.divider()
    col1, col2, col3 = st.columns(3)
    with col1:
        st.caption("Smalltalk Development Toolkit v2.0")
    with col2:
        st.caption(f"Dialect: {dialect}")
    with col3:
        st.caption(f"Model: {selected_model}")

if __name__ == "__main__":
    main()
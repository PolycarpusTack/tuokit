#!/usr/bin/env python3
"""
Complete the unified tools by porting implementations
Step 4 of the migration process
"""
import ast
import json
from pathlib import Path
from datetime import datetime

class UnifiedToolCompleter:
    def __init__(self):
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.completed_count = 0
        
    def run(self):
        """Complete unified tool implementations"""
        print("🔧 Completing Unified Tool Implementations")
        print("=" * 60)
        
        # Load latest feature analysis
        analysis = self.load_latest_analysis()
        
        # Complete SQL toolkit
        self.complete_sql_toolkit(analysis)
        
        # Add test file
        self.create_test_file()
        
        print(f"\n✅ Completed {self.completed_count} implementations!")
        print("\n🎯 Next steps:")
        print("  1. Run: python test_unified_tools.py")
        print("  2. Deploy with toggle OFF by default")
        print("  3. Monitor via migration dashboard")
    
    def load_latest_analysis(self):
        """Load feature analysis"""
        analysis_files = list(Path('.').glob('feature_analysis_*.json'))
        if not analysis_files:
            raise FileNotFoundError("No analysis found! Run extract_unique_features.py first")
        
        latest = max(analysis_files, key=lambda p: p.stat().st_mtime)
        with open(latest, 'r') as f:
            return json.load(f)
    
    def complete_sql_toolkit(self, analysis):
        """Add actual implementations to SQL toolkit"""
        print("\n📝 Completing SQL Toolkit implementations...")
        
        # Read current sql_toolkit_next.py
        toolkit_path = Path("pages/sql_toolkit_next.py")
        if not toolkit_path.exists():
            print("❌ sql_toolkit_next.py not found! Run smart_cleanup.py first")
            return
        
        with open(toolkit_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Port implementations from original files
        implementations = {
            'generate_sql': self.get_generate_sql_implementation(),
            'optimize_sql': self.get_optimize_sql_implementation(),
            'explain_sql': self.get_explain_sql_implementation(),
            'create_pipeline': self.get_pipeline_implementation()
        }
        
        # Replace NotImplementedError with actual implementations
        for func_name, impl in implementations.items():
            pattern = f'def {func_name}\\(self.*?\\):.*?raise NotImplementedError.*?\\n\\n'
            replacement = impl + '\n'
            
            import re
            if re.search(pattern, content, re.DOTALL):
                content = re.sub(pattern, replacement, content, flags=re.DOTALL)
                self.completed_count += 1
                print(f"  ✓ Implemented {func_name}")
        
        # Write updated content
        with open(toolkit_path, 'w', encoding='utf-8') as f:
            f.write(content)
    
    def get_generate_sql_implementation(self):
        """Get actual generate_sql implementation"""
        return '''def generate_sql(self, description: str, dialect: str = "postgresql", 
                     schema: dict = None, **kwargs):
        """Generate SQL from natural language description"""
        self._track_usage('generate_sql', 'sql_generator.py')
        
        # Use the unified generate method
        result = self.generate(description, dialect, schema, **kwargs)
        
        # Return in legacy format for compatibility
        if result['success']:
            return result['sql']
        else:
            return f"-- Error: {result.get('error', 'Unknown error')}"'''
    
    def get_optimize_sql_implementation(self):
        """Get actual optimize_sql implementation"""
        return '''def optimize_sql(self, sql: str, explain_plan: str = None, **kwargs):
        """Optimize existing SQL query"""
        self._track_usage('optimize_sql', 'sql_optimizer.py')
        
        # Use the unified optimize method
        result = self.optimize(sql, explain_plan, **kwargs)
        
        # Return in legacy format
        if result['success']:
            return {
                'optimized_sql': result['optimized_sql'],
                'recommendations': result.get('indexes', []),
                'explanation': result.get('explanation', '')
            }
        else:
            return {'error': result.get('error', 'Optimization failed')}'''
    
    def get_explain_sql_implementation(self):
        """Get actual explain_sql implementation"""
        return '''def explain_sql(self, sql: str, level: str = "beginner"):
        """Explain SQL query in plain English"""
        self._track_usage('explain_sql', 'sql_generator.py')
        
        explain_prompt = f"""
Explain this SQL query in simple terms for a {level} level audience:

```sql
{sql}
```

Include:
- What data is being retrieved
- Which tables are involved  
- How they're connected
- Any filters or conditions
- The expected output format
"""
        
        result = self.generate_with_logging(explain_prompt, temperature=0.7)
        
        if result['error']:
            return f"Error explaining SQL: {result['response']}"
        
        return result['response']'''
    
    def get_pipeline_implementation(self):
        """Get actual pipeline implementation"""
        return '''def create_pipeline(self, steps: list, name: str = "ETL Pipeline"):
        """Create multi-step SQL pipeline"""
        self._track_usage('create_pipeline', 'sql_pipeline.py')
        
        pipeline_prompt = f"""
Create a SQL pipeline named '{name}' with these steps:
{json.dumps(steps, indent=2)}

For each step provide:
1. SQL query
2. Dependencies on previous steps
3. Error handling approach

Format as executable SQL with comments.
"""
        
        result = self.generate_with_logging(pipeline_prompt, temperature=0.3)
        
        if result['error']:
            return {'success': False, 'error': result['response']}
        
        # Parse response into structured pipeline
        sql_blocks = self._extract_sql_blocks(result['response'])
        
        return {
            'success': True,
            'name': name,
            'steps': [
                {
                    'step': i+1,
                    'sql': block,
                    'description': f"Step {i+1} of {name}"
                }
                for i, block in enumerate(sql_blocks)
            ],
            'full_script': result['response']
        }
    
    def _extract_sql_blocks(self, text: str) -> list:
        """Extract multiple SQL blocks from text"""
        import re
        blocks = re.findall(r'```sql\n(.*?)\n```', text, re.DOTALL)
        if not blocks:
            # Try to extract by looking for SQL statements
            lines = text.split('\\n')
            current_block = []
            blocks = []
            
            for line in lines:
                if any(line.strip().upper().startswith(cmd) for cmd in 
                       ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'WITH', '--']):
                    current_block.append(line)
                elif current_block and line.strip() == '':
                    blocks.append('\\n'.join(current_block))
                    current_block = []
                elif current_block:
                    current_block.append(line)
            
            if current_block:
                blocks.append('\\n'.join(current_block))
        
        return blocks'''
    
    def create_test_file(self):
        """Create test file for unified tools"""
        print("\n🧪 Creating test file...")
        
        test_code = '''#!/usr/bin/env python3
"""
Test unified tools to ensure they work correctly
"""
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

def test_sql_toolkit():
    """Test SQL Toolkit Next"""
    print("\\n🧪 Testing SQL Toolkit Next...")
    
    try:
        from pages.sql_toolkit_next import SQLToolkitNext
        toolkit = SQLToolkitNext()
        
        # Test 1: Generate SQL
        print("  Testing SQL generation...")
        result = toolkit.generate("show all users created this month")
        assert result['success'], "SQL generation failed"
        assert 'sql' in result, "No SQL in result"
        print("  ✓ SQL generation works")
        
        # Test 2: Optimize SQL  
        print("  Testing SQL optimization...")
        test_sql = "SELECT * FROM users WHERE id IN (SELECT user_id FROM orders)"
        result = toolkit.optimize(test_sql)
        assert result['success'], "SQL optimization failed"
        print("  ✓ SQL optimization works")
        
        # Test 3: Legacy compatibility
        print("  Testing legacy method names...")
        sql = toolkit.generate_sql("test query")
        assert isinstance(sql, str), "Legacy generate_sql failed"
        print("  ✓ Legacy compatibility works")
        
        # Test 4: Feature tracking
        usage = toolkit.get_usage_report()
        assert len(usage) > 0, "Feature tracking not working"
        print(f"  ✓ Feature tracking works ({len(usage)} features used)")
        
        print("\\n✅ SQL Toolkit Next: All tests passed!")
        return True
        
    except Exception as e:
        print(f"\\n❌ SQL Toolkit test failed: {e}")
        return False

def test_agent_next():
    """Test Agent Next"""
    print("\\n🧪 Testing Agent Next...")
    
    try:
        from pages.agent_next import AgentNext
        agent = AgentNext()
        
        # Test 1: Basic processing
        print("  Testing basic processing...")
        result = agent.process("Hello, can you help me?")
        assert 'response' in result, "No response from agent"
        assert len(result['response']) > 0, "Empty response"
        print("  ✓ Basic processing works")
        
        # Test 2: Planning
        print("  Testing planning capability...")
        result = agent.process("Generate SQL for user analytics")
        assert 'plan' in result, "No plan created"
        assert 'steps' in result['plan'], "No steps in plan"
        print("  ✓ Planning works")
        
        print("\\n✅ Agent Next: All tests passed!")
        return True
        
    except Exception as e:
        print(f"\\n❌ Agent test failed: {e}")
        return False

def main():
    """Run all tests"""
    print("🧪 Testing Unified Tools")
    print("=" * 60)
    
    # Check if unified tools exist
    sql_toolkit_exists = Path("pages/sql_toolkit_next.py").exists()
    agent_exists = Path("pages/agent_next.py").exists()
    
    if not sql_toolkit_exists or not agent_exists:
        print("❌ Unified tools not found!")
        print("\\nRun these commands first:")
        print("  1. python extract_unique_features.py")
        print("  2. python smart_cleanup.py")
        print("  3. python add_feature_toggle.py")
        print("  4. python complete_unified_tools.py")
        return
    
    # Run tests
    sql_passed = test_sql_toolkit()
    agent_passed = test_agent_next()
    
    # Summary
    print("\\n" + "=" * 60)
    print("📊 Test Summary:")
    print(f"  SQL Toolkit: {'✅ PASSED' if sql_passed else '❌ FAILED'}")
    print(f"  Agent Next: {'✅ PASSED' if agent_passed else '❌ FAILED'}")
    
    if sql_passed and agent_passed:
        print("\\n🎉 All tests passed! Ready for deployment.")
        print("\\n🚀 Next steps:")
        print("  1. Deploy with feature toggle OFF")
        print("  2. Test in production with select users")
        print("  3. Monitor via migration dashboard")
    else:
        print("\\n⚠️  Some tests failed. Please fix before deploying.")

if __name__ == "__main__":
    main()
'''
        
        with open("test_unified_tools.py", 'w') as f:
            f.write(test_code)
        
        print("  ✓ Created test_unified_tools.py")


def main():
    """Complete unified tool implementations"""
    completer = UnifiedToolCompleter()
    completer.run()


if __name__ == "__main__":
    main()

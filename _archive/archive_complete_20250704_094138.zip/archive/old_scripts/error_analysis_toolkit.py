"""
TuoKit - Error Analysis Toolkit (Consolidated Edition)
Combines Error Decoder, Exception Advisor, and Crash Analyzer Pro
"""

import streamlit as st
import json
import hashlib
import re
import time
import textwrap
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path
from utils import (
    DatabaseManager, 
    safe_ollama_generate,
    capture_knowledge,
    validate_file_size
)

# Initialize database
db = DatabaseManager()

# ============== CONFIGURATION ==============
ERROR_DECODER_CONFIG = {
    "analysis_depths": ["Quick", "Standard", "Deep"],
    "supported_languages": ["Python", "JavaScript", "Java", "C++", "Ruby", "Rails", "SmallTalk"],
    "enable_code_fixes": True,
    "track_statistics": True
}

EXCEPTION_ADVISOR_CONFIG = {
    "system_types": ["Web Application", "Microservice", "Desktop Application", 
                     "Mobile App", "Data Pipeline", "IoT Device", "Game Engine"],
    "strategy_options": ["logging", "monitoring", "testing", "recovery"],
    "enable_anti_patterns": True
}

CRASH_ANALYZER_CONFIG = {
    "max_file_size_mb": 5,
    "chunk_size": 26000,  # Increased for 200 chunks on 5MB files
    "chunk_overlap": 1000,  # Increased overlap for larger chunks
    "max_chunks": 200,  # Limited to 200 chunks
    "smart_sampling_threshold_mb": 1,
    "performance_warning_threshold_seconds": 30,
    "pattern_match_context_chars": 100,
    "enable_abort": True,
    "chunk_processing_delay": 0.05,  # Reduced delay for better performance
    "skip_empty_chunks": True,
    "max_consecutive_failures": 10
}

# ============== PATTERN DATABASES ==============

# Error patterns with enhanced regex
ERROR_PATTERNS = {
    "Python": r"(?P<error_type>\w+Error|Exception):\s*(?P<message>.*?)(?:\n|$)",
    "JavaScript": r"(?P<error_type>TypeError|ReferenceError|SyntaxError|RangeError|Error):\s*(?P<message>.*?)(?:\n|$)",
    "Java": r"(?P<error_type>\w+Exception|Error):\s*(?P<message>.*?)(?:\n|$)",
    "C++": r"(?P<error_type>std::\w+|runtime_error|exception):\s*(?P<message>.*?)(?:\n|$)",
    "Ruby": r"(?P<error_type>\w+Error|Exception):\s*(?P<message>.*?)(?:\n|$)",
    "Rails": r"(?P<error_type>ActiveRecord::\w+|ActionController::\w+|\w+Error):\s*(?P<message>.*?)(?:\n|$)",
    "SmallTalk": r"(?P<error_type>MessageNotUnderstood|Error|Exception):\s*(?P<message>.*?)(?:\n|$)"
}

# Educational content database
EDUCATIONAL_CONTENT = {
    "MessageNotUnderstood": {
        "title": "Message Not Understood Error",
        "categories": ["SmallTalk", "Object-Oriented"],
        "explanation": """
This error occurs in SmallTalk when an object receives a message (method call) 
that it doesn't understand or hasn't implemented. It's SmallTalk's equivalent 
of a 'method not found' error in other languages.
        """,
        "analogy": """
It's like asking a fish to climb a tree. The fish (object) understands that 
you're asking it to do something (message), but it simply doesn't have the 
ability (method) to climb trees.
        """,
        "causes": [
            "Misspelled message selector (method name)",
            "Sending message to nil or wrong object type",
            "Method not implemented in the receiver's class hierarchy",
            "Incorrect number of arguments in the message",
            "Dynamic typing issues where object type isn't what you expected"
        ],
        "fixes": [
            "Check spelling of the message selector",
            "Verify the receiver object is not nil",
            "Implement the missing method in the appropriate class",
            "Use 'respondsTo:' to check if object understands the message",
            "Add debugging with 'self halt' to inspect the receiver"
        ],
        "best_practices": [
            "Use the debugger to inspect object types at runtime",
            "Implement 'doesNotUnderstand:' for custom error handling",
            "Use protocols to document expected messages",
            "Write comprehensive unit tests with SUnit",
            "Use type hints in method comments"
        ],
        "code_example": """
"Safe message sending in SmallTalk"
| result |
(anObject respondsTo: #doSomething)
    ifTrue: [result := anObject doSomething]
    ifFalse: [result := 'Method not available'].
^ result
        """,
        "case_study": """
A real-world example: A developer was building a graphics application and got 
MessageNotUnderstood when trying to call 'draw' on a collection of shapes. 
The issue? One element in the collection was nil. The fix was to filter out 
nil values: shapes reject: [:each | each isNil].
        """,
        "resources": [
            "SmallTalk-80: The Language and its Implementation",
            "Pharo by Example (free online book)",
            "SmallTalk Best Practice Patterns by Kent Beck"
        ]
    },
    "NoMethodError": {
        "title": "No Method Error",
        "categories": ["Ruby", "Rails", "Dynamic Languages"],
        "explanation": """
This error occurs in Ruby when you try to call a method on an object that 
doesn't have that method defined. It's one of the most common errors in Ruby 
due to its dynamic nature.
        """,
        "analogy": """
It's like trying to use a feature on your phone that hasn't been installed yet. 
The phone (object) exists, but the app (method) you're trying to use isn't there.
        """,
        "causes": [
            "Typos in method names",
            "Calling methods on nil objects",
            "Incorrect object type due to dynamic typing",
            "Method is private or protected when called externally",
            "Rails: Forgetting to run migrations for model attributes"
        ],
        "fixes": [
            "Use '&.' safe navigation operator: object&.method_name",
            "Check for nil: object.method_name if object",
            "Use respond_to? to verify method existence",
            "In Rails: Run 'rails db:migrate' for database attributes",
            "Use 'defined?' to check if method exists"
        ],
        "best_practices": [
            "Always handle nil cases explicitly",
            "Use duck typing with respond_to? checks",
            "Write defensive code with guard clauses",
            "Use type checking gems like Sorbet or RBS",
            "Implement method_missing for dynamic behavior"
        ],
        "code_example": """
# Safe method calling in Ruby
# Using safe navigation operator
user&.profile&.name || 'Anonymous'

# Using respond_to?
if user.respond_to?(:premium_features)
  user.premium_features
else
  'Basic features only'
end

# Guard clause pattern
def process_user(user)
  return unless user
  return unless user.active?
  
  user.process_data
end
        """,
        "case_study": """
A Rails developer encountered NoMethodError on a User model's 'email' attribute. 
The issue: The migration adding the email column hadn't been run on the 
production database. Solution: Added a deployment check for pending migrations 
and used attribute_present? before accessing.
        """,
        "resources": [
            "The Ruby Programming Language (Matz & Flanagan)",
            "Eloquent Ruby by Russ Olsen",
            "Rails Guides: Active Record Basics"
        ]
    },
    "NullPointerException": {
        "title": "Null Pointer Exception",
        "categories": ["Java", "C++", "System Programming"],
        "explanation": """
This exception occurs when your code attempts to use a reference that points to 
no location in memory (null) as though it's pointing to an object. It's one of 
the most common runtime exceptions in Java.
        """,
        "analogy": """
It's like having a business card with no address on it. When you try to visit 
the address (use the object), you realize there's nowhere to go (it's null).
        """,
        "causes": [
            "Uninitialized object references",
            "Method returning null unexpectedly",
            "Accessing array elements beyond initialization",
            "Incorrect null handling in conditionals",
            "Race conditions in multi-threaded code"
        ],
        "fixes": [
            "Initialize objects before use: Object obj = new Object();",
            "Add null checks: if (obj != null) { obj.method(); }",
            "Use Optional<T> in Java 8+: Optional.ofNullable(obj)",
            "Set default values in constructors",
            "Use @NonNull and @Nullable annotations"
        ],
        "best_practices": [
            "Follow 'fail-fast' principle - check nulls early",
            "Use Optional<T> for potentially null returns",
            "Leverage IDE null-analysis tools",
            "Write unit tests for null scenarios",
            "Consider Null Object Pattern for default behavior"
        ],
        "code_example": """
// Java - Safe null handling
// Using Optional
Optional<User> user = findUser(id);
user.ifPresent(u -> System.out.println(u.getName()));
String name = user.map(User::getName).orElse("Unknown");

// Traditional null check
if (user != null && user.getProfile() != null) {
    return user.getProfile().getSettings();
}
return defaultSettings();

// Null Object Pattern
public class NullUser extends User {
    @Override
    public String getName() {
        return "Guest";
    }
}
        """,
        "case_study": """
An e-commerce application crashed with NPE during checkout. Investigation revealed 
the shipping address was optional, but the code assumed it always existed. 
Solution: Implemented Optional<Address> and added a flow for users to add 
shipping address when missing.
        """,
        "resources": [
            "Effective Java by Joshua Bloch",
            "Java Concurrency in Practice",
            "Clean Code by Robert Martin"
        ]
    },
    "IndexError": {
        "title": "Index Error / Out of Bounds",
        "categories": ["Python", "General Programming"],
        "explanation": """
This error occurs when you try to access an index that doesn't exist in a 
sequence (list, tuple, string). You're trying to access an element at a position 
that's beyond the size of the collection.
        """,
        "analogy": """
It's like trying to get to the 11th floor in a 10-story building. The elevator 
(your code) can't take you there because that floor (index) doesn't exist.
        """,
        "causes": [
            "Off-by-one errors in loops",
            "Assuming list has elements when it's empty",
            "Using wrong variable for index",
            "Not accounting for zero-based indexing",
            "List modified during iteration"
        ],
        "fixes": [
            "Check list length: if index < len(list)",
            "Use try/except for safe access",
            "Use list slicing which doesn't raise errors",
            "Enumerate with index tracking",
            "Use get() method for dictionaries"
        ],
        "best_practices": [
            "Always validate indices before access",
            "Use Pythonic iteration: 'for item in list'",
            "Leverage enumerate() for index needs",
            "Consider using collections.deque for queue operations",
            "Use slicing for safe subsequence access"
        ],
        "code_example": """
# Python - Safe index access
# Check bounds
def safe_access(lst, index, default=None):
    if 0 <= index < len(lst):
        return lst[index]
    return default

# Using slicing (never raises IndexError)
first_three = my_list[:3]  # Gets up to 3 elements

# Safe iteration with enumerate
for i, value in enumerate(my_list):
    print(f"Index {i}: {value}")

# Try/except pattern
try:
    value = my_list[index]
except IndexError:
    value = default_value
        """,
        "case_study": """
A data processing script failed with IndexError when processing CSV files. 
The issue: Some rows had fewer columns than expected. Solution: Used the 
csv.DictReader which handles missing columns gracefully, and added validation 
for required fields.
        """,
        "resources": [
            "Python Crash Course by Eric Matthes",
            "Fluent Python by Luciano Ramalho",
            "Python Cookbook by David Beazley"
        ]
    },
    "OutOfMemoryError": {
        "title": "Out of Memory Error",
        "categories": ["Java", "System", "Performance"],
        "explanation": """
This error occurs when the Java Virtual Machine (JVM) cannot allocate an object 
because it's out of memory, and no more memory could be made available by the 
garbage collector.
        """,
        "analogy": """
It's like trying to put more groceries in your car trunk when it's already full. 
No matter how you rearrange (garbage collection), there's simply no more space 
available.
        """,
        "causes": [
            "Memory leaks - objects not being garbage collected",
            "Loading large files entirely into memory",
            "Infinite loops creating objects",
            "Heap size too small for application needs",
            "Memory fragmentation in long-running applications"
        ],
        "fixes": [
            "Increase heap size: -Xmx2g or -Xmx4g",
            "Fix memory leaks - review object references",
            "Use streaming for large file processing",
            "Implement object pooling for frequently used objects",
            "Profile with tools like JProfiler or YourKit"
        ],
        "best_practices": [
            "Monitor memory usage in production",
            "Implement proper resource cleanup (try-with-resources)",
            "Use weak references for caches",
            "Process large datasets in chunks",
            "Regular heap dump analysis"
        ],
        "code_example": """
// Java - Memory efficient patterns
// Streaming large files
try (Stream<String> lines = Files.lines(Paths.get("large.txt"))) {
    lines.forEach(this::processLine);
}

// Object pooling
public class ConnectionPool {
    private final Queue<Connection> pool;
    
    public Connection borrow() {
        Connection conn = pool.poll();
        return conn != null ? conn : createNew();
    }
    
    public void release(Connection conn) {
        if (pool.size() < MAX_SIZE) {
            pool.offer(conn);
        } else {
            conn.close();
        }
    }
}

// Weak reference cache
Map<Key, WeakReference<ExpensiveObject>> cache = new WeakHashMap<>();
        """,
        "case_study": """
A reporting service crashed with OOM when generating large Excel files. 
Investigation showed the entire dataset was loaded into memory. Solution: 
Switched to Apache POI's streaming API (SXSSFWorkbook) which writes to 
temp files, reducing memory from 2GB to 100MB.
        """,
        "resources": [
            "Java Performance by Scott Oaks",
            "Java Memory Management (Oracle docs)",
            "Troubleshooting Guide for HotSpot VM"
        ]
    },
    "ActiveRecord::RecordNotFound": {
        "title": "ActiveRecord Record Not Found",
        "categories": ["Rails", "Database", "Web"],
        "explanation": """
This Rails exception occurs when a database query using finder methods like 
find(), find_by!() doesn't return any results. It's Rails' way of enforcing 
that certain records must exist.
        """,
        "analogy": """
It's like going to a library with a specific book's ID number, but the book 
has been checked out or removed. The library system (ActiveRecord) tells you 
definitively: "That book is not here."
        """,
        "causes": [
            "Record was deleted but ID still referenced",
            "Using wrong ID or parameter",
            "Case sensitivity in database queries",
            "Record exists in different database/environment",
            "Race condition where record is deleted between checks"
        ],
        "fixes": [
            "Use find_by instead of find for graceful nil return",
            "Implement rescue_from in controllers",
            "Add existence checks before operations",
            "Use database constraints and foreign keys",
            "Implement soft deletes for important records"
        ],
        "best_practices": [
            "Always handle RecordNotFound in controllers",
            "Use find_by for optional records",
            "Implement proper 404 pages",
            "Log missing records for debugging",
            "Use database transactions for related operations"
        ],
        "code_example": """
# Rails - Handling RecordNotFound
# In Controller
class UsersController < ApplicationController
  rescue_from ActiveRecord::RecordNotFound, with: :not_found
  
  def show
    @user = User.find(params[:id])  # Raises if not found
  end
  
  private
  
  def not_found
    render json: { error: 'User not found' }, status: 404
  end
end

# Safe finding
user = User.find_by(id: params[:id])
if user
  # process user
else
  # handle missing user
end

# Using where with first
user = User.where(email: email).first || User.new

# Existence check
if User.exists?(id: params[:id])
  # proceed with operation
end
        """,
        "case_study": """
An e-learning platform showed 500 errors when users bookmarked courses that 
were later removed. Solution: Implemented soft deletes with paranoia gem, 
added a CourseArchive model, and showed "This course is no longer available" 
message instead of error.
        """,
        "resources": [
            "Rails Guides: Active Record Query Interface",
            "The Rails 7 Way by Obie Fernandez",
            "Rails AntiPatterns by Chad Pytel"
        ]
    }
}

# Crash analyzer patterns
CRASH_PATTERNS = {
    "NullPointerException": {
        "pattern": r"NullPointerException|NPE|null.*reference|nil.*reference|accessing null object|nil object",
        "quick_fix": "Add null checks before object access: `if (obj != null)`",
        "prevention": "Use defensive programming and Optional types",
        "severity": "High",
        "color": "#FF9800"
    },
    "OutOfMemoryError": {
        "pattern": r"OutOfMemoryError|OOM|heap.*space|memory.*exhausted|GC overhead limit|Java heap space",
        "quick_fix": "Increase JVM heap size: `-Xmx2g` or `-Xmx4g`. Check for memory leaks",
        "prevention": "Profile memory usage, fix memory leaks, optimize collections",
        "severity": "Critical",
        "color": "#F44336"
    },
    "StackOverflowError": {
        "pattern": r"StackOverflowError|stack.*overflow|recursion.*limit|deep recursion|infinite recursion",
        "quick_fix": "Check for infinite recursion or circular references",
        "prevention": "Add recursion depth limits and base cases",
        "severity": "High",
        "color": "#E91E63"
    },
    "DatabaseTimeout": {
        "pattern": r"timeout|connection.*timed.*out|query.*timeout|database.*timeout|JDBC.*timeout",
        "quick_fix": "Increase timeout settings or optimize query",
        "prevention": "Add indexes, optimize queries, use connection pooling",
        "severity": "Medium",
        "color": "#2196F3"
    },
    "FileNotFound": {
        "pattern": r"FileNotFoundException|file.*not.*found|no.*such.*file|path.*not.*found",
        "quick_fix": "Verify file path and permissions",
        "prevention": "Add file existence checks before access",
        "severity": "Medium",
        "color": "#4CAF50"
    },
    "PermissionDenied": {
        "pattern": r"Permission.*denied|Access.*denied|Unauthorized|403|Forbidden",
        "quick_fix": "Check file/process permissions and user rights",
        "prevention": "Implement proper permission checks and user roles",
        "severity": "Medium",
        "color": "#9C27B0"
    },
    "ConnectionRefused": {
        "pattern": r"Connection.*refused|ECONNREFUSED|Unable.*to.*connect|Connection.*failed",
        "quick_fix": "Verify service is running and port is correct",
        "prevention": "Implement retry logic and health checks",
        "severity": "High",
        "color": "#00BCD4"
    },
    "DeadlockDetected": {
        "pattern": r"Deadlock.*detected|deadlock.*victim|Lock.*wait.*timeout|circular.*lock",
        "quick_fix": "Review transaction ordering and lock acquisition",
        "prevention": "Use consistent lock ordering, shorter transactions",
        "severity": "Critical",
        "color": "#FF5722"
    }
}

# ============== ERROR DECODER FUNCTIONS ==============

def parse_error_message(content: str, language: str = "Auto") -> Dict[str, Any]:
    """Parse error message and extract key information"""
    if language == "Auto":
        # Try to detect language from content
        for lang, pattern in ERROR_PATTERNS.items():
            if re.search(pattern, content, re.MULTILINE | re.IGNORECASE):
                language = lang
                break
    
    if language in ERROR_PATTERNS:
        pattern = ERROR_PATTERNS[language]
        match = re.search(pattern, content, re.MULTILINE | re.IGNORECASE)
        if match:
            return {
                "language": language,
                "error_type": match.group("error_type"),
                "message": match.group("message"),
                "raw_match": match.group(0)
            }
    
    return {
        "language": "Unknown",
        "error_type": "Unknown Error",
        "message": content[:200],
        "raw_match": content[:200]
    }

def get_educational_content(error_type: str) -> Dict[str, Any]:
    """Get educational content for error type"""
    # Check exact match first
    if error_type in EDUCATIONAL_CONTENT:
        return EDUCATIONAL_CONTENT[error_type]
    
    # Check partial matches
    for key, content in EDUCATIONAL_CONTENT.items():
        if key.lower() in error_type.lower() or error_type.lower() in key.lower():
            return content
    
    return None

def generate_code_fix(error_info: Dict[str, Any], code_context: str, model: str) -> str:
    """Generate code fix for the error"""
    prompt = f"""
    Fix this {error_info['language']} error:
    
    Error Type: {error_info['error_type']}
    Error Message: {error_info['message']}
    
    Code Context:
    {code_context}
    
    Provide:
    1. Fixed code
    2. Explanation of changes
    3. Prevention tips
    """
    
    response = safe_ollama_generate(model, prompt)
    if isinstance(response, dict):
        return response.get('response', 'Unable to generate fix')
    return str(response)

def update_error_statistics(error_type: str, language: str):
    """Update error frequency statistics in database"""
    try:
        # Query existing stats
        result = db.execute_query(
            "SELECT frequency FROM error_statistics WHERE error_type = %s AND language = %s",
            (error_type, language)
        )
        
        if result:
            # Update frequency
            db.execute_query(
                "UPDATE error_statistics SET frequency = frequency + 1, last_seen = %s WHERE error_type = %s AND language = %s",
                (datetime.now(), error_type, language)
            )
        else:
            # Insert new record
            db.execute_query(
                "INSERT INTO error_statistics (error_type, language, frequency, last_seen) VALUES (%s, %s, 1, %s)",
                (error_type, language, datetime.now())
            )
    except Exception as e:
        st.error(f"Failed to update statistics: {e}")

# ============== EXCEPTION ADVISOR FUNCTIONS ==============

def analyze_exception_handling(code: str, language: str) -> Dict[str, Any]:
    """Analyze exception handling in code"""
    analysis = {
        "has_exception_handling": False,
        "patterns_found": [],
        "anti_patterns": [],
        "suggestions": []
    }
    
    # Language-specific patterns
    if language == "Python":
        if re.search(r'try:\s*\n.*except.*:', code, re.MULTILINE):
            analysis["has_exception_handling"] = True
            
        # Check for bare except
        if re.search(r'except\s*:', code):
            analysis["anti_patterns"].append("Bare except clause found - catches all exceptions")
            
        # Check for exception in loops
        if re.search(r'for.*:\s*\n\s*try:', code, re.MULTILINE):
            analysis["patterns_found"].append("Exception handling in loop")
    
    elif language == "Java":
        if re.search(r'try\s*{.*}\s*catch', code, re.DOTALL):
            analysis["has_exception_handling"] = True
            
        # Check for empty catch blocks
        if re.search(r'catch\s*\([^)]+\)\s*{\s*}', code):
            analysis["anti_patterns"].append("Empty catch block found")
    
    elif language == "Ruby":
        if re.search(r'begin.*rescue.*end', code, re.DOTALL):
            analysis["has_exception_handling"] = True
            
        # Check for rescuing Exception
        if re.search(r'rescue\s+Exception', code):
            analysis["anti_patterns"].append("Rescuing Exception class directly")
    
    return analysis

def generate_exception_strategy(system_type: str, options: Dict[str, bool], model: str) -> str:
    """Generate exception handling strategy"""
    prompt = f"""
    Create a comprehensive exception handling strategy for a {system_type}.
    
    Include these aspects:
    {' '.join([f'- {k.replace("_", " ").title()}' for k, v in options.items() if v])}
    
    Provide:
    1. Strategy overview
    2. Implementation guidelines
    3. Code examples
    4. Best practices
    5. Common pitfalls to avoid
    """
    
    response = safe_ollama_generate(model, prompt, temperature=0.3)
    if isinstance(response, dict):
        return response.get('response', 'Unable to generate strategy')
    return str(response)

# ============== CRASH ANALYZER FUNCTIONS ==============

@st.cache_data(show_spinner=False, max_entries=20, ttl=3600)
def match_crash_patterns(content: str) -> List[Dict[str, Any]]:
    """Match crash content against known patterns"""
    matches = []
    for pattern_name, pattern_info in CRASH_PATTERNS.items():
        pattern_matches = re.finditer(pattern_info["pattern"], content, re.IGNORECASE)
        for match in pattern_matches:
            start = max(0, match.start() - CRASH_ANALYZER_CONFIG["pattern_match_context_chars"] // 2)
            end = min(len(content), match.end() + CRASH_ANALYZER_CONFIG["pattern_match_context_chars"] // 2)
            context = content[start:end].replace('\n', ' ')
            
            matches.append({
                "pattern": pattern_name,
                "quick_fix": pattern_info["quick_fix"],
                "prevention": pattern_info["prevention"],
                "severity": pattern_info.get("severity", "Medium"),
                "color": pattern_info.get("color", "#9E9E9E"),
                "context": textwrap.shorten(context, width=150, placeholder="..."),
                "position": match.start()
            })
    return matches

@st.cache_data(show_spinner=False, max_entries=10, ttl=3600)
def extract_critical_sections(content: str, max_length: int = 15000) -> str:
    """Extract the most important sections from a crash dump"""
    # Exception information
    exception_match = re.search(
        r'(.*Exception:.*)|(.*Error:.*)|(FATAL:.*)|(SEVERE:.*)', 
        content, 
        re.IGNORECASE | re.MULTILINE
    )
    
    # Stack trace
    stack_trace_match = re.search(
        r'(?s)(\s+at\s+.*\n)+|(Thread\s+\d+.*\n.*\n.*\n)|(Call stack:.*?\n\n)',
        content
    )
    
    critical_content = ""
    
    if exception_match:
        critical_content += "--- EXCEPTION INFO ---\n" + exception_match.group(0) + "\n\n"
    
    if stack_trace_match:
        critical_content += "--- STACK TRACE ---\n" + stack_trace_match.group(0) + "\n"
    
    # Get samples from different parts if no patterns found
    if not critical_content:
        sections = []
        chunk_size = min(3000, len(content) // 4)
        
        # Beginning
        sections.append(content[:chunk_size])
        
        # Middle sections
        if len(content) > chunk_size * 4:
            mid_point = len(content) // 2
            sections.append(content[mid_point-chunk_size//2:mid_point+chunk_size//2])
        
        # End
        sections.append(content[-chunk_size:])
        
        critical_content = "\n\n--- SAMPLE ---\n\n".join(sections)
    
    return critical_content[:max_length]

def analyze_with_chunking(content: str) -> Dict[str, Any]:
    """Analyze large files using chunking approach"""
    chunk_size = CRASH_ANALYZER_CONFIG["chunk_size"]
    overlap = CRASH_ANALYZER_CONFIG["chunk_overlap"]
    max_chunks = CRASH_ANALYZER_CONFIG["max_chunks"]
    
    # Initialize analysis state
    st.session_state.analysis_active = True
    st.session_state.analysis_cancelled = False
    
    chunks = []
    start = 0
    chunk_num = 1
    
    # Create chunks
    while start < len(content) and chunk_num <= max_chunks:
        end = min(start + chunk_size, len(content))
        chunk_content = content[start:end]
        
        # Skip empty chunks
        if CRASH_ANALYZER_CONFIG["skip_empty_chunks"] and not chunk_content.strip():
            start = end - overlap
            continue
            
        chunks.append({
            "number": chunk_num,
            "start": start,
            "end": end,
            "size": end - start,
            "content": chunk_content,
            "analysis": None,
            "errors": [],
            "status": "Pending"
        })
        start = end - overlap
        chunk_num += 1
    
    # UI elements
    progress_bar = st.progress(0, text="Preparing chunk analysis...")
    status_text = st.empty()
    chunk_container = st.container()
    cancel_container = st.container()
    results = []
    consecutive_failures = 0
    
    # Cancel button
    with cancel_container:
        if st.button("⛔ Cancel Analysis", key="cancel_btn", type="primary", use_container_width=True):
            st.session_state.analysis_cancelled = True
            st.session_state.analysis_active = False
    
    # Analyze chunks
    for i, chunk in enumerate(chunks):
        # Check if cancelled
        if not st.session_state.analysis_active:
            status_text.warning("Analysis cancelled by user")
            break
        
        # Check consecutive failures
        if consecutive_failures >= CRASH_ANALYZER_CONFIG["max_consecutive_failures"]:
            status_text.error("Too many consecutive failures. Stopping analysis.")
            break
            
        chunks[i]["status"] = "Processing"
        status_text.text(f"Analyzing chunk {i+1}/{len(chunks)} ({chunk['start']}-{chunk['end']} bytes)")
        update_chunk_display(chunk_container, chunks)
        
        # Analyze chunk
        prompt = f"""
        Analyze this crash dump chunk and identify key issues.
        
        CHUNK {chunk['number']} (Bytes {chunk['start']}-{chunk['end']}):
        {chunk['content']}
        
        Respond with JSON format:
        {{
            "errors": ["list", "of", "specific", "errors", "found"],
            "summary": "brief technical summary of findings",
            "severity": "Critical/High/Medium/Low",
            "status": "Success"
        }}
        """
        
        try:
            response = safe_ollama_generate(
                model=st.session_state.get("selected_model", "deepseek-r1:latest"),
                prompt=prompt,
                format="json",
                timeout=120
            )
            
            if isinstance(response, dict):
                response_text = response.get('response', '{}')
            else:
                response_text = str(response)
            
            chunk_data = json.loads(response_text)
            chunks[i]["analysis"] = chunk_data.get("summary", "No summary")
            chunks[i]["errors"] = chunk_data.get("errors", [])
            chunks[i]["status"] = "Completed"
            consecutive_failures = 0
            
            results.append({
                "chunk": chunk['number'],
                "start": chunk['start'],
                "end": chunk['end'],
                "errors": len(chunks[i]["errors"]),
                "severity": chunk_data.get("severity", "Unknown"),
                "status": chunks[i]["status"],
                "summary": chunks[i]["analysis"][:100] + "..." if chunks[i]["analysis"] else ""
            })
            
        except Exception as e:
            chunks[i]["status"] = f"Error: {str(e)}"
            chunks[i]["analysis"] = "Chunk analysis failed"
            consecutive_failures += 1
        
        progress_bar.progress((i + 1) / len(chunks))
        update_chunk_display(chunk_container, chunks)
        time.sleep(CRASH_ANALYZER_CONFIG["chunk_processing_delay"])
    
    # Synthesize results if not cancelled
    if st.session_state.analysis_active and not st.session_state.analysis_cancelled:
        status_text.text("Synthesizing final report...")
        
        # Combine findings
        combined_errors = set()
        combined_summary = "## Chunk Analysis Results\n\n"
        severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0}
        
        for chunk in chunks:
            if chunk['status'] == "Completed":
                combined_summary += f"### Chunk {chunk['number']} (Bytes {chunk['start']}-{chunk['end']})\n"
                combined_summary += f"{chunk['analysis']}\n\n"
                combined_errors.update(chunk['errors'])
        
        # Synthesize with LLM
        synthesis_prompt = f"""
        You are a senior software engineer analyzing crash reports. 
        Synthesize these chunk analyses into a coherent diagnostic report.
        
        CHUNK SUMMARIES:
        {combined_summary}
        
        Create a professional report with:
        1. Executive Summary (2-3 sentences)
        2. Root Cause Analysis
        3. Severity Assessment
        4. Immediate Actions Required
        5. Long-term Recommendations
        6. Key Patterns Observed
        """
        
        try:
            synthesis = safe_ollama_generate(
                model=st.session_state.get("selected_model", "deepseek-r1:latest"),
                prompt=synthesis_prompt,
                temperature=0.2
            )
            
            if isinstance(synthesis, dict):
                synthesized_report = synthesis.get('response', 'Synthesis failed')
            else:
                synthesized_report = str(synthesis)
            
            # Build final report
            final_report = f"""## 🧩 Synthesized Crash Analysis Report

**File:** {st.session_state.file_name}  
**Analysis Method:** Full Chunk Analysis ({len(chunks)} chunks)  
**Total File Size:** {len(content):,} bytes

---

{synthesized_report}

---

### Detailed Chunk Findings

{combined_summary}

### Combined Error List ({len(combined_errors)} unique errors)

"""
            for error in sorted(combined_errors):
                final_report += f"- {error}\n"
            
            status_text.success(f"Analysis complete! Processed {len(chunks)} chunks.")
            return {
                "chunks": chunks,
                "report": final_report,
                "errors": list(combined_errors),
                "chunk_data": results
            }
            
        except Exception as e:
            status_text.error(f"Synthesis failed: {str(e)}")
            return {
                "chunks": chunks,
                "report": "## ❌ Report synthesis failed\n\n" + combined_summary,
                "errors": list(combined_errors),
                "chunk_data": results
            }
    
    # Return partial results if cancelled
    else:
        partial_summary = "## ⚠️ Analysis Cancelled\n\nPartial results:\n\n"
        completed_chunks = sum(1 for c in chunks if c['status'] == 'Completed')
        partial_summary += f"Processed {completed_chunks} of {len(chunks)} chunks\n\n"
        
        for chunk in chunks:
            if chunk['status'] == 'Completed':
                partial_summary += f"### Chunk {chunk['number']}\n{chunk.get('analysis', 'No analysis')}\n\n"
        
        return {
            "chunks": chunks,
            "report": partial_summary,
            "errors": [],
            "chunk_data": results
        }

def update_chunk_display(container, chunks):
    """Update chunk visualization display"""
    with container:
        st.subheader("📊 Chunk Analysis Progress")
        
        # Metrics
        completed = sum(1 for c in chunks if c["status"] == "Completed")
        errors = sum(1 for c in chunks if "Error" in c["status"])
        processing = sum(1 for c in chunks if c["status"] == "Processing")
        pending = sum(1 for c in chunks if c["status"] == "Pending")
        
        cols = st.columns(4)
        cols[0].metric("Total Chunks", len(chunks))
        cols[1].metric("Completed", completed)
        cols[2].metric("Processing", processing)
        cols[3].metric("Errors", errors)
        
        # Chunk visualization
        st.markdown("### Chunk Map")
        chunk_cols = st.columns(min(10, max(1, len(chunks) // 20 + 1)))
        
        for i, chunk in enumerate(chunks):
            col_idx = i % len(chunk_cols)
            with chunk_cols[col_idx]:
                status_color = {
                    "Pending": "#9E9E9E",
                    "Processing": "#2196F3",
                    "Completed": "#4CAF50",
                }.get(chunk["status"].split(':')[0], "#F44336")
                
                error_count = len(chunk.get("errors", []))
                error_badge = f"❗{error_count}" if error_count > 0 else ""
                
                st.markdown(
                    f"<div style='background-color: {status_color}; padding: 4px; "
                    f"border-radius: 3px; margin: 1px; color: white; font-size: 0.7em; text-align: center;'>"
                    f"{chunk['number']}{error_badge}</div>",
                    unsafe_allow_html=True
                )

# ============== UI COMPONENTS ==============

def show_error_decoder():
    """Error Decoder UI"""
    st.header("🔍 Error Decoder")
    
    # Language selection
    languages = ["Auto"] + ERROR_DECODER_CONFIG["supported_languages"]
    selected_language = st.selectbox("Language", languages)
    
    # Error input
    error_input = st.text_area(
        "Paste your error message",
        height=150,
        placeholder="Paste your error message, exception, or stack trace here..."
    )
    
    # Code context (optional)
    with st.expander("Add code context (optional)"):
        code_context = st.text_area(
            "Code where error occurred",
            height=200,
            placeholder="Paste the relevant code snippet..."
        )
    
    # Analysis depth
    analysis_depth = st.select_slider(
        "Analysis Depth",
        options=ERROR_DECODER_CONFIG["analysis_depths"],
        value="Standard"
    )
    
    # Example gallery
    with st.expander("📚 Example Errors"):
        example_cols = st.columns(2)
        examples = [
            ("Python IndexError", "IndexError: list index out of range\n  File 'app.py', line 42, in process_data\n    value = data[index]"),
            ("Java NPE", "java.lang.NullPointerException\n\tat com.example.UserService.getUser(UserService.java:25)"),
            ("Ruby NoMethod", "NoMethodError: undefined method `name' for nil:NilClass\n  from app.rb:15:in `display_user'"),
            ("Rails Not Found", "ActiveRecord::RecordNotFound: Couldn't find User with 'id'=999")
        ]
        
        for i, (title, error) in enumerate(examples):
            with example_cols[i % 2]:
                if st.button(title, key=f"example_{i}"):
                    st.session_state.error_input = error
                    st.rerun()
    
    # Load from session state if available
    if 'error_input' in st.session_state:
        error_input = st.session_state.error_input
        del st.session_state.error_input
    
    # Analyze button
    if st.button("🔍 Analyze Error", type="primary", disabled=not error_input):
        with st.spinner("Analyzing error..."):
            # Parse error
            error_info = parse_error_message(error_input, selected_language)
            
            # Get educational content
            educational = get_educational_content(error_info['error_type'])
            
            # Update statistics
            if ERROR_DECODER_CONFIG["track_statistics"]:
                update_error_statistics(error_info['error_type'], error_info['language'])
            
            # Display results
            st.subheader("📊 Analysis Results")
            
            # Basic info
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Language", error_info['language'])
                st.metric("Error Type", error_info['error_type'])
            with col2:
                if educational:
                    st.metric("Knowledge Base", "✅ Found")
                    st.metric("Severity", educational.get('severity', 'Medium'))
                else:
                    st.metric("Knowledge Base", "❌ Not Found")
            
            # Error message
            st.markdown("**Error Message:**")
            st.code(error_info['message'])
            
            # Educational content
            if educational:
                st.subheader("📚 Educational Content")
                
                tabs = st.tabs(["Explanation", "Causes & Fixes", "Best Practices", "Examples", "Resources"])
                
                with tabs[0]:
                    st.markdown(educational['explanation'])
                    if 'analogy' in educational:
                        st.info(f"💡 **Analogy:** {educational['analogy']}")
                
                with tabs[1]:
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown("**Common Causes:**")
                        for cause in educational['causes']:
                            st.markdown(f"- {cause}")
                    with col2:
                        st.markdown("**Quick Fixes:**")
                        for fix in educational['fixes']:
                            st.markdown(f"- {fix}")
                
                with tabs[2]:
                    st.markdown("**Best Practices:**")
                    for practice in educational['best_practices']:
                        st.markdown(f"- {practice}")
                
                with tabs[3]:
                    if 'code_example' in educational:
                        st.code(educational['code_example'], language=error_info['language'].lower())
                    if 'case_study' in educational:
                        st.markdown("**Real-World Case Study:**")
                        st.markdown(educational['case_study'])
                
                with tabs[4]:
                    st.markdown("**Learning Resources:**")
                    for resource in educational.get('resources', []):
                        st.markdown(f"- {resource}")
            
            # AI Analysis
            if analysis_depth != "Quick":
                st.subheader("🤖 AI Analysis")
                
                prompt = f"""
                Analyze this {error_info['language']} error in detail:
                
                Error Type: {error_info['error_type']}
                Error Message: {error_info['message']}
                Analysis Depth: {analysis_depth}
                
                {"Code Context:\n" + code_context if code_context else ""}
                
                Provide:
                1. Root cause analysis
                2. Step-by-step debugging approach
                3. Prevention strategies
                4. Common variations of this error
                {"5. Code fix suggestion" if code_context else ""}
                """
                
                ai_response = safe_ollama_generate(
                    st.session_state.get("selected_model", "deepseek-r1:latest"),
                    prompt
                )
                
                if isinstance(ai_response, dict):
                    st.markdown(ai_response.get('response', 'Analysis failed'))
                else:
                    st.markdown(str(ai_response))
            
            # Generate fix if code provided
            if code_context and ERROR_DECODER_CONFIG["enable_code_fixes"]:
                if st.button("🔧 Generate Code Fix"):
                    with st.spinner("Generating fix..."):
                        fix = generate_code_fix(error_info, code_context, 
                                              st.session_state.get("selected_model", "deepseek-r1:latest"))
                        st.subheader("🔧 Suggested Fix")
                        st.markdown(fix)
            
            # Save to knowledge base
            if st.button("💾 Save Analysis"):
                capture_knowledge(
                    tool_name="error_decoder",
                    query=error_input,
                    response=json.dumps({
                        "error_info": error_info,
                        "educational": educational is not None,
                        "analysis_depth": analysis_depth
                    }),
                    metadata={
                        "error_type": error_info['error_type'],
                        "language": error_info['language']
                    }
                )
                st.success("Analysis saved to knowledge base!")

def show_exception_advisor():
    """Exception Advisor UI"""
    st.header("🛡️ Exception Advisor")
    
    # System type selection
    system_type = st.selectbox(
        "System Type",
        EXCEPTION_ADVISOR_CONFIG["system_types"]
    )
    
    # Language selection
    language = st.selectbox(
        "Primary Language",
        ERROR_DECODER_CONFIG["supported_languages"]
    )
    
    # Strategy options
    st.subheader("Strategy Components")
    options = {}
    cols = st.columns(2)
    for i, option in enumerate(EXCEPTION_ADVISOR_CONFIG["strategy_options"]):
        with cols[i % 2]:
            options[option] = st.checkbox(
                option.replace("_", " ").title(),
                value=True
            )
    
    # Code analysis section
    with st.expander("Analyze Existing Code"):
        code_to_analyze = st.text_area(
            "Paste code to analyze",
            height=200,
            placeholder="Paste your code here to analyze its exception handling..."
        )
        
        if st.button("🔍 Analyze Code"):
            if code_to_analyze:
                analysis = analyze_exception_handling(code_to_analyze, language)
                
                st.subheader("Code Analysis Results")
                
                # Metrics
                cols = st.columns(3)
                with cols[0]:
                    st.metric("Has Exception Handling", 
                             "✅ Yes" if analysis["has_exception_handling"] else "❌ No")
                with cols[1]:
                    st.metric("Patterns Found", len(analysis["patterns_found"]))
                with cols[2]:
                    st.metric("Anti-patterns", len(analysis["anti_patterns"]))
                
                # Details
                if analysis["patterns_found"]:
                    st.markdown("**Patterns Found:**")
                    for pattern in analysis["patterns_found"]:
                        st.markdown(f"- ✅ {pattern}")
                
                if analysis["anti_patterns"]:
                    st.markdown("**⚠️ Anti-patterns Detected:**")
                    for anti in analysis["anti_patterns"]:
                        st.markdown(f"- ❌ {anti}")
    
    # Generate strategy
    if st.button("🎯 Generate Exception Strategy", type="primary"):
        with st.spinner("Generating strategy..."):
            strategy = generate_exception_strategy(
                system_type,
                options,
                st.session_state.get("selected_model", "deepseek-r1:latest")
            )
            
            st.subheader("📋 Exception Handling Strategy")
            st.markdown(strategy)
            
            # Language-specific guide
            st.subheader(f"📚 {language} Specific Guidelines")
            
            if language == "Python":
                st.code("""
# Python Exception Handling Pattern
try:
    # Risky operation
    result = risky_operation()
except SpecificException as e:
    # Handle specific exception
    logger.error(f"Operation failed: {e}")
    # Recovery or re-raise
except AnotherException as e:
    # Handle another type
    handle_error(e)
finally:
    # Cleanup code
    cleanup_resources()
                """)
            elif language == "Java":
                st.code("""
// Java Exception Handling Pattern
try {
    // Risky operation
    Result result = riskyOperation();
} catch (SpecificException e) {
    // Handle specific exception
    logger.error("Operation failed", e);
    // Recovery logic
} catch (AnotherException e) {
    // Handle another type
    handleError(e);
} finally {
    // Cleanup code
    cleanupResources();
}
                """)
            elif language == "Ruby":
                st.code("""
# Ruby Exception Handling Pattern
begin
  # Risky operation
  result = risky_operation
rescue SpecificError => e
  # Handle specific exception
  Rails.logger.error "Operation failed: #{e.message}"
  # Recovery logic
rescue AnotherError => e
  # Handle another type
  handle_error(e)
ensure
  # Cleanup code
  cleanup_resources
end
                """)
            
            # Save strategy
            if st.button("💾 Save Strategy"):
                capture_knowledge(
                    tool_name="exception_advisor",
                    query=f"{system_type} - {language}",
                    response=strategy,
                    metadata={
                        "system_type": system_type,
                        "language": language,
                        "options": options
                    }
                )
                st.success("Strategy saved!")
    
    # Anti-patterns reference
    with st.expander("⚠️ Common Anti-patterns"):
        st.markdown("""
        ### Exception Handling Anti-patterns
        
        1. **Swallowing Exceptions**
           - Empty catch blocks
           - Logging but not handling
           - Catching and ignoring
        
        2. **Catching Too Broadly**
           - Catching Exception/Throwable
           - Bare except clauses
           - Not differentiating error types
        
        3. **Using Exceptions for Control Flow**
           - Expected conditions as exceptions
           - Performance implications
           - Code clarity issues
        
        4. **Poor Error Messages**
           - Generic messages
           - No context information
           - Technical jargon for users
        
        5. **Resource Leaks**
           - Not using finally/ensure
           - Missing cleanup code
           - Unclosed connections
        """)

def show_crash_analyzer():
    """Crash Analyzer UI"""
    st.header("🚨 Crash Analyzer Pro")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload crash dump",
        type=["txt", "log", "dmp", "wcr", "crash", "error"],
        help=f"Maximum file size: {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB"
    )
    
    if uploaded_file:
        # Validate file
        if not validate_file_size(uploaded_file, max_size_mb=CRASH_ANALYZER_CONFIG['max_file_size_mb']):
            st.error(f"File too large. Maximum size is {CRASH_ANALYZER_CONFIG['max_file_size_mb']}MB.")
            return
        
        # Read content
        try:
            content = uploaded_file.getvalue().decode("utf-8", errors='ignore')
            content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
            
            # Store in session state
            st.session_state.crash_content = content
            st.session_state.crash_file_name = uploaded_file.name
            st.session_state.crash_file_hash = content_hash
            
        except Exception as e:
            st.error(f"Error reading file: {str(e)}")
            return
    
    # Main analysis area
    if 'crash_content' in st.session_state:
        content = st.session_state.crash_content
        
        # File info
        st.subheader(f"📄 {st.session_state.crash_file_name}")
        
        cols = st.columns(4)
        cols[0].metric("File Size", f"{len(content):,} bytes")
        cols[1].metric("Lines", f"{len(content.splitlines()):,}")
        cols[2].metric("Hash", st.session_state.crash_file_hash)
        cols[3].metric("Patterns", len(match_crash_patterns(content)))
        
        # Pattern matches preview
        pattern_matches = match_crash_patterns(content)
        if pattern_matches:
            with st.expander(f"🔍 Detected Patterns ({len(pattern_matches)})"):
                for match in pattern_matches[:10]:  # Show first 10
                    st.markdown(
                        f"<div style='border-left: 4px solid {match['color']}; padding: 10px; margin: 5px 0;'>"
                        f"<b>{match['pattern']}</b> ({match['severity']})<br>"
                        f"<i>{match['context']}</i><br>"
                        f"<b>Quick Fix:</b> {match['quick_fix']}</div>",
                        unsafe_allow_html=True
                    )
        
        # Analysis methods
        st.subheader("🔍 Analysis Methods")
        
        method_cols = st.columns(4)
        
        with method_cols[0]:
            if st.button("⚡ Basic Analysis", use_container_width=True,
                        help="Fast analysis of critical sections"):
                with st.spinner("Analyzing..."):
                    extracted = extract_critical_sections(content)
                    st.session_state.crash_analysis_type = "basic"
                    st.session_state.crash_analysis_result = extracted
        
        with method_cols[1]:
            if st.button("🎯 Smart Sampling", use_container_width=True,
                        help="Strategic sampling of large files"):
                with st.spinner("Sampling..."):
                    # Implement smart sampling
                    st.session_state.crash_analysis_type = "sampling"
                    st.session_state.crash_analysis_result = "Smart sampling analysis..."
        
        with method_cols[2]:
            if st.button("🧩 Chunk Analysis", use_container_width=True,
                        help=f"Full analysis in {CRASH_ANALYZER_CONFIG['max_chunks']} chunks"):
                if len(content) > 100000:  # 100KB
                    st.warning(f"Large file will be analyzed in up to {CRASH_ANALYZER_CONFIG['max_chunks']} chunks")
                
                st.session_state.crash_analysis_type = "chunks"
                st.session_state.analysis_active = True
                st.session_state.analysis_cancelled = False
                
                with st.spinner("Starting chunk analysis..."):
                    result = analyze_with_chunking(content)
                    st.session_state.crash_analysis_result = result
        
        with method_cols[3]:
            if st.button("📊 Statistics", use_container_width=True,
                        help="Statistical analysis and trends"):
                st.session_state.crash_analysis_type = "stats"
                # Generate statistics
        
        # Display results
        if 'crash_analysis_type' in st.session_state:
            if st.session_state.crash_analysis_type == "basic":
                st.subheader("📋 Basic Analysis")
                st.code(st.session_state.crash_analysis_result)
                
            elif st.session_state.crash_analysis_type == "chunks":
                st.subheader("🧩 Chunk Analysis Report")
                result = st.session_state.crash_analysis_result
                
                # Synthesized report
                with st.container():
                    st.markdown(result['report'])
                
                # Chunk details
                if result.get('chunk_data'):
                    with st.expander("View chunk details"):
                        df = pd.DataFrame(result['chunk_data'])
                        st.dataframe(df)
                
            elif st.session_state.crash_analysis_type == "stats":
                st.subheader("📊 Crash Statistics")
                # Show statistics dashboard
        
        # Export options
        with st.expander("💾 Export Options"):
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📄 Download Report"):
                    # Generate downloadable report
                    st.success("Report ready for download")
            with col2:
                if st.button("💾 Save to Knowledge Base"):
                    # Save analysis
                    st.success("Analysis saved!")

# ============== MAIN APPLICATION ==============

def main(standalone=True):
    # Only set page config if running standalone (not from unified app)
    if standalone:
        try:
            st.set_page_config(
                page_title="Error Analysis Toolkit",
                page_icon="🔍",
                layout="wide",
                initial_sidebar_state="expanded"
            )
        except:
            # Page config already set (running from unified app)
            pass
    
    # Custom CSS
    st.markdown("""
    <style>
        .stTabs [data-baseweb="tab-list"] button[aria-selected="true"] {
            background-color: #4CAF50;
        }
        .metric-card {
            background-color: #1e1e1e;
            padding: 1rem;
            border-radius: 0.5rem;
            border: 1px solid #333;
        }
        .pattern-match {
            border-radius: 5px;
            padding: 10px;
            margin: 5px 0;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.title("🔍 Error Analysis Toolkit")
        
        # Tool selection
        tool = st.radio(
            "Select Tool",
            ["Error Decoder", "Exception Advisor", "Crash Analyzer"],
            help="Choose the analysis tool"
        )
        
        st.divider()
        
        # Model selection
        st.subheader("⚙️ Settings")
        models = ["deepseek-r1:latest", "qwen2.5-coder:latest", "llama3.2:latest"]
        selected_model = st.selectbox("AI Model", models)
        st.session_state.selected_model = selected_model
        
        # Statistics
        st.divider()
        st.subheader("📊 Statistics")
        
        # Get recent analyses
        try:
            recent = db.execute_query(
                """
                SELECT tool, COUNT(*) as count 
                FROM queries 
                WHERE created_at > %s
                GROUP BY tool
                """,
                (datetime.now() - timedelta(days=7),)
            )
            
            if recent:
                for row in recent:
                    st.metric(row['tool'], row['count'])
            else:
                st.info("No recent analyses")
                
        except Exception as e:
            st.error(f"Failed to load statistics: {e}")
        
        # Navigation
        st.divider()
        st.markdown("### 🔗 Quick Links")
        st.markdown("- [Knowledge Library](/Knowledge_Library)")
        st.markdown("- [Help Guide](/Help_Guide)")
    
    # Main content
    if tool == "Error Decoder":
        show_error_decoder()
    elif tool == "Exception Advisor":
        show_exception_advisor()
    elif tool == "Crash Analyzer":
        show_crash_analyzer()
    
    # Footer
    st.divider()
    st.caption("Error Analysis Toolkit v2.0 - Unified Edition")

if __name__ == "__main__":
    main()
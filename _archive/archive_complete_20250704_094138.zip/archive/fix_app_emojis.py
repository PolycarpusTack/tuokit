"""
Fix emoji issues in app.py for Windows compatibility
"""

import re

# Read app.py
with open("C:/Projects/Tuokit/app.py", "r", encoding="utf-8") as f:
    content = f.read()

# Replace emojis with text
replacements = {
    "🧠": "[AI]",
    "🏠": "[HOME]",
    "🔍": "[SEARCH]",
    "✅": "[OK]",
    "❌": "[ERROR]",
    "🌟": "[STAR]",
    "🤖": "[BOT]",
    "🛢️": "[DB]",
    "💎": "[GEM]",
    "📊": "[CHART]",
    "💡": "[TIP]",
    "•": "-"
}

for emoji, replacement in replacements.items():
    content = content.replace(emoji, replacement)

# Write back
with open("C:/Projects/Tuokit/app.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Fixed emoji issues in app.py")

# Also fix the Home page
with open("C:/Projects/Tuokit/pages/0_Home.py", "r", encoding="utf-8") as f:
    content = f.read()

# Remove emojis from title
content = content.replace('"""
🏠 TuoKit Home - Organized Tool Navigation
"""', '"""
TuoKit Home - Organized Tool Navigation
"""')

with open("C:/Projects/Tuokit/pages/0_Home.py", "w", encoding="utf-8") as f:
    f.write(content)

print("Fixed Home page")

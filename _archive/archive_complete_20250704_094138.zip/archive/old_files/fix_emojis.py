"""
Quick fix to remove emojis from Ollama files
"""

import re

# Fix ollama.py
ollama_path = "C:/Projects/Tuokit/utils/ollama.py"
with open(ollama_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace emojis with text
replacements = {
    '🔍': '[TEST]',
    '✅': '[OK]',
    '❌': '[ERROR]',
    '🔧': '[FIX]',
    '🚀': '[START]',
    '📊': '[INFO]',
    '⚙️': '[CONFIG]',
    '🧪': '[TEST]'
}

for emoji, text in replacements.items():
    content = content.replace(emoji, text)

# Write back
with open(ollama_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed emoji issues in ollama.py")

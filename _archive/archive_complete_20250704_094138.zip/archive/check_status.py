"""
Quick check if TuoKit/Streamlit is running
"""
import requests
import subprocess

def check_streamlit():
    """Check if streamlit is running on default port"""
    try:
        response = requests.get("http://localhost:8501", timeout=2)
        if response.status_code == 200:
            print("✅ TuoKit is running at http://localhost:8501")
            print("Open your browser to access it!")
            return True
    except:
        pass
    
    print("❌ TuoKit is not running")
    print("Start it with: python start.py")
    return False

def check_processes():
    """Check for streamlit processes"""
    try:
        result = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq python.exe'], 
                              capture_output=True, text=True)
        if 'streamlit' in result.stdout.lower():
            print("📍 Found streamlit process running")
    except:
        pass

if __name__ == "__main__":
    check_streamlit()
    check_processes()

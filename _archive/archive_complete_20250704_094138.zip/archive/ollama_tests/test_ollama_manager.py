#!/usr/bin/env python3
"""
Direct test of OllamaManager
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.ollama import OllamaManager

print("Testing OllamaManager.get_status()...")
print("-" * 60)

try:
    status = OllamaManager.get_status()
    print(f"Running: {status['running']}")
    print(f"Model Count: {status['model_count']}")
    print(f"Models: {status['models']}")
    print(f"Error: {status['error']}")
    
    if status['running']:
        print("\n[SUCCESS] OllamaManager detects Ollama properly!")
    else:
        print("\n[ISSUE] OllamaManager is not detecting Ollama")
        
except Exception as e:
    print(f"[ERROR] {str(e)}")
    import traceback
    traceback.print_exc()

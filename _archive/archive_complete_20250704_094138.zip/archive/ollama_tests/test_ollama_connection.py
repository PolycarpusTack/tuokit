#!/usr/bin/env python3
"""
Test Ollama Connection
Diagnose connection issues with Ollama
"""

import os
import subprocess
import sys
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

def test_ollama_connection():
    print("=" * 60)
    print("TuoKit Ollama Connection Test")
    print("=" * 60)
    
    # Check environment variables
    print("\n1. Environment Variables:")
    print(f"   TUOKIT_OLLAMA_HOST: {os.getenv('TUOKIT_OLLAMA_HOST', 'Not set')}")
    print(f"   OLLAMA_HOST: {os.getenv('OLLAMA_HOST', 'Not set')}")
    
    # Test 1: Command line ollama
    print("\n2. Testing command line 'ollama list':")
    try:
        result = subprocess.run(
            ["ollama", "list"], 
            capture_output=True, 
            text=True, 
            timeout=5
        )
        if result.returncode == 0:
            print("   ✅ SUCCESS - Command line working")
            print("   Output:")
            print("   " + "\n   ".join(result.stdout.strip().split('\n')[:5]))
        else:
            print(f"   ❌ FAILED - Return code: {result.returncode}")
            print(f"   Error: {result.stderr}")
    except FileNotFoundError:
        print("   ❌ FAILED - 'ollama' command not found in PATH")
        print("   Make sure Ollama is installed and in your PATH")
    except Exception as e:
        print(f"   ❌ FAILED - {type(e).__name__}: {e}")
    
    # Test 2: Python ollama package
    print("\n3. Testing Python ollama package:")
    try:
        import ollama
        print("   ✅ Package imported successfully")
        
        # Set OLLAMA_HOST
        ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
        os.environ["OLLAMA_HOST"] = ollama_host
        print(f"   Setting OLLAMA_HOST to: {ollama_host}")
        
        # Try to list models
        print("   Attempting to list models...")
        models = ollama.list()
        
        if models and 'models' in models:
            print(f"   ✅ SUCCESS - Found {len(models['models'])} models:")
            for model in models['models'][:5]:  # Show first 5
                print(f"      - {model['name']}")
        else:
            print("   ⚠️  No models found")
            
    except ImportError:
        print("   ❌ FAILED - ollama package not installed")
        print("   Run: pip install ollama")
    except Exception as e:
        print(f"   ❌ FAILED - {type(e).__name__}: {e}")
        
    # Test 3: Direct HTTP connection
    print("\n4. Testing direct HTTP connection:")
    ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
    try:
        import requests
        response = requests.get(f"{ollama_host}/api/tags", timeout=5)
        if response.status_code == 200:
            print(f"   ✅ SUCCESS - HTTP connection to {ollama_host} working")
            data = response.json()
            if 'models' in data:
                print(f"   Found {len(data['models'])} models via HTTP")
        else:
            print(f"   ❌ FAILED - HTTP {response.status_code}")
    except ImportError:
        print("   ⚠️  requests package not installed, skipping HTTP test")
    except Exception as e:
        print(f"   ❌ FAILED - {type(e).__name__}: {e}")
    
    # Test 4: Try the new OllamaManager
    print("\n5. Testing TuoKit OllamaManager:")
    try:
        from utils.ollama import OllamaManager
        status = OllamaManager.get_status()
        print(f"   Running: {status['running']}")
        print(f"   Model count: {status['model_count']}")
        if status['models']:
            print(f"   Models: {', '.join(status['models'][:3])}")
        if status['error']:
            print(f"   Error: {status['error']}")
    except Exception as e:
        print(f"   ❌ FAILED - {type(e).__name__}: {e}")
    
    print("\n" + "=" * 60)
    print("Troubleshooting Tips:")
    print("1. Make sure Ollama is running: ollama serve")
    print("2. Check if Ollama is on a different host/port")
    print("3. Update TUOKIT_OLLAMA_HOST in .env if needed")
    print("4. Try: ollama pull deepseek-r1:latest")
    print("=" * 60)

if __name__ == "__main__":
    test_ollama_connection()
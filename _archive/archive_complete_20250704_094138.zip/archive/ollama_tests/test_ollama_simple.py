import os
import requests
import subprocess
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

print("Testing Ollama Connection...")
print("=" * 60)

# Check environment
ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
print(f"TUOKIT_OLLAMA_HOST: {ollama_host}")

# Test 1: Direct HTTP
print("\n1. Testing HTTP connection to", ollama_host)
try:
    response = requests.get(f"{ollama_host}/api/tags", timeout=5)
    print(f"   HTTP Status: {response.status_code}")
    if response.status_code == 200:
        data = response.json()
        print(f"   SUCCESS! Found {len(data.get('models', []))} models")
        for model in data.get('models', [])[:3]:
            print(f"   - {model['name']}")
    else:
        print(f"   FAILED: HTTP {response.status_code}")
except Exception as e:
    print(f"   FAILED: {type(e).__name__}: {str(e)}")

# Test 2: Try Windows host if on localhost
if "localhost" in ollama_host:
    print("\n2. Testing alternative hosts...")
    
    # Try Windows host detection
    windows_hosts = []
    try:
        # Method 1: From resolv.conf (WSL)
        if os.path.exists('/etc/resolv.conf'):
            with open('/etc/resolv.conf', 'r') as f:
                for line in f:
                    if line.startswith('nameserver'):
                        windows_hosts.append(line.split()[1])
    except:
        pass
    
    # Add common Windows hosts
    windows_hosts.extend(['host.docker.internal', '172.17.0.1'])
    
    for host in set(windows_hosts):
        test_url = f"http://{host}:11434"
        print(f"\n   Testing {test_url}...")
        try:
            response = requests.get(f"{test_url}/api/tags", timeout=2)
            if response.status_code == 200:
                data = response.json()
                print(f"   SUCCESS! Found {len(data.get('models', []))} models at {test_url}")
                print(f"\n   RECOMMENDATION: Update .env file:")
                print(f"   TUOKIT_OLLAMA_HOST={test_url}")
                break
        except:
            print(f"   Failed to connect to {test_url}")

# Test 3: Check if ollama command works
print("\n3. Testing 'ollama' command...")
try:
    result = subprocess.run(['ollama', '--version'], capture_output=True, text=True, timeout=5)
    if result.returncode == 0:
        print(f"   Ollama command found: {result.stdout.strip()}")
    else:
        print(f"   Ollama command failed: {result.stderr}")
except FileNotFoundError:
    print("   Ollama command not found in PATH")
except Exception as e:
    print(f"   Error: {str(e)}")

print("\n" + "=" * 60)
print("If Ollama is not detected:")
print("1. Make sure Ollama is running: ollama serve")
print("2. Check if it's running on a different port")
print("3. Update TUOKIT_OLLAMA_HOST in .env file")

#!/usr/bin/env python3
"""
Test Ollama Auto-detection
Verify if the enhanced OllamaManager can auto-detect Ollama on Windows host
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from utils.ollama import OllamaManager, get_available_models

def main():
    print("Testing Ollama auto-detection...")
    print("=" * 60)
    
    # Test get_status with auto-detection
    print("\n1. Testing OllamaManager.get_status():")
    status = OllamaManager.get_status()
    print(f"   Running: {status['running']}")
    print(f"   Model count: {status['model_count']}")
    print(f"   Error: {status['error']}")
    if status['models']:
        print(f"   Models: {', '.join(status['models'][:3])}")
    
    # Test get_available_models
    print("\n2. Testing get_available_models():")
    models = get_available_models()
    print(f"   Found {len(models)} models")
    for model in models[:5]:
        print(f"   - {model}")
    
    # Show current OLLAMA_HOST
    print(f"\n3. Current OLLAMA_HOST: {os.environ.get('OLLAMA_HOST', 'Not set')}")
    
    print("\n" + "=" * 60)
    
    if status['running']:
        print("✅ Ollama is accessible!")
        print(f"   Using: {os.environ.get('OLLAMA_HOST')}")
        print("\nTo make this permanent, update your .env file:")
        print(f"   TUOKIT_OLLAMA_HOST={os.environ.get('OLLAMA_HOST')}")
    else:
        print("❌ Ollama is still not accessible")
        print("\nPlease follow the instructions in fix_ollama_wsl.md")

if __name__ == "__main__":
    main()
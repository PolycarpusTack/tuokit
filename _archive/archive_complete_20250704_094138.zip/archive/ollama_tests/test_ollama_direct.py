#!/usr/bin/env python3
"""
Direct Ollama Test
Test Ollama connection without full imports
"""

import os
import sys
import subprocess
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def test_ollama_direct():
    print("Direct Ollama Connection Test")
    print("=" * 60)
    
    # Get potential hosts
    ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
    windows_host = None
    
    # Get Windows host IP from WSL
    if os.path.exists("/etc/resolv.conf"):
        try:
            with open("/etc/resolv.conf", "r") as f:
                for line in f:
                    if line.startswith("nameserver"):
                        windows_host = line.split()[1]
                        break
        except:
            pass
    
    print(f"1. Current TUOKIT_OLLAMA_HOST: {ollama_host}")
    print(f"2. Detected Windows host IP: {windows_host}")
    
    # Test with requests
    try:
        import requests
        
        # Test configured host
        print(f"\n3. Testing {ollama_host}...")
        try:
            r = requests.get(f"{ollama_host}/api/tags", timeout=2)
            if r.status_code == 200:
                data = r.json()
                print(f"   ✅ SUCCESS - Found {len(data.get('models', []))} models")
                return True
            else:
                print(f"   ❌ HTTP {r.status_code}")
        except Exception as e:
            print(f"   ❌ Failed: {type(e).__name__}")
        
        # Test Windows host if available
        if windows_host and "localhost" in ollama_host:
            test_url = f"http://{windows_host}:11434"
            print(f"\n4. Testing Windows host {test_url}...")
            try:
                r = requests.get(f"{test_url}/api/tags", timeout=2)
                if r.status_code == 200:
                    data = r.json()
                    print(f"   ✅ SUCCESS - Found {len(data.get('models', []))} models")
                    print(f"\n   📝 Update your .env file:")
                    print(f"      TUOKIT_OLLAMA_HOST={test_url}")
                    return True
                else:
                    print(f"   ❌ HTTP {r.status_code}")
            except Exception as e:
                print(f"   ❌ Failed: {type(e).__name__}")
                
    except ImportError:
        print("❌ requests module not installed")
    
    print("\n" + "=" * 60)
    print("❌ Could not connect to Ollama")
    print("\nSolutions:")
    print("1. On Windows, restart Ollama with: ollama serve --host 0.0.0.0")
    print("2. Or install Ollama in WSL: curl -fsSL https://ollama.com/install.sh | sh")
    print("3. Check the fix_ollama_wsl.md file for detailed instructions")
    
    return False

if __name__ == "__main__":
    test_ollama_direct()
"""
Simple Ollama test to verify the utilities work
"""

import sys
import os

# Add project root
sys.path.insert(0, "C:/Projects/Tuokit")

print("Testing Ollama utilities...")

try:
    from utils.ollama import OllamaManager, get_available_models
    print("[OK] Imports successful")
    
    # Create manager
    manager = OllamaManager()
    print(f"[OK] Manager created with host: {manager.host}")
    
    # Get status
    status = manager.get_status()
    print(f"[INFO] Ollama running: {status['running']}")
    print(f"[INFO] Models available: {status['model_count']}")
    
    if status['models']:
        print("[INFO] Models:")
        for model in status['models'][:3]:
            print(f"  - {model}")
            
    # Test convenience function
    models = get_available_models()
    print(f"\n[OK] get_available_models() returned {len(models)} models")
    
    print("\n[SUCCESS] Ollama utilities are working!")
    
except Exception as e:
    print(f"[ERROR] Test failed: {e}")
    import traceback
    traceback.print_exc()

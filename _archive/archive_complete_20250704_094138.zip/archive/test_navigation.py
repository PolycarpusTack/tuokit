"""
Test Navigation System
"""

import sys
sys.path.insert(0, "C:/Projects/Tuokit")

from utils.navigation import (
    NAVIGATION_CATEGORIES, 
    get_all_tools, 
    search_tools,
    get_tool_count,
    get_category_count
)

print("=== Navigation System Test ===\n")

# Test category count
print(f"Categories: {get_category_count()}")
print(f"Total tools: {get_tool_count()}")

# Show categories
print("\nCategories:")
for category in NAVIGATION_CATEGORIES:
    tool_count = len(NAVIGATION_CATEGORIES[category]["tools"])
    print(f"  - {category}: {tool_count} tools")

# Test search
print("\n\nSearch Test:")
test_queries = ["sql", "ruby", "error", "agent"]

for query in test_queries:
    results = search_tools(query)
    print(f"  '{query}' -> {len(results)} results")
    if results:
        print(f"    First result: {results[0]['name']}")

print("\n[SUCCESS] Navigation system working correctly!")

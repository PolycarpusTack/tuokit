"""
Quick fix for navigation to work without emojis
"""

# Fix app.py imports
app_path = "C:/Projects/Tuokit/app.py"
with open(app_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the problematic import
content = content.replace("from utils import OllamaManager,", "from utils import")

with open(app_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed app.py imports")

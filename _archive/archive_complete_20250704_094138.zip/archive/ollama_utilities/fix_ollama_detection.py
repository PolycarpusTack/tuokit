#!/usr/bin/env python3
"""
Quick fix for TuoKit Ollama detection issues
"""
import streamlit as st
from utils.ollama import OllamaManager
import sys

print("Testing TuoKit Ollama integration...")
print("-" * 60)

# Clear any cached status
if hasattr(st, 'session_state'):
    if 'ollama_status' in st.session_state:
        del st.session_state['ollama_status']
        print("Cleared cached Ollama status")

# Test the OllamaManager directly
try:
    status = OllamaManager.get_status()
    print(f"Ollama Status: {'Running' if status['running'] else 'Not Running'}")
    print(f"Model Count: {status['model_count']}")
    print(f"Models: {', '.join(status['models'][:3]) if status['models'] else 'None'}")
    
    if status['error']:
        print(f"Error: {status['error']}")
    
    if status['running']:
        print("\n[SUCCESS] Ollama is properly connected!")
    else:
        print("\n[FAILED] Ollama connection issue detected")
        print("\nTroubleshooting:")
        print("1. Verify Ollama is running: ollama serve")
        print("2. Check TUOKIT_OLLAMA_HOST in .env file")
        print("3. Try restarting TuoKit")
        
except Exception as e:
    print(f"[ERROR] Failed to test OllamaManager: {str(e)}")
    import traceback
    traceback.print_exc()

print("-" * 60)

#!/usr/bin/env python3
"""
Detect Ollama Host
Automatically detect where Ollama is running
"""

import os
import subprocess
import requests
from dotenv import load_dotenv
import socket

# Load environment variables
load_dotenv()

def test_url(url, timeout=2):
    """Test if Ollama is accessible at a given URL"""
    try:
        response = requests.get(f"{url}/api/tags", timeout=timeout)
        if response.status_code == 200:
            data = response.json()
            return True, len(data.get('models', []))
        return False, 0
    except:
        return False, 0

def get_windows_host_ip():
    """Get Windows host IP from WSL"""
    try:
        # Method 1: From /etc/resolv.conf
        with open('/etc/resolv.conf', 'r') as f:
            for line in f:
                if line.startswith('nameserver'):
                    return line.split()[1]
    except:
        pass
    
    try:
        # Method 2: From ip route
        result = subprocess.run(['ip', 'route'], capture_output=True, text=True)
        for line in result.stdout.split('\n'):
            if 'default' in line:
                return line.split()[2]
    except:
        pass
    
    return None

def main():
    print("🔍 Detecting Ollama host...")
    print("=" * 60)
    
    # Test candidates
    candidates = [
        ("localhost:11434", "http://localhost:11434"),
        ("host.docker.internal:11434", "http://host.docker.internal:11434"),
    ]
    
    # Add Windows host if in WSL
    windows_ip = get_windows_host_ip()
    if windows_ip:
        candidates.append((f"{windows_ip}:11434", f"http://{windows_ip}:11434"))
    
    # Add custom host from env
    custom_host = os.getenv("TUOKIT_OLLAMA_HOST")
    if custom_host and custom_host not in [c[1] for c in candidates]:
        candidates.append(("Custom env", custom_host))
    
    # Test each candidate
    working_hosts = []
    for name, url in candidates:
        print(f"\nTesting {name} ({url})...")
        success, model_count = test_url(url)
        if success:
            print(f"  ✅ SUCCESS - Found {model_count} models")
            working_hosts.append((name, url, model_count))
        else:
            print(f"  ❌ Failed")
    
    print("\n" + "=" * 60)
    if working_hosts:
        print("✅ Found Ollama running on:")
        for name, url, count in working_hosts:
            print(f"   • {url} ({count} models)")
        
        # Recommend the best one
        best = working_hosts[0]
        print(f"\n📝 Recommended .env configuration:")
        print(f"   TUOKIT_OLLAMA_HOST={best[1]}")
        
        # Update .env if different
        if custom_host != best[1]:
            print(f"\n⚠️  Your current TUOKIT_OLLAMA_HOST is: {custom_host}")
            print(f"   Consider updating it to: {best[1]}")
    else:
        print("❌ Ollama not found on any tested hosts")
        print("\nPossible solutions:")
        print("1. Make sure Ollama is running: ollama serve")
        print("2. If on Windows, run Ollama in Windows (not WSL)")
        print("3. Check Windows Firewall settings")
        print("4. Try running: ollama pull deepseek-r1:latest")

if __name__ == "__main__":
    main()
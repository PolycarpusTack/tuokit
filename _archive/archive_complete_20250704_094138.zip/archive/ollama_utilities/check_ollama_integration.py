#!/usr/bin/env python3
"""
TuoKit Ollama Integration Diagnostic Tool
Comprehensive check of Ollama setup and integration with TuoKit
"""

import os
import sys
import json
import subprocess
from pathlib import Path

# Add utils to path
sys.path.append(str(Path(__file__).parent))

def check_ollama_installation():
    """Check if Ollama is installed"""
    print("1️⃣ Checking Ollama Installation...")
    try:
        result = subprocess.run(['ollama', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Ollama is installed: {result.stdout.strip()}")
            return True
        else:
            print("❌ Ollama command not found")
            return False
    except FileNotFoundError:
        print("❌ Ollama is not installed or not in PATH")
        print("   Install from: https://ollama.ai")
        return False

def check_ollama_service():
    """Check if Ollama service is running"""
    print("\n2️⃣ Checking Ollama Service...")
    try:
        result = subprocess.run(['ollama', 'list'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            print("✅ Ollama service is running")
            return True
        else:
            print("❌ Ollama service is not running")
            print("   Start with: ollama serve")
            return False
    except subprocess.TimeoutExpired:
        print("❌ Ollama service timeout - likely not running")
        print("   Start with: ollama serve")
        return False
    except Exception as e:
        print(f"❌ Error checking service: {e}")
        return False

def check_python_library():
    """Check if Python ollama library is installed"""
    print("\n3️⃣ Checking Python Library...")
    try:
        import ollama
        print("✅ Python ollama library is installed")
        print(f"   Version: {ollama.__version__ if hasattr(ollama, '__version__') else 'Unknown'}")
        return True
    except ImportError:
        print("❌ Python ollama library not installed")
        print("   Install with: pip install ollama")
        return False

def check_models():
    """Check available models"""
    print("\n4️⃣ Checking Available Models...")
    try:
        import ollama
        models = ollama.list()
        
        if models and 'models' in models:
            print(f"✅ Found {len(models['models'])} models:")
            for model in models['models']:
                name = model.get('name', 'Unknown')
                size = model.get('size', 0) / (1024**3)  # Convert to GB
                print(f"   • {name:<40} ({size:.1f} GB)")
            
            # Check for recommended models
            model_names = [m['name'] for m in models['models']]
            recommended = ['deepseek-r1:latest', 'deepseek-coder:6.7b', 'deepseek-r1:1.5b']
            
            print("\n📋 Recommended Models Status:")
            for rec_model in recommended:
                if any(rec_model in name for name in model_names):
                    print(f"   ✅ {rec_model}")
                else:
                    print(f"   ❌ {rec_model} - Install with: ollama pull {rec_model}")
            
            return True
        else:
            print("❌ No models found")
            print("   Install a model with: ollama pull deepseek-r1:latest")
            return False
            
    except Exception as e:
        print(f"❌ Error listing models: {e}")
        return False

def test_generation():
    """Test actual generation"""
    print("\n5️⃣ Testing Generation...")
    try:
        import ollama
        
        # Get first available model
        models = ollama.list()
        if not models or not models.get('models'):
            print("❌ No models available for testing")
            return False
            
        test_model = models['models'][0]['name']
        print(f"   Using model: {test_model}")
        
        # Test with TuoKit's safe_ollama_generate
        from utils.ollama import safe_ollama_generate
        
        result = safe_ollama_generate(
            model=test_model,
            prompt="Say 'TuoKit is working!' and nothing else.",
            temperature=0.1
        )
        
        if result.get('error'):
            print(f"❌ Generation failed: {result.get('response')}")
            return False
        else:
            print(f"✅ Generation successful: {result.get('response', '').strip()}")
            return True
            
    except Exception as e:
        print(f"❌ Error during generation: {e}")
        return False

def check_tuokit_config():
    """Check TuoKit specific configuration"""
    print("\n6️⃣ Checking TuoKit Configuration...")
    
    # Check .env file
    env_path = Path('.env')
    if env_path.exists():
        print("✅ .env file found")
    else:
        print("⚠️  .env file not found (optional)")
    
    # Check required directories
    dirs_to_check = ['utils', 'pages', 'docs']
    all_good = True
    for dir_name in dirs_to_check:
        if Path(dir_name).exists():
            print(f"✅ {dir_name}/ directory exists")
        else:
            print(f"❌ {dir_name}/ directory missing")
            all_good = False
    
    return all_good

def main():
    """Run all checks"""
    print("🔍 TuoKit Ollama Integration Diagnostic")
    print("=" * 60)
    
    results = {
        "installation": check_ollama_installation(),
        "service": check_ollama_service(),
        "library": check_python_library(),
        "models": False,
        "generation": False,
        "config": check_tuokit_config()
    }
    
    # Only check models and generation if service is running
    if results["service"] and results["library"]:
        results["models"] = check_models()
        if results["models"]:
            results["generation"] = test_generation()
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 SUMMARY")
    print("=" * 60)
    
    all_good = all(results.values())
    
    for check, passed in results.items():
        status = "✅" if passed else "❌"
        print(f"{status} {check.title()}")
    
    if all_good:
        print("\n🎉 All checks passed! TuoKit is ready to use.")
    else:
        print("\n⚠️  Some checks failed. Please address the issues above.")
        print("\n🔧 Quick Fix Commands:")
        
        if not results["installation"]:
            print("1. Install Ollama: https://ollama.ai")
        
        if results["installation"] and not results["service"]:
            print("2. Start Ollama: ollama serve")
        
        if not results["library"]:
            print("3. Install Python library: pip install ollama")
        
        if results["service"] and not results["models"]:
            print("4. Install a model: ollama pull deepseek-r1:latest")
    
    return 0 if all_good else 1

if __name__ == "__main__":
    sys.exit(main())
"""
Ollama integration utilities for TuoKit
Handles model management and safe generation
"""

import subprocess
from typing import Dict, Optional, List
import json
import os

class OllamaManager:
    """Manages Ollama service and models"""
    
    @staticmethod
    def get_status() -> Dict[str, any]:
        """Check Ollama service status"""
        # Set OLLAMA_HOST from TuoKit environment if available
        ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
        
        # Auto-detect WSL2 Windows host if localhost fails
        if "localhost" in ollama_host and os.path.exists("/etc/resolv.conf"):
            try:
                with open("/etc/resolv.conf", "r") as f:
                    for line in f:
                        if line.startswith("nameserver"):
                            windows_host = line.split()[1]
                            # Try Windows host first
                            test_url = f"http://{windows_host}:11434"
                            import requests
                            try:
                                r = requests.get(f"{test_url}/api/tags", timeout=1)
                                if r.status_code == 200:
                                    ollama_host = test_url
                                    print(f"[INFO] Auto-detected Ollama on Windows host: {test_url}")
                            except:
                                pass
                            break
            except:
                pass
        
        os.environ["OLLAMA_HOST"] = ollama_host
        
        try:
            # Try the Python ollama package first
            import ollama
            models_response = ollama.list()
            
            if models_response and 'models' in models_response:
                models = models_response['models']
                return {
                    "running": True,
                    "model_count": len(models),
                    "models": [m['name'] for m in models],
                    "error": None
                }
        except Exception as ollama_error:
            # Fallback to subprocess
            try:
                # Try without --json flag as it might not be supported
                result = subprocess.run(
                    ["ollama", "list"], 
                    capture_output=True, 
                    text=True, 
                    timeout=5
                )
                
                if result.returncode == 0 and result.stdout:
                    # Parse the output
                    lines = result.stdout.strip().split('\n')
                    # Skip header line if present
                    if lines and 'NAME' in lines[0]:
                        lines = lines[1:]
                    
                    models = []
                    for line in lines:
                        if line.strip():
                            # Extract model name (first column)
                            parts = line.split()
                            if parts:
                                models.append(parts[0])
                    
                    return {
                        "running": True,
                        "model_count": len(models),
                        "models": models,
                        "error": None
                    }
                else:
                    raise Exception(f"Command failed: {result.stderr}")
                    
            except Exception as e:
                return {
                    "running": False,
                    "model_count": 0,
                    "models": [],
                    "error": f"Connection failed: {str(e)}. Ollama error: {str(ollama_error)}"
                }
        
        return {
            "running": False,
            "model_count": 0,
            "models": [],
            "error": "Could not connect to Ollama"
        }
    
    @staticmethod
    def list_models() -> List[str]:
        """Get list of available models"""
        # Use get_status to ensure proper host detection
        status = OllamaManager.get_status()
        if not status["running"]:
            return []
        
        try:
            import ollama
            models = ollama.list()
            if models and 'models' in models:
                # Extract just the model names
                return [m['name'] for m in models['models']]
            return []
        except Exception:
            # Fallback to get_status method
            status = OllamaManager.get_status()
            if status["running"] and status["models"]:
                return status["models"]
            return []
    
    @staticmethod
    def pull_model(model_name: str) -> bool:
        """Pull a model from Ollama registry"""
        try:
            result = subprocess.run(
                ["ollama", "pull", model_name],
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes for large models
            )
            return result.returncode == 0
        except:
            return False

def get_available_models(default_models: List[str] = None) -> List[str]:
    """Get available Ollama models with fallback to defaults"""
    if default_models is None:
        default_models = ["deepseek-r1:latest", "deepseek-coder:6.7b", "deepseek-r1:1.5b"]
    
    try:
        # Try to get live models from Ollama
        live_models = OllamaManager.list_models()
        if live_models:
            return live_models
    except Exception:
        pass
    
    # Return defaults if Ollama is not available
    return default_models

def safe_ollama_generate(model: str, prompt: str, 
                        temperature: float = 0.7,
                        max_tokens: Optional[int] = None,
                        system: Optional[str] = None,
                        format: Optional[str] = None) -> Dict:
    """Safely call Ollama generate with error handling and retries"""
    # Ensure Ollama is properly configured with auto-detection
    _ = OllamaManager.get_status()
    
    try:
        import ollama
        
        # Build options
        options = {"temperature": temperature}
        if max_tokens:
            options["num_predict"] = max_tokens
            
        # Add system prompt if provided
        if system:
            full_prompt = f"{system}\n\n{prompt}"
        else:
            full_prompt = prompt
        
        # Build generation parameters
        gen_params = {
            "model": model,
            "prompt": full_prompt,
            "options": options
        }
        
        # Add format if specified
        if format:
            gen_params["format"] = format
            
        response = ollama.generate(**gen_params)
        
        return {
            "response": response.get("response", ""),
            "error": False,
            "model": model,
            "total_duration": response.get("total_duration"),
            "eval_count": response.get("eval_count")
        }
        
    except Exception as e:
        error_msg = str(e)
        
        # Provide helpful error messages
        if "model not found" in error_msg.lower():
            suggestion = f"Model '{model}' not found. Run: ollama pull {model}"
        elif "connection" in error_msg.lower():
            suggestion = "Ollama service not running. Start with: ollama serve"
        else:
            suggestion = "Check Ollama installation and try again"
            
        return {
            "response": f"Error: {error_msg}\n\nSuggestion: {suggestion}",
            "error": True,
            "model": model,
            "error_type": type(e).__name__
        }

class OllamaToolBase:
    """Base class for Ollama-powered tools with automatic logging"""
    
    def __init__(self, tool_name: str, default_model: str = "deepseek-coder:6.7b"):
        self.tool_name = tool_name
        self.default_model = default_model
        
        # Lazy import to avoid circular dependencies
        self._db = None
        
    @property
    def db(self):
        """Lazy load database manager"""
        if self._db is None:
            from .database import DatabaseManager
            self._db = DatabaseManager()
        return self._db
    
    def generate_with_logging(self, prompt: str, model: Optional[str] = None,
                            **kwargs) -> Dict:
        """Generate response and automatically log to knowledge base"""
        model = model or self.default_model
        
        # Generate response
        result = safe_ollama_generate(model, prompt, **kwargs)
        
        # Log if successful and database connected
        if not result["error"] and self.db.connected:
            self.db.log_query(
                tool=self.tool_name,
                model=model,
                prompt=prompt,
                response=result["response"],
                metadata={
                    "duration_ms": result.get("total_duration", 0) / 1_000_000,
                    "tokens": result.get("eval_count", 0)
                }
            )
            
        return result

# Ollama Connection Patch for utils/ollama.py
# This ensures proper error handling and connection detection

def get_status_fixed():
    """
    Fixed version of get_status with better error handling
    Add this method to OllamaManager class in utils/ollama.py
    """
    import os
    import requests
    
    # Get configured host
    ollama_host = os.getenv("TUOKIT_OLLAMA_HOST", "http://localhost:11434")
    
    # Simple HTTP test first
    try:
        response = requests.get(f"{ollama_host}/api/tags", timeout=3)
        if response.status_code == 200:
            data = response.json()
            models = data.get('models', [])
            return {
                "running": True,
                "model_count": len(models),
                "models": [m['name'] for m in models],
                "error": None
            }
    except Exception as e:
        pass
    
    # If localhost fails, try alternative hosts
    if "localhost" in ollama_host:
        alt_hosts = ["http://127.0.0.1:11434", "http://host.docker.internal:11434"]
        for host in alt_hosts:
            try:
                response = requests.get(f"{host}/api/tags", timeout=2)
                if response.status_code == 200:
                    # Update environment for this session
                    os.environ["OLLAMA_HOST"] = host
                    os.environ["TUOKIT_OLLAMA_HOST"] = host
                    
                    data = response.json()
                    models = data.get('models', [])
                    return {
                        "running": True,
                        "model_count": len(models),
                        "models": [m['name'] for m in models],
                        "error": None,
                        "note": f"Auto-detected at {host}"
                    }
            except:
                continue
    
    # All attempts failed
    return {
        "running": False,
        "model_count": 0,
        "models": [],
        "error": "Cannot connect to Ollama. Is it running?"
    }

#!/usr/bin/env python3
"""
Auto-fix Ollama detection issues in TuoKit
"""
import os
import shutil
from pathlib import Path

print("TuoKit Ollama Auto-Fix Script")
print("=" * 60)

# 1. Check current .env
env_path = Path(".env")
if env_path.exists():
    with open(env_path, 'r') as f:
        env_content = f.read()
    
    # Backup current .env
    shutil.copy(env_path, ".env.backup")
    print("[OK] Backed up .env to .env.backup")
    
    # Check if Ollama host is set correctly
    if "TUOKIT_OLLAMA_HOST" in env_content:
        current_host = None
        for line in env_content.split('\n'):
            if line.startswith("TUOKIT_OLLAMA_HOST"):
                current_host = line.split('=')[1].strip()
                break
        
        print(f"Current TUOKIT_OLLAMA_HOST: {current_host}")
        
        # Test if current host works
        import requests
        try:
            response = requests.get(f"{current_host}/api/tags", timeout=2)
            if response.status_code == 200:
                print("[OK] Current Ollama host is working!")
            else:
                print("[WARNING] Current host not responding properly")
        except:
            print("[ERROR] Cannot connect to current Ollama host")
            
            # Try to find working host
            print("\nSearching for working Ollama host...")
            working_host = None
            
            test_hosts = [
                "http://localhost:11434",
                "http://127.0.0.1:11434",
                "http://host.docker.internal:11434"
            ]
            
            for host in test_hosts:
                try:
                    response = requests.get(f"{host}/api/tags", timeout=2)
                    if response.status_code == 200:
                        print(f"[FOUND] Ollama working at: {host}")
                        working_host = host
                        break
                except:
                    continue
            
            if working_host and working_host != current_host:
                print(f"\nUpdating .env with working host: {working_host}")
                env_content = env_content.replace(
                    f"TUOKIT_OLLAMA_HOST={current_host}",
                    f"TUOKIT_OLLAMA_HOST={working_host}"
                )
                with open(env_path, 'w') as f:
                    f.write(env_content)
                print("[OK] Updated .env file")

# 2. Fix import issues in utils/__init__.py
print("\n2. Checking utils/__init__.py for import issues...")
utils_init = Path("utils/__init__.py")
if utils_init.exists():
    with open(utils_init, 'r') as f:
        init_content = f.read()
    
    # Check if it has conditional imports
    if "import streamlit" in init_content and "try:" not in init_content:
        print("[WARNING] Found direct streamlit import in utils/__init__.py")
        print("This can cause issues when streamlit is not installed.")
        print("Consider wrapping streamlit imports in try/except blocks.")

print("\n" + "=" * 60)
print("Auto-fix complete!")
print("\nNext steps:")
print("1. Run: start_tuokit_fixed.bat")
print("2. If issues persist, check:")
print("   - Is Ollama running? (ollama serve)")
print("   - Is Windows Firewall blocking port 11434?")
print("   - Try: ollama pull deepseek-r1:latest")

"""
Fix all emojis in navigation.py to use text markers
"""

# Read navigation.py
nav_path = "C:/Projects/Tuokit/utils/navigation.py"
with open(nav_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace emojis with text markers
replacements = {
    "🤖": "[BOT]",
    "💻": "[CODE]",
    "📚": "[BOOK]",
    "🗄️": "[DB]",
    "💎": "[GEM]",
    "🚂": "[TRAIN]",
    "🐭": "[MOUSE]",
    "⚙️": "[GEAR]",
    "💡": "[LIGHT]",
    "🔍": "[SEARCH]",
    "🐛": "[BUG]",
    "⚠️": "[WARN]",
    "🔤": "[ABC]",
    "🎨": "[ART]",
    "🖼️": "[PIC]",
    "📄": "[DOC]",
    "🎓": "[GRAD]",
    "📖": "[BOOK2]",
    "🧠": "[BRAIN]",
    "❓": "[HELP]",
    "🛢️": "[TANK]",
    "📊": "[CHART]",
    "🧮": "[CALC]",
    "🎯": "[TARGET]",
    "🥋": "[KATA]",
    "🔄": "[CYCLE]",
    "🏗️": "[BUILD]",
    "🎮": "[GAME]",
    "🔗": "[LINK]",
    "🐞": "[DEBUG]",
    "⬆️": "[UP]",
    "🧪": "[TEST]",
    "🔧": "[TOOL]",
    "🏛️": "[TEMPLE]",
    "🔨": "[HAMMER]",
    "🔮": "[CRYSTAL]",
    "📝": "[NOTE]",
    "🌊": "[WAVE]",
    "🚀": "[ROCKET]"
}

for emoji, replacement in replacements.items():
    content = content.replace(emoji, replacement)

# Write back
with open(nav_path, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed emoji issues in navigation.py")

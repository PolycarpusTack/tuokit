"""
TuoKit Main Application
Distributed architecture with local UI and remote services
"""
import streamlit as st
from pathlib import Path
import sys
import os

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

# Import utilities
from utils.ollama_client import test_ollama_setup, get_ollama_client
from utils.database_client import test_database_connection, TuoKitDB
from config.connection_config import config

# Import tools (these will be created/imported as needed)
# from tools.code_explainer import code_explainer_page
# from tools.document_qa import document_qa_page
# from tools.knowledge_search import knowledge_search_page

def check_connections():
    """Check and display connection status"""
    col1, col2, col3 = st.columns(3)
    
    with col1:
        with st.spinner("Checking Ollama..."):
            if test_ollama_setup():
                st.success("✅ Ollama Connected")
            else:
                st.error("❌ Ollama Offline")
                st.stop()
    
    with col2:
        with st.spinner("Checking Database..."):
            if test_database_connection():
                st.success("✅ Database Connected")
            else:
                st.error("❌ Database Offline")
                with st.expander("Setup Instructions"):
                    st.code("""
# First-time setup:
1. Run: streamlit run setup_local.py
2. Enter your server details
3. Test connections
4. Save configuration
                    """)
                st.stop()
    
    with col3:
        storage_path = Path(config.shared_storage_path)
        if storage_path.exists() or storage_path.parent.exists():
            st.success("✅ Storage Ready")
        else:
            st.warning("⚠️ Creating Storage")
            storage_path.mkdir(parents=True, exist_ok=True)

def initialize_session_state():
    """Initialize session state variables"""
    if 'initialized' not in st.session_state:
        st.session_state.initialized = True
        st.session_state.current_tool = "Home"
        st.session_state.session_id = os.urandom(8).hex()
        
        # Initialize database schema if needed
        try:
            db = TuoKitDB()
            db.initialize_schema()
        except Exception as e:
            st.error(f"Database initialization error: {str(e)}")

def main():
    """Main application entry point"""
    st.set_page_config(
        page_title="TuoKit - AI Developer Toolkit",
        page_icon="🔧",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize session
    initialize_session_state()
    
    # Sidebar navigation
    with st.sidebar:
        st.title("🔧 TuoKit")
        st.caption(f"Connected to: {config.ollama_host}")
        
        # Connection status in sidebar
        with st.expander("🔌 Connection Status", expanded=False):
            check_connections()
        
        st.divider()
        
        # Tool selection
        tool = st.radio(
            "Select Tool",
            ["🏠 Home", "💻 Code Explainer", "📄 Document Q&A", 
             "🔍 Knowledge Search", "⚙️ Settings"],
            key="tool_selector"
        )
        
        st.divider()
        
        # Quick stats
        try:
            db = TuoKitDB()
            stats = db.get_statistics()
            st.metric("Knowledge Entries", stats['total_entries'])
            st.metric("Active Tools", stats['unique_tools'])
        except:
            st.caption("Database stats unavailable")
    
    # Main content area
    if tool == "🏠 Home":
        show_home_page()
    elif tool == "💻 Code Explainer":
        show_code_explainer()
    elif tool == "📄 Document Q&A":
        show_document_qa()
    elif tool == "🔍 Knowledge Search":
        show_knowledge_search()
    elif tool == "⚙️ Settings":
        show_settings()

def show_home_page():
    """Display home page with overview"""
    st.title("Welcome to TuoKit")
    st.markdown("""
    ### 🚀 Your AI-Powered Developer Toolkit
    
    TuoKit connects your local development environment with powerful remote AI services:
    - **🤖 Remote Ollama Server**: Access powerful AI models without local GPU requirements
    - **🗄️ Shared PostgreSQL**: Build a team knowledge base that grows with usage
    - **💡 Smart Tools**: Purpose-built interfaces for common development tasks
    """)
    
    # Show current configuration
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📡 Current Configuration")
        st.json({
            "Ollama Server": config.ollama_host,
            "Database": f"{config.postgres_host}:{config.postgres_port}",
            "Storage": config.shared_storage_path
        })
    
    with col2:
        st.subheader("🎯 Available Models")
        try:
            client = get_ollama_client()
            models = client.list_models()
            for model in models:
                st.write(f"• {model['name']} ({model.get('size', 'N/A')})")
        except:
            st.warning("Could not fetch model list")
    
    # Quick start guide
    st.divider()
    st.subheader("🏃 Quick Start")
    st.markdown("""
    1. **Code Explainer**: Paste code and get AI-powered explanations
    2. **Document Q&A**: Upload documents and ask questions about them
    3. **Knowledge Search**: Search through your team's accumulated knowledge
    4. **Settings**: Configure models and preferences
    """)

def show_code_explainer():
    """Code explanation tool"""
    st.title("💻 Code Explainer")
    st.markdown("Paste code to get detailed explanations and documentation")
    
    # Language selection
    col1, col2 = st.columns([2, 1])
    with col1:
        language = st.selectbox(
            "Programming Language",
            ["Python", "JavaScript", "TypeScript", "Java", "C++", "Go", "Rust", "Other"]
        )
    
    with col2:
        model = st.selectbox(
            "AI Model",
            ["deepseek-r1", "codellama", "llama3.2"],
            index=0
        )
    
    # Code input
    code_input = st.text_area(
        "Paste your code here:",
        height=300,
        placeholder="def example_function():\n    # Your code here\n    pass"
    )
    
    # Analysis options
    col3, col4, col5 = st.columns(3)
    with col3:
        explain_code = st.checkbox("Explain Code", value=True)
    with col4:
        find_bugs = st.checkbox("Find Potential Bugs")
    with col5:
        suggest_improvements = st.checkbox("Suggest Improvements")
    
    if st.button("🔍 Analyze Code", type="primary"):
        if code_input.strip():
            analyze_code(code_input, language, model, 
                        explain_code, find_bugs, suggest_improvements)
        else:
            st.warning("Please paste some code to analyze")

def analyze_code(code: str, language: str, model: str, 
                explain: bool, bugs: bool, improvements: bool):
    """Analyze code with selected options"""
    from utils.ollama_client import query_ollama
    from utils.database_client import save_to_knowledge_base
    
    # Build prompt based on selected options
    prompt_parts = [f"Analyze this {language} code:\n\n```{language.lower()}\n{code}\n```\n"]
    
    if explain:
        prompt_parts.append("\n1. Explain what this code does in detail.")
    if bugs:
        prompt_parts.append("\n2. Identify any potential bugs or issues.")
    if improvements:
        prompt_parts.append("\n3. Suggest improvements for better performance or readability.")
    
    prompt = "\n".join(prompt_parts)
    
    # Get response
    with st.spinner(f"Analyzing with {model}..."):
        response = query_ollama(prompt, model=model)
    
    if response:
        st.subheader("📊 Analysis Results")
        st.markdown(response)
        
        # Save to knowledge base
        save_to_knowledge_base(
            tool="code_explainer",
            prompt=f"Analyze {language} code",
            response=response,
            model=model,
            context={"language": language, "code_length": len(code)}
        )
        
        st.success("✅ Analysis saved to knowledge base")

def show_document_qa():
    """Document Q&A tool placeholder"""
    st.title("📄 Document Q&A")
    st.info("Document Q&A functionality will be implemented here")
    # TODO: Implement document upload and Q&A

def show_knowledge_search():
    """Knowledge search tool"""
    st.title("🔍 Knowledge Search")
    
    from utils.database_client import TuoKitDB
    db = TuoKitDB()
    
    # Search interface
    search_query = st.text_input(
        "Search knowledge base:",
        placeholder="Enter keywords or questions..."
    )
    
    col1, col2 = st.columns([3, 1])
    with col1:
        tool_filter = st.selectbox(
            "Filter by tool:",
            ["All Tools"] + (db.get_statistics()['tools_list'] or [])
        )
    
    with col2:
        limit = st.number_input("Results limit:", min_value=5, max_value=50, value=10)
    
    if search_query:
        # Perform search
        results = db.search_knowledge(
            search_query, 
            tool_name=None if tool_filter == "All Tools" else tool_filter,
            limit=limit
        )
        
        if results:
            st.subheader(f"Found {len(results)} results")
            
            for result in results:
                with st.expander(f"{result['tool_name']} - {result['prompt'][:100]}..."):
                    st.write(f"**Tool:** {result['tool_name']}")
                    st.write(f"**Prompt:** {result['prompt']}")
                    st.write(f"**Response:** {result['response']}")
                    st.write(f"**Model:** {result['model_used']}")
                    st.write(f"**Date:** {result['created_at']}")
                    
                    if result['tags']:
                        st.write(f"**Tags:** {', '.join(result['tags'])}")
        else:
            st.info("No results found. Try different keywords.")
    else:
        # Show recent entries
        st.subheader("Recent Knowledge Entries")
        recent = db.get_recent_entries(limit=10)
        
        for entry in recent:
            with st.expander(f"{entry['tool_name']} - {entry['created_at'].strftime('%Y-%m-%d')}"):
                st.write(f"**Prompt:** {entry['prompt']}")
                st.write(f"**Response:** {entry['response'][:500]}...")

def show_settings():
    """Settings page"""
    st.title("⚙️ Settings")
    
    tab1, tab2, tab3 = st.tabs(["Connection Info", "Model Settings", "Database Management"])
    
    with tab1:
        st.subheader("Current Connections")
        st.json({
            "Ollama Host": config.ollama_host,
            "PostgreSQL Host": config.postgres_host,
            "PostgreSQL Port": config.postgres_port,
            "Database Name": config.postgres_db,
            "Storage Path": config.shared_storage_path,
            "SSL Enabled": config.enable_ssl
        })
        
        if st.button("🔄 Re-run Setup Wizard"):
            st.info("Run `streamlit run setup_local.py` in terminal")
    
    with tab2:
        st.subheader("Model Management")
        
        client = get_ollama_client()
        
        # List current models
        try:
            models = client.list_models()
            st.write("**Installed Models:**")
            for model in models:
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(f"• {model['name']}")
                with col2:
                    st.caption(model.get('size', 'N/A'))
        except:
            st.error("Could not fetch model list")
        
        # Pull new model
        st.divider()
        new_model = st.text_input("Pull new model:", placeholder="mistral:latest")
        if st.button("📥 Pull Model"):
            if new_model:
                client.pull_model(new_model)
    
    with tab3:
        st.subheader("Database Statistics")
        
        try:
            db = TuoKitDB()
            stats = db.get_statistics()
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Entries", stats['total_entries'])
            with col2:
                st.metric("Unique Tools", stats['unique_tools'])
            with col3:
                st.metric("Active Days", stats['active_days'])
            
            if st.button("🗑️ Clear Old Entries", type="secondary"):
                st.warning("This feature is not yet implemented")
                # TODO: Implement cleanup functionality
        except Exception as e:
            st.error(f"Database error: {str(e)}")

if __name__ == "__main__":
    main()

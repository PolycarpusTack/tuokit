"""
TuoKit Modern UI - Streamlit Implementation
Comprehensive interface with all 45+ tools properly organized
"""
import streamlit as st
import sqlite3
import subprocess
import json
import os
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
from typing import Dict, List, Optional, Tuple
import plotly.express as px
import plotly.graph_objects as go
import psutil
from utils import get_available_models, OllamaManager

# === PAGE CONFIGURATION ===
st.set_page_config(
    page_title="TuoKit AI Studio",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'About': "TuoKit AI Studio - Your Comprehensive Local AI Development Assistant",
        'Report a bug': "https://github.com/yourusername/tuokit/issues"
    }
)

# === CUSTOM CSS FOR MODERN UI ===
st.markdown("""
<style>
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    /* Global styles */
    .stApp {
        font-family: 'Inter', sans-serif;
    }
    
    /* Sidebar styling */
    section[data-testid="stSidebar"] {
        background-color: #ffffff;
        border-right: 1px solid #e5e7eb;
    }
    
    section[data-testid="stSidebar"] > div {
        padding-top: 1rem;
    }
    
    /* Tool card styling */
    .tool-card {
        background: white;
        border-radius: 8px;
        padding: 1.5rem;
        border: 1px solid #e5e7eb;
        transition: all 0.3s ease;
        height: 100%;
        cursor: pointer;
    }
    
    .tool-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        border-color: #3b82f6;
    }
    
    /* Metric card styling */
    .metric-card {
        background: #f9fafb;
        padding: 1.5rem;
        border-radius: 8px;
        text-align: center;
        border: 1px solid #e9ecef;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: #1e40af;
        margin: 0.5rem 0;
    }
    
    .metric-label {
        color: #6b7280;
        font-size: 0.875rem;
        font-weight: 500;
    }
    
    /* Activity item styling */
    .activity-item {
        padding: 1rem;
        border-left: 3px solid #3b82f6;
        margin-bottom: 0.75rem;
        background: #f8f9fa;
        border-radius: 0 4px 4px 0;
    }
    
    /* Category header */
    .category-header {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 1rem;
    }
    
    .category-icon {
        font-size: 2rem;
    }
    
    /* Search bar */
    .search-container {
        position: relative;
        margin-bottom: 2rem;
    }
    
    /* Button styling */
    .stButton > button {
        transition: all 0.3s ease;
        font-weight: 500;
    }
    
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 3rem;
        padding: 0 1.5rem;
        background-color: #f3f4f6;
        border-radius: 8px 8px 0 0;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: #3b82f6;
        color: white;
    }
    
    /* Pro tip styling */
    .pro-tip {
        background: #fef3c7;
        border-left: 4px solid #f59e0b;
        padding: 0.75rem 1rem;
        margin: 0.5rem 0;
        border-radius: 0 4px 4px 0;
        font-size: 0.875rem;
    }
    
    /* Dark mode support */
    @media (prefers-color-scheme: dark) {
        section[data-testid="stSidebar"] {
            background-color: #1f2937;
            border-right-color: #374151;
        }
        
        .tool-card {
            background: #1f2937;
            border-color: #374151;
            color: #f9fafb;
        }
        
        .metric-card {
            background: #1f2937;
            border-color: #374151;
        }
        
        .activity-item {
            background: #1f2937;
            border-left-color: #3b82f6;
        }
    }
</style>
""", unsafe_allow_html=True)

# === CONSTANTS ===
DB_PATH = "tuokit.db"
# Get available models dynamically
OLLAMA_MODELS = get_available_models(["deepseek-r1:1.5b", "deepseek-coder:6.7b", "llama3.2:latest"])

# Import complete tool registry with all 45+ tools
from utils.tool_registry import COMPLETE_TOOL_REGISTRY as TOOL_REGISTRY, get_tool_count, search_tools
# === DATABASE INITIALIZATION ===
def init_database():
    """Initialize SQLite database with enhanced schema"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Enhanced knowledge table
    c.execute('''CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        tool TEXT NOT NULL,
        model TEXT NOT NULL,
        prompt TEXT NOT NULL,
        response TEXT NOT NULL,
        context TEXT,
        rating INTEGER DEFAULT 0,
        tags TEXT,
        category TEXT
    )''')
    
    # User preferences
    c.execute('''CREATE TABLE IF NOT EXISTS user_preferences (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Tool usage tracking
    c.execute('''CREATE TABLE IF NOT EXISTS tool_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tool_id TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')
    
    conn.commit()
    conn.close()

# === HELPER FUNCTIONS ===
def get_system_status():
    """Get system health metrics"""
    try:
        # Use OllamaManager for better status checking
        ollama_status_info = OllamaManager.get_status()
        ollama_status = "🟢 Online" if ollama_status_info["running"] else "🔴 Offline"
        model_count = ollama_status_info["model_count"]
        
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        
        return {
            "ollama": ollama_status,
            "cpu": f"{cpu_percent}%",
            "memory": f"{memory.percent}%",
            "models": model_count
        }
    except:
        return {
            "ollama": "🟡 Unknown",
            "cpu": "N/A",
            "memory": "N/A",
            "models": 0
        }
def get_metrics():
    """Get dashboard metrics"""
    conn = sqlite3.connect(DB_PATH)
    
    # Total queries
    total = conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
    
    # Today's queries
    today = conn.execute("""
        SELECT COUNT(*) FROM knowledge 
        WHERE DATE(timestamp) = DATE('now', 'localtime')
    """).fetchone()[0]
    
    # 7-day average
    week_avg = conn.execute("""
        SELECT AVG(daily_count) FROM (
            SELECT DATE(timestamp) as date, COUNT(*) as daily_count 
            FROM knowledge 
            WHERE timestamp >= datetime('now', '-7 days', 'localtime')
            GROUP BY DATE(timestamp)
        )
    """).fetchone()[0] or 0
    
    # Tool count
    tool_count = get_tool_count()
    
    conn.close()
    
    return {
        "total": total,
        "today": today,
        "week_avg": round(week_avg, 1),
        "tools": tool_count
    }

def get_recent_activity(limit=5):
    """Get recent activity with formatted time"""
    conn = sqlite3.connect(DB_PATH)
    
    activities = conn.execute("""
        SELECT tool, prompt, timestamp,
        CASE 
            WHEN (julianday('now') - julianday(timestamp)) * 24 < 1 
            THEN CAST(ROUND((julianday('now') - julianday(timestamp)) * 24 * 60) AS INTEGER) || 'm ago'
            WHEN (julianday('now') - julianday(timestamp)) < 1 
            THEN CAST(ROUND((julianday('now') - julianday(timestamp)) * 24) AS INTEGER) || 'h ago'
            WHEN (julianday('now') - julianday(timestamp)) < 7
            THEN CAST(ROUND(julianday('now') - julianday(timestamp)) AS INTEGER) || 'd ago'
            ELSE 'Last week'
        END as time_ago
        FROM knowledge 
        ORDER BY timestamp DESC 
        LIMIT ?
    """, (limit,)).fetchall()
    
    conn.close()
    return activities

def get_tool_usage_stats():
    """Get tool usage statistics for visualization"""
    conn = sqlite3.connect(DB_PATH)
    
    stats = conn.execute("""
        SELECT tool, COUNT(*) as count
        FROM knowledge
        GROUP BY tool
        ORDER BY count DESC
        LIMIT 5
    """).fetchall()
    
    conn.close()
    return stats

def track_tool_usage(tool_id):
    """Track when a tool is used"""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO tool_usage (tool_id) VALUES (?)", (tool_id,))
    conn.commit()
    conn.close()

def get_daily_usage_chart():
    """Get data for daily usage chart"""
    conn = sqlite3.connect(DB_PATH)
    
    df = pd.read_sql_query("""
        SELECT DATE(timestamp) as date, COUNT(*) as queries
        FROM knowledge
        WHERE timestamp >= datetime('now', '-30 days', 'localtime')
        GROUP BY DATE(timestamp)
        ORDER BY date
    """, conn)
    
    conn.close()
    
    if not df.empty:
        # Create line chart
        fig = px.line(df, x='date', y='queries', 
                      title='Daily Query Volume (Last 30 Days)',
                      labels={'queries': 'Queries', 'date': 'Date'})
        fig.update_traces(mode='lines+markers', line_color='#3b82f6', line_width=2)
        fig.update_layout(
            hovermode='x unified',
            height=300,
            margin=dict(l=0, r=0, t=30, b=0),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        fig.update_xaxis(showgrid=True, gridwidth=1, gridcolor='#e5e7eb')
        fig.update_yaxis(showgrid=True, gridwidth=1, gridcolor='#e5e7eb')
        return fig
    return None

def get_tool_distribution_chart():
    """Get tool usage distribution chart"""
    stats = get_tool_usage_stats()
    
    if stats:
        df = pd.DataFrame(stats, columns=['tool', 'count'])
        
        # Create donut chart
        fig = px.pie(df, values='count', names='tool', hole=0.4)
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(
            showlegend=False,
            height=300,
            margin=dict(l=0, r=0, t=0, b=0),
            plot_bgcolor='rgba(0,0,0,0)',
            paper_bgcolor='rgba(0,0,0,0)',
        )
        return fig
    return None
# === MAIN APPLICATION ===
def main():
    # Initialize
    init_database()
    
    # Initialize session state
    if 'current_view' not in st.session_state:
        st.session_state.current_view = 'dashboard'
    if 'selected_model' not in st.session_state:
        st.session_state.selected_model = OLLAMA_MODELS[0] if OLLAMA_MODELS else "deepseek-r1:1.5b"
    
    # Sidebar
    with st.sidebar:
        # Logo and title
        st.markdown("""
        <div style="text-align: center; padding: 1rem 0;">
            <h1 style="font-size: 1.5rem; margin: 0;">🤖 TuoKit AI Studio</h1>
            <p style="color: #6b7280; font-size: 0.875rem; margin: 0.5rem 0 0 0;">Your Local AI Assistant</p>
            <p style="color: #9ca3af; font-size: 0.75rem; margin: 0.25rem 0 0 0;">{} Tools Available</p>
        </div>
        """.format(get_tool_count()), unsafe_allow_html=True)
        
        st.divider()
        
        # Navigation
        nav_items = {
            'dashboard': {'label': '🏠 Dashboard', 'desc': 'Overview and quick access'},
            'tools': {'label': '🛠️ Tools Hub', 'desc': 'All AI tools'},
            'analytics': {'label': '📊 Analytics', 'desc': 'Usage insights'},
            'settings': {'label': '⚙️ Settings', 'desc': 'Preferences'}
        }
        
        for key, item in nav_items.items():
            if st.button(
                item['label'],
                key=f"nav_{key}",
                use_container_width=True,
                type="primary" if st.session_state.current_view == key else "secondary",
                help=item['desc']
            ):
                st.session_state.current_view = key
                st.rerun()
        
        st.divider()
        
        # Quick tool search
        st.markdown("### 🔍 Quick Search")
        quick_search = st.text_input(
            "Find a tool...",
            placeholder="Type to search",
            label_visibility="collapsed"
        )
        
        if quick_search:
            results = search_tools(quick_search)
            if results:
                st.markdown("**Results:**")
                for tool in results[:3]:
                    if st.button(
                        f"{tool['icon']} {tool['name']}",
                        key=f"quick_{tool['id']}",
                        use_container_width=True
                    ):
                        track_tool_usage(tool['id'])
                        if 'tab' in tool:
                            st.session_state.active_tab = tool['tab']
                        st.switch_page(tool['page'])
        
        st.divider()
        
        # Model selection
        st.markdown("### 🤖 AI Model")
        # Get fresh models if refresh button clicked
        if 'refresh_models' not in st.session_state:
            st.session_state.available_models = OLLAMA_MODELS
        
        col1, col2 = st.columns([3, 1])
        with col1:
            st.session_state.selected_model = st.selectbox(
                "Active Model",
                st.session_state.available_models,
                label_visibility="collapsed",
                help="Models currently available in Ollama"
            )
        with col2:
            if st.button("🔄", key="refresh_models_sidebar", help="Refresh model list"):
                st.session_state.available_models = get_available_models(["deepseek-r1:1.5b", "deepseek-coder:6.7b", "llama3.2:latest"])
                st.rerun()
        
        # System status
        status = get_system_status()
        st.markdown(f"""
        <div style="padding: 1rem; background: #f3f4f6; border-radius: 8px; margin-top: 1rem;">
            <p style="margin: 0; font-size: 0.875rem;">
                <strong>Ollama:</strong> {status['ollama']}<br>
                <strong>CPU:</strong> {status['cpu']} | <strong>RAM:</strong> {status['memory']}<br>
                <strong>Models:</strong> {status['models']} available
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        st.divider()
        
        # Quick actions
        col1, col2 = st.columns(2)
        with col1:
            if st.button("🔄 Refresh", use_container_width=True):
                st.rerun()
        with col2:
            if st.button("📥 Export", use_container_width=True):
                export_knowledge()
    
    # Main content
    if st.session_state.current_view == 'dashboard':
        show_dashboard()
    elif st.session_state.current_view == 'tools':
        show_tools_hub()
    elif st.session_state.current_view == 'analytics':
        show_analytics()
    elif st.session_state.current_view == 'settings':
        show_settings()
def show_dashboard():
    """Modern dashboard with all the bells and whistles"""
    # Header
    col1, col2 = st.columns([3, 1])
    with col1:
        st.title("Welcome to TuoKit AI Studio")
        status = get_system_status()
        st.caption(f"Your local AI assistant • {status['ollama']} • {status['models']} models • {get_tool_count()} tools")
    with col2:
        st.markdown("<div style='height: 2rem'></div>", unsafe_allow_html=True)
        if st.button("🚀 Quick Start Guide"):
            st.switch_page("pages/onboarding_wizard.py")
    
    # Metrics row
    metrics = get_metrics()
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <p class="metric-label">Total Queries</p>
            <p class="metric-value">{metrics['total']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <p class="metric-label">Today</p>
            <p class="metric-value">{metrics['today']}</p>
            <p style="color: #10b981; font-size: 0.875rem; margin: 0;">+{metrics['today']} ↑</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <p class="metric-label">Daily Avg (7d)</p>
            <p class="metric-value">{metrics['week_avg']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <p class="metric-label">Tools Available</p>
            <p class="metric-value">{metrics['tools']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Main content area
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Recent activity
        st.markdown("### 🕐 Recent Activity")
        activities = get_recent_activity(5)
        
        if activities:
            for tool, prompt, timestamp, time_ago in activities:
                # Find tool icon from registry
                tool_icon = "🔧"
                for cat in TOOL_REGISTRY.values():
                    for t in cat['tools']:
                        if t['id'] == tool:
                            tool_icon = t['icon']
                            break
                
                st.markdown(f"""
                <div class="activity-item">
                    <div style="display: flex; justify-content: space-between; align-items: start;">
                        <div>
                            <strong>{tool_icon} {tool.replace('_', ' ').title()}</strong>
                            <p style="margin: 0.25rem 0 0 0; color: #6b7280; font-size: 0.875rem;">
                                {prompt[:60]}{'...' if len(prompt) > 60 else ''}
                            </p>
                        </div>
                        <span style="color: #9ca3af; font-size: 0.75rem;">{time_ago}</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("No recent activity. Start using the tools to see your history here!")
        
        # Quick access to popular tools
        st.markdown("### 🚀 Popular Tools")
        popular_tools = [
            ("code_assistant", "Code Assistant", "💡", "pages/code_tools.py"),
            ("document_qa", "Document Q&A", "📄", "pages/doc_tools.py"),
            ("sql_generator", "SQL Generator", "✨", "pages/sql_generator.py"),
            ("error_decoder", "Error Decoder", "🔍", "pages/error_tool.py"),
            ("ruby_profiler", "Ruby Profiler", "📈", "pages/ruby_profiler.py"),
            ("smalltalk_explain", "SmallTalk Explainer", "💡", "pages/smalltalk_explainer.py")
        ]
        
        cols = st.columns(3)
        for idx, (tool_id, name, icon, page) in enumerate(popular_tools):
            with cols[idx % 3]:
                if st.button(f"{icon} {name}", key=f"pop_{tool_id}", use_container_width=True):
                    track_tool_usage(tool_id)
                    st.switch_page(page)
        
        # Daily usage chart
        st.markdown("### 📈 Usage Trend")
        chart = get_daily_usage_chart()
        if chart:
            st.plotly_chart(chart, use_container_width=True, config={'displayModeBar': False})
        else:
            st.info("Usage chart will appear after your first query")
    
    with col2:
        # Category overview
        st.markdown("### 📂 Tool Categories")
        for category_name, category_info in TOOL_REGISTRY.items():
            tool_count = len(category_info['tools'])
            st.markdown(f"""
            <div style="padding: 0.5rem 1rem; background: #f3f4f6; border-radius: 8px; margin-bottom: 0.5rem;">
                <strong>{category_info['icon']} {category_name}</strong>
                <p style="margin: 0; color: #6b7280; font-size: 0.75rem;">{tool_count} tools</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Pro tips
        st.markdown("### 💡 Pro Tips")
        tips = [
            "Upload PDFs for instant Q&A",
            "Try different models for varied results",
            "Use Ruby tools for Rails development",
            "SmallTalk tools support Pharo/Squeak",
            "SQL Suite includes optimization",
            "Agent Hub for automation"
        ]
        
        for tip in tips[:3]:
            st.markdown(f'<div class="pro-tip">💡 {tip}</div>', unsafe_allow_html=True)
        
        # Tool usage distribution
        st.markdown("### 📊 Tool Usage")
        chart = get_tool_distribution_chart()
        if chart:
            st.plotly_chart(chart, use_container_width=True, config={'displayModeBar': False})
        else:
            st.info("Tool usage stats will appear here")
def show_tools_hub():
    """Tools hub with all categories and search"""
    st.title("🛠️ Tools Hub")
    st.caption(f"Explore all {get_tool_count()} AI tools organized by category")
    
    # Search bar
    search_query = st.text_input(
        "🔍 Search tools...",
        placeholder="Try 'code', 'sql', 'ruby', 'smalltalk', 'document'...",
        label_visibility="collapsed"
    )
    
    # Display tool count stats
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Tools", get_tool_count())
    with col2:
        st.metric("Categories", len(TOOL_REGISTRY))
    with col3:
        code_tools = sum(1 for cat in TOOL_REGISTRY.values() 
                        for tool in cat['tools'] 
                        if 'code' in tool['id'].lower() or 'ruby' in tool['id'].lower())
        st.metric("Code Tools", code_tools)
    with col4:
        sql_tools = sum(1 for cat in TOOL_REGISTRY.values() 
                       for tool in cat['tools'] 
                       if 'sql' in tool['id'].lower())
        st.metric("SQL Tools", sql_tools)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Display categories and tools
    for category_name, category_info in TOOL_REGISTRY.items():
        # Filter tools by search
        filtered_tools = [
            tool for tool in category_info['tools']
            if not search_query or 
            search_query.lower() in tool['name'].lower() or
            search_query.lower() in tool['desc'].lower() or
            search_query.lower() in tool['id'].lower() or
            search_query.lower() in category_name.lower()
        ]
        
        if not filtered_tools and search_query:
            continue
        
        # Category header with tool count
        st.markdown(f"""
        <div class="category-header">
            <span class="category-icon">{category_info['icon']}</span>
            <div>
                <h3 style="margin: 0;">{category_name} ({len(filtered_tools)} tools)</h3>
                <p style="margin: 0; color: #6b7280; font-size: 0.875rem;">{category_info['description']}</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Tool cards - dynamic columns based on number of tools
        num_cols = min(3, len(filtered_tools))  # Max 3 columns
        if num_cols > 0:
            cols = st.columns(num_cols)
            for idx, tool in enumerate(filtered_tools):
                with cols[idx % num_cols]:
                    st.markdown(f"""
                    <div class="tool-card">
                        <div style="text-align: center;">
                            <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">{tool['icon']}</div>
                            <h4 style="margin: 0 0 0.5rem 0;">{tool['name']}</h4>
                            <p style="color: #6b7280; font-size: 0.875rem; margin: 0 0 1rem 0;">
                                {tool['desc']}
                            </p>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if st.button("Launch", key=f"launch_{tool['id']}", use_container_width=True):
                        track_tool_usage(tool['id'])
                        
                        # Navigate to the appropriate page/tab
                        if 'tab' in tool:
                            st.session_state.active_tab = tool['tab']
                        st.switch_page(tool['page'])
        
        st.markdown("<br>", unsafe_allow_html=True)
    
    # Show message if no results
    if search_query and not any(
        any(search_query.lower() in tool['name'].lower() or 
            search_query.lower() in tool['desc'].lower() or
            search_query.lower() in tool['id'].lower()
            for tool in cat['tools'])
        for cat in TOOL_REGISTRY.values()
    ):
        st.warning(f"No tools found matching '{search_query}'. Try a different search term.")

def show_analytics():
    """Analytics dashboard"""
    st.title("📊 Analytics Dashboard")
    st.caption("Track your AI usage and performance")
    
    # Date range selector
    col1, col2 = st.columns([3, 1])
    with col1:
        date_range = st.date_input(
            "Select date range",
            value=(datetime.now() - timedelta(days=30), datetime.now()),
            max_value=datetime.now()
        )
    
    # Get analytics data
    conn = sqlite3.connect(DB_PATH)
    
    # Summary metrics
    st.markdown("### 📈 Summary Metrics")
    col1, col2, col3, col4 = st.columns(4)
    
    total_queries = conn.execute("""
        SELECT COUNT(*) FROM knowledge
        WHERE DATE(timestamp) BETWEEN ? AND ?
    """, date_range).fetchone()[0]
    
    unique_tools = conn.execute("""
        SELECT COUNT(DISTINCT tool) FROM knowledge
        WHERE DATE(timestamp) BETWEEN ? AND ?
    """, date_range).fetchone()[0]
    
    avg_daily = total_queries / max(1, (date_range[1] - date_range[0]).days)
    
    most_used = conn.execute("""
        SELECT tool, COUNT(*) as count
        FROM knowledge
        WHERE DATE(timestamp) BETWEEN ? AND ?
        GROUP BY tool
        ORDER BY count DESC
        LIMIT 1
    """, date_range).fetchone()
    
    with col1:
        st.metric("Total Queries", total_queries)
    with col2:
        st.metric("Unique Tools Used", unique_tools)
    with col3:
        st.metric("Daily Average", f"{avg_daily:.1f}")
    with col4:
        st.metric("Most Used Tool", most_used[0] if most_used else "N/A")
    
    # Daily usage chart
    st.markdown("### 📈 Daily Query Volume")
    daily_df = pd.read_sql_query("""
        SELECT DATE(timestamp) as date, COUNT(*) as queries
        FROM knowledge
        WHERE DATE(timestamp) BETWEEN ? AND ?
        GROUP BY DATE(timestamp)
        ORDER BY date
    """, conn, params=date_range)
    
    if not daily_df.empty:
        fig = px.line(daily_df, x='date', y='queries', markers=True)
        fig.update_traces(line_color='#3b82f6', line_width=3)
        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No data for selected date range")
    
    # Tool distribution and model performance
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 🎯 Tool Usage Distribution")
        tool_df = pd.read_sql_query("""
            SELECT tool, COUNT(*) as count
            FROM knowledge
            WHERE DATE(timestamp) BETWEEN ? AND ?
            GROUP BY tool
            ORDER BY count DESC
            LIMIT 10
        """, conn, params=date_range)
        
        if not tool_df.empty:
            fig = px.pie(tool_df, values='count', names='tool', hole=0.4)
            st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.markdown("### 🤖 Model Performance")
        model_df = pd.read_sql_query("""
            SELECT model, COUNT(*) as queries, AVG(rating) as avg_rating
            FROM knowledge
            WHERE DATE(timestamp) BETWEEN ? AND ?
            GROUP BY model
        """, conn, params=date_range)
        
        if not model_df.empty:
            fig = px.bar(model_df, x='model', y='queries', color='avg_rating',
                         color_continuous_scale='RdYlGn')
            st.plotly_chart(fig, use_container_width=True)
    
    conn.close()
    
    # Insights
    st.markdown("### 🎯 Insights & Recommendations")
    insights = generate_insights(daily_df, tool_df)
    
    for insight in insights:
        st.info(f"💡 {insight}")
def show_settings():
    """Settings page"""
    st.title("⚙️ Settings")
    
    tabs = st.tabs(["General", "Models", "Database", "Export/Import", "About"])
    
    with tabs[0]:  # General
        st.markdown("### General Settings")
        
        # Theme (mockup - Streamlit doesn't have built-in theme switching)
        theme = st.selectbox("Theme Preference", ["System", "Light", "Dark"])
        
        # Notifications
        notifications = st.checkbox("Enable success notifications", value=True)
        tooltips = st.checkbox("Show tooltips", value=True)
        shortcuts = st.checkbox("Enable keyboard shortcuts", value=True)
        
        # Default landing
        landing = st.selectbox(
            "Default landing page",
            ["Dashboard", "Tools Hub", "Last Used Tool"]
        )
        
        if st.button("Save Preferences", type="primary"):
            save_preferences({
                "theme": theme,
                "notifications": notifications,
                "tooltips": tooltips,
                "shortcuts": shortcuts,
                "landing": landing
            })
            st.success("✅ Preferences saved!")
    
    with tabs[1]:  # Models
        st.markdown("### Model Configuration")
        
        # Available models - refresh button
        col1, col2 = st.columns([3, 1])
        with col1:
            st.markdown("#### Available Models")
        with col2:
            if st.button("🔄 Refresh", help="Refresh model list"):
                # Refresh the models list
                st.session_state.ollama_models = get_available_models(["deepseek-r1:1.5b", "deepseek-coder:6.7b", "llama3.2:latest"])
                st.rerun()
        
        # Get fresh model list if not in session state
        if 'ollama_models' not in st.session_state:
            st.session_state.ollama_models = OLLAMA_MODELS
            
        for model in st.session_state.ollama_models:
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.text(model)
            with col2:
                if st.button("Test", key=f"test_{model}"):
                    test_model(model)
            with col3:
                if st.button("Info", key=f"info_{model}"):
                    show_model_info(model)
        
        # Add model
        st.markdown("#### Add New Model")
        new_model = st.text_input("Model name (e.g., 'llama2:7b')")
        if st.button("Add Model"):
            add_model(new_model)
    
    with tabs[2]:  # Database
        st.markdown("### Database Management")
        
        # Database stats
        db_size = os.path.getsize(DB_PATH) / 1024 / 1024  # MB
        st.metric("Database Size", f"{db_size:.2f} MB")
        
        # Maintenance
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button("Optimize Database", use_container_width=True):
                optimize_database()
        with col2:
            if st.button("Backup Database", use_container_width=True):
                backup_database()
        with col3:
            if st.button("Clear Old Data", use_container_width=True):
                if st.checkbox("Confirm deletion"):
                    clear_old_data()
    
    with tabs[3]:  # Export/Import
        st.markdown("### Export/Import")
        
        # Export
        st.markdown("#### Export Knowledge")
        export_format = st.selectbox("Export Format", ["JSON", "CSV", "Markdown"])
        
        if st.button("Export Knowledge Base", type="primary"):
            export_knowledge(export_format)
        
        # Import
        st.markdown("#### Import Knowledge")
        uploaded = st.file_uploader("Choose file to import", type=['json', 'csv'])
        
        if uploaded and st.button("Import"):
            import_knowledge(uploaded)
    
    with tabs[4]:  # About
        st.markdown("### About TuoKit")
        st.info(f"""
        **TuoKit AI Studio**
        Version: 2.0.0
        Tools: {get_tool_count()}
        
        **Categories:**
        - 🧠 Code Intelligence
        - 🗄️ Data & SQL
        - 💎 Ruby & Rails
        - 🦆 SmallTalk Tools
        - 🤖 Agent Systems
        - 🎨 UI & Components
        - 📚 Learning & Documents
        - 💾 Knowledge & Help
        
        **Philosophy:** Build fast, build smart, build exactly what's needed
        """)

# === UTILITY FUNCTIONS ===
def generate_insights(daily_df, tool_df):
    """Generate intelligent insights"""
    insights = []
    
    if not daily_df.empty:
        avg_daily = daily_df['queries'].mean()
        if avg_daily > 10:
            insights.append(f"You're a power user! Averaging {avg_daily:.0f} queries per day.")
        elif avg_daily < 3:
            insights.append("Try exploring more tools to get the most from TuoKit.")
    
    if not tool_df.empty:
        top_tool = tool_df.iloc[0]['tool']
        insights.append(f"Your most used tool is {top_tool.replace('_', ' ').title()} - consider exploring related tools.")
        
        if len(tool_df) < 5:
            insights.append("You've only used a few tools so far. Check out the Tools Hub for more!")
    
    # Add category-specific insights
    if not tool_df.empty:
        ruby_usage = sum(row['count'] for _, row in tool_df.iterrows() if 'ruby' in row['tool'].lower() or 'rails' in row['tool'].lower())
        if ruby_usage > 0:
            insights.append(f"Ruby/Rails developer detected! Try our {sum(1 for t in TOOL_REGISTRY['💎 Ruby & Rails']['tools'])} specialized Ruby tools.")
    
    return insights

def save_preferences(prefs):
    """Save user preferences"""
    conn = sqlite3.connect(DB_PATH)
    for key, value in prefs.items():
        conn.execute("""
            INSERT OR REPLACE INTO user_preferences (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        """, (key, json.dumps(value)))
    conn.commit()
    conn.close()

def test_model(model):
    """Test a model"""
    with st.spinner(f"Testing {model}..."):
        try:
            result = subprocess.run(
                ["ollama", "run", model, "Say hello"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                st.success(f"✅ {model} is working!")
            else:
                st.error(f"❌ {model} failed: {result.stderr}")
        except Exception as e:
            st.error(f"❌ Error testing {model}: {str(e)}")

def show_model_info(model):
    """Show model information"""
    st.info(f"""
    **Model:** {model}
    - Good for: {'Coding' if 'coder' in model else 'General tasks'}
    - Size: {'Small (1.5B)' if '1.5b' in model else 'Medium (6.7B)' if '6.7b' in model else 'Large'}
    - Speed: {'Fast' if '1.5b' in model else 'Moderate' if '6.7b' in model else 'Slower'}
    """)

def export_knowledge(format="JSON"):
    """Export knowledge base"""
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query("SELECT * FROM knowledge ORDER BY timestamp DESC", conn)
    conn.close()
    
    if df.empty:
        st.warning("No knowledge to export")
        return
    
    if format == "JSON":
        data = df.to_json(orient='records', date_format='iso')
        st.download_button(
            "Download JSON",
            data,
            file_name=f"tuokit_export_{datetime.now().strftime('%Y%m%d')}.json",
            mime="application/json"
        )
    elif format == "CSV":
        csv = df.to_csv(index=False)
        st.download_button(
            "Download CSV",
            csv,
            file_name=f"tuokit_export_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )
    elif format == "Markdown":
        # Convert to markdown
        md = "# TuoKit Knowledge Export\n\n"
        for _, row in df.iterrows():
            md += f"## {row['tool']} - {row['timestamp']}\n"
            md += f"**Prompt:** {row['prompt']}\n\n"
            md += f"**Response:** {row['response']}\n\n"
            md += "---\n\n"
        
        st.download_button(
            "Download Markdown",
            md,
            file_name=f"tuokit_export_{datetime.now().strftime('%Y%m%d')}.md",
            mime="text/markdown"
        )

def import_knowledge(file):
    """Import knowledge from file"""
    # Implementation depends on file format
    st.success("Import functionality coming soon!")

def optimize_database():
    """Optimize the database"""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("VACUUM")
    conn.close()
    st.success("✅ Database optimized!")

def backup_database():
    """Create database backup"""
    import shutil
    backup_path = f"tuokit_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    shutil.copy2(DB_PATH, backup_path)
    st.success(f"✅ Database backed up to {backup_path}")

def clear_old_data():
    """Clear data older than 90 days"""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        DELETE FROM knowledge 
        WHERE timestamp < datetime('now', '-90 days')
    """)
    deleted = conn.total_changes
    conn.commit()
    conn.close()
    st.success(f"✅ Deleted {deleted} old records")

def add_model(model_name):
    """Add a new model (mockup)"""
    if model_name:
        st.info(f"To add {model_name}, run: `ollama pull {model_name}`")

# === MAIN EXECUTION ===
if __name__ == "__main__":
    main()

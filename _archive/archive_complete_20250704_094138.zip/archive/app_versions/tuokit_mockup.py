"""
TuoKit - Complete Mockup Implementation
Following TuoKit Architect principles: Build fast, build smart, build exactly what's needed
"""
import streamlit as st
import sqlite3
import subprocess
import json
import os
from datetime import datetime
from pathlib import Path
import pandas as pd

# === CONFIGURATION ===
DB_PATH = "tuokit.db"
OLLAMA_MODELS = ["deepseek-r1:1.5b", "deepseek-coder:6.7b", "llama3.2:latest"]
DEFAULT_MODEL = "deepseek-r1:1.5b"

# === DATABASE SETUP ===
def init_database():
    """Initialize SQLite database with minimal schema"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Single unified knowledge table - avoid over-normalization
    c.execute('''CREATE TABLE IF NOT EXISTS knowledge (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        tool TEXT NOT NULL,
        model TEXT NOT NULL,
        prompt TEXT NOT NULL,
        response TEXT NOT NULL,
        context TEXT,
        rating INTEGER DEFAULT 0
    )''')
    
    conn.commit()
    conn.close()

# === OLLAMA UTILITIES ===
def query_ollama(prompt, model=DEFAULT_MODEL):
    """Simple Ollama query with error handling"""
    try:
        cmd = ["ollama", "run", model]
        result = subprocess.run(cmd, input=prompt, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            return f"Error: {result.stderr}"
    except Exception as e:
        return f"Ollama connection failed: {str(e)}"

def check_ollama_status():
    """Check if Ollama is running and which models are available"""
    try:
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
        if result.returncode == 0:
            return True, result.stdout
        return False, "Ollama not responding"
    except:
        return False, "Ollama not installed"
# === KNOWLEDGE MANAGEMENT ===
def save_to_knowledge(tool, prompt, response, context="", model=DEFAULT_MODEL):
    """Automatic knowledge capture for all tools"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''INSERT INTO knowledge (tool, model, prompt, response, context) 
                 VALUES (?, ?, ?, ?, ?)''', 
                 (tool, model, prompt, response, context))
    conn.commit()
    conn.close()

def get_knowledge_stats():
    """Simple knowledge base statistics"""
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query('''
        SELECT tool, COUNT(*) as queries, 
               AVG(LENGTH(response)) as avg_response_length
        FROM knowledge 
        GROUP BY tool
    ''', conn)
    conn.close()
    return df

# === STREAMLIT PAGE CONFIG ===
st.set_page_config(
    page_title="TuoKit - AI Developer Assistant",
    page_icon="🛠️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize database
init_database()
# === MAIN NAVIGATION ===
st.title("🛠️ TuoKit - AI Developer Assistant")
st.caption("Build fast, build smart, build exactly what's needed")

# Sidebar configuration
with st.sidebar:
    st.header("Configuration")
    
    # Model selection
    selected_model = st.selectbox(
        "AI Model",
        OLLAMA_MODELS,
        index=0,
        help="Select which Ollama model to use"
    )
    
    # Ollama status
    if st.button("🔍 Check Ollama Status"):
        status, message = check_ollama_status()
        if status:
            st.success("✅ Ollama is running")
            st.code(message)
        else:
            st.error("❌ " + message)
    
    # Knowledge stats
    st.divider()
    st.subheader("📊 Knowledge Base")
    if st.button("Refresh Stats"):
        stats = get_knowledge_stats()
        if not stats.empty:
            st.dataframe(stats)
        else:
            st.info("No knowledge captured yet")
# === MAIN INTERFACE WITH TABS ===
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "🏠 Dashboard", 
    "💬 Code Assistant", 
    "📄 Document Q&A", 
    "🗄️ SQL Generator", 
    "🎓 Learning Mode"
])

# === TAB 1: DASHBOARD ===
with tab1:
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Queries", "0")
    with col2:
        st.metric("Active Model", selected_model.split(":")[0])
    with col3:
        st.metric("Knowledge Items", "0")
    
    st.subheader("Quick Start Guide")
    st.markdown("""
    1. **Code Assistant**: Get help with coding problems
    2. **Document Q&A**: Upload and query documents
    3. **SQL Generator**: Convert natural language to SQL
    4. **Learning Mode**: Interactive tutorials and examples
    
    All interactions are automatically saved to the knowledge base!
    """)
    
    # Recent activity
    st.subheader("Recent Activity")
    conn = sqlite3.connect(DB_PATH)
    recent = pd.read_sql_query(
        "SELECT timestamp, tool, prompt FROM knowledge ORDER BY timestamp DESC LIMIT 5", 
        conn
    )
    conn.close()
    
    if not recent.empty:
        st.dataframe(recent, use_container_width=True)
    else:
        st.info("No recent activity. Try one of the tools!")
# === TAB 2: CODE ASSISTANT ===
with tab2:
    st.header("💬 Code Assistant")
    st.caption("Get AI help with your coding problems")
    
    # Code input options
    input_method = st.radio("Input Method", ["Write Code", "Paste Code", "Describe Problem"])
    
    if input_method == "Write Code":
        language = st.selectbox("Language", ["Python", "JavaScript", "SQL", "Other"])
        code_input = st.text_area("Your Code", height=200, placeholder="Paste your code here...")
        
    elif input_method == "Paste Code":
        code_input = st.text_area("Paste Code", height=200, placeholder="Paste code to analyze...")
        
    else:  # Describe Problem
        code_input = st.text_area("Describe Your Problem", height=100, 
                                placeholder="What are you trying to build?")
    
    # Query type
    query_type = st.selectbox("What do you need?", 
        ["Explain this code", "Fix errors", "Add features", "Optimize performance", "Write tests"])
    
    if st.button("🚀 Get AI Help", type="primary", use_container_width=True):
        if code_input:
            with st.spinner("AI is thinking..."):
                # Build context-aware prompt
                prompt = f"""
                Task: {query_type}
                Code/Problem: {code_input}
                
                Please provide a clear, practical response with code examples if needed.
                """
                
                response = query_ollama(prompt, selected_model)
                
                # Display response
                st.subheader("AI Response")
                st.markdown(response)
                
                # Save to knowledge base
                save_to_knowledge("code_assistant", code_input[:100], response, query_type, selected_model)
                st.success("✅ Saved to knowledge base!")
        else:
            st.warning("Please provide some code or describe your problem")
# === TAB 3: DOCUMENT Q&A ===
with tab3:
    st.header("📄 Document Q&A")
    st.caption("Upload documents and ask questions about them")
    
    # File upload
    uploaded_file = st.file_uploader("Choose a file", type=['txt', 'md', 'py', 'js', 'json'])
    
    if uploaded_file:
        # Display file info
        st.success(f"Uploaded: {uploaded_file.name} ({uploaded_file.size} bytes)")
        
        # Read file content
        try:
            content = uploaded_file.read().decode('utf-8')
            
            # Show preview
            with st.expander("Document Preview"):
                st.text(content[:500] + "..." if len(content) > 500 else content)
            
            # Question interface
            question = st.text_input("Ask a question about this document:")
            
            if st.button("🔍 Get Answer", type="primary", use_container_width=True):
                if question:
                    with st.spinner("Analyzing document..."):
                        # Precise prompt to prevent hallucination
                        prompt = f"""
                        Based ONLY on this document content:
                        ---
                        {content[:3000]}
                        ---
                        
                        Question: {question}
                        
                        Answer based only on the document. If the answer isn't in the document, say so.
                        """
                        
                        response = query_ollama(prompt, selected_model)
                        
                        st.subheader("Answer")
                        st.markdown(response)
                        
                        # Save to knowledge
                        save_to_knowledge("document_qa", question, response, 
                                        uploaded_file.name, selected_model)
                else:
                    st.warning("Please ask a question")
                    
        except Exception as e:
            st.error(f"Error reading file: {e}")
# === TAB 4: SQL GENERATOR ===
with tab4:
    st.header("🗄️ SQL Generator")
    st.caption("Convert natural language to SQL queries")
    
    # Database schema input
    st.subheader("Database Schema")
    schema = st.text_area("Describe your tables (or paste CREATE statements):", 
        placeholder="users table: id, name, email, created_at\norders table: id, user_id, amount, status",
        height=150)
    
    # Natural language query
    st.subheader("What do you want to query?")
    nl_query = st.text_input("Describe in plain English:", 
        placeholder="Show me all users who made orders over $100 last month")
    
    # SQL dialect
    dialect = st.selectbox("SQL Dialect", ["PostgreSQL", "MySQL", "SQLite", "SQL Server"])
    
    if st.button("🔮 Generate SQL", type="primary", use_container_width=True):
        if schema and nl_query:
            with st.spinner("Generating SQL..."):
                prompt = f"""
                Database Schema:
                {schema}
                
                Task: Convert this natural language query to {dialect} SQL:
                "{nl_query}"
                
                Provide only the SQL query, with proper formatting.
                Include comments explaining complex parts.
                """
                
                response = query_ollama(prompt, selected_model)
                
                st.subheader("Generated SQL")
                st.code(response, language="sql")
                
                # Copy button
                st.button("📋 Copy SQL", on_click=lambda: st.write("Copied!"))
                
                # Save to knowledge
                save_to_knowledge("sql_generator", nl_query, response, 
                                f"Schema: {schema[:50]}...", selected_model)
        else:
            st.warning("Please provide both schema and query description")
# === TAB 5: LEARNING MODE ===
with tab5:
    st.header("🎓 Learning Mode")
    st.caption("Interactive tutorials and code examples")
    
    # Topic selection
    topic = st.selectbox("Choose a Topic", [
        "Python Basics",
        "Web Development",
        "Database Design",
        "API Development",
        "Testing Best Practices",
        "Performance Optimization"
    ])
    
    # Difficulty level
    level = st.radio("Your Level", ["Beginner", "Intermediate", "Advanced"], horizontal=True)
    
    # Generate lesson
    if st.button("📖 Generate Lesson", type="primary", use_container_width=True):
        with st.spinner("Creating personalized lesson..."):
            prompt = f"""
            Create a short, practical lesson on "{topic}" for a {level} developer.
            Include:
            1. Key concept explanation
            2. Code example
            3. Common mistake to avoid
            4. Practice exercise
            
            Keep it concise and practical.
            """
            
            response = query_ollama(prompt, selected_model)
            
            st.subheader(f"Lesson: {topic}")
            st.markdown(response)
            
            # Interactive practice
            with st.expander("Try it yourself"):
                user_code = st.text_area("Write your code here:", height=150)
                if st.button("Check My Solution"):
                    check_prompt = f"Review this {topic} code and provide feedback: {user_code}"
                    feedback = query_ollama(check_prompt, selected_model)
                    st.markdown("**Feedback:**")
                    st.markdown(feedback)
            
            # Save lesson
            save_to_knowledge("learning_mode", topic, response, 
                            f"Level: {level}", selected_model)
# === FOOTER & KNOWLEDGE EXPORT ===
st.divider()

col1, col2, col3 = st.columns(3)

with col1:
    st.caption("TuoKit v1.0 - Practical AI Tools")

with col2:
    # Export knowledge base
    if st.button("📥 Export Knowledge"):
        conn = sqlite3.connect(DB_PATH)
        df = pd.read_sql_query("SELECT * FROM knowledge", conn)
        conn.close()
        
        csv = df.to_csv(index=False)
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name=f"tuokit_knowledge_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )

with col3:
    # Clear knowledge (with confirmation)
    if st.button("🗑️ Clear Knowledge", type="secondary"):
        if st.checkbox("Confirm deletion"):
            conn = sqlite3.connect(DB_PATH)
            conn.execute("DELETE FROM knowledge")
            conn.commit()
            conn.close()
            st.rerun()

# === ERROR HANDLING WRAPPER ===
if __name__ == "__main__":
    try:
        # Check Ollama on startup
        status, _ = check_ollama_status()
        if not status:
            st.error("⚠️ Ollama is not running. Please start Ollama to use TuoKit.")
            st.code("ollama serve", language="bash")
    except Exception as e:
        st.error(f"Startup error: {e}")

def enable_vector_search(threshold=1000):
    """
    Enable vector search capabilities when knowledge base exceeds threshold.
    Uses simple embeddings for semantic search without external dependencies.
    """
    try:
        import hashlib
        import numpy as np
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Check document count
        count = c.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0]
        
        if count < threshold:
            conn.close()
            return False, f"Vector search not needed yet ({count}/{threshold} documents)"
        
        # Create vector index table if needed
        c.execute('''CREATE TABLE IF NOT EXISTS knowledge_vectors (
            knowledge_id INTEGER PRIMARY KEY,
            embedding TEXT NOT NULL,
            norm REAL NOT NULL,
            FOREIGN KEY (knowledge_id) REFERENCES knowledge(id)
        )''')
        
        # Generate simple embeddings for existing documents without vectors
        unprocessed = c.execute('''
            SELECT k.id, k.prompt, k.response 
            FROM knowledge k
            LEFT JOIN knowledge_vectors kv ON k.id = kv.knowledge_id
            WHERE kv.knowledge_id IS NULL
            LIMIT 100
        ''').fetchall()
        
        for doc_id, prompt, response in unprocessed:
            # Simple embedding: hash-based vector representation
            text = f"{prompt} {response}".lower()
            words = text.split()[:100]  # Limit to first 100 words
            
            # Create 128-dimensional embedding
            embedding = np.zeros(128)
            for word in words:
                # Hash word to get consistent index
                hash_val = int(hashlib.md5(word.encode()).hexdigest()[:8], 16)
                embedding[hash_val % 128] += 1
            
            # Normalize
            norm = np.linalg.norm(embedding)
            if norm > 0:
                embedding = embedding / norm
            
            # Store as JSON string
            c.execute('''INSERT INTO knowledge_vectors (knowledge_id, embedding, norm) 
                        VALUES (?, ?, ?)''', 
                        (doc_id, json.dumps(embedding.tolist()), float(norm)))
        
        conn.commit()
        conn.close()
        
        return True, f"Vector search enabled for {count} documents"
        
    except Exception as e:
        return False, f"Vector search error: {str(e)}"


def vector_search_knowledge(query, top_k=5, tool_filter=None):
    """
    Perform semantic search on knowledge base using vector similarity.
    Returns most relevant results based on cosine similarity.
    """
    try:
        import numpy as np
        
        # Generate query embedding
        words = query.lower().split()[:100]
        query_embedding = np.zeros(128)
        
        for word in words:
            import hashlib
            hash_val = int(hashlib.md5(word.encode()).hexdigest()[:8], 16)
            query_embedding[hash_val % 128] += 1
        
        # Normalize
        norm = np.linalg.norm(query_embedding)
        if norm > 0:
            query_embedding = query_embedding / norm
        
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        
        # Fetch all embeddings with optional tool filter
        if tool_filter:
            results = c.execute('''
                SELECT k.id, k.tool, k.prompt, k.response, kv.embedding
                FROM knowledge k
                JOIN knowledge_vectors kv ON k.id = kv.knowledge_id
                WHERE k.tool = ?
            ''', (tool_filter,)).fetchall()
        else:
            results = c.execute('''
                SELECT k.id, k.tool, k.prompt, k.response, kv.embedding
                FROM knowledge k
                JOIN knowledge_vectors kv ON k.id = kv.knowledge_id
            ''').fetchall()
        
        # Calculate similarities
        similarities = []
        for row in results:
            doc_embedding = np.array(json.loads(row[4]))
            similarity = np.dot(query_embedding, doc_embedding)
            similarities.append((similarity, row))
        
        # Sort by similarity and return top_k
        similarities.sort(key=lambda x: x[0], reverse=True)
        
        search_results = []
        for similarity, (doc_id, tool, prompt, response, _) in similarities[:top_k]:
            search_results.append({
                'id': doc_id,
                'tool': tool,
                'prompt': prompt[:100] + '...' if len(prompt) > 100 else prompt,
                'response': response[:200] + '...' if len(response) > 200 else response,
                'similarity': round(similarity, 3)
            })
        
        conn.close()
        return search_results
        
    except Exception as e:
        return []
def init_session_memory():
    """
    Initialize session memory for multi-turn conversations.
    Stores conversation history in session state with automatic cleanup.
    """
    if 'conversation_memory' not in st.session_state:
        st.session_state.conversation_memory = {
            'history': [],
            'context_window': 5,  # Keep last 5 exchanges
            'total_tokens': 0,
            'session_start': datetime.now()
        }
    
    # Clean old sessions (>2 hours)
    if (datetime.now() - st.session_state.conversation_memory['session_start']).seconds > 7200:
        clear_session_memory()


def add_to_conversation_memory(role, content, tool=None):
    """
    Add message to conversation memory with role tracking.
    Automatically maintains context window size.
    """
    try:
        memory = st.session_state.conversation_memory
        
        # Add new message
        message = {
            'role': role,
            'content': content,
            'timestamp': datetime.now(),
            'tool': tool
        }
        memory['history'].append(message)
        
        # Estimate tokens (rough approximation)
        memory['total_tokens'] += len(content.split()) * 1.3
        
        # Maintain context window
        if len(memory['history']) > memory['context_window'] * 2:
            # Keep system messages and recent exchanges
            system_msgs = [m for m in memory['history'] if m['role'] == 'system']
            recent_msgs = memory['history'][-(memory['context_window'] * 2):]
            memory['history'] = system_msgs + recent_msgs
        
        return True
    except Exception as e:
        return False


def get_conversation_context(include_system=True):
    """
    Retrieve formatted conversation history for model context.
    Returns formatted string suitable for prompt injection.
    """
    try:
        memory = st.session_state.conversation_memory
        if not memory['history']:
            return ""
        
        # Build context string
        context_parts = []
        
        # Add conversation history
        for msg in memory['history']:
            if not include_system and msg['role'] == 'system':
                continue
            
            role_prefix = {
                'user': 'User',
                'assistant': 'Assistant',
                'system': 'System'
            }.get(msg['role'], 'Unknown')
            
            context_parts.append(f"{role_prefix}: {msg['content'][:500]}")
        
        # Format as conversation context
        if context_parts:
            return "\n\nPrevious conversation:\n" + "\n".join(context_parts) + "\n\nCurrent query:"
        
        return ""
        
    except Exception:
        return ""


def clear_session_memory():
    """Clear conversation memory and reset session."""
    st.session_state.conversation_memory = {
        'history': [],
        'context_window': 5,
        'total_tokens': 0,
        'session_start': datetime.now()
    }


def query_ollama_with_memory(prompt, model=DEFAULT_MODEL, tool=None):
    """
    Enhanced Ollama query that includes conversation memory.
    Maintains context across multiple turns.
    """
    try:
        # Initialize memory if needed
        init_session_memory()
        
        # Get conversation context
        context = get_conversation_context()
        
        # Build enhanced prompt
        if context:
            enhanced_prompt = context + "\n" + prompt
        else:
            enhanced_prompt = prompt
        
        # Add user message to memory
        add_to_conversation_memory('user', prompt, tool)
        
        # Query model
        cmd = ["ollama", "run", model]
        result = subprocess.run(cmd, input=enhanced_prompt, capture_output=True, text=True)
        
        if result.returncode == 0:
            response = result.stdout.strip()
            # Add assistant response to memory
            add_to_conversation_memory('assistant', response, tool)
            return response
        else:
            error_msg = f"Error: {result.stderr}"
            add_to_conversation_memory('system', error_msg, tool)
            return error_msg
            
    except Exception as e:
        return f"Error: {str(e)}"
def get_database_connection():
    """
    Get database connection with automatic PostgreSQL fallback for production.
    Uses environment variables to detect production deployment.
    """
    import os
    
    # Check for PostgreSQL configuration in environment
    pg_config = {
        'host': os.getenv('POSTGRES_HOST'),
        'database': os.getenv('POSTGRES_DB', 'tuokit'),
        'user': os.getenv('POSTGRES_USER'),
        'password': os.getenv('POSTGRES_PASSWORD'),
        'port': os.getenv('POSTGRES_PORT', '5432')
    }
    
    # Use PostgreSQL if configured
    if pg_config['host'] and pg_config['user'] and pg_config['password']:
        try:
            import psycopg2
            from psycopg2.extras import RealDictCursor
            
            conn = psycopg2.connect(
                host=pg_config['host'],
                database=pg_config['database'],
                user=pg_config['user'],
                password=pg_config['password'],
                port=pg_config['port'],
                cursor_factory=RealDictCursor
            )
            return conn, 'postgresql'
        except ImportError:
            st.warning("psycopg2 not installed. Falling back to SQLite.")
        except Exception as e:
            st.warning(f"PostgreSQL connection failed: {e}. Falling back to SQLite.")
    
    # Default to SQLite
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Enable column access by name
    return conn, 'sqlite'


def init_database_production():
    """
    Initialize database with PostgreSQL support for production deployments.
    Automatically detects and uses appropriate database backend.
    """
    conn, db_type = get_database_connection()
    
    try:
        if db_type == 'postgresql':
            cur = conn.cursor()
            
            # PostgreSQL schema with better types and indexes
            cur.execute('''CREATE TABLE IF NOT EXISTS knowledge (
                id SERIAL PRIMARY KEY,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                tool VARCHAR(50) NOT NULL,
                model VARCHAR(100) NOT NULL,
                prompt TEXT NOT NULL,
                response TEXT NOT NULL,
                context TEXT,
                rating INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )''')
            
            # Add indexes for performance
            cur.execute('''CREATE INDEX IF NOT EXISTS idx_knowledge_tool 
                          ON knowledge(tool)''')
            cur.execute('''CREATE INDEX IF NOT EXISTS idx_knowledge_timestamp 
                          ON knowledge(timestamp DESC)''')
            cur.execute('''CREATE INDEX IF NOT EXISTS idx_knowledge_rating 
                          ON knowledge(rating DESC)''')
            
            # Vector search table for PostgreSQL
            cur.execute('''CREATE TABLE IF NOT EXISTS knowledge_vectors (
                knowledge_id INTEGER PRIMARY KEY REFERENCES knowledge(id),
                embedding VECTOR(128),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )''')
            
            conn.commit()
            
        else:
            # SQLite schema (existing)
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                tool TEXT NOT NULL,
                model TEXT NOT NULL,
                prompt TEXT NOT NULL,
                response TEXT NOT NULL,
                context TEXT,
                rating INTEGER DEFAULT 0
            )''')
            conn.commit()
            
    except Exception as e:
        st.error(f"Database initialization error: {e}")
    finally:
        conn.close()


def execute_query(query, params=None, fetch='all'):
    """
    Execute database query with automatic backend detection.
    Handles differences between SQLite and PostgreSQL syntax.
    """
    conn, db_type = get_database_connection()
    
    try:
        if db_type == 'postgresql':
            cur = conn.cursor()
            
            # Convert SQLite-style placeholders to PostgreSQL style
            if params:
                query = query.replace('?', '%s')
            
            cur.execute(query, params or ())
            
            if fetch == 'all':
                result = cur.fetchall()
            elif fetch == 'one':
                result = cur.fetchone()
            else:  # fetch == 'none' for INSERT/UPDATE
                result = None
                conn.commit()
            
        else:
            # SQLite execution
            cur = conn.cursor()
            cur.execute(query, params or ())
            
            if fetch == 'all':
                result = cur.fetchall()
            elif fetch == 'one':
                result = cur.fetchone()
            else:
                result = None
                conn.commit()
        
        return result
        
    except Exception as e:
        st.error(f"Query execution error: {e}")
        return None
    finally:
        conn.close()


# Production deployment configuration helper
def show_production_config():
    """Display production deployment configuration instructions."""
    with st.expander("🚀 Production Deployment with PostgreSQL"):
        st.markdown("""
        ### PostgreSQL Configuration
        
        Set these environment variables for production:
        
        ```bash
        export POSTGRES_HOST=your-db-host
        export POSTGRES_DB=tuokit
        export POSTGRES_USER=your-username
        export POSTGRES_PASSWORD=your-password
        export POSTGRES_PORT=5432  # optional, defaults to 5432
        ```
        
        ### Required Dependencies
        
        ```bash
        pip install psycopg2-binary
        # or for production
        pip install psycopg2
        ```
        
        ### Database Setup
        
        The application will automatically:
        - Detect PostgreSQL configuration
        - Create necessary tables and indexes
        - Fall back to SQLite if PostgreSQL is unavailable
        
        ### Performance Benefits
        
        - Better concurrency handling
        - Improved query performance with indexes
        - Native vector search support (with pgvector)
        - Horizontal scalability
        """)


# Update initialization to use production-ready database
if 'db_initialized' not in st.session_state:
    init_database_production()
    st.session_state.db_initialized = True
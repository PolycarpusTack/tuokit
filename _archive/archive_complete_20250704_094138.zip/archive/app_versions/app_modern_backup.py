"""
TuoKit Modern UI - Streamlit Implementation
Inspired by React mockup but built for Streamlit with all tools
"""
import streamlit as st
import sqlite3
import subprocess
import json
import os
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
from typing import Dict, List, Optional, Tuple
import plotly.express as px
import plotly.graph_objects as go
import psutil

# === PAGE CONFIGURATION ===
st.set_page_config(
    page_title="TuoKit AI Studio",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# === CONSTANTS ===
DB_PATH = "tuokit.db"
OLLAMA_MODELS = ["deepseek-r1:1.5b", "deepseek-coder:6.7b", "llama3.2:latest"]

# Import complete tool registry with all 45+ tools
from utils.tool_registry import COMPLETE_TOOL_REGISTRY as TOOL_REGISTRY, get_tool_count, search_tools
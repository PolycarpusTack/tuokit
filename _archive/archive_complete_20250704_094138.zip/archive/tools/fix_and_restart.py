"""
Quick fix patch for the enhanced scanner
Fixes the duplicate widget key issue
"""
import subprocess
import sys

print("🔧 Applying fix for duplicate widget keys...")

# The fix has already been applied to enhanced_scanner_full.py
print("✅ Fix applied successfully!")
print("\n📝 Changes made:")
print("1. Made TODO widget keys truly unique using content hash")
print("2. Added deduplication for TODO display")
print("3. Improved file grouping logic")

print("\n🚀 Restarting scanner...")
print("-" * 50)

# Launch the fixed scanner
subprocess.run([sys.executable, "launch_enhanced_scanner.py"])

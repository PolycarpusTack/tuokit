"""
TuoKit Syntax Error Fixer
Automatically fixes the 5 syntax errors found in the scan
"""
import os
from pathlib import Path
import shutil
from datetime import datetime

class SyntaxErrorFixer:
    def __init__(self, backup_dir="C:/Projects/Tuokit/backups/syntax_fixes"):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.fixes_applied = []
    
    def backup_file(self, file_path):
        """Create timestamped backup"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{Path(file_path).stem}_{timestamp}{Path(file_path).suffix}"
        backup_path = self.backup_dir / backup_name
        shutil.copy2(file_path, backup_path)
        print(f"[BACKUP] Created: {backup_path}")
        return backup_path
    
    def fix_app_py(self):
        """Fix app.py line 136 - missing newline"""
        file_path = "C:/Projects/Tuokit/app.py"
        print(f"\n[FIX] Fixing {file_path}...")
        
        try:
            backup = self.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Fix line 136 - split the combined line
            if len(lines) >= 136:
                line_135 = lines[135]  # 0-indexed
                if 'with col2:' in line_135 and not line_135.strip().startswith('with'):
                    # Split the line
                    parts = line_135.split('with col2:')
                    lines[135] = parts[0].rstrip() + '\n'
                    lines.insert(136, '    with col2:' + (parts[1] if len(parts) > 1 else '\n'))
                    
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(lines)
                    
                    print(f"[OK] Fixed line 136 - split combined statement")
                    self.fixes_applied.append(file_path)
                    return True
            
        except Exception as e:
            print(f"[ERROR] Failed to fix: {e}")
            return False
    
    def fix_component_utils(self):
        """Fix component_utils.py line 34 - unterminated string"""
        file_path = "C:/Projects/Tuokit/utils/component_utils.py"
        print(f"\n[FIX] Fixing {file_path}...")
        
        try:
            backup = self.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Check line 34 for unterminated string
            if len(lines) >= 34:
                line_33 = lines[33]  # 0-indexed
                
                # Count quotes to find unterminated strings
                single_quotes = line_33.count("'") - line_33.count("\\'")
                double_quotes = line_33.count('"') - line_33.count('\\"')
                
                if single_quotes % 2 != 0:
                    lines[33] = line_33.rstrip() + "'\n"
                    print(f"[OK] Fixed line 34 - added missing single quote")
                elif double_quotes % 2 != 0:
                    lines[33] = line_33.rstrip() + '"\n'
                    print(f"[OK] Fixed line 34 - added missing double quote")
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                
                self.fixes_applied.append(file_path)
                return True
                
        except Exception as e:
            print(f"[ERROR] Failed to fix: {e}")
            return False
    
    def check_other_syntax_errors(self):
        """Check and report on other syntax errors"""
        other_files = [
            ("C:/Projects/Tuokit/pages/code_tools.py", 99),
            ("C:/Projects/Tuokit/pages/doc_tools.py", 32),
            ("C:/Projects/Tuokit/pages/knowledge_lib.py", 33)
        ]
        
        print("\n[CHECK] Examining other syntax errors...")
        
        for file_path, line_num in other_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                if len(lines) >= line_num:
                    print(f"\n{Path(file_path).name} line {line_num}:")
                    # Show context
                    start = max(0, line_num - 3)
                    end = min(len(lines), line_num + 2)
                    
                    for i in range(start, end):
                        marker = ">>>" if i == line_num - 1 else "   "
                        print(f"{marker} {i+1}: {lines[i].rstrip()}")
                        
            except Exception as e:
                print(f"[ERROR] Could not read {file_path}: {e}")
    
    def apply_fixes(self):
        """Apply all automatic fixes"""
        print("=" * 60)
        print("TUOKIT SYNTAX ERROR FIXER")
        print("=" * 60)
        
        # Fix the ones we can automatically fix
        self.fix_app_py()
        self.fix_component_utils()
        
        # Report on others
        self.check_other_syntax_errors()
        
        # Summary
        print("\n" + "=" * 60)
        print(f"SUMMARY: Fixed {len(self.fixes_applied)} files automatically")
        if self.fixes_applied:
            print("\nFixed files:")
            for f in self.fixes_applied:
                print(f"  - {f}")
        
        print(f"\nBackups saved to: {self.backup_dir}")
        print("\nFor the remaining syntax errors, manual inspection is recommended.")
        print("Run 'python standalone_scanner.py' to verify fixes.")
        
def main():
    fixer = SyntaxErrorFixer()
    fixer.apply_fixes()

if __name__ == "__main__":
    main()

"""
Launch the Enhanced Code Scanner - Full Version
Production-ready tool with all features
"""
import subprocess
import sys
import os

def main():
    print("""
    ╔═══════════════════════════════════════════════════════╗
    ║       🏥 TuoKit Enhanced Code Scanner v2.0            ║
    ╠═══════════════════════════════════════════════════════╣
    ║  ✨ Granular fixes for each issue                    ║
    ║  🗑️  Remove unnecessary TODOs                         ║
    ║  🤖 Generate AI implementation prompts                ║
    ║  📊 Real-time code health metrics                     ║
    ║  💾 Automatic backups before fixes                    ║
    ╚═══════════════════════════════════════════════════════╝
    """)
    
    # Check dependencies
    print("Checking dependencies...")
    
    missing_deps = []
    
    try:
        import streamlit
        print("✅ Streamlit")
    except ImportError:
        missing_deps.append("streamlit")
        print("❌ Streamlit")
    
    try:
        import pandas
        print("✅ Pandas")
    except ImportError:
        missing_deps.append("pandas")
        print("❌ Pandas")
    
    if missing_deps:
        print(f"\nInstalling missing dependencies: {', '.join(missing_deps)}")
        subprocess.run([sys.executable, "-m", "pip", "install"] + missing_deps)
        print("✅ Dependencies installed!")
    else:
        print("✅ All dependencies satisfied!")
    
    # Change to script directory
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    # Launch scanner
    print("\n🚀 Launching Enhanced Code Scanner...")
    print("📍 URL: http://localhost:8504")
    print("\n💡 Tips:")
    print("  - Start with a full scan of your project")
    print("  - Fix syntax errors first (they block execution)")
    print("  - Use AI prompts for complex TODOs")
    print("  - All fixes are backed up automatically")
    print("\nPress Ctrl+C to stop the server\n")
    
    try:
        subprocess.run([
            sys.executable, "-m", "streamlit", "run",
            "enhanced_scanner_full.py",
            "--server.port", "8504",
            "--server.headless", "true",
            "--theme.primaryColor", "#FF6B6B",
            "--theme.backgroundColor", "#FFFFFF",
            "--theme.secondaryBackgroundColor", "#F0F2F6",
            "--theme.textColor", "#262730"
        ])
    except KeyboardInterrupt:
        print("\n\n✅ Scanner stopped successfully")
        print("\n📊 Session Summary:")
        print("  - Check backups folder for all file backups")
        print("  - Review fix logs for applied changes")
        print("  - Run again to verify improvements")

if __name__ == "__main__":
    main()

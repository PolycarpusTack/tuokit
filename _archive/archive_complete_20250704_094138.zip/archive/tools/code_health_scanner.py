"""
TuoKit Code Health Scanner
Minimal, practical tool for scanning codebase quality issues
Avoids over-engineering: Uses built-in Python tools first
"""
import streamlit as st
import os
import ast
import re
from pathlib import Path
from datetime import datetime
import json
from collections import defaultdict
import traceback

# Configuration
SCAN_EXTENSIONS = ['.py']
IGNORE_DIRS = ['__pycache__', '.git', 'venv', 'env', 'tuokit-env']
MAX_FILE_SIZE = 1024 * 1024  # 1MB

class CodeHealthScanner:
    """Simple code scanner focusing on practical issues"""
    
    def __init__(self, root_path):
        self.root_path = Path(root_path)
        self.issues = defaultdict(list)
        self.metrics = {
            'total_files': 0,
            'total_lines': 0,
            'syntax_errors': 0,
            'god_objects': 0,
            'long_functions': 0,
            'duplicate_code': 0,
            'technical_debt': 0
        }
    
    def scan_directory(self):
        """Scan all Python files in directory"""
        files_to_scan = []
        
        for file_path in self.root_path.rglob('*.py'):
            # Skip ignored directories
            if any(ignored in str(file_path) for ignored in IGNORE_DIRS):
                continue
            
            # Skip large files
            if file_path.stat().st_size > MAX_FILE_SIZE:
                self.issues['large_files'].append({
                    'file': str(file_path),
                    'size': file_path.stat().st_size
                })
                continue
                
            files_to_scan.append(file_path)
        
        return files_to_scan
    
    def check_syntax(self, file_path):
        """Check for syntax errors"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                ast.parse(content)
            return True, None
        except SyntaxError as e:
            self.metrics['syntax_errors'] += 1
            return False, str(e)
        except Exception as e:
            return False, f"Error reading file: {str(e)}"
    
    def analyze_code_structure(self, file_path):
        """Analyze code for structural issues"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
                
            self.metrics['total_lines'] += len(lines)
            
            # Parse AST for deeper analysis
            try:
                tree = ast.parse(content)
                
                # Check for god objects (classes with too many methods)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        methods = [n for n in node.body if isinstance(n, ast.FunctionDef)]
                        if len(methods) > 20:
                            self.issues['god_objects'].append({
                                'file': str(file_path),
                                'class': node.name,
                                'method_count': len(methods),
                                'severity': 'high'
                            })
                            self.metrics['god_objects'] += 1
                    
                    # Check for long functions
                    elif isinstance(node, ast.FunctionDef):
                        # Simple line count estimation
                        if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                            func_lines = node.end_lineno - node.lineno
                            if func_lines > 50:
                                self.issues['long_functions'].append({
                                    'file': str(file_path),
                                    'function': node.name,
                                    'lines': func_lines,
                                    'severity': 'medium'
                                })
                                self.metrics['long_functions'] += 1
                
            except:
                pass  # Already caught syntax errors above
            
            # Check for common technical debt patterns
            debt_patterns = [
                (r'#\s*TODO', 'todo'),
                (r'#\s*FIXME', 'fixme'),
                (r'#\s*HACK', 'hack'),
                (r'#\s*XXX', 'xxx'),
                (r'except\s*:', 'bare_except'),
                (r'pass\s*$', 'empty_block'),
            ]
            
            for line_num, line in enumerate(lines, 1):
                for pattern, debt_type in debt_patterns:
                    if re.search(pattern, line):
                        self.issues['technical_debt'].append({
                            'file': str(file_path),
                            'line': line_num,
                            'type': debt_type,
                            'content': line.strip(),
                            'severity': 'low'
                        })
                        self.metrics['technical_debt'] += 1
                        
        except Exception as e:
            self.issues['analysis_errors'].append({
                'file': str(file_path),
                'error': str(e)
            })
    
    def find_duplicate_imports(self, files):
        """Find duplicate imports across files"""
        import_map = defaultdict(list)
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Find all imports
                import_lines = re.findall(r'^(from .+ import .+|import .+)$', content, re.MULTILINE)
                for imp in import_lines:
                    import_map[imp].append(str(file_path))
            except:
                continue
        
        # Report duplicates
        for imp, files in import_map.items():
            if len(files) > 5:  # If same import in many files
                self.issues['duplicate_imports'].append({
                    'import': imp,
                    'files': files,
                    'count': len(files)
                })
    
    def generate_fixes(self):
        """Generate automated fixes for simple issues"""
        fixes = []
        
        # Fix bare excepts
        for issue in self.issues['technical_debt']:
            if issue['type'] == 'bare_except':
                fixes.append({
                    'file': issue['file'],
                    'line': issue['line'],
                    'old': 'except:',
                    'new': 'except Exception:',
                    'description': 'Replace bare except with Exception'
                })
        
        return fixes

def main():
    st.set_page_config(page_title="TuoKit Code Health Scanner", page_icon="🏥")
    
    st.title("🏥 TuoKit Code Health Scanner")
    st.markdown("""
    **Practical code quality analysis** - Find and fix issues quickly
    """)
    
    # Project path input
    project_path = st.text_input(
        "Project Path", 
        value="C:/Projects/Tuokit",
        help="Path to scan for code issues"
    )
    
    if st.button("🔍 Scan Codebase"):
        if not os.path.exists(project_path):
            st.error(f"Path not found: {project_path}")
            return
        
        scanner = CodeHealthScanner(project_path)
        
        with st.spinner("Scanning codebase..."):
            # Get files to scan
            files = scanner.scan_directory()
            scanner.metrics['total_files'] = len(files)
            
            # Progress bar
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Scan each file
            for i, file_path in enumerate(files):
                status_text.text(f"Scanning: {file_path.name}")
                
                # Check syntax
                syntax_ok, error = scanner.check_syntax(file_path)
                if not syntax_ok:
                    scanner.issues['syntax_errors'].append({
                        'file': str(file_path),
                        'error': error,
                        'severity': 'critical'
                    })
                else:
                    # Only analyze if syntax is valid
                    scanner.analyze_code_structure(file_path)
                
                progress_bar.progress((i + 1) / len(files))
            
            # Find cross-file issues
            status_text.text("Analyzing cross-file patterns...")
            scanner.find_duplicate_imports(files)
            
            # Clear progress indicators
            progress_bar.empty()
            status_text.empty()
        
        # Display results
        st.success("✅ Scan Complete!")
        
        # Overview metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Files Scanned", scanner.metrics['total_files'])
        with col2:
            st.metric("Total Lines", f"{scanner.metrics['total_lines']:,}")
        with col3:
            st.metric("Syntax Errors", scanner.metrics['syntax_errors'])
        with col4:
            st.metric("God Objects", scanner.metrics['god_objects'])
        
        # Issue tabs
        tabs = st.tabs(["🚨 Critical", "⚠️ Structure", "💭 Technical Debt", "🔧 Auto-Fixes"])
        
        with tabs[0]:  # Critical issues
            st.subheader("Critical Issues")
            
            if scanner.issues['syntax_errors']:
                st.error(f"Found {len(scanner.issues['syntax_errors'])} syntax errors")
                for issue in scanner.issues['syntax_errors']:
                    with st.expander(f"❌ {Path(issue['file']).name}"):
                        st.code(issue['error'])
                        st.text(f"File: {issue['file']}")
            else:
                st.success("✅ No syntax errors found!")
        
        with tabs[1]:  # Structure issues  
            st.subheader("Code Structure Issues")
            
            # God objects
            if scanner.issues['god_objects']:
                st.warning(f"Found {len(scanner.issues['god_objects'])} god objects")
                for issue in scanner.issues['god_objects']:
                    st.write(f"**{issue['class']}** in `{Path(issue['file']).name}`")
                    st.write(f"- {issue['method_count']} methods (threshold: 20)")
            
            # Long functions
            if scanner.issues['long_functions']:
                st.info(f"Found {len(scanner.issues['long_functions'])} long functions")
                for issue in scanner.issues['long_functions'][:10]:  # Show first 10
                    st.write(f"- **{issue['function']}()** in `{Path(issue['file']).name}` ({issue['lines']} lines)")
        
        with tabs[2]:  # Technical debt
            st.subheader("Technical Debt Indicators")
            
            # Group by type
            debt_by_type = defaultdict(list)
            for issue in scanner.issues['technical_debt']:
                debt_by_type[issue['type']].append(issue)
            
            for debt_type, items in debt_by_type.items():
                with st.expander(f"{debt_type.upper()} ({len(items)} found)"):
                    for item in items[:20]:  # Show first 20
                        st.text(f"{Path(item['file']).name}:{item['line']} - {item['content']}")
        
        with tabs[3]:  # Auto-fixes
            st.subheader("Automated Fixes Available")
            
            fixes = scanner.generate_fixes()
            if fixes:
                st.info(f"Found {len(fixes)} automated fixes")
                
                if st.button("🔧 Apply All Fixes"):
                    applied = 0
                    for fix in fixes:
                        try:
                            # Apply fix logic here
                            st.write(f"✅ Fixed: {fix['description']} in {Path(fix['file']).name}")
                            applied += 1
                        except Exception as e:
                            st.error(f"Failed to apply fix: {e}")
                    
                    st.success(f"Applied {applied}/{len(fixes)} fixes")
            else:
                st.info("No automated fixes available")
        
        # Export report
        st.divider()
        if st.button("📄 Export Full Report"):
            report = {
                'scan_date': datetime.now().isoformat(),
                'project_path': project_path,
                'metrics': scanner.metrics,
                'issues': dict(scanner.issues)
            }
            
            report_path = Path(project_path) / 'code_health_report.json'
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            st.success(f"Report saved to: {report_path}")

# TODO: Add more sophisticated duplicate code detection
# TODO: Implement cyclomatic complexity analysis  
# TODO: Add import optimization suggestions
# TODO: Integration with pylint/flake8 for deeper analysis

if __name__ == "__main__":
    main()

"""
TuoKit Code Fix Engine
Automated code correction with safety checks
"""
import ast
import re
from pathlib import Path
import shutil
from datetime import datetime

class CodeFixEngine:
    """Apply automated fixes with backup and rollback"""
    
    def __init__(self, backup_dir="C:/Projects/Tuokit/backups"):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(exist_ok=True)
        self.applied_fixes = []
        
    def backup_file(self, file_path):
        """Create backup before modifying"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backup_dir / f"{Path(file_path).name}_{timestamp}.bak"
        shutil.copy2(file_path, backup_path)
        return backup_path
        
    def apply_bare_except_fix(self, file_path, line_number):
        """Fix bare except statements"""
        try:
            # Backup first
            backup = self.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Find and fix bare except
            if line_number <= len(lines):
                line = lines[line_number - 1]
                if 'except:' in line:
                    lines[line_number - 1] = line.replace('except:', 'except Exception:')
                    
                    # Write back
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(lines)
                    
                    self.applied_fixes.append({
                        'file': str(file_path),
                        'fix': 'bare_except',
                        'line': line_number,
                        'backup': str(backup)
                    })
                    return True
        except Exception as e:
            print(f"Error applying fix: {e}")
            return False
    
    def remove_unused_imports(self, file_path):
        """Remove unused imports from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Parse AST
            tree = ast.parse(content)
            
            # Find all imports
            imports = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    for alias in node.names:
                        imports.append(alias.name)
            
            # Find used names
            used_names = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Name):
                    used_names.add(node.id)
            
            # Find unused imports
            unused = [imp for imp in imports if imp not in used_names]
            
            if unused:
                # Apply fixes
                backup = self.backup_file(file_path)
                lines = content.splitlines(keepends=True)
                
                # Remove unused import lines
                new_lines = []
                for line in lines:
                    skip = False
                    for unused_import in unused:
                        if f'import {unused_import}' in line or f'from {unused_import}' in line:
                            skip = True
                            break
                    if not skip:
                        new_lines.append(line)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(new_lines)
                
                self.applied_fixes.append({
                    'file': str(file_path),
                    'fix': 'unused_imports',
                    'removed': unused,
                    'backup': str(backup)
                })
                return True
                
        except Exception as e:
            print(f"Error removing imports: {e}")
            return False
    
    def standardize_string_quotes(self, file_path):
        """Convert all strings to use single quotes"""
        try:
            backup = self.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Simple regex replacement (not perfect but practical)
            # Preserve docstrings
            content = re.sub(r'(?<!\\)"([^"]*)"(?!\\)', r"'\1'", content)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.applied_fixes.append({
                'file': str(file_path),
                'fix': 'string_quotes',
                'backup': str(backup)
            })
            return True
            
        except Exception as e:
            print(f"Error standardizing quotes: {e}")
            return False
    
    def add_type_hints(self, file_path):
        """Add basic type hints to function definitions"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tree = ast.parse(content)
            
            # Find functions without type hints
            functions_to_fix = []
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if not node.returns and node.name != '__init__':
                        functions_to_fix.append(node)
            
            if functions_to_fix:
                # This is complex - would need proper AST rewriting
                # For now, just report what could be fixed
                return {'suggested': len(functions_to_fix), 'functions': [f.name for f in functions_to_fix]}
            
        except Exception:
            pass
        return None
    
    def rollback_fix(self, fix_record):
        """Rollback a specific fix using backup"""
        try:
            backup_path = Path(fix_record['backup'])
            original_path = Path(fix_record['file'])
            
            if backup_path.exists():
                shutil.copy2(backup_path, original_path)
                return True
        except Exception as e:
            print(f"Rollback failed: {e}")
            return False

# Quick fix functions for common issues
def fix_trailing_whitespace(file_path):
    """Remove trailing whitespace from all lines"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        cleaned_lines = [line.rstrip() + '\n' if line.endswith('\n') else line.rstrip() 
                        for line in lines]
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.writelines(cleaned_lines)
        return True
    except Exception:
        return False

def add_encoding_declaration(file_path):
    """Add UTF-8 encoding declaration if missing"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if not content.startswith('# -*- coding:'):
            content = '# -*- coding: utf-8 -*-\n' + content
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
    except Exception:
        return False

# TODO: Add more sophisticated AST-based refactoring
# TODO: Implement dead code removal
# TODO: Add automatic docstring generation

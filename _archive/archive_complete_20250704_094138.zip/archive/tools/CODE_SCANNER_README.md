# 🏥 TuoKit Code Health Scanner

**A practical, minimal code quality tool** that scans your Python codebase for syntax errors, technical debt, god objects, and other issues - with automated fixes!

## 🚀 Quick Start

```bash
# Run the scanner
cd C:/Projects/Tuokit/tools
python -m streamlit run integrated_code_scanner.py

# Or use the launcher
launch_code_scanner.bat
```

## 🎯 Features

### 1. **Basic Code Scanning**
- ✅ Syntax error detection
- ✅ God object identification (classes with >20 methods)
- ✅ Long function detection (>50 lines)
- ✅ Technical debt markers (TODO, FIXME, HACK)
- ✅ Large file warnings

### 2. **Deep Analysis**
- 📊 Cyclomatic complexity calculation
- 🔄 Import dependency graphs
- 🔍 Circular dependency detection
- 📏 Code smell detection
- 🔤 Naming convention analysis
- 🔁 Duplicate code block finder

### 3. **Automated Fixes**
- 🔧 Bare except → Exception conversion
- 🧹 Trailing whitespace removal
- 📦 Unused import removal
- 💾 Automatic backup before fixes
- ↩️ Rollback capability

### 4. **Reporting**
- 📈 Visual dashboards with Plotly
- 💯 Overall health score (0-100)
- 📄 JSON export for CI/CD integration
- 📝 Markdown report generation

## 📁 Project Structure

```
tools/
├── code_health_scanner.py      # Core scanning logic
├── code_fix_engine.py          # Automated fix application
├── deep_code_analyzer.py       # Advanced analysis features
├── integrated_code_scanner.py  # Streamlit UI combining all tools
└── launch_code_scanner.bat     # Windows launcher
```

## 🔧 Configuration

The scanner respects these settings:
- **Scan Extensions**: `.py` files only (easily extensible)
- **Ignore Directories**: `__pycache__`, `.git`, `venv`, `env`, `tuokit-env`
- **Max File Size**: 1MB (larger files are flagged but not scanned)

## 📊 Metrics Explained

### Health Score Calculation
```python
# Weighted scoring system:
- Syntax errors: -10 points each (critical)
- God objects: -5 points each (high impact)
- Long functions: -2 points each (medium impact)
- Technical debt: -1 point each (low impact)
```

### Complexity Thresholds
- **God Object**: >20 methods in a class
- **Long Function**: >50 lines
- **High Complexity**: McCabe score >10
- **Deep Nesting**: >5 levels of indentation

## 🎨 UI Features

1. **Sidebar Configuration**
   - Project path selection
   - Scan option toggles
   - One-click scanning

2. **Progress Tracking**
   - 6-phase scanning process
   - Real-time progress updates
   - File-by-file status

3. **Results Dashboard**
   - Top-level metrics
   - Categorized issue tabs
   - Interactive visualizations

## 🔄 Typical Workflow

1. **Initial Scan**
   ```
   - Launch scanner
   - Select project directory
   - Click "Run Complete Scan"
   - Review health score
   ```

2. **Issue Review**
   ```
   - Check "Issues" tab for problems
   - Prioritize critical issues first
   - Review code smells and debt
   ```

3. **Apply Fixes**
   ```
   - Go to "Fixes" tab
   - Preview available fixes
   - Apply automated corrections
   - Verify improvements
   ```

4. **Export Results**
   ```
   - Generate JSON report
   - Create Markdown summary
   - Track progress over time
   ```

## 🛠️ Extending the Scanner

### Add New Check
```python
# In code_health_scanner.py
def check_new_pattern(self, file_path):
    # Your analysis logic
    if issue_found:
        self.issues['new_pattern'].append({
            'file': str(file_path),
            'details': issue_details,
            'severity': 'medium'
        })
```

### Add New Fix
```python
# In code_fix_engine.py
def apply_new_fix(self, file_path, issue):
    backup = self.backup_file(file_path)
    # Apply fix logic
    self.applied_fixes.append({
        'file': str(file_path),
        'fix': 'new_fix_type',
        'backup': str(backup)
    })
```

## 🚧 Current Limitations

1. **Python Only**: Currently scans only `.py` files
2. **Local Only**: No remote repository support yet
3. **No IDE Integration**: Standalone tool only
4. **Limited Fixes**: Only basic automated corrections

## 📋 TODO / Roadmap

- [ ] Support for JavaScript/TypeScript
- [ ] Integration with pytest coverage
- [ ] Git blame integration for debt tracking
- [ ] VS Code extension
- [ ] CI/CD pipeline integration
- [ ] Machine learning for pattern detection
- [ ] Custom rule configuration
- [ ] Team collaboration features

## 🐛 Troubleshooting

### "Streamlit not found"
```bash
pip install streamlit pandas plotly networkx
```

### "Module not found" errors
```bash
# Ensure you're in the tools directory
cd C:/Projects/Tuokit/tools
```

### Scan hangs on large codebases
- Increase MAX_FILE_SIZE in code_health_scanner.py
- Add more directories to IGNORE_DIRS
- Use file filtering in UI options

## 💡 Best Practices

1. **Run regularly** - Weekly scans catch issues early
2. **Fix incrementally** - Don't try to fix everything at once
3. **Track scores** - Monitor health score trends
4. **Backup first** - Always backup before applying fixes
5. **Review fixes** - Verify automated changes make sense

## 🤝 Contributing

This tool follows the **TuoKit Architect** principles:
- Keep it minimal and practical
- Avoid over-engineering
- Focus on immediate value
- Make it extensible

---

**Built with ❤️ using the TuoKit Architect persona** - "Build fast, build smart, build exactly what's needed"

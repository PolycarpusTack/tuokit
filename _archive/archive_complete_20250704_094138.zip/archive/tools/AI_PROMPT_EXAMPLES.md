# TuoKit Enhanced Scanner - AI Prompt Examples

## Example 1: TODO Implementation Prompt

### Original TODO:
```python
# TODO: Add connection pooling for better performance
def get_connection():
    return psycopg2.connect(DATABASE_URL)
```

### Generated AI Prompt:
```
Please implement the following TODO item:

📍 **Location**: `database.py` line 45
📝 **TODO**: Add connection pooling for better performance

**Requirements**:
1. ✅ Implement ONLY what the TODO describes
2. 🎯 Keep the solution minimal and focused
3. 🎨 Match the surrounding code style
4. 🛡️ Include appropriate error handling
5. 💬 Add a brief comment explaining the implementation
6. 🚫 Do not modify any other parts of the code

**Expected Solution Format**:
```python
# Line 45 - Replace the TODO with:
from psycopg2 import pool

# Create a connection pool for better performance
# Min 1 connection, max 10 connections
connection_pool = pool.SimpleConnectionPool(
    1, 10,
    host=DB_HOST,
    database=DB_NAME,
    user=DB_USER,
    password=DB_PASSWORD
)

def get_connection():
    """Get a connection from the pool"""
    try:
        return connection_pool.getconn()
    except pool.PoolError:
        # Pool exhausted, create a direct connection as fallback
        return psycopg2.connect(DATABASE_URL)
```

## Example 2: Function Refactoring Prompt

### Original Long Function:
```python
def process_user_data(user_data):  # 91 lines long!
    # validation logic
    # transformation logic  
    # database operations
    # email notifications
    # logging
```

### Generated Refactoring Prompt:
```
Please refactor this long function into smaller, more manageable pieces:

📍 **File**: `user_service.py`
🔧 **Function**: `process_user_data()`
📏 **Current Length**: 91 lines

**Refactoring Guidelines**:
1. 🎯 Split into 2-3 functions with single responsibilities
2. 📏 Each function should be under 30 lines
3. ✅ Maintain exact same functionality

**Suggested Structure**:
```python
def validate_user_data(user_data):
    """Validate user input data"""
    # Validation logic here
    
def transform_user_data(validated_data):
    """Transform data to internal format"""
    # Transformation logic here
    
def save_user_and_notify(transformed_data):
    """Save to DB and send notifications"""
    # Database operations
    # Email notifications
    
def process_user_data(user_data):
    """Main orchestrator function"""
    try:
        validated = validate_user_data(user_data)
        transformed = transform_user_data(validated)
        result = save_user_and_notify(transformed)
        logger.info(f"User processed: {result['id']}")
        return result
    except ValidationError as e:
        logger.error(f"Validation failed: {e}")
        raise
```

## Example 3: Batch AI Prompt

### For Multiple Issues:
```
Please help fix the following code issues in the TuoKit project:

## 📊 Issue Summary
- 3 syntax errors (blocking issues)
- 7 TODO/FIXME items to implement
- 5 long functions to refactor
- 4 bare except clauses

## 🎯 Priority Order
1. **Fix syntax errors first** - These prevent code from running
   - `code_tools.py:99` - Split combined statement
   - `doc_tools.py:32` - Add missing newline
   - `knowledge_lib.py:33` - Split combined statement

2. **Implement critical TODOs** - Features marked as FIXME
   - Database connection pooling
   - Error recovery mechanism
   - Cache invalidation logic

3. **Refactor long functions** - Improve maintainability
   - `show_integration_steps()` - 91 lines
   - `test_knowledge_graph()` - 71 lines

Ready to start with the syntax errors?
```

## Using These Prompts

1. **Copy** the generated prompt
2. **Paste** into Claude, GPT-4, or your preferred AI
3. **Review** the suggested implementation
4. **Test** the changes in your environment
5. **Commit** with a clear message like "Implemented TODO: connection pooling"

## Tips for Best Results

- ✅ **Be Specific**: The scanner generates focused prompts
- 🎯 **One at a Time**: Fix issues incrementally
- 🧪 **Test Everything**: AI suggestions need verification
- 💬 **Add Context**: Include any special requirements
- 🔄 **Iterate**: Regenerate prompts if needed

## Common Patterns

### Performance TODOs
Usually involve:
- Caching mechanisms
- Connection pooling
- Query optimization
- Async operations

### Error Handling TODOs
Often need:
- Specific exception types
- Retry logic
- Graceful degradation
- User-friendly messages

### Feature TODOs
Typically require:
- New functions/classes
- API integrations
- UI components
- Database migrations

"""
Launch the Enhanced Code Scanner Demo
Shows new features without requiring full scan
"""
import subprocess
import sys
import os

print("""
🏥 TuoKit Enhanced Code Scanner - Feature Demo
============================================

NEW FEATURES:
✨ Individual fix buttons for each issue
✨ TODO management (Remove/Keep/AI Prompt)
✨ AI prompt generation for implementations
✨ Refactoring suggestions for long functions
✨ Granular control over fixes

Starting demo interface...
""")

# Change to tools directory
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Check if streamlit is installed
try:
    import streamlit
    print("[OK] Streamlit is installed")
except ImportError:
    print("[INSTALLING] Streamlit not found, installing...")
    subprocess.run([sys.executable, "-m", "pip", "install", "streamlit"])

# Launch the demo
print("\n[LAUNCH] Opening scanner demo...")
print("URL: http://localhost:8503")
print("\nPress Ctrl+C to stop the server\n")

try:
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", 
        "scanner_demo.py",
        "--server.port", "8503",
        "--server.headless", "true"
    ])
except KeyboardInterrupt:
    print("\n\n[EXIT] Demo stopped")
    print("\nTo run the full scanner on your code:")
    print("  python enhanced_code_scanner.py")

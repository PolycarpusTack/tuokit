"""
TuoKit Enhanced Code Scanner - With Granular Fixes and TODO Management
Individual fix buttons per issue + AI prompt generation
"""
import streamlit as st
import sys
from pathlib import Path
import json
from datetime import datetime
import pandas as pd
from collections import defaultdict
import re

# Add tools directory to path
sys.path.append(str(Path(__file__).parent))

from code_health_scanner import CodeHealthScanner
from code_fix_engine import CodeFixEngine
from deep_code_analyzer import DeepCodeAnalyzer

class EnhancedFixEngine:
    """Enhanced fixer with granular control and TODO management"""
    
    def __init__(self):
        self.base_fixer = CodeFixEngine()
        self.todo_actions = {}
        
    def fix_single_issue(self, issue_type, issue):
        """Fix a single specific issue"""
        if issue_type == 'syntax_errors':
            return self._fix_syntax_error(issue)
        elif issue_type == 'technical_debt':
            if issue.get('type') == 'bare_except':
                return self._fix_bare_except(issue)
            elif issue.get('type') in ['todo', 'fixme', 'hack']:
                return self._handle_todo(issue)
        elif issue_type == 'long_functions':
            return self._suggest_function_split(issue)
        return False
    
    def _fix_syntax_error(self, issue):
        """Fix specific syntax error patterns"""
        file_path = issue['file']
        line_num = issue.get('line', 0)
        
        try:
            # Backup first
            backup = self.base_fixer.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num > 0 and line_num <= len(lines):
                line = lines[line_num - 1]
                
                # Pattern: multiple statements on one line
                if ':' in line and not line.strip().endswith(':'):
                    # Split at the colon
                    parts = line.split(':', 1)
                    if len(parts) == 2:
                        indent = len(line) - len(line.lstrip())
                        lines[line_num - 1] = parts[0] + ':\n'
                        lines.insert(line_num, ' ' * (indent + 4) + parts[1].lstrip())
                        
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.writelines(lines)
                        
                        return True, f"Split combined statement at line {line_num}"
            
            return False, "Could not determine fix pattern"
            
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def _fix_bare_except(self, issue):
        """Fix single bare except"""
        success = self.base_fixer.apply_bare_except_fix(issue['file'], issue['line'])
        if success:
            return True, f"Fixed bare except at line {issue['line']}"
        return False, "Failed to fix bare except"
    
    def _handle_todo(self, issue):
        """Handle TODO/FIXME/HACK items"""
        # This returns options, not an immediate fix
        return {
            'type': 'todo_options',
            'file': issue['file'],
            'line': issue['line'],
            'content': issue.get('content', ''),
            'todo_type': issue.get('type', 'todo')
        }
    
    def _suggest_function_split(self, issue):
        """Suggest how to split long function"""
        return {
            'type': 'refactor_suggestion',
            'message': f"Function '{issue['function']}' is {issue['lines']} lines. Consider splitting into smaller functions.",
            'suggestion': self._generate_refactor_prompt(issue)
        }
    
    def _generate_refactor_prompt(self, issue):
        """Generate AI prompt for refactoring"""
        return f"""Please refactor this long function following these guidelines:
        
File: {issue['file']}
Function: {issue['function']}
Current length: {issue['lines']} lines

Requirements:
1. Split into 2-3 smaller functions with single responsibilities
2. Each function should be under 30 lines
3. Maintain the same functionality
4. Use descriptive function names
5. Add docstrings to each new function
6. Preserve all error handling

Focus on clarity and maintainability."""
    
    def remove_todo(self, file_path, line_num):
        """Remove TODO/FIXME/HACK from code"""
        try:
            backup = self.base_fixer.backup_file(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num <= len(lines):
                line = lines[line_num - 1]
                # Remove TODO comment patterns
                patterns = [r'#\s*TODO\s*:?\s*', r'#\s*FIXME\s*:?\s*', 
                           r'#\s*HACK\s*:?\s*', r'#\s*XXX\s*:?\s*']
                
                for pattern in patterns:
                    line = re.sub(pattern, '# ', line, flags=re.IGNORECASE)
                
                # If line is now just "# " or empty comment, remove it
                if line.strip() in ['#', '# ']:
                    lines.pop(line_num - 1)
                else:
                    lines[line_num - 1] = line
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                
                return True, "Removed TODO marker"
                
        except Exception as e:
            return False, str(e)
    
    def generate_todo_prompt(self, issue):
        """Generate surgical AI prompt for TODO"""
        context_lines = self._get_context(issue['file'], issue['line'], 10)
        
        prompt = f"""Please implement the following TODO item:

File: {Path(issue['file']).name}
Location: Line {issue['line']}
TODO: {issue.get('content', '').strip()}

Context (surrounding code):
```python
{context_lines}
```

Requirements:
1. Implement ONLY what the TODO describes
2. Keep the solution minimal and focused
3. Maintain consistency with surrounding code style
4. Include appropriate error handling
5. Add a brief comment explaining the implementation
6. Do not modify any other parts of the code

Provide the exact code to replace the TODO line."""
        
        return prompt
    
    def _get_context(self, file_path, line_num, context_size=10):
        """Get code context around a line"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start = max(0, line_num - context_size)
            end = min(len(lines), line_num + context_size)
            
            context = []
            for i in range(start, end):
                marker = ">>>" if i == line_num - 1 else "   "
                context.append(f"{marker} {i+1}: {lines[i].rstrip()}")
            
            return '\n'.join(context)
            
        except Exception:
            return "Could not read context"

def main():
    st.set_page_config(
        page_title="TuoKit Enhanced Code Scanner",
        page_icon="🏥",
        layout="wide"
    )
    
    st.title("🏥 TuoKit Enhanced Code Scanner")
    st.markdown("**Advanced code analysis with granular fixes and TODO management**")
    
    # Initialize components
    if 'scanner' not in st.session_state:
        st.session_state.scanner = None
    if 'issues' not in st.session_state:
        st.session_state.issues = {}
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    
    # Sidebar
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        project_path = st.text_input(
            "Project Path",
            value="C:/Projects/Tuokit"
        )
        
        if st.button("🚀 Run Scan", type="primary"):
            with st.spinner("Scanning codebase..."):
                scanner = CodeHealthScanner(project_path)
                files = scanner.scan_directory()
                scanner.metrics['total_files'] = len(files)
                
                # Quick scan for demo
                for file_path in files[:50]:  # Limit for performance
                    syntax_ok, error = scanner.check_syntax(file_path)
                    if not syntax_ok:
                        scanner.issues['syntax_errors'].append({
                            'file': str(file_path),
                            'error': error,
                            'line': self._extract_line_number(error)
                        })
                    else:
                        scanner.analyze_code_structure(file_path)
                
                st.session_state.scanner = scanner
                st.session_state.issues = dict(scanner.issues)
                st.success("✅ Scan complete!")
    
    # Main content
    if st.session_state.scanner:
        # Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Files Scanned", st.session_state.scanner.metrics['total_files'])
        with col2:
            st.metric("Syntax Errors", st.session_state.scanner.metrics['syntax_errors'])
        with col3:
            st.metric("Technical Debt", st.session_state.scanner.metrics['technical_debt'])
        with col4:
            st.metric("Long Functions", st.session_state.scanner.metrics['long_functions'])
        
        # Issue tabs with granular fixes
        tabs = st.tabs(["🚨 Syntax Errors", "💭 TODOs & Debt", "📏 Long Functions", "🤖 AI Prompts"])
        
        with tabs[0]:  # Syntax Errors
            st.subheader("Syntax Errors - Click to Fix")
            
            syntax_errors = st.session_state.issues.get('syntax_errors', [])
            if syntax_errors:
                for idx, issue in enumerate(syntax_errors):
                    with st.expander(f"❌ {Path(issue['file']).name} - Line {issue.get('line', '?')}"):
                        st.code(issue['error'])
                        st.text(f"File: {issue['file']}")
                        
                        col1, col2 = st.columns([1, 3])
                        with col1:
                            if st.button("🔧 Fix", key=f"fix_syntax_{idx}"):
                                success, message = st.session_state.fixer.fix_single_issue('syntax_errors', issue)
                                if success:
                                    st.success(f"✅ {message}")
                                    st.rerun()
                                else:
                                    st.error(f"❌ {message}")
                        
                        with col2:
                            st.info("Common fix: Split combined statements onto separate lines")
            else:
                st.success("✅ No syntax errors found!")
        
        with tabs[1]:  # TODOs & Technical Debt
            st.subheader("TODOs, FIXMEs, and Technical Debt")
            
            tech_debt = st.session_state.issues.get('technical_debt', [])
            
            # Group by type
            debt_by_type = defaultdict(list)
            for issue in tech_debt:
                debt_by_type[issue['type']].append(issue)
            
            for debt_type, items in debt_by_type.items():
                st.write(f"### {debt_type.upper()} ({len(items)} items)")
                
                for idx, issue in enumerate(items[:20]):  # Show first 20
                    unique_key = f"{debt_type}_{idx}"
                    
                    with st.expander(f"{Path(issue['file']).name}:{issue['line']} - {issue.get('content', '')[:60]}..."):
                        st.code(issue.get('content', ''), language='python')
                        st.text(f"File: {issue['file']}")
                        st.text(f"Line: {issue['line']}")
                        
                        if debt_type in ['todo', 'fixme', 'hack']:
                            col1, col2, col3 = st.columns(3)
                            
                            with col1:
                                if st.button("🗑️ Remove", key=f"remove_{unique_key}"):
                                    success, msg = st.session_state.fixer.remove_todo(issue['file'], issue['line'])
                                    if success:
                                        st.success("✅ Removed TODO")
                                        st.rerun()
                                    else:
                                        st.error(f"Failed: {msg}")
                            
                            with col2:
                                if st.button("✅ Keep", key=f"keep_{unique_key}"):
                                    st.info("TODO kept in code")
                            
                            with col3:
                                if st.button("🤖 AI Prompt", key=f"ai_{unique_key}"):
                                    st.session_state[f'show_prompt_{unique_key}'] = True
                            
                            # Show AI prompt if requested
                            if st.session_state.get(f'show_prompt_{unique_key}', False):
                                st.divider()
                                st.markdown("**🤖 AI Implementation Prompt:**")
                                prompt = st.session_state.fixer.generate_todo_prompt(issue)
                                st.code(prompt, language='markdown')
                                
                                if st.button("📋 Copy Prompt", key=f"copy_{unique_key}"):
                                    st.write("Prompt copied! (implement clipboard in production)")
                        
                        elif debt_type == 'bare_except':
                            if st.button("🔧 Fix to 'except Exception:'", key=f"fix_except_{unique_key}"):
                                success, msg = st.session_state.fixer.fix_single_issue('technical_debt', issue)
                                if isinstance(success, bool) and success:
                                    st.success(f"✅ {msg}")
                                    st.rerun()
        
        with tabs[2]:  # Long Functions
            st.subheader("Long Functions - Refactoring Suggestions")
            
            long_funcs = st.session_state.issues.get('long_functions', [])
            if long_funcs:
                for idx, issue in enumerate(long_funcs[:10]):
                    with st.expander(f"📏 {issue['function']}() - {issue['lines']} lines"):
                        st.write(f"**File:** {issue['file']}")
                        st.write(f"**Start Line:** {issue.get('start_line', 'N/A')}")
                        st.write(f"**Length:** {issue['lines']} lines (threshold: 50)")
                        
                        if st.button("🤖 Generate Refactor Prompt", key=f"refactor_{idx}"):
                            result = st.session_state.fixer._suggest_function_split(issue)
                            st.divider()
                            st.markdown("**Refactoring Suggestion:**")
                            st.info(result['message'])
                            st.markdown("**AI Prompt:**")
                            st.code(result['suggestion'], language='markdown')
            else:
                st.success("✅ No long functions found!")
        
        with tabs[3]:  # AI Prompts
            st.subheader("🤖 AI Assistant Integration")
            
            st.markdown("""
            This tab helps you generate precise prompts for AI assistants to fix code issues.
            
            ### How to use:
            1. Select issues from other tabs
            2. Click "AI Prompt" buttons
            3. Copy the generated prompts
            4. Paste into your AI assistant (Claude, GPT, etc.)
            5. Review and apply the suggested fixes
            """)
            
            # Summary of AI-fixable issues
            total_todos = len([i for i in tech_debt if i.get('type') in ['todo', 'fixme', 'hack']])
            total_long_funcs = len(long_funcs)
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("TODOs for AI", total_todos)
            with col2:
                st.metric("Functions to Refactor", total_long_funcs)
            
            if st.button("📋 Generate Batch AI Prompt"):
                batch_prompt = f"""Please help fix the following code issues in the TuoKit project:

## Summary
- {total_todos} TODO/FIXME items to implement
- {total_long_funcs} long functions to refactor
- {len(syntax_errors)} syntax errors to fix

## Priority Order
1. Fix syntax errors first (blocking issues)
2. Implement critical TODOs
3. Refactor long functions

For each fix:
- Make minimal, surgical changes
- Maintain code style consistency
- Add appropriate error handling
- Include brief comments explaining changes

Ready to start with the first issue?"""
                
                st.code(batch_prompt, language='markdown')

# Utility functions
def _extract_line_number(error_msg):
    """Extract line number from error message"""
    import re
    match = re.search(r'[Ll]ine (\d+)', str(error_msg))
    if match:
        return int(match.group(1))
    return 0

if __name__ == "__main__":
    main()

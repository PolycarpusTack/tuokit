"""
TuoKit Code Scanner - Standalone CLI Version
No dependencies required except Python standard library
"""
import os
import ast
import re
from pathlib import Path
from collections import defaultdict
import json
from datetime import datetime

# Configuration
SCAN_EXTENSIONS = ['.py']
IGNORE_DIRS = ['__pycache__', '.git', 'venv', 'env', 'tuokit-env']
MAX_FILE_SIZE = 1024 * 1024  # 1MB

class StandaloneCodeScanner:
    """Lightweight code scanner with no external dependencies"""
    
    def __init__(self, root_path):
        self.root_path = Path(root_path)
        self.issues = defaultdict(list)
        self.metrics = {
            'total_files': 0,
            'total_lines': 0,
            'syntax_errors': 0,
            'god_objects': 0,
            'long_functions': 0,
            'technical_debt': 0
        }
        
    def scan(self):
        """Run complete scan"""
        print(f"[SCAN] Scanning {self.root_path}...")
        
        # Get files
        files = list(self.get_python_files())
        self.metrics['total_files'] = len(files)
        print(f"Found {len(files)} Python files")
        
        # Scan each file
        for i, file_path in enumerate(files):
            print(f"\r[{i+1}/{len(files)}] {file_path.name}...", end='')
            
            # Check syntax
            syntax_ok = self.check_syntax(file_path)
            if syntax_ok:
                self.analyze_file(file_path)
        
        print("\n[OK] Scan complete!")
        return self.generate_report()
    
    def get_python_files(self):
        """Get all Python files to scan"""
        for file_path in self.root_path.rglob('*.py'):
            # Skip ignored directories
            if any(ignored in str(file_path) for ignored in IGNORE_DIRS):
                continue
            
            # Skip large files
            try:
                if file_path.stat().st_size > MAX_FILE_SIZE:
                    self.issues['large_files'].append({
                        'file': str(file_path),
                        'size': file_path.stat().st_size
                    })
                    continue
            except:
                continue
                
            yield file_path
    
    def check_syntax(self, file_path):
        """Check for syntax errors"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                ast.parse(content)
            return True
        except SyntaxError as e:
            self.metrics['syntax_errors'] += 1
            self.issues['syntax_errors'].append({
                'file': str(file_path),
                'error': f"Line {e.lineno}: {e.msg}",
                'line': e.lineno
            })
            return False
        except Exception as e:
            self.issues['read_errors'].append({
                'file': str(file_path),
                'error': str(e)
            })
            return False
    
    def analyze_file(self, file_path):
        """Analyze single file for issues"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
            
            self.metrics['total_lines'] += len(lines)
            
            # Parse AST
            try:
                tree = ast.parse(content)
                
                # Check for god objects
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        methods = [n for n in node.body 
                                 if isinstance(n, ast.FunctionDef)]
                        if len(methods) > 20:
                            self.issues['god_objects'].append({
                                'file': str(file_path),
                                'class': node.name,
                                'method_count': len(methods),
                                'line': node.lineno
                            })
                            self.metrics['god_objects'] += 1
                    
                    # Check for long functions
                    elif isinstance(node, ast.FunctionDef):
                        if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                            func_lines = node.end_lineno - node.lineno
                            if func_lines > 50:
                                self.issues['long_functions'].append({
                                    'file': str(file_path),
                                    'function': node.name,
                                    'lines': func_lines,
                                    'start_line': node.lineno
                                })
                                self.metrics['long_functions'] += 1
            except:
                pass
            
            # Check for technical debt patterns
            debt_patterns = [
                (r'#\s*TODO', 'todo'),
                (r'#\s*FIXME', 'fixme'),
                (r'#\s*HACK', 'hack'),
                (r'#\s*XXX', 'xxx'),
                (r'except\s*:', 'bare_except'),
            ]
            
            for line_num, line in enumerate(lines, 1):
                for pattern, debt_type in debt_patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        self.issues['technical_debt'].append({
                            'file': str(file_path),
                            'line': line_num,
                            'type': debt_type,
                            'content': line.strip()[:80]
                        })
                        self.metrics['technical_debt'] += 1
                        
        except Exception as e:
            self.issues['analysis_errors'].append({
                'file': str(file_path),
                'error': str(e)
            })
    
    def generate_report(self):
        """Generate analysis report"""
        # Calculate health score
        total_issues = (
            self.metrics['syntax_errors'] * 10 +
            self.metrics['god_objects'] * 5 +
            self.metrics['long_functions'] * 2 +
            self.metrics['technical_debt'] * 1
        )
        
        max_issues = max(self.metrics['total_files'] * 20, 1)
        health_score = max(0, 100 - (total_issues / max_issues * 100))
        
        report = {
            'scan_date': datetime.now().isoformat(),
            'project_path': str(self.root_path),
            'health_score': round(health_score, 1),
            'metrics': self.metrics,
            'top_issues': self._get_top_issues()
        }
        
        return report
    
    def _get_top_issues(self):
        """Get most important issues"""
        top_issues = []
        
        # Critical: Syntax errors
        for issue in self.issues['syntax_errors'][:5]:
            top_issues.append({
                'severity': 'CRITICAL',
                'type': 'Syntax Error',
                'file': Path(issue['file']).name,
                'details': issue['error']
            })
        
        # High: God objects
        for issue in self.issues['god_objects'][:3]:
            top_issues.append({
                'severity': 'HIGH',
                'type': 'God Object',
                'file': Path(issue['file']).name,
                'details': f"{issue['class']} has {issue['method_count']} methods"
            })
        
        # Medium: Long functions
        for issue in self.issues['long_functions'][:3]:
            top_issues.append({
                'severity': 'MEDIUM',
                'type': 'Long Function',
                'file': Path(issue['file']).name,
                'details': f"{issue['function']}() is {issue['lines']} lines"
            })
        
        return top_issues
    
    def print_summary(self, report):
        """Print readable summary"""
        print("\n" + "="*60)
        print("CODE HEALTH REPORT")
        print("="*60)
        
        print(f"\n[SCORE] Health Score: {report['health_score']}%")
        
        print("\n[METRICS]:")
        print(f"  Files scanned:    {report['metrics']['total_files']}")
        print(f"  Total lines:      {report['metrics']['total_lines']:,}")
        print(f"  Syntax errors:    {report['metrics']['syntax_errors']}")
        print(f"  God objects:      {report['metrics']['god_objects']}")
        print(f"  Long functions:   {report['metrics']['long_functions']}")
        print(f"  Technical debt:   {report['metrics']['technical_debt']}")
        
        if report['top_issues']:
            print("\n[TOP ISSUES]:")
            for issue in report['top_issues']:
                icon = {'CRITICAL': 'X', 'HIGH': '!', 'MEDIUM': '*'}.get(issue['severity'], '-')
                print(f"\n  [{icon}] [{issue['severity']}] {issue['type']}")
                print(f"     File: {issue['file']}")
                print(f"     {issue['details']}")
        
        print("\n" + "="*60)

def main():
    """CLI entry point"""
    import sys
    
    # Get path from argument or use default
    if len(sys.argv) > 1:
        project_path = sys.argv[1]
    else:
        project_path = "C:/Projects/Tuokit"
    
    # Run scan
    scanner = StandaloneCodeScanner(project_path)
    report = scanner.scan()
    
    # Print summary
    scanner.print_summary(report)
    
    # Save detailed report
    report_file = Path(project_path) / f"code_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(report_file, 'w') as f:
        json.dump({
            **report,
            'issues': dict(scanner.issues)
        }, f, indent=2)
    
    print(f"\n[SAVED] Detailed report saved to: {report_file}")
    
    # Return health score as exit code (0-100, where 100 is best)
    return int(100 - report['health_score'])

if __name__ == "__main__":
    exit(main())

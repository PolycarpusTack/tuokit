# 🏥 TuoKit Enhanced Code Scanner v2.0 - User Guide

## 🚀 Quick Start

### Launch the Scanner
```bash
cd C:/Projects/Tuokit/tools
python launch_enhanced_scanner.py
```

Or simply double-click `launch_enhanced_scanner.py` in Windows Explorer.

### First Scan
1. The scanner opens at http://localhost:8504
2. Verify the project path (default: `C:/Projects/Tuokit`)
3. Click **"🚀 Run Full Scan"**
4. Wait for analysis to complete (progress shown)
5. Explore issues and apply fixes!

## ✨ Key Features

### 1. Granular Issue Fixes
Every detected issue has its own fix button - no more "fix all or nothing"!

**Example: Syntax Error Fix**
```
❌ code_tools.py - Line 99
   Error: Multiple statements on one line
   Code: else:            try:
   
   [🔧 Auto Fix] [👀 Preview]
```

### 2. Advanced TODO Management
For each TODO/FIXME/HACK, you get three options:

- **🗑️ Remove** - Delete outdated TODOs
- **✅ Keep** - Mark as important, keep in code  
- **🤖 AI Prompt** - Generate implementation prompt

**Example TODO:**
```python
# TODO: Add caching to improve performance

[🗑️ Remove] [✅ Keep] [🤖 Generate AI Prompt]
```

### 3. AI Prompt Generation
Generates surgical, context-aware prompts for:
- TODO implementations
- Function refactoring
- Batch fixes

**Generated Prompt Example:**
```markdown
📍 Location: `database.py` line 45
📝 Task: Add connection pooling for better performance

Context:
[15 lines of surrounding code]

Requirements:
✅ Implement ONLY what the TODO describes
🎯 Keep the solution minimal and focused
[... more guidelines ...]
```

## 📊 Understanding the Dashboard

### Health Score
- **90-100%**: Excellent - minimal issues
- **70-89%**: Good - some cleanup needed
- **50-69%**: Fair - significant issues
- **Below 50%**: Poor - major refactoring needed

### Issue Severity
- **🔴 Critical**: Syntax errors (block execution)
- **🟡 High**: God objects, security issues
- **🟠 Medium**: Long functions, complexity
- **🟢 Low**: TODOs, style issues

## 🛠️ Feature Deep Dive

### Syntax Error Fixes
The scanner can automatically fix:
- Combined statements (`else: try:` → separate lines)
- Missing newlines between statements
- Unterminated strings
- Incorrect indentation after colons

### TODO Management Workflow
1. **Scan** - Identifies all TODO/FIXME/HACK comments
2. **Triage** - Decide: Remove, Keep, or Implement
3. **Generate** - Create AI prompts for implementation
4. **Track** - Monitor which TODOs were addressed

### Long Function Refactoring
For functions over 50 lines:
1. Click "🤖 Generate Refactoring Plan"
2. Get detailed splitting suggestions
3. Copy prompt to your AI assistant
4. Apply refactored code
5. Re-scan to verify improvement

### Backup System
- Every fix creates a timestamped backup
- Backups stored in: `C:/Projects/Tuokit/backups/enhanced_scanner/`
- Session tracking for easy rollback
- JSON log of all changes made

## 💡 Best Practices

### Scan Strategy
1. **Initial Scan**: Run full scan to baseline
2. **Fix Critical**: Address syntax errors first
3. **Clean Debt**: Remove outdated TODOs
4. **Implement**: Use AI for important TODOs
5. **Refactor**: Split long functions
6. **Verify**: Re-scan to see improvements

### AI Integration Tips
1. **Use Claude or GPT-4** for best results
2. **Provide context** about your project
3. **Review suggestions** before applying
4. **Test incrementally** after each fix
5. **Commit often** to version control

### Performance Tips
- Limit initial scan to 200 files
- Exclude test files if not needed
- Fix issues in small batches
- Use "New Scan" to reset between sessions

## 🎯 Common Workflows

### Workflow 1: Quick Cleanup
```
1. Run scan
2. Fix all syntax errors (one by one)
3. Remove outdated TODOs
4. Export report
```

### Workflow 2: Feature Implementation
```
1. Run scan
2. Filter TODOs by "fixme"
3. Generate AI prompts for each
4. Implement with AI assistance
5. Mark completed TODOs as removed
```

### Workflow 3: Code Refactoring
```
1. Run scan with deep analysis
2. Sort long functions by size
3. Generate refactor prompts for top 5
4. Apply refactoring incrementally
5. Verify with new scan
```

## 📈 Metrics Explained

### File Metrics
- **Total Files**: Python files analyzed
- **Total Lines**: Aggregate line count
- **Excluded Files**: Large or test files skipped

### Issue Metrics
- **Syntax Errors**: Must fix first
- **God Objects**: Classes with >20 methods
- **Long Functions**: Functions >50 lines
- **Technical Debt**: TODOs + bare excepts

### Fix Metrics
- **Fixes Applied**: Changes made this session
- **Backups Created**: Safety snapshots
- **Success Rate**: Percentage of successful fixes

## 🔧 Advanced Features

### Export Options
1. **JSON Report**: Machine-readable format
2. **Markdown Report**: Human-readable summary
3. **Fix Log**: Detailed change history

### Batch Operations
- **Master AI Prompt**: All issues in one prompt
- **Fix All Syntax**: Batch syntax fixes (coming soon)
- **Remove All TODOs**: Bulk TODO cleanup (use carefully)

### Custom Patterns
Edit `enhanced_scanner_full.py` to add:
- New issue patterns
- Custom fix logic
- Additional languages (future)

## 🐛 Troubleshooting

### Scanner Won't Start
```bash
# Install dependencies manually
pip install streamlit pandas

# Try direct launch
streamlit run enhanced_scanner_full.py
```

### Fixes Fail to Apply
- Check file permissions
- Ensure files aren't open in editor
- Verify backup directory is writable
- Check for syntax errors in target file

### Performance Issues
- Reduce max files to scan
- Exclude unnecessary directories
- Close other applications
- Use standalone scanner for large codebases

## 🎨 UI Navigation

### Sidebar
- **Project Path**: Root directory to scan
- **Scan Options**: Configure analysis
- **Run Scan**: Start analysis
- **Fix Summary**: Applied fixes count

### Main Area Tabs
1. **Syntax Errors**: Critical issues
2. **TODOs & Debt**: Technical debt items
3. **Long Functions**: Refactoring targets
4. **AI Prompts**: Batch operations
5. **Summary**: Overall metrics and export

### Issue Cards
Each issue shows:
- File name and line number
- Error or issue description
- Relevant code snippet
- Action buttons
- Fix status

## 📝 Example Session

```
1. Launch scanner → http://localhost:8504
2. Click "Run Full Scan" → 101 files analyzed
3. Health Score: 87.9% → Room for improvement
4. Syntax Errors tab → 5 errors found
5. Fix each syntax error → All green
6. TODOs tab → 74 technical debt items
7. Remove 20 outdated TODOs → Cleaner code
8. Generate AI prompts for 5 FIXMEs → Copy to Claude
9. Long Functions tab → 60 functions over 50 lines
10. Generate refactor plan for largest → 91 lines to split
11. Summary tab → Export JSON report
12. Health Score: 92.3% → Much better!
```

## 🚦 Next Steps

After your first scan:
1. **Set up CI integration** - Run scanner in pipeline
2. **Create team standards** - Agree on thresholds
3. **Schedule regular scans** - Weekly recommended
4. **Track trends** - Monitor health score over time
5. **Customize rules** - Add project-specific checks

---

**Happy Scanning!** 🎉

For issues or suggestions, check the source code in `enhanced_scanner_full.py`

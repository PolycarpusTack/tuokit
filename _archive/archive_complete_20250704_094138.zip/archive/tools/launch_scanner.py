"""
Quick launcher for TuoKit Code Scanner
Handles restarts and dependencies
"""
import subprocess
import sys
import os

def main():
    print("=== TuoKit Code Health Scanner ===\n")
    
    # Change to tools directory
    os.chdir("C:/Projects/Tuokit/tools")
    
    # Check dependencies
    try:
        import streamlit
        import pandas
        import plotly
        import networkx
        print("[OK] All dependencies installed")
    except ImportError as e:
        print(f"[ERROR] Missing dependency: {e}")
        print("\nInstalling dependencies...")
        subprocess.run([sys.executable, "-m", "pip", "install", 
                       "streamlit", "pandas", "plotly", "networkx"])
    
    # Launch the scanner
    print("\n[LAUNCH] Starting Code Health Scanner...")
    print("URL: http://localhost:8502\n")
    
    try:
        subprocess.run([sys.executable, "-m", "streamlit", "run", 
                       "integrated_code_scanner.py", 
                       "--server.port", "8502",
                       "--server.headless", "true"])
    except KeyboardInterrupt:
        print("\n[EXIT] Scanner stopped by user")
    except Exception as e:
        print(f"\n[ERROR] {e}")
        print("\nTry running the standalone scanner instead:")
        print(f"  python {os.path.join(os.getcwd(), 'standalone_scanner.py')}")

if __name__ == "__main__":
    main()

"""
TuoKit Enhanced Code Scanner - Full Production Version
Complete code quality tool with granular fixes and AI-powered TODO management
"""
import streamlit as st
import os
import ast
import re
from pathlib import Path
from datetime import datetime
import json
from collections import defaultdict
import shutil
import traceback
import sys

# Add tools directory to path for imports
sys.path.append(str(Path(__file__).parent))
from clipboard_utils import display_prompt_with_copy

# Configuration
SCAN_EXTENSIONS = ['.py']
IGNORE_DIRS = ['__pycache__', '.git', 'venv', 'env', 'tuokit-env', 'backups']
MAX_FILE_SIZE = 1024 * 1024  # 1MB
BACKUP_DIR = "C:/Projects/Tuokit/backups/enhanced_scanner"

class EnhancedCodeScanner:
    """Complete scanner with all enhanced features"""
    
    def __init__(self, root_path):
        self.root_path = Path(root_path)
        self.issues = defaultdict(list)
        self.metrics = {
            'total_files': 0,
            'total_lines': 0,
            'syntax_errors': 0,
            'god_objects': 0,
            'long_functions': 0,
            'technical_debt': 0,
            'todos': 0,
            'fixmes': 0,
            'hacks': 0,
            'bare_excepts': 0
        }
        self.file_cache = {}
        
    def scan_directory(self):
        """Scan all Python files in directory"""
        files_to_scan = []
        
        for file_path in self.root_path.rglob('*.py'):
            # Skip ignored directories
            if any(ignored in str(file_path) for ignored in IGNORE_DIRS):
                continue
            
            # Skip large files
            try:
                if file_path.stat().st_size > MAX_FILE_SIZE:
                    self.issues['large_files'].append({
                        'file': str(file_path),
                        'size': file_path.stat().st_size
                    })
                    continue
            except:
                continue
                
            files_to_scan.append(file_path)
        
        self.metrics['total_files'] = len(files_to_scan)
        return files_to_scan
    
    def check_syntax(self, file_path):
        """Check for syntax errors with detailed info"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                self.file_cache[str(file_path)] = content
                ast.parse(content)
            return True, None
        except SyntaxError as e:
            self.metrics['syntax_errors'] += 1
            # Get the problematic line
            try:
                lines = content.splitlines()
                problem_line = lines[e.lineno - 1] if e.lineno <= len(lines) else ""
            except:
                problem_line = ""
                
            return False, {
                'msg': str(e.msg),
                'line': e.lineno,
                'offset': e.offset,
                'text': e.text or problem_line
            }
        except Exception as e:
            return False, {'msg': f"Error reading file: {str(e)}", 'line': 0}
    
    def analyze_code_structure(self, file_path):
        """Analyze code for structural issues"""
        try:
            content = self.file_cache.get(str(file_path))
            if not content:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    self.file_cache[str(file_path)] = content
                    
            lines = content.splitlines()
            self.metrics['total_lines'] += len(lines)
            
            # Parse AST for deeper analysis
            try:
                tree = ast.parse(content)
                
                # Check for god objects
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef):
                        methods = [n for n in node.body if isinstance(n, ast.FunctionDef)]
                        if len(methods) > 20:
                            self.issues['god_objects'].append({
                                'file': str(file_path),
                                'class': node.name,
                                'method_count': len(methods),
                                'line': node.lineno,
                                'severity': 'high'
                            })
                            self.metrics['god_objects'] += 1
                    
                    # Check for long functions
                    elif isinstance(node, ast.FunctionDef):
                        if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                            func_lines = node.end_lineno - node.lineno
                            if func_lines > 50:
                                self.issues['long_functions'].append({
                                    'file': str(file_path),
                                    'function': node.name,
                                    'lines': func_lines,
                                    'start_line': node.lineno,
                                    'end_line': node.end_lineno,
                                    'severity': 'medium'
                                })
                                self.metrics['long_functions'] += 1
                
            except:
                pass  # Already caught syntax errors
            
            # Check for technical debt patterns
            debt_patterns = [
                (r'#\s*TODO\s*:?\s*(.+)', 'todo'),
                (r'#\s*FIXME\s*:?\s*(.+)', 'fixme'),
                (r'#\s*HACK\s*:?\s*(.+)', 'hack'),
                (r'#\s*XXX\s*:?\s*(.+)', 'xxx'),
                (r'except\s*:', 'bare_except'),
            ]
            
            for line_num, line in enumerate(lines, 1):
                for pattern, debt_type in debt_patterns:
                    match = re.search(pattern, line)
                    if match:
                        issue = {
                            'file': str(file_path),
                            'line': line_num,
                            'type': debt_type,
                            'content': line.strip(),
                            'severity': 'low'
                        }
                        
                        # Extract TODO message if available
                        if debt_type in ['todo', 'fixme', 'hack', 'xxx'] and match.groups():
                            issue['message'] = match.group(1).strip()
                        
                        self.issues['technical_debt'].append(issue)
                        self.metrics['technical_debt'] += 1
                        self.metrics[f'{debt_type}s'] = self.metrics.get(f'{debt_type}s', 0) + 1
                        
        except Exception as e:
            self.issues['analysis_errors'].append({
                'file': str(file_path),
                'error': str(e)
            })

class EnhancedFixEngine:
    """Apply fixes with full backup and rollback support"""
    
    def __init__(self, backup_dir=BACKUP_DIR):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.applied_fixes = []
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
    def create_backup(self, file_path):
        """Create timestamped backup with session tracking"""
        file_path = Path(file_path)
        backup_name = f"{file_path.stem}_{self.session_id}{file_path.suffix}"
        backup_path = self.backup_dir / backup_name
        
        shutil.copy2(file_path, backup_path)
        
        # Also track in session log
        session_log = self.backup_dir / f"session_{self.session_id}.json"
        log_data = []
        if session_log.exists():
            with open(session_log, 'r') as f:
                log_data = json.load(f)
        
        log_data.append({
            'timestamp': datetime.now().isoformat(),
            'original': str(file_path),
            'backup': str(backup_path)
        })
        
        with open(session_log, 'w') as f:
            json.dump(log_data, f, indent=2)
            
        return backup_path
    
    def fix_syntax_error(self, issue):
        """Fix specific syntax error patterns"""
        file_path = Path(issue['file'])
        line_num = issue.get('line', 0)
        
        try:
            # Create backup
            backup = self.create_backup(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num > 0 and line_num <= len(lines):
                line = lines[line_num - 1]
                original_line = line
                fixed = False
                
                # Get the error text for better pattern matching
                error_text = issue.get('text', line).strip()
                
                # Pattern 1: Multiple statements on one line with colon
                # Handle variations with different spacing
                if ':' in error_text:
                    # More flexible patterns to catch various formats
                    patterns = [
                        # Standard control flow patterns
                        (r'(\s*else\s*:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*elif\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*if\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*try\s*:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*except.*:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*finally\s*:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*with\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*for\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*while\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*def\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        (r'(\s*class\s+.+:)\s+(\S.*)', r'\1\n    \2'),
                        # Handle multiple spaces between statements
                        (r'(\S.*)\s{2,}(try\s*:)', r'\1\n\2'),
                        (r'(\S.*)\s{2,}(except.*:)', r'\1\n\2'),
                        (r'(\S.*)\s{2,}(if\s+.*:)', r'\1\n\2'),
                        (r'(\S.*)\s{2,}(with\s+.*:)', r'\1\n\2'),
                        # General case: something followed by spaces and a keyword with colon
                        (r'(.+?)\s{2,}(\w+\s*:)', r'\1\n\2'),
                        # Return statement followed by except
                        (r'(\s*return\s+.+?)\s+(except\s+\w+)', r'\1\n\2'),
                        (r'(\s*return\s+.+?)\s+(except\s*:)', r'\1\n\2'),
                    ]
                    
                    for pattern, replacement in patterns:
                        match = re.search(pattern, line)
                        if match:
                            # Calculate proper indentation
                            indent = len(line) - len(line.lstrip())
                            
                            # Apply the fix
                            new_line = re.sub(pattern, replacement, line)
                            
                            # Ensure proper indentation for the second part
                            if '\n' in new_line:
                                parts = new_line.split('\n', 1)
                                if len(parts) == 2 and parts[1].strip():
                                    # Add appropriate indentation to second part
                                    if any(keyword in parts[0] for keyword in ['if', 'else', 'elif', 'try', 'except', 'with', 'for', 'while', 'def', 'class']):
                                        parts[1] = ' ' * (indent + 4) + parts[1].lstrip()
                                    else:
                                        parts[1] = ' ' * indent + parts[1].lstrip()
                                    new_line = '\n'.join(parts)
                            
                            lines[line_num - 1] = new_line
                            fixed = True
                            break
                
                # Pattern 2: Unterminated string literal
                if not fixed and 'unterminated string' in str(issue.get('error', '')).lower():
                    # Count quotes to find the issue
                    single_quotes = line.count("'") - line.count("\\'")
                    double_quotes = line.count('"') - line.count('\\"')
                    triple_single = line.count("'''")
                    triple_double = line.count('"""')
                    
                    # Adjust for triple quotes
                    single_quotes -= triple_single * 3
                    double_quotes -= triple_double * 3
                    
                    if single_quotes % 2 != 0:
                        lines[line_num - 1] = line.rstrip() + "'\n"
                        fixed = True
                    elif double_quotes % 2 != 0:
                        lines[line_num - 1] = line.rstrip() + '"\n'
                        fixed = True
                    elif triple_single % 2 != 0:
                        lines[line_num - 1] = line.rstrip() + "'''\n"
                        fixed = True
                    elif triple_double % 2 != 0:
                        lines[line_num - 1] = line.rstrip() + '"""\n'
                        fixed = True
                
                # Pattern 3: Missing indentation after colon
                if not fixed and line.strip().endswith(':') and line_num < len(lines):
                    next_line = lines[line_num] if line_num < len(lines) else ""
                    if next_line.strip() and not next_line[0].isspace():
                        # Add indentation to next line
                        indent = len(line) - len(line.lstrip())
                        lines[line_num] = ' ' * (indent + 4) + next_line.lstrip()
                        fixed = True
                
                if fixed:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(lines)
                    
                    self.applied_fixes.append({
                        'file': str(file_path),
                        'line': line_num,
                        'type': 'syntax_error',
                        'original': original_line.strip(),
                        'fixed': lines[line_num - 1].strip(),
                        'backup': str(backup)
                    })
                    
                    return True, f"Fixed syntax error at line {line_num}"
                else:
                    # Provide more helpful error message
                    return False, f"Could not auto-fix this pattern. Line content: '{error_text}'. Try manual fix or use AI prompt for help."
            
            return False, "Invalid line number"
            
        except Exception as e:
            return False, f"Error applying fix: {str(e)}"
    
    def fix_bare_except(self, issue):
        """Fix bare except statements"""
        file_path = Path(issue['file'])
        line_num = issue['line']
        
        try:
            backup = self.create_backup(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num <= len(lines):
                line = lines[line_num - 1]
                if 'except:' in line:
                    # Preserve indentation and comments
                    new_line = line.replace('except:', 'except Exception:')
                    lines[line_num - 1] = new_line
                    
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.writelines(lines)
                    
                    self.applied_fixes.append({
                        'file': str(file_path),
                        'line': line_num,
                        'type': 'bare_except',
                        'original': line.strip(),
                        'fixed': new_line.strip(),
                        'backup': str(backup)
                    })
                    
                    return True, "Fixed bare except"
                    
        except Exception as e:
            return False, f"Error: {str(e)}"
        
        return False, "Could not fix bare except"
    
    def remove_todo(self, issue):
        """Remove TODO/FIXME/HACK from code"""
        file_path = Path(issue['file'])
        line_num = issue['line']
        
        try:
            backup = self.create_backup(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            if line_num <= len(lines):
                line = lines[line_num - 1]
                original = line
                
                # Remove TODO comment patterns
                patterns = [
                    r'#\s*TODO\s*:?\s*',
                    r'#\s*FIXME\s*:?\s*',
                    r'#\s*HACK\s*:?\s*',
                    r'#\s*XXX\s*:?\s*'
                ]
                
                for pattern in patterns:
                    line = re.sub(pattern, '# ', line, flags=re.IGNORECASE)
                
                # If line is now just empty comment, remove entire line
                if line.strip() in ['#', '# ']:
                    lines.pop(line_num - 1)
                    action = "Removed entire TODO line"
                else:
                    lines[line_num - 1] = line
                    action = "Removed TODO marker, kept comment"
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.writelines(lines)
                
                self.applied_fixes.append({
                    'file': str(file_path),
                    'line': line_num,
                    'type': 'remove_todo',
                    'original': original.strip(),
                    'action': action,
                    'backup': str(backup)
                })
                
                return True, action
                
        except Exception as e:
            return False, f"Error: {str(e)}"
    
    def generate_todo_prompt(self, issue):
        """Generate surgical AI prompt for TODO implementation"""
        file_path = Path(issue['file'])
        line_num = issue['line']
        message = issue.get('message', issue.get('content', ''))
        
        # Get context
        context = self._get_context(file_path, line_num, 15)
        
        # Analyze TODO type
        todo_type = "feature"
        if any(word in message.lower() for word in ['performance', 'optimize', 'speed', 'cache']):
            todo_type = "performance"
        elif any(word in message.lower() for word in ['error', 'exception', 'handle', 'catch']):
            todo_type = "error_handling"
        elif any(word in message.lower() for word in ['security', 'auth', 'validate', 'sanitize']):
            todo_type = "security"
        
        prompt = f"""Please implement the following {issue['type'].upper()} item:

📍 **Location**: `{file_path.name}` line {line_num}
📝 **Task**: {message}
🏷️ **Type**: {todo_type}

**Context (surrounding code):**
```python
{context}
```

**Requirements:**
1. ✅ Implement ONLY what the {issue['type'].upper()} describes
2. 🎯 Keep the solution minimal and focused
3. 🎨 Match the surrounding code style exactly
4. 🛡️ Include appropriate error handling
5. 💬 Add a brief comment explaining the implementation
6. 🚫 Do not modify any other parts of the code
7. ⚡ Ensure the solution is production-ready

**Expected Solution Format:**
```python
# Line {line_num} - Replace the {issue['type'].upper()} line with:
<your implementation here>
```

**Additional Considerations for {todo_type}:**
"""
        
        # Add type-specific guidelines
        if todo_type == "performance":
            prompt += """
- Consider caching if appropriate
- Avoid premature optimization
- Measure impact if possible
- Document any trade-offs"""
        elif todo_type == "error_handling":
            prompt += """
- Use specific exception types
- Provide helpful error messages
- Consider retry logic if appropriate
- Log errors appropriately"""
        elif todo_type == "security":
            prompt += """
- Follow security best practices
- Validate all inputs
- Use parameterized queries for DB operations
- Consider rate limiting if applicable"""
        
        return prompt
    
    def generate_syntax_error_prompt(self, issue):
        """Generate AI prompt for fixing syntax errors"""
        file_path = Path(issue['file'])
        line_num = issue.get('line', 0)
        error_msg = issue.get('error', 'syntax error')
        error_text = issue.get('text', '')
        
        # Get context
        context = self._get_context(file_path, line_num, 15)
        
        prompt = f"""Please fix the following syntax error in Python code:

📍 **Location**: `{file_path.name}` line {line_num}
❌ **Error**: {error_msg}
📝 **Problematic Line**: 
```python
{error_text}
```

**Context (surrounding code):**
```python
{context}
```

**Requirements:**
1. ✅ Fix ONLY the syntax error on line {line_num}
2. 🎯 Make the minimal change necessary
3. 🎨 Preserve the original indentation
4. 💡 Maintain the intended logic
5. 🚫 Do not modify any other lines
6. 📝 Explain what was wrong and how you fixed it

**Common Patterns to Check:**
- Multiple statements on one line (need to split)
- Missing colons after if/else/try/except/with/for/while
- Unterminated strings or brackets
- Incorrect indentation
- Missing newlines between statements

**Expected Output Format:**
```python
# Line {line_num} - Fixed version:
<corrected line here>
```

**Explanation:**
<Brief explanation of what was wrong and what you changed>

Please provide the corrected line that will replace line {line_num}."""
        
        return prompt
        """Generate AI prompt for function refactoring"""
        file_path = Path(issue['file'])
        
        prompt = f"""Please refactor this long function following clean code principles:

📍 **File**: `{file_path.name}`
🔧 **Function**: `{issue['function']}()`
📏 **Current Length**: {issue['lines']} lines (lines {issue.get('start_line', '?')}-{issue.get('end_line', '?')})

**Refactoring Requirements:**
1. 🎯 Split into 2-4 smaller functions with single responsibilities
2. 📏 Each function should be under 30 lines
3. ✅ Maintain the exact same functionality and behavior
4. 📝 Use descriptive, verb-based function names
5. 💬 Add comprehensive docstrings to each function
6. 🛡️ Preserve all error handling and edge cases
7. 🧪 Ensure the refactored code is easily testable

**Analysis Guidelines:**
- Identify logical sections within the function
- Look for repeated code that can be extracted
- Find different levels of abstraction
- Separate data processing from business logic
- Extract complex conditions into well-named functions

**Expected Output Structure:**
```python
def {issue['function']}_validate_input(args):
    \"\"\"Validate and preprocess input arguments.
    
    Args:
        args: Input arguments to validate
        
    Returns:
        Validated arguments
        
    Raises:
        ValueError: If validation fails
    \"\"\"
    # Validation logic
    
def {issue['function']}_process_data(validated_args):
    \"\"\"Core processing logic.
    
    Args:
        validated_args: Pre-validated arguments
        
    Returns:
        Processed result
    \"\"\"
    # Processing logic
    
def {issue['function']}(original_args):
    \"\"\"Main orchestrator function - maintains original interface.
    
    Original docstring here...
    \"\"\"
    validated = {issue['function']}_validate_input(original_args)
    result = {issue['function']}_process_data(validated)
    return result
```

Please provide the complete refactored implementation."""
        
        return prompt
    
    def _get_context(self, file_path, line_num, context_size=10):
        """Get code context around a line"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start = max(0, line_num - context_size)
            end = min(len(lines), line_num + context_size)
            
            context = []
            for i in range(start, end):
                marker = ">>>" if i == line_num - 1 else "   "
                context.append(f"{marker} {i+1}: {lines[i].rstrip()}")
            
            return '\n'.join(context)
            
        except Exception:
            return "Could not read context"
    
    def rollback_fix(self, fix_record):
        """Rollback a specific fix using backup"""
        try:
            backup_path = Path(fix_record['backup'])
            original_path = Path(fix_record['file'])
            
            if backup_path.exists():
                shutil.copy2(backup_path, original_path)
                return True, "Successfully rolled back"
        except Exception as e:
            return False, f"Rollback failed: {e}"
        
        return False, "Backup not found"

def main():
    st.set_page_config(
        page_title="TuoKit Enhanced Code Scanner",
        page_icon="🏥",
        layout="wide"
    )
    
    # Initialize session state
    if 'scanner' not in st.session_state:
        st.session_state.scanner = None
    if 'fixer' not in st.session_state:
        st.session_state.fixer = EnhancedFixEngine()
    if 'scan_complete' not in st.session_state:
        st.session_state.scan_complete = False
    if 'fixed_issues' not in st.session_state:
        st.session_state.fixed_issues = []
    
    # Header
    st.title("🏥 TuoKit Enhanced Code Scanner")
    st.markdown("""
    **Production-ready code scanner** with granular fixes and AI-powered TODO management
    
    ✨ Fix individual issues | 🗑️ Remove outdated TODOs | 🤖 Generate AI prompts
    """)
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        project_path = st.text_input(
            "Project Path",
            value="C:/Projects/Tuokit",
            help="Root directory to scan"
        )
        
        scan_options = st.expander("Scan Options", expanded=True)
        with scan_options:
            max_files = st.number_input(
                "Max files to scan",
                min_value=10,
                max_value=1000,
                value=200,
                step=50,
                help="Limit for performance"
            )
            
            include_tests = st.checkbox("Include test files", value=True)
            deep_analysis = st.checkbox("Deep code analysis", value=True)
        
        st.divider()
        
        # Scan button
        if st.button("🚀 Run Full Scan", type="primary", disabled=st.session_state.scan_complete):
            run_scan(project_path, max_files, include_tests, deep_analysis)
        
        if st.session_state.scan_complete:
            if st.button("🔄 New Scan"):
                # Reset state
                st.session_state.scanner = None
                st.session_state.scan_complete = False
                st.session_state.fixed_issues = []
                st.rerun()
        
        # Fix summary
        if st.session_state.fixed_issues:
            st.divider()
            st.success(f"✅ {len(st.session_state.fixed_issues)} fixes applied")
            
            with st.expander("View fixes"):
                for fix in st.session_state.fixed_issues:
                    st.text(f"• {Path(fix['file']).name}:{fix['line']}")
    
    # Main content area
    if st.session_state.scanner and st.session_state.scan_complete:
        display_results()
    elif st.session_state.scanner:
        # Show progress
        st.info("🔍 Scanning in progress...")
        progress_placeholder = st.empty()
        with progress_placeholder.container():
            st.progress(0.5)
            st.text("Analyzing code structure...")
    else:
        # Welcome screen
        st.info("👈 Configure options and click 'Run Full Scan' to begin")
        
        # Feature highlights
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("""
            ### 🔧 Granular Fixes
            - Fix individual issues
            - Preview changes first
            - Automatic backups
            - Rollback support
            """)
        
        with col2:
            st.markdown("""
            ### 💭 TODO Management  
            - Remove outdated TODOs
            - Keep important ones
            - Generate AI prompts
            - Track decisions
            """)
        
        with col3:
            st.markdown("""
            ### 🤖 AI Integration
            - Surgical prompts
            - Context-aware
            - Copy-paste ready
            - Best practices
            """)

def run_scan(project_path, max_files, include_tests, deep_analysis):
    """Execute the code scan"""
    scanner = EnhancedCodeScanner(project_path)
    
    with st.spinner("🔍 Discovering Python files..."):
        files = scanner.scan_directory()
        
        # Filter test files if needed
        if not include_tests:
            files = [f for f in files if 'test' not in f.name.lower()]
        
        # Limit files
        files = files[:max_files]
        
        st.session_state.scanner = scanner
    
    # Progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    for i, file_path in enumerate(files):
        # Update progress
        progress = (i + 1) / len(files)
        progress_bar.progress(progress)
        status_text.text(f"Scanning: {file_path.name}")
        
        # Check syntax
        syntax_ok, error_info = scanner.check_syntax(file_path)
        if not syntax_ok:
            scanner.issues['syntax_errors'].append({
                'file': str(file_path),
                'error': error_info.get('msg', 'Unknown error'),
                'line': error_info.get('line', 0),
                'text': error_info.get('text', ''),
                'severity': 'critical'
            })
        else:
            # Analyze structure if syntax is OK
            if deep_analysis:
                scanner.analyze_code_structure(file_path)
    
    # Clear progress
    progress_bar.empty()
    status_text.empty()
    
    # Calculate health score
    calculate_health_score(scanner)
    
    st.session_state.scan_complete = True
    st.success(f"✅ Scan complete! Analyzed {len(files)} files")
    st.rerun()

def calculate_health_score(scanner):
    """Calculate overall code health score"""
    total_issues = (
        scanner.metrics.get('syntax_errors', 0) * 10 +
        scanner.metrics.get('god_objects', 0) * 5 +
        scanner.metrics.get('long_functions', 0) * 2 +
        scanner.metrics.get('technical_debt', 0) * 1
    )
    
    max_issues = scanner.metrics.get('total_files', 1) * 20
    score = max(0, 100 - (total_issues / max_issues * 100))
    scanner.metrics['health_score'] = round(score, 1)

def display_results():
    """Display scan results with fix options"""
    scanner = st.session_state.scanner
    fixer = st.session_state.fixer
    
    # Metrics row
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric(
            "Health Score",
            f"{scanner.metrics.get('health_score', 0)}%",
            help="Overall code health (0-100)"
        )
    
    with col2:
        st.metric("Files Scanned", scanner.metrics['total_files'])
    
    with col3:
        st.metric("Syntax Errors", scanner.metrics['syntax_errors'])
    
    with col4:
        st.metric("TODOs", scanner.metrics.get('todos', 0))
    
    with col5:
        st.metric("Long Functions", scanner.metrics['long_functions'])
    
    # Issue tabs
    tabs = st.tabs([
        "🚨 Syntax Errors",
        "💭 TODOs & Debt", 
        "📏 Long Functions",
        "🤖 AI Prompts",
        "📊 Summary"
    ])
    
    with tabs[0]:  # Syntax Errors
        display_syntax_errors(scanner, fixer)
    
    with tabs[1]:  # TODOs
        display_todos(scanner, fixer)
    
    with tabs[2]:  # Long Functions
        display_long_functions(scanner, fixer)
    
    with tabs[3]:  # AI Prompts
        display_ai_prompts(scanner)
    
    with tabs[4]:  # Summary
        display_summary(scanner, fixer)

def display_syntax_errors(scanner, fixer):
    """Display syntax errors with fix options"""
    st.subheader("Syntax Errors - Click to Fix")
    
    syntax_errors = scanner.issues.get('syntax_errors', [])
    
    if not syntax_errors:
        st.success("✅ No syntax errors found!")
        return
    
    st.error(f"Found {len(syntax_errors)} syntax errors that prevent code execution")
    
    for idx, issue in enumerate(syntax_errors):
        issue_id = f"syntax_{idx}"
        
        # Check if already fixed
        if any(f['file'] == issue['file'] and f['line'] == issue['line'] 
               for f in st.session_state.fixed_issues):
            continue
        
        with st.expander(
            f"❌ {Path(issue['file']).name} - Line {issue.get('line', '?')}",
            expanded=idx < 3  # Expand first 3
        ):
            # Error details
            st.error(issue['error'])
            
            if issue.get('text'):
                st.code(issue['text'], language='python')
            
            st.caption(f"File: `{issue['file']}`")
            
            # Fix options
            col1, col2, col3 = st.columns([1, 1, 1])
            
            with col1:
                if st.button("🔧 Auto Fix", key=f"fix_{issue_id}"):
                    with st.spinner("Applying fix..."):
                        success, message = fixer.fix_syntax_error(issue)
                        if success:
                            st.success(f"✅ {message}")
                            st.session_state.fixed_issues.append(issue)
                            st.rerun()
                        else:
                            st.error(f"❌ {message}")
            
            with col2:
                if st.button("👀 Preview", key=f"preview_{issue_id}"):
                    st.info("Preview: Will split combined statements onto separate lines")
            
            with col3:
                if st.button("🤖 AI Prompt", key=f"ai_syntax_{issue_id}",
                           help="Generate AI prompt to fix this error"):
                    st.session_state[f'show_syntax_prompt_{issue_id}'] = True
            
            # Show AI prompt if requested
            if st.session_state.get(f'show_syntax_prompt_{issue_id}', False):
                st.divider()
                prompt = fixer.generate_syntax_error_prompt(issue)
                display_prompt_with_copy(
                    prompt, 
                    title="AI Fix Prompt for Syntax Error",
                    key_prefix=f"syntax_{issue_id}"
                )

def display_todos(scanner, fixer):
    """Display TODOs with management options"""
    st.subheader("TODO Management with AI Integration")
    
    tech_debt = scanner.issues.get('technical_debt', [])
    
    # Separate by type
    todos = [i for i in tech_debt if i['type'] in ['todo', 'fixme', 'hack', 'xxx']]
    bare_excepts = [i for i in tech_debt if i['type'] == 'bare_except']
    
    # Stats
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("TODOs", scanner.metrics.get('todos', 0))
    with col2:
        st.metric("FIXMEs", scanner.metrics.get('fixmes', 0))
    with col3:
        st.metric("HACKs", scanner.metrics.get('hacks', 0))
    with col4:
        st.metric("Bare Excepts", scanner.metrics.get('bare_excepts', 0))
    
    # TODO section
    if todos:
        st.write("### 📝 TODOs / FIXMEs / HACKs")
        
        # Group by file and deduplicate
        todos_by_file = defaultdict(list)
        seen_todos = set()
        
        for todo in todos:
            # Create unique identifier for deduplication
            todo_id = (todo['file'], todo['line'], todo.get('content', ''))
            if todo_id not in seen_todos:
                seen_todos.add(todo_id)
                todos_by_file[todo['file']].append(todo)
        
        # Display with limit
        displayed_files = 0
        for file_path, file_todos in todos_by_file.items():
            if displayed_files >= 20:  # Limit display
                st.info(f"Showing first 20 files. {len(todos_by_file) - 20} more files with TODOs not shown.")
                break
                
            with st.expander(f"📄 {Path(file_path).name} ({len(file_todos)} items)"):
                for todo in file_todos:
                    display_single_todo(todo, fixer)
            
            displayed_files += 1
    
    # Bare except section
    if bare_excepts:
        st.write("### ⚠️ Bare Except Statements")
        
        for idx, issue in enumerate(bare_excepts[:10]):
            with st.expander(f"{Path(issue['file']).name}:{issue['line']}"):
                st.code(issue['content'], language='python')
                
                col1, col2 = st.columns([1, 2])
                with col1:
                    if st.button("🔧 Fix to 'except Exception:'", 
                               key=f"fix_except_{idx}"):
                        success, message = fixer.fix_bare_except(issue)
                        if success:
                            st.success(f"✅ {message}")
                            st.session_state.fixed_issues.append(issue)
                            st.rerun()
                        else:
                            st.error(f"❌ {message}")
                
                with col2:
                    st.info("Best practice: Use specific exception types when possible")

def display_single_todo(todo, fixer):
    """Display a single TODO with options"""
    # Create truly unique key by including content hash
    import hashlib
    content_hash = hashlib.md5(str(todo).encode()).hexdigest()[:8]
    unique_key = f"{Path(todo['file']).stem}_{todo['line']}_{content_hash}"
    
    # Skip if already processed
    if any(f['file'] == todo['file'] and f['line'] == todo['line'] 
           for f in st.session_state.fixed_issues):
        return
    
    st.divider()
    
    # TODO content
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown(f"**Line {todo['line']}** - {todo['type'].upper()}")
        message = todo.get('message', todo.get('content', ''))
        st.code(message, language='python')
    
    with col2:
        st.caption(f"Type: {todo['type']}")
    
    # Action buttons
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🗑️ Remove", key=f"remove_{unique_key}",
                   help="Remove this TODO from the code"):
            with st.spinner("Removing TODO..."):
                success, message = fixer.remove_todo(todo)
                if success:
                    st.success(f"✅ {message}")
                    st.session_state.fixed_issues.append(todo)
                    st.rerun()
                else:
                    st.error(f"❌ {message}")
    
    with col2:
        if st.button("✅ Keep", key=f"keep_{unique_key}",
                   help="Mark as important - keep in code"):
            st.info("TODO marked as important")
    
    with col3:
        if st.button("🤖 AI Prompt", key=f"ai_{unique_key}",
                   help="Generate implementation prompt"):
            st.session_state[f'show_prompt_{unique_key}'] = True
    
    # Show AI prompt if requested
    if st.session_state.get(f'show_prompt_{unique_key}', False):
        with st.container():
            st.divider()
            prompt = fixer.generate_todo_prompt(todo)
            display_prompt_with_copy(
                prompt,
                title="AI Implementation Prompt",
                key_prefix=f"todo_{unique_key}"
            )

def display_long_functions(scanner, fixer):
    """Display long functions with refactoring options"""
    st.subheader("Long Functions - Refactoring Assistant")
    
    long_funcs = scanner.issues.get('long_functions', [])
    
    if not long_funcs:
        st.success("✅ No long functions found!")
        return
    
    st.warning(f"Found {len(long_funcs)} functions over 50 lines")
    
    # Sort by length
    long_funcs.sort(key=lambda x: x['lines'], reverse=True)
    
    for idx, issue in enumerate(long_funcs[:10]):  # Show top 10
        with st.expander(
            f"📏 {issue['function']}() - {issue['lines']} lines - {Path(issue['file']).name}"
        ):
            # Function details
            col1, col2, col3 = st.columns([2, 1, 1])
            
            with col1:
                st.write(f"**File**: `{issue['file']}`")
                st.write(f"**Lines**: {issue.get('start_line', '?')} - {issue.get('end_line', '?')}")
            
            with col2:
                st.metric("Length", f"{issue['lines']} lines")
            
            with col3:
                severity_color = "🔴" if issue['lines'] > 100 else "🟡"
                st.write(f"{severity_color} {issue.get('severity', 'medium').title()}")
            
            # Refactoring options
            if st.button("🤖 Generate Refactoring Plan", key=f"refactor_{idx}"):
                st.divider()
                prompt = fixer.generate_refactor_prompt(issue)
                display_prompt_with_copy(
                    prompt,
                    title="AI Refactoring Prompt",
                    key_prefix=f"refactor_{idx}"
                )
                
                with st.expander("💡 Refactoring Best Practices"):
                    st.markdown("""
                    1. **Extract Method**: Pull logical sections into separate functions
                    2. **Single Responsibility**: Each function does one thing
                    3. **Descriptive Names**: Use verbs (e.g., `validate_input`)
                    4. **Reduce Nesting**: Use early returns
                    5. **Parameter Objects**: Group related parameters
                    """)

def display_ai_prompts(scanner):
    """Display AI integration options"""
    st.subheader("🤖 AI Assistant Integration")
    
    # Quick stats
    todos = len([i for i in scanner.issues.get('technical_debt', []) 
                 if i['type'] in ['todo', 'fixme', 'hack']])
    syntax_errors = len(scanner.issues.get('syntax_errors', []))
    long_funcs = len(scanner.issues.get('long_functions', []))
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Fixable Syntax Errors", syntax_errors)
    with col2:
        st.metric("Implementable TODOs", todos)
    with col3:
        st.metric("Refactorable Functions", long_funcs)
    
    st.divider()
    
    # Batch operations
    st.write("### 📋 Batch AI Prompts")
    
    if st.button("🤖 Generate Master Prompt for All Issues"):
        master_prompt = generate_master_prompt(scanner)
        st.code(master_prompt, language='markdown')
        
        st.info("""
        **How to use this prompt:**
        1. Copy the entire prompt
        2. Paste into your AI assistant (Claude, GPT-4, etc.)
        3. Work through issues in priority order
        4. Apply fixes incrementally
        5. Run scanner again to verify
        """)
    
    # Integration tips
    with st.expander("💡 AI Integration Best Practices"):
        st.markdown("""
        ### Getting the Best Results
        
        **1. Choose the Right AI Model**
        - Claude: Best for complex refactoring and understanding context
        - GPT-4: Great for standard implementations and explanations
        - GitHub Copilot: Good for inline suggestions
        
        **2. Prompt Strategy**
        - Use the generated prompts as-is for consistency
        - Add project-specific context if needed
        - Review all suggestions before applying
        
        **3. Incremental Approach**
        - Fix syntax errors first (blocking issues)
        - Implement critical TODOs next
        - Refactor long functions last
        
        **4. Verification**
        - Always test AI-generated code
        - Run the scanner again after fixes
        - Use version control for safety
        """)

def display_summary(scanner, fixer):
    """Display summary and export options"""
    st.subheader("📊 Scan Summary & Export")
    
    # Summary metrics
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("### 📈 Code Quality Metrics")
        
        metrics_df = pd.DataFrame([
            {"Metric": "Health Score", "Value": f"{scanner.metrics.get('health_score', 0)}%"},
            {"Metric": "Total Files", "Value": str(scanner.metrics['total_files'])},
            {"Metric": "Total Lines", "Value": f"{scanner.metrics['total_lines']:,}"},
            {"Metric": "Syntax Errors", "Value": str(scanner.metrics['syntax_errors'])},
            {"Metric": "TODOs", "Value": str(scanner.metrics.get('todos', 0))},
            {"Metric": "Long Functions", "Value": str(scanner.metrics['long_functions'])},
        ])
        
        st.dataframe(metrics_df, use_container_width=True, hide_index=True)
    
    with col2:
        st.write("### 🔧 Fix Summary")
        
        if st.session_state.fixed_issues:
            fixes_df = pd.DataFrame([
                {
                    "File": Path(fix['file']).name,
                    "Line": str(fix['line']),
                    "Type": fix['type']
                }
                for fix in st.session_state.fixed_issues
            ])
            
            st.dataframe(fixes_df, use_container_width=True, hide_index=True)
        else:
            st.info("No fixes applied yet")
    
    st.divider()
    
    # Export options
    st.write("### 💾 Export Options")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📄 Export JSON Report"):
            report = generate_json_report(scanner, fixer)
            st.download_button(
                "Download JSON",
                json.dumps(report, indent=2),
                file_name=f"code_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
    
    with col2:
        if st.button("📝 Export Markdown Report"):
            md_report = generate_markdown_report(scanner, fixer)
            st.download_button(
                "Download Markdown",
                md_report,
                file_name=f"code_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                mime="text/markdown"
            )
    
    with col3:
        if st.button("🔧 Export Fix Log"):
            if st.session_state.fixed_issues:
                fix_log = generate_fix_log(fixer)
                st.download_button(
                    "Download Fix Log",
                    fix_log,
                    file_name=f"fixes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
                    mime="text/plain"
                )
            else:
                st.info("No fixes to export")

def generate_master_prompt(scanner):
    """Generate comprehensive AI prompt for all issues"""
    syntax_errors = scanner.issues.get('syntax_errors', [])
    todos = [i for i in scanner.issues.get('technical_debt', []) 
             if i['type'] in ['todo', 'fixme', 'hack']]
    long_funcs = scanner.issues.get('long_functions', [])
    
    prompt = f"""Please help improve the TuoKit codebase by addressing these code quality issues:

## 📊 Overall Summary
- **Health Score**: {scanner.metrics.get('health_score', 0)}%
- **Files Analyzed**: {scanner.metrics['total_files']}
- **Total Issues**: {len(syntax_errors) + len(todos) + len(long_funcs)}

## 🚨 Priority 1: Syntax Errors (Blocking Issues)
These prevent the code from running and must be fixed first:

"""
    
    for i, error in enumerate(syntax_errors[:5], 1):
        prompt += f"""
{i}. **{Path(error['file']).name}** line {error.get('line', '?')}
   Error: {error['error']}
   Suggested fix: Split combined statements onto separate lines
"""
    
    prompt += f"""

## 💭 Priority 2: TODO/FIXME Items
Implement these features and fixes:

"""
    
    # Group TODOs by type
    todo_groups = defaultdict(list)
    for todo in todos[:10]:
        todo_groups[todo['type']].append(todo)
    
    for todo_type, items in todo_groups.items():
        prompt += f"\n### {todo_type.upper()}s ({len(items)} items)\n"
        for item in items[:3]:
            prompt += f"- {Path(item['file']).name}:{item['line']} - {item.get('message', 'See code')}\n"
    
    prompt += f"""

## 📏 Priority 3: Long Functions
Refactor these functions for better maintainability:

"""
    
    for func in long_funcs[:5]:
        prompt += f"""
- **{func['function']}()** in {Path(func['file']).name}
  Length: {func['lines']} lines (threshold: 50)
  Recommendation: Split into 2-3 smaller functions
"""
    
    prompt += """

## 📋 General Guidelines
1. Make minimal, focused changes
2. Preserve all existing functionality
3. Follow the existing code style
4. Add appropriate error handling
5. Include brief comments for complex logic
6. Test each change thoroughly

Ready to start with the syntax errors?"""
    
    return prompt

def generate_json_report(scanner, fixer):
    """Generate JSON report"""
    return {
        'scan_date': datetime.now().isoformat(),
        'project_path': str(scanner.root_path),
        'health_score': scanner.metrics.get('health_score', 0),
        'metrics': dict(scanner.metrics),
        'issues': {k: len(v) for k, v in scanner.issues.items()},
        'fixes_applied': len(st.session_state.fixed_issues),
        'session_id': fixer.session_id
    }

def generate_markdown_report(scanner, fixer):
    """Generate Markdown report"""
    report = f"""# Code Health Report

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
Project: {scanner.root_path}

## Summary
- **Health Score**: {scanner.metrics.get('health_score', 0)}%
- **Files Scanned**: {scanner.metrics['total_files']}
- **Total Lines**: {scanner.metrics['total_lines']:,}
- **Fixes Applied**: {len(st.session_state.fixed_issues)}

## Issues Found
"""
    
    for issue_type, issues in scanner.issues.items():
        if issues:
            report += f"- **{issue_type.replace('_', ' ').title()}**: {len(issues)}\n"
    
    if st.session_state.fixed_issues:
        report += "\n## Fixes Applied\n"
        for fix in st.session_state.fixed_issues:
            report += f"- {Path(fix['file']).name}:{fix['line']} - {fix.get('type', 'unknown')}\n"
    
    return report

def generate_fix_log(fixer):
    """Generate detailed fix log"""
    log = f"""Fix Log - Session {fixer.session_id}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Fixes Applied:
"""
    
    for fix in fixer.applied_fixes:
        log += f"""
---
File: {fix['file']}
Line: {fix['line']}
Type: {fix['type']}
Original: {fix.get('original', 'N/A')}
Fixed: {fix.get('fixed', fix.get('action', 'N/A'))}
Backup: {fix['backup']}
"""
    
    return log

# Import required for DataFrame
import pandas as pd

if __name__ == "__main__":
    main()

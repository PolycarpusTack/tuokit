"""
Utility functions for clipboard operations in Streamlit
"""
import streamlit as st
import streamlit.components.v1 as components

def create_copy_button(text_to_copy, button_id="copy_btn"):
    """Create a copy to clipboard button with JavaScript"""
    
    # Escape quotes in the text
    escaped_text = text_to_copy.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
    
    # JavaScript code for copying
    copy_script = f"""
    <script>
    function copyToClipboard_{button_id}() {{
        const text = "{escaped_text}";
        
        // Try modern clipboard API first
        if (navigator.clipboard && navigator.clipboard.writeText) {{
            navigator.clipboard.writeText(text).then(
                function() {{
                    alert('✅ Copied to clipboard!');
                }},
                function(err) {{
                    console.error('Clipboard API failed:', err);
                    fallbackCopy_{button_id}(text);
                }}
            );
        }} else {{
            // Fallback for older browsers
            fallbackCopy_{button_id}(text);
        }}
    }}
    
    function fallbackCopy_{button_id}(text) {{
        // Create a textarea element
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        
        // Add to DOM, select, copy, and remove
        document.body.appendChild(textarea);
        textarea.select();
        
        try {{
            const successful = document.execCommand('copy');
            if (successful) {{
                alert('✅ Copied to clipboard!');
            }} else {{
                alert('❌ Copy failed. Please select and copy manually.');
            }}
        }} catch (err) {{
            alert('❌ Copy failed. Please select and copy manually.');
        }}
        
        document.body.removeChild(textarea);
    }}
    </script>
    
    <button onclick="copyToClipboard_{button_id}()" 
            style="background-color: #262730; 
                   color: white; 
                   border: 1px solid #4a4a4a; 
                   padding: 0.5rem 1rem; 
                   border-radius: 0.25rem; 
                   cursor: pointer;
                   font-size: 14px;
                   font-family: inherit;
                   margin: 0.5rem 0;">
        📋 Copy to Clipboard
    </button>
    """
    
    components.html(copy_script, height=50)

def display_prompt_with_copy(prompt, title="AI Prompt", key_prefix="prompt"):
    """Display a prompt with both text area and copy button"""
    st.markdown(f"### 🤖 {title}")
    
    # Text area for easy manual copying
    prompt_area = st.text_area(
        "Prompt (select all to copy manually):",
        prompt,
        height=400,
        key=f"{key_prefix}_textarea",
        help="Click inside and press Ctrl+A (or Cmd+A on Mac) to select all, then Ctrl+C to copy"
    )
    
    # Copy button
    create_copy_button(prompt, button_id=key_prefix)
    
    st.caption("💡 Paste this into Claude, GPT-4, or your preferred AI assistant")
    
    return prompt_area

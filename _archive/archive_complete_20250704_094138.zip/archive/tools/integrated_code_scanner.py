"""
TuoKit Code Health - Integrated Scanner
Complete code quality tool with scanning, analysis, and fixes
Run with: streamlit run integrated_code_scanner.py
"""
import streamlit as st
import sys
from pathlib import Path
import json
from datetime import datetime
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

# Add tools directory to path
sys.path.append(str(Path(__file__).parent))

from code_health_scanner import CodeHealthScanner
from code_fix_engine import CodeFixEngine
from deep_code_analyzer import DeepCodeAnalyzer

def create_metrics_dashboard(metrics):
    """Create visual dashboard for metrics"""
    # Create gauge charts
    fig1 = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = metrics.get('code_health_score', 0),
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Overall Health Score"},
        gauge = {
            'axis': {'range': [None, 100]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 50], 'color': "lightgray"},
                {'range': [50, 80], 'color': "gray"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 90
            }
        }
    ))
    
    return fig1

def calculate_health_score(scanner):
    """Calculate overall code health score"""
    total_issues = sum([
        scanner.metrics.get('syntax_errors', 0) * 10,  # Critical weight
        scanner.metrics.get('god_objects', 0) * 5,
        scanner.metrics.get('long_functions', 0) * 2,
        scanner.metrics.get('technical_debt', 0) * 1
    ])
    
    # Score out of 100
    max_issues = scanner.metrics.get('total_files', 1) * 20
    score = max(0, 100 - (total_issues / max_issues * 100))
    return round(score, 1)

def main():
    st.set_page_config(
        page_title="TuoKit Code Health", 
        page_icon="🏥",
        layout="wide"
    )
    
    # Header
    st.title("🏥 TuoKit Code Health - Complete Analysis")
    st.markdown("""
    **Comprehensive code quality scanner** with automated fixes and deep analysis
    """)
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        project_path = st.text_input(
            "Project Path",
            value="C:/Projects/Tuokit",
            help="Root directory to scan"
        )
        
        scan_options = st.expander("Scan Options", expanded=True)
        with scan_options:
            include_tests = st.checkbox("Include test files", value=False)
            check_imports = st.checkbox("Analyze imports", value=True)
            find_duplicates = st.checkbox("Find duplicate code", value=True)
            complexity_analysis = st.checkbox("Complexity analysis", value=True)
        
        st.divider()
        
        if st.button("🚀 Run Complete Scan", type="primary"):
            st.session_state['run_scan'] = True
    
    # Main content area
    if st.session_state.get('run_scan', False):
        # Initialize scanners
        scanner = CodeHealthScanner(project_path)
        analyzer = DeepCodeAnalyzer(project_path)
        fixer = CodeFixEngine()
        
        # Scan progress
        progress_container = st.container()
        with progress_container:
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Phase 1: Basic scanning
            status_text.text("Phase 1: Scanning files...")
            files = scanner.scan_directory()
            scanner.metrics['total_files'] = len(files)
            progress_bar.progress(20)
            
            # Phase 2: Syntax and structure
            status_text.text("Phase 2: Analyzing code structure...")
            for i, file_path in enumerate(files):
                syntax_ok, error = scanner.check_syntax(file_path)
                if not syntax_ok:
                    scanner.issues['syntax_errors'].append({
                        'file': str(file_path),
                        'error': error,
                        'severity': 'critical'
                    })
                else:
                    scanner.analyze_code_structure(file_path)
                
                # Update progress
                progress = 20 + (30 * (i + 1) / len(files))
                progress_bar.progress(int(progress))
            
            # Phase 3: Deep analysis
            if complexity_analysis:
                status_text.text("Phase 3: Complexity analysis...")
                for file_path in files:
                    analyzer.calculate_cyclomatic_complexity(file_path)
                progress_bar.progress(60)
            
            # Phase 4: Import analysis
            if check_imports:
                status_text.text("Phase 4: Analyzing dependencies...")
                import_metrics = analyzer.analyze_imports_graph(files)
                progress_bar.progress(80)
            
            # Phase 5: Duplicate detection
            if find_duplicates:
                status_text.text("Phase 5: Finding duplicate code...")
                duplicates = analyzer.find_duplicate_code_blocks(files)
                progress_bar.progress(90)
            
            # Phase 6: Code smells
            status_text.text("Phase 6: Detecting code smells...")
            all_smells = []
            for file_path in files[:20]:  # Sample for performance
                smells = analyzer.find_code_smells(file_path)
                all_smells.extend(smells)
            
            progress_bar.progress(100)
            status_text.text("✅ Scan complete!")
        
        # Calculate health score
        health_score = calculate_health_score(scanner)
        scanner.metrics['code_health_score'] = health_score
        
        # Clear progress
        progress_container.empty()
        
        # Results Dashboard
        st.header("📊 Results Dashboard")
        
        # Top metrics row
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric(
                "Health Score",
                f"{health_score}%",
                delta=None,
                help="Overall code health (0-100)"
            )
        
        with col2:
            st.metric(
                "Files Scanned",
                scanner.metrics['total_files']
            )
        
        with col3:
            st.metric(
                "Total Lines",
                f"{scanner.metrics['total_lines']:,}"
            )
        
        with col4:
            critical_count = len(scanner.issues.get('syntax_errors', []))
            st.metric(
                "Critical Issues",
                critical_count,
                delta=None if critical_count == 0 else -critical_count
            )
        
        with col5:
            st.metric(
                "Tech Debt Items",
                scanner.metrics.get('technical_debt', 0)
            )
        
        # Detailed tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "🚨 Issues", "📊 Analysis", "🔧 Fixes", "📈 Metrics", "📄 Report"
        ])
        
        with tab1:  # Issues tab
            st.subheader("Code Issues by Category")
            
            # Issue summary
            issue_summary = []
            for issue_type, issues in scanner.issues.items():
                if issues:
                    issue_summary.append({
                        'Type': issue_type.replace('_', ' ').title(),
                        'Count': len(issues),
                        'Severity': 'Critical' if 'error' in issue_type else 'Medium'
                    })
            
            if issue_summary:
                df_issues = pd.DataFrame(issue_summary)
                st.dataframe(df_issues, use_container_width=True)
                
                # Detailed issues
                for issue_type, issues in scanner.issues.items():
                    if issues:
                        with st.expander(f"{issue_type.replace('_', ' ').title()} ({len(issues)})"):
                            for issue in issues[:10]:  # Show first 10
                                if issue_type == 'syntax_errors':
                                    st.error(f"**{Path(issue['file']).name}**")
                                    st.code(issue['error'])
                                else:
                                    st.write(f"**{Path(issue.get('file', 'Unknown')).name}**")
                                    st.json(issue)
        
        with tab2:  # Analysis tab
            st.subheader("Deep Code Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Complexity distribution
                if analyzer.complexity_scores:
                    st.write("**High Complexity Functions**")
                    complexity_df = pd.DataFrame([
                        {'Function': k, 'Complexity': v}
                        for k, v in sorted(analyzer.complexity_scores.items(), 
                                         key=lambda x: x[1], reverse=True)[:10]
                    ])
                    fig = px.bar(complexity_df, x='Function', y='Complexity',
                                title="Top 10 Complex Functions")
                    st.plotly_chart(fig, use_container_width=True)
                
                # Naming conventions
                if hasattr(analyzer, 'naming_stats'):
                    st.write("**Naming Convention Analysis**")
                    naming_data = analyzer.analyze_naming_conventions(files)
                    st.json(naming_data)
            
            with col2:
                # Import analysis
                if check_imports and 'import_metrics' in locals():
                    st.write("**Import Dependencies**")
                    st.write(f"Max import depth: {import_metrics.get('import_depth', 0)}")
                    
                    if import_metrics.get('circular_dependencies'):
                        st.warning(f"Found {len(import_metrics['circular_dependencies'])} circular dependencies!")
                    
                    if import_metrics.get('isolated_modules'):
                        st.info(f"Isolated modules: {len(import_metrics['isolated_modules'])}")
                
                # Code smells
                if all_smells:
                    st.write("**Code Smells Detected**")
                    smell_counts = pd.DataFrame(all_smells).groupby('type').size()
                    st.bar_chart(smell_counts)
        
        with tab3:  # Fixes tab
            st.subheader("🔧 Automated Fixes")
            
            # Available fixes
            fix_categories = {
                'Bare Excepts': sum(1 for issue in scanner.issues.get('technical_debt', []) 
                                  if issue.get('type') == 'bare_except'),
                'Trailing Whitespace': 0,  # Would need to scan for this
                'Unused Imports': 0  # Would need deeper analysis
            }
            
            st.write("**Available Automated Fixes**")
            for fix_type, count in fix_categories.items():
                if count > 0:
                    col1, col2, col3 = st.columns([3, 1, 1])
                    with col1:
                        st.write(f"{fix_type}: {count} instances")
                    with col2:
                        if st.button(f"Preview", key=f"preview_{fix_type}"):
                            st.info(f"Would fix {count} instances of {fix_type}")
                    with col3:
                        if st.button(f"Apply", key=f"apply_{fix_type}"):
                            # Apply fixes
                            applied = 0
                            for issue in scanner.issues.get('technical_debt', []):
                                if issue.get('type') == 'bare_except':
                                    if fixer.apply_bare_except_fix(issue['file'], issue['line']):
                                        applied += 1
                            st.success(f"Applied {applied} fixes!")
            
            # Fix history
            if fixer.applied_fixes:
                st.write("**Applied Fixes**")
                fix_df = pd.DataFrame(fixer.applied_fixes)
                st.dataframe(fix_df, use_container_width=True)
        
        with tab4:  # Metrics tab
            st.subheader("📈 Code Metrics Visualization")
            
            # Create visualizations
            fig = create_metrics_dashboard(scanner.metrics)
            st.plotly_chart(fig, use_container_width=True)
            
            # Trend placeholder
            st.info("💡 Run multiple scans to see trends over time")
        
        with tab5:  # Report tab
            st.subheader("📄 Export Report")
            
            # Generate report
            report = {
                'scan_date': datetime.now().isoformat(),
                'project_path': project_path,
                'health_score': health_score,
                'metrics': scanner.metrics,
                'issues_summary': {k: len(v) for k, v in scanner.issues.items()},
                'configuration': {
                    'include_tests': include_tests,
                    'check_imports': check_imports,
                    'find_duplicates': find_duplicates,
                    'complexity_analysis': complexity_analysis
                }
            }
            
            # Display report
            st.json(report)
            
            # Export options
            col1, col2 = st.columns(2)
            with col1:
                if st.button("💾 Save JSON Report"):
                    report_path = Path(project_path) / f"code_health_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                    with open(report_path, 'w') as f:
                        json.dump(report, f, indent=2)
                    st.success(f"Report saved to: {report_path}")
            
            with col2:
                if st.button("📧 Generate Markdown"):
                    md_report = f"""# Code Health Report
                    
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
Project: {project_path}

## Summary
- **Health Score**: {health_score}%
- **Files Scanned**: {scanner.metrics['total_files']}
- **Total Lines**: {scanner.metrics['total_lines']:,}

## Issues Found
"""
                    for issue_type, count in report['issues_summary'].items():
                        if count > 0:
                            md_report += f"- **{issue_type}**: {count}\n"
                    
                    st.markdown(md_report)
                    st.download_button(
                        "Download Markdown",
                        md_report,
                        file_name="code_health_report.md",
                        mime="text/markdown"
                    )

# TODO: Add historical tracking
# TODO: Integrate with CI/CD webhooks
# TODO: Add team collaboration features
# TODO: Machine learning for pattern detection

if __name__ == "__main__":
    main()

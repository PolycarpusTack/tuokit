"""
TuoKit Deep Code Analysis
Advanced metrics and insights for codebase health
"""
import ast
import os
from collections import defaultdict, Counter
from pathlib import Path
import networkx as nx
import re

class DeepCodeAnalyzer:
    """Advanced code analysis beyond basic scanning"""
    
    def __init__(self, project_path):
        self.project_path = Path(project_path)
        self.dependency_graph = nx.DiGraph()
        self.complexity_scores = {}
        self.code_patterns = defaultdict(list)
        
    def analyze_imports_graph(self, files):
        """Build import dependency graph"""
        module_map = {}
        
        for file_path in files:
            try:
                # Get module name from path
                rel_path = file_path.relative_to(self.project_path)
                module_name = str(rel_path).replace(os.sep, '.').replace('.py', '')
                module_map[module_name] = file_path
                
                with open(file_path, 'r', encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                
                # Extract imports
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            self.dependency_graph.add_edge(module_name, alias.name)
                    elif isinstance(node, ast.ImportFrom):
                        if node.module:
                            self.dependency_graph.add_edge(module_name, node.module)
                            
            except Exception:
                continue
        
        # Calculate metrics
        metrics = {
            'circular_dependencies': list(nx.simple_cycles(self.dependency_graph)),
            'most_imported': self._get_most_imported_modules(),
            'import_depth': self._calculate_import_depth(),
            'isolated_modules': self._find_isolated_modules(module_map)
        }
        
        return metrics
    
    def _get_most_imported_modules(self, top_n=10):
        """Find most frequently imported modules"""
        # Count how many times each module is imported
        import_counts = Counter()
        for source, target in self.dependency_graph.edges():
            import_counts[target] += 1
        return import_counts.most_common(top_n)
    
    def _calculate_import_depth(self):
        """Calculate maximum import chain depth"""
        max_depth = 0
        for node in self.dependency_graph.nodes():
            try:
                depth = nx.dag_longest_path_length(self.dependency_graph)
                max_depth = max(max_depth, depth)
            except:
                pass
        return max_depth
    
    def _find_isolated_modules(self, module_map):
        """Find modules with no imports or dependencies"""
        all_modules = set(module_map.keys())
        connected_modules = set(self.dependency_graph.nodes())
        return list(all_modules - connected_modules)
    
    def calculate_cyclomatic_complexity(self, file_path):
        """Calculate McCabe cyclomatic complexity"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read())
            
            complexity_map = {}
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    complexity = 1  # Base complexity
                    
                    # Count decision points
                    for child in ast.walk(node):
                        if isinstance(child, (ast.If, ast.While, ast.For)):
                            complexity += 1
                        elif isinstance(child, ast.BoolOp):
                            complexity += len(child.values) - 1
                        elif isinstance(child, ast.ExceptHandler):
                            complexity += 1
                    
                    complexity_map[node.name] = complexity
                    
                    # Store high complexity functions
                    if complexity > 10:
                        self.complexity_scores[f"{file_path}::{node.name}"] = complexity
            
            return complexity_map
            
        except Exception:
            return {}
    
    def find_code_smells(self, file_path):
        """Detect common code smells"""
        smells = []
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.splitlines()
            
            tree = ast.parse(content)
            
            # Long parameter lists
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    if len(node.args.args) > 5:
                        smells.append({
                            'type': 'long_parameter_list',
                            'function': node.name,
                            'count': len(node.args.args),
                            'line': node.lineno
                        })
            
            # Deeply nested code
            for i, line in enumerate(lines, 1):
                indent_level = len(line) - len(line.lstrip())
                if indent_level > 20:  # 5 levels of 4-space indentation
                    smells.append({
                        'type': 'deep_nesting',
                        'line': i,
                        'level': indent_level // 4
                    })
            
            # Magic numbers
            magic_number_pattern = r'\b\d{2,}\b'  # Numbers with 2+ digits
            for i, line in enumerate(lines, 1):
                if re.search(magic_number_pattern, line) and not line.strip().startswith('#'):
                    smells.append({
                        'type': 'magic_number',
                        'line': i,
                        'content': line.strip()
                    })
            
            # Commented out code
            commented_code_pattern = r'^\s*#\s*(if|for|while|def|class|import|from)\s'
            for i, line in enumerate(lines, 1):
                if re.match(commented_code_pattern, line):
                    smells.append({
                        'type': 'commented_code',
                        'line': i,
                        'content': line.strip()
                    })
            
        except Exception:
            pass
        
        return smells
    
    def analyze_naming_conventions(self, files):
        """Check naming convention consistency"""
        patterns = {
            'snake_case': re.compile(r'^[a-z_][a-z0-9_]*$'),
            'camelCase': re.compile(r'^[a-z][a-zA-Z0-9]*$'),
            'PascalCase': re.compile(r'^[A-Z][a-zA-Z0-9]*$'),
            'UPPER_CASE': re.compile(r'^[A-Z_][A-Z0-9_]*$')
        }
        
        naming_stats = defaultdict(lambda: defaultdict(int))
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                
                # Check function names
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        for style, pattern in patterns.items():
                            if pattern.match(node.name):
                                naming_stats['functions'][style] += 1
                                break
                    
                    elif isinstance(node, ast.ClassDef):
                        for style, pattern in patterns.items():
                            if pattern.match(node.name):
                                naming_stats['classes'][style] += 1
                                break
                    
                    elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                        for style, pattern in patterns.items():
                            if pattern.match(node.id):
                                naming_stats['variables'][style] += 1
                                break
                                
            except Exception:
                continue
        
        return dict(naming_stats)
    
    def find_duplicate_code_blocks(self, files, min_lines=5):
        """Find potential duplicate code blocks"""
        code_blocks = defaultdict(list)
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                # Extract code blocks
                for i in range(len(lines) - min_lines):
                    block = ''.join(lines[i:i+min_lines])
                    # Normalize whitespace
                    normalized = ' '.join(block.split())
                    if len(normalized) > 50:  # Minimum meaningful size
                        code_blocks[normalized].append({
                            'file': str(file_path),
                            'start_line': i + 1,
                            'end_line': i + min_lines
                        })
                        
            except Exception:
                continue
        
        # Find duplicates
        duplicates = []
        for block, locations in code_blocks.items():
            if len(locations) > 1:
                duplicates.append({
                    'block': block[:100] + '...' if len(block) > 100 else block,
                    'locations': locations,
                    'count': len(locations)
                })
        
        return sorted(duplicates, key=lambda x: x['count'], reverse=True)

# TODO: Add test coverage analysis
# TODO: Implement documentation coverage metrics
# TODO: Add security vulnerability detection
# TODO: Performance profiling integration

"""
TuoKit Enhanced Scanner Demo
Shows the new granular fix features with sample data
"""
import streamlit as st
from pathlib import Path
import json
from datetime import datetime

# Sample issues for demo
DEMO_ISSUES = {
    'syntax_errors': [
        {
            'file': 'C:/Projects/Tuokit/pages/code_tools.py',
            'line': 99,
            'error': "Line 99: invalid syntax - multiple statements on one line",
            'content': 'else:            try:'
        },
        {
            'file': 'C:/Projects/Tuokit/pages/doc_tools.py',
            'line': 32,
            'error': "Line 32: invalid syntax - missing newline",
            'content': 'return text        except ImportError:'
        }
    ],
    'technical_debt': [
        {
            'file': 'C:/Projects/Tuokit/utils/database.py',
            'line': 45,
            'type': 'todo',
            'content': '# TODO: Add connection pooling for better performance'
        },
        {
            'file': 'C:/Projects/Tuokit/pages/sql_generator.py',
            'line': 128,
            'type': 'fixme',
            'content': '# FIXME: Handle edge case when table has no columns'
        },
        {
            'file': 'C:/Projects/Tuokit/utils/ollama.py',
            'line': 67,
            'type': 'hack',
            'content': '# HACK: Retry 3 times to work around API timeout'
        },
        {
            'file': 'C:/Projects/Tuokit/app.py',
            'line': 234,
            'type': 'bare_except',
            'content': 'except:  # Catch all exceptions'
        }
    ],
    'long_functions': [
        {
            'file': 'C:/Projects/Tuokit/integrate_agent_lite.py',
            'function': 'show_integration_steps',
            'lines': 91,
            'start_line': 45
        },
        {
            'file': 'C:/Projects/Tuokit/test_knowledge_graph.py',
            'function': 'test_knowledge_graph',
            'lines': 71,
            'start_line': 120
        }
    ]
}

def generate_todo_prompt(issue):
    """Generate AI prompt for TODO implementation"""
    prompt = f"""Please implement the following TODO item:

📍 **Location**: `{Path(issue['file']).name}` line {issue['line']}
📝 **TODO**: {issue.get('content', '').replace('# TODO:', '').replace('# FIXME:', '').replace('# HACK:', '').strip()}

**Requirements**:
1. ✅ Implement ONLY what the TODO describes
2. 🎯 Keep the solution minimal and focused
3. 🎨 Match the surrounding code style
4. 🛡️ Include appropriate error handling
5. 💬 Add a brief comment explaining the implementation
6. 🚫 Do not modify any other parts of the code

**Expected Solution Format**:
```python
# Line {issue['line']} - Replace the TODO with:
<your implementation here>
```

Please provide the exact code to replace the TODO line."""
    
    return prompt

def generate_refactor_prompt(issue):
    """Generate AI prompt for function refactoring"""
    return f"""Please refactor this long function into smaller, more manageable pieces:

📍 **File**: `{Path(issue['file']).name}`
🔧 **Function**: `{issue['function']}()`
📏 **Current Length**: {issue['lines']} lines (starts at line {issue.get('start_line', 'N/A')})

**Refactoring Guidelines**:
1. 🎯 Split into 2-3 functions with single responsibilities
2. 📏 Each function should be under 30 lines
3. ✅ Maintain exact same functionality
4. 📝 Use descriptive function names
5. 💬 Add docstrings to each new function
6. 🛡️ Preserve all error handling
7. 🧪 Ensure all edge cases are covered

**Expected Output Format**:
```python
def {issue['function']}_part1():
    \"\"\"First responsibility\"\"\"
    # Implementation
    
def {issue['function']}_part2():
    \"\"\"Second responsibility\"\"\"
    # Implementation
    
def {issue['function']}():
    \"\"\"Main function - orchestrates the parts\"\"\"
    # Call the split functions
```"""

def main():
    st.set_page_config(
        page_title="Enhanced Scanner Demo",
        page_icon="🏥",
        layout="wide"
    )
    
    # Header
    st.title("🏥 TuoKit Enhanced Code Scanner - Demo")
    st.markdown("""
    **New Features**: Granular fixes per issue + Advanced TODO management with AI prompts
    
    This demo shows the enhanced UI with sample issues. Click the buttons to see how each feature works!
    """)
    
    # Initialize session state
    if 'fixed_issues' not in st.session_state:
        st.session_state.fixed_issues = []
    if 'removed_todos' not in st.session_state:
        st.session_state.removed_todos = []
    
    # Metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Health Score", "87.9%", "+2.1%")
    with col2:
        syntax_count = len([i for i in DEMO_ISSUES['syntax_errors'] 
                          if f"syntax_{DEMO_ISSUES['syntax_errors'].index(i)}" not in st.session_state.fixed_issues])
        st.metric("Syntax Errors", syntax_count, -len(st.session_state.fixed_issues) if st.session_state.fixed_issues else None)
    with col3:
        todo_count = len([i for i in DEMO_ISSUES['technical_debt'] 
                         if i['type'] in ['todo', 'fixme', 'hack'] and 
                         f"todo_{DEMO_ISSUES['technical_debt'].index(i)}" not in st.session_state.removed_todos])
        st.metric("Active TODOs", todo_count)
    with col4:
        st.metric("Long Functions", len(DEMO_ISSUES['long_functions']))
    
    # Tabs
    tabs = st.tabs(["🚨 Syntax Errors", "💭 TODOs & Debt", "📏 Long Functions", "📊 Summary"])
    
    with tabs[0]:  # Syntax Errors
        st.subheader("Syntax Errors with Individual Fix Buttons")
        
        for idx, issue in enumerate(DEMO_ISSUES['syntax_errors']):
            issue_key = f"syntax_{idx}"
            if issue_key not in st.session_state.fixed_issues:
                with st.expander(f"❌ {Path(issue['file']).name} - Line {issue['line']}", expanded=True):
                    col1, col2 = st.columns([2, 1])
                    
                    with col1:
                        st.error(issue['error'])
                        st.code(issue['content'], language='python')
                        st.caption(f"File: `{issue['file']}`")
                    
                    with col2:
                        st.write("**Quick Fix Available**")
                        st.info("Split the combined statements onto separate lines")
                        
                        if st.button("🔧 Apply Fix", key=f"fix_{issue_key}", type="primary"):
                            st.session_state.fixed_issues.append(issue_key)
                            st.success("✅ Fixed!")
                            st.balloons()
                            st.rerun()
            else:
                st.success(f"✅ {Path(issue['file']).name} - Line {issue['line']} - FIXED")
    
    with tabs[1]:  # TODOs
        st.subheader("TODO Management with AI Integration")
        
        # Group by type
        todos = [i for i in DEMO_ISSUES['technical_debt'] if i['type'] in ['todo', 'fixme', 'hack']]
        bare_excepts = [i for i in DEMO_ISSUES['technical_debt'] if i['type'] == 'bare_except']
        
        st.write("### 📝 TODOs / FIXMEs / HACKs")
        
        for idx, issue in enumerate(todos):
            todo_key = f"todo_{DEMO_ISSUES['technical_debt'].index(issue)}"
            
            if todo_key not in st.session_state.removed_todos:
                with st.expander(f"{issue['type'].upper()} - {Path(issue['file']).name}:{issue['line']}", expanded=True):
                    st.code(issue['content'], language='python')
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if st.button("🗑️ Remove", key=f"remove_{todo_key}", 
                                   help="Mark as unnecessary and remove from code"):
                            st.session_state.removed_todos.append(todo_key)
                            st.success("Removed!")
                            st.rerun()
                    
                    with col2:
                        if st.button("✅ Keep", key=f"keep_{todo_key}",
                                   help="Keep this TODO in the code"):
                            st.info("TODO marked as valid - keeping in code")
                    
                    with col3:
                        if st.button("🤖 Generate AI Prompt", key=f"ai_{todo_key}",
                                   help="Generate a surgical prompt for AI implementation"):
                            st.session_state[f'show_prompt_{todo_key}'] = True
                    
                    # Show AI prompt if requested
                    if st.session_state.get(f'show_prompt_{todo_key}', False):
                        st.divider()
                        st.markdown("### 🤖 AI Implementation Prompt")
                        prompt = generate_todo_prompt(issue)
                        st.code(prompt, language='markdown')
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.button("📋 Copy to Clipboard", key=f"copy_{todo_key}",
                                    help="Copy this prompt to use with your AI assistant")
                        with col2:
                            st.button("🔄 Regenerate", key=f"regen_{todo_key}",
                                    help="Generate a different version of the prompt")
        
        st.write("### ⚠️ Bare Except Clauses")
        
        for issue in bare_excepts:
            with st.expander(f"Bare except - {Path(issue['file']).name}:{issue['line']}"):
                st.code(issue['content'], language='python')
                
                col1, col2 = st.columns([1, 1])
                with col1:
                    st.write("**Suggested Fix:**")
                    st.code("except Exception:  # Catch all exceptions", language='python')
                
                with col2:
                    if st.button("🔧 Apply Fix", key=f"fix_except_{DEMO_ISSUES['technical_debt'].index(issue)}"):
                        st.success("✅ Fixed bare except!")
    
    with tabs[2]:  # Long Functions
        st.subheader("Long Function Refactoring Assistant")
        
        for idx, issue in enumerate(DEMO_ISSUES['long_functions']):
            with st.expander(f"📏 {issue['function']}() - {issue['lines']} lines", expanded=True):
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    st.write(f"**File**: `{issue['file']}`")
                    st.write(f"**Function**: `{issue['function']}()`")
                    st.write(f"**Length**: {issue['lines']} lines (starts at line {issue.get('start_line', 'N/A')})")
                    
                    st.warning("Functions over 50 lines are hard to maintain and test")
                
                with col2:
                    st.metric("Complexity", "High", delta="Needs refactoring")
                
                if st.button("🤖 Generate Refactoring Plan", key=f"refactor_{idx}"):
                    st.divider()
                    st.markdown("### 🔧 AI Refactoring Prompt")
                    prompt = generate_refactor_prompt(issue)
                    st.code(prompt, language='markdown')
                    
                    with st.expander("💡 Refactoring Tips"):
                        st.markdown("""
                        **Best Practices for Function Refactoring:**
                        1. **Extract Method**: Pull out logical sections into separate functions
                        2. **Single Responsibility**: Each function should do one thing well
                        3. **Descriptive Names**: Use verbs for functions (e.g., `calculate_total`, `validate_input`)
                        4. **Parameter Objects**: If passing many parameters, consider using a class/dict
                        5. **Early Returns**: Use guard clauses to reduce nesting
                        """)
    
    with tabs[3]:  # Summary
        st.subheader("📊 Code Health Summary & Batch Operations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 🎯 Quick Actions")
            
            if st.button("🔧 Fix All Syntax Errors", type="primary"):
                st.success("Would fix all remaining syntax errors")
                
            if st.button("🧹 Remove All Unnecessary TODOs"):
                st.info("Would scan and remove outdated TODOs")
                
            if st.button("🤖 Generate Master AI Prompt"):
                st.session_state['show_master_prompt'] = True
        
        with col2:
            st.markdown("### 📈 Progress Tracking")
            
            # Progress metrics
            total_issues = (len(DEMO_ISSUES['syntax_errors']) + 
                          len(DEMO_ISSUES['technical_debt']) + 
                          len(DEMO_ISSUES['long_functions']))
            
            fixed_count = len(st.session_state.fixed_issues) + len(st.session_state.removed_todos)
            progress = fixed_count / total_issues if total_issues > 0 else 0
            
            st.progress(progress)
            st.write(f"Fixed {fixed_count} of {total_issues} issues ({progress*100:.1f}%)")
        
        if st.session_state.get('show_master_prompt', False):
            st.divider()
            st.markdown("### 🤖 Master AI Prompt for All Issues")
            
            remaining_syntax = len([i for i in DEMO_ISSUES['syntax_errors'] 
                                  if f"syntax_{DEMO_ISSUES['syntax_errors'].index(i)}" not in st.session_state.fixed_issues])
            remaining_todos = len([i for i in DEMO_ISSUES['technical_debt'] 
                                 if i['type'] in ['todo', 'fixme', 'hack']])
            
            master_prompt = f"""Please help improve the TuoKit codebase by addressing these issues:

## 📊 Issue Summary
- {remaining_syntax} syntax errors (blocking issues)
- {remaining_todos} TODO/FIXME items
- {len(DEMO_ISSUES['long_functions'])} long functions needing refactoring
- {len([i for i in DEMO_ISSUES['technical_debt'] if i['type'] == 'bare_except'])} bare except clauses

## 🎯 Priority Order
1. **Fix syntax errors first** - These prevent code from running
2. **Implement critical TODOs** - Features marked as FIXME
3. **Refactor long functions** - Improve maintainability
4. **Clean up bare excepts** - Better error handling

## 📋 Guidelines
- Make minimal, surgical changes
- Maintain existing code style
- Add error handling where missing
- Include brief comments for complex logic
- Ensure backward compatibility

Ready to start with the highest priority syntax errors?"""
            
            st.code(master_prompt, language='markdown')
    
    # Footer
    st.divider()
    st.caption("💡 **Tip**: Use the generated AI prompts with Claude, GPT-4, or your preferred AI assistant for best results")

if __name__ == "__main__":
    main()

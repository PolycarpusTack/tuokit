"""
Ruby Unified Toolkit - Consolidated Ruby Development Tools
Combines all Ruby-specific functionality into a single, powerful module
"""

from typing import Dict, List, Optional, Any, Tuple
import re
from dataclasses import dataclass
from enum import Enum
import ast

class RubyToolType(Enum):
    """Types of Ruby tools available"""
    PROFILER = "profiler"
    MEMORY_OPTIMIZER = "memory_optimizer"
    PATTERN_MATCHING = "pattern_matching"
    C_EXTENSION = "c_extension"
    RACTOR = "ractor"
    KATA = "kata"

@dataclass
class RubyAnalysisConfig:
    """Configuration for Ruby code analysis"""
    tool_type: RubyToolType
    code: str
    analysis_depth: str = "full"  # quick, standard, full
    optimization_level: str = "balanced"  # conservative, balanced, aggressive
    features: List[str] = None

@dataclass
class PerformanceMetrics:
    """Performance analysis metrics"""
    complexity: str
    memory_usage: str
    execution_time: str
    bottlenecks: List[Dict[str, Any]]
    optimization_potential: float

class RubyUnifiedToolkit:
    """Unified toolkit for all Ruby development needs"""
    
    def __init__(self, ollama_model: str = "deepseek-r1:latest"):
        self.model = ollama_model
        self.analyzers = {
            RubyToolType.PROFILER: self._analyze_performance,
            RubyToolType.MEMORY_OPTIMIZER: self._optimize_memory,
            RubyToolType.PATTERN_MATCHING: self._analyze_patterns,
            RubyToolType.C_EXTENSION: self._generate_c_extension,
            RubyToolType.RACTOR: self._analyze_concurrency,
            RubyToolType.KATA: self._generate_kata
        }
    
    def analyze(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Main entry point for all Ruby analysis"""
        analyzer = self.analyzers.get(config.tool_type)
        if not analyzer:
            raise ValueError(f"Unknown tool type: {config.tool_type}")
        
        return analyzer(config)
    
    def _analyze_performance(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Comprehensive performance analysis"""
        # Quick complexity estimation
        if config.analysis_depth == "quick":
            return {
                "complexity": self._estimate_complexity(config.code),
                "quick_tips": self._get_quick_performance_tips(config.code)
            }
        
        # Full analysis
        metrics = self._calculate_performance_metrics(config.code)
        issues = self._detect_performance_issues(config.code)
        optimizations = self._suggest_optimizations(config.code, config.optimization_level)
        
        return {
            "metrics": metrics,
            "issues": issues,
            "optimizations": optimizations,
            "optimized_code": self._apply_optimizations(config.code, optimizations),
            "benchmarks": self._generate_benchmarks(config.code),
            "profiling_commands": self._get_profiling_commands(config.code)
        }
    
    def _optimize_memory(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Memory usage optimization"""
        # Detect memory patterns
        patterns = self._detect_memory_patterns(config.code)
        allocations = self._analyze_allocations(config.code)
        leaks = self._detect_memory_leaks(config.code)
        
        # Generate optimizations
        optimizations = {
            "string_pooling": self._optimize_strings(config.code),
            "lazy_loading": self._implement_lazy_loading(config.code),
            "object_reuse": self._implement_object_reuse(config.code),
            "gc_tuning": self._suggest_gc_tuning(patterns)
        }
        
        # Calculate savings
        savings = self._estimate_memory_savings(config.code, optimizations)
        
        return {
            "current_usage": allocations,
            "memory_leaks": leaks,
            "patterns": patterns,
            "optimizations": optimizations,
            "optimized_code": self._apply_memory_optimizations(config.code, optimizations),
            "estimated_savings": savings,
            "monitoring_setup": self._generate_memory_monitoring(config.code)
        }
    
    def _analyze_patterns(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Pattern matching analysis and generation"""
        if "generate" in (config.features or []):
            # Generate pattern matching examples
            return self._generate_pattern_examples(config)
        
        # Analyze existing patterns
        patterns = self._extract_patterns(config.code)
        explanations = self._explain_patterns(patterns)
        alternatives = self._generate_pattern_alternatives(patterns)
        
        return {
            "patterns": patterns,
            "explanations": explanations,
            "alternatives": alternatives,
            "best_practices": self._get_pattern_best_practices(),
            "ruby_version_notes": self._get_ruby_version_compatibility(patterns)
        }
    
    def _generate_c_extension(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Generate C extension for performance-critical code"""
        # Analyze Ruby code for C conversion
        analysis = self._analyze_for_c_conversion(config.code)
        
        # Generate C extension components
        components = {
            "c_source": self._generate_c_source(config.code, analysis),
            "extconf": self._generate_extconf(config.features),
            "ruby_bindings": self._generate_ruby_bindings(analysis),
            "makefile_template": self._generate_makefile_template(),
            "tests": self._generate_c_extension_tests(config.code),
            "benchmarks": self._generate_c_benchmarks(config.code)
        }
        
        # Safety and debugging
        safety = {
            "memory_management": self._add_memory_safety(components["c_source"]),
            "error_handling": self._add_error_handling(components["c_source"]),
            "thread_safety": self._ensure_thread_safety(components["c_source"]),
            "debugging_guide": self._generate_debugging_guide()
        }
        
        return {
            "components": components,
            "safety": safety,
            "build_instructions": self._generate_build_instructions(),
            "performance_comparison": self._estimate_c_performance_gain(config.code)
        }
    
    def _analyze_concurrency(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Ractor and concurrency analysis"""
        # Analyze code for parallelization
        parallelizable = self._find_parallelizable_sections(config.code)
        
        # Generate Ractor implementation
        ractor_impl = self._generate_ractor_implementation(config.code, parallelizable)
        
        # Alternative concurrency models
        alternatives = {
            "threads": self._generate_thread_implementation(config.code),
            "fibers": self._generate_fiber_implementation(config.code),
            "async": self._generate_async_implementation(config.code),
            "processes": self._generate_process_implementation(config.code)
        }
        
        # Performance comparison
        comparison = self._compare_concurrency_models(config.code, alternatives)
        
        return {
            "parallelizable_sections": parallelizable,
            "ractor_implementation": ractor_impl,
            "alternatives": alternatives,
            "comparison": comparison,
            "best_model": self._recommend_concurrency_model(comparison),
            "safety_analysis": self._analyze_thread_safety(config.code)
        }
    
    def _generate_kata(self, config: RubyAnalysisConfig) -> Dict[str, Any]:
        """Generate Ruby coding kata"""
        difficulty = (config.features or ["intermediate"])[0]
        topic = (config.features[1] if len(config.features) > 1 else "algorithms")
        
        # Generate kata components
        kata = {
            "challenge": self._generate_challenge(difficulty, topic),
            "starter_code": self._generate_starter_code(difficulty, topic),
            "test_suite": self._generate_test_suite(difficulty, topic),
            "hints": self._generate_progressive_hints(difficulty, topic),
            "solution": self._generate_solution(difficulty, topic),
            "variations": self._generate_kata_variations(difficulty, topic)
        }
        
        # Learning materials
        learning = {
            "concepts": self._identify_learning_concepts(kata),
            "ruby_idioms": self._highlight_ruby_idioms(kata["solution"]),
            "common_mistakes": self._identify_common_mistakes(topic),
            "further_reading": self._suggest_resources(topic)
        }
        
        return {
            "kata": kata,
            "learning": learning,
            "estimated_time": self._estimate_completion_time(difficulty),
            "skill_level": self._determine_skill_requirements(kata)
        }
    
    # Performance analysis helpers
    def _estimate_complexity(self, code: str) -> str:
        """Quick complexity estimation"""
        # Count various complexity indicators
        loops = len(re.findall(r'\b(each|map|select|reduce|while|for|times)\b', code))
        nested_loops = len(re.findall(r'(each|map|select).*\n.*\s+(each|map|select)', code))
        recursion = len(re.findall(r'def\s+\w+.*\n.*\1', code))
        
        if nested_loops > 0 or recursion > 1:
            return "O(n²) or higher - Performance concern!"
        elif loops > 3:
            return "O(n log n) - Moderate complexity"
        elif loops > 0:
            return "O(n) - Linear complexity"
        else:
            return "O(1) - Constant time"
    
    def _detect_performance_issues(self, code: str) -> List[Dict[str, Any]]:
        """Detect various performance issues"""
        issues = []
        
        # N+1 queries
        if re.search(r'\.each.*\.(where|find|includes)', code):
            issues.append({
                "type": "N+1 Query",
                "severity": "high",
                "line": self._find_line_number(code, r'\.each.*\.(where|find|includes)'),
                "fix": "Use includes() or joins() for eager loading"
            })
        
        # String concatenation in loops
        if re.search(r'(each|times|while).*\n.*\+=', code):
            issues.append({
                "type": "String Building",
                "severity": "medium",
                "line": self._find_line_number(code, r'(each|times|while).*\n.*\+='),
                "fix": "Use Array#join or StringIO for efficient string building"
            })
        
        # Large data operations
        if re.search(r'\.all\.(each|map|select)', code):
            issues.append({
                "type": "Unbounded Query",
                "severity": "high",
                "line": self._find_line_number(code, r'\.all\.(each|map|select)'),
                "fix": "Use find_each or batch processing for large datasets"
            })
        
        return issues
    
    # Memory optimization helpers
    def _detect_memory_patterns(self, code: str) -> Dict[str, Any]:
        """Detect memory usage patterns"""
        patterns = {
            "string_duplication": len(re.findall(r'"[^"]*"', code)),
            "array_operations": len(re.findall(r'\.(push|<<|concat|unshift)', code)),
            "hash_operations": len(re.findall(r'\[[\w_]+\]\s*=', code)),
            "object_creation": len(re.findall(r'\.new\b', code)),
            "large_collections": len(re.findall(r'\.all\b', code))
        }
        
        return patterns
    
    def _optimize_strings(self, code: str) -> str:
        """Optimize string usage"""
        # Freeze string literals
        optimized = re.sub(r'"([^"]*)"', r'"\1".freeze', code)
        
        # Use symbols for hash keys
        optimized = re.sub(r'"(\w+)"\s*=>', r':\1 =>', optimized)
        
        return optimized
    
    # Pattern matching helpers
    def _extract_patterns(self, code: str) -> List[Dict[str, str]]:
        """Extract pattern matching constructs"""
        patterns = []
        
        # Find case/in patterns
        case_matches = re.finditer(r'case\s+(\w+)(.*?)end', code, re.DOTALL)
        for match in case_matches:
            patterns.append({
                "type": "case_pattern",
                "variable": match.group(1),
                "pattern": match.group(0)
            })
        
        return patterns
    
    # C extension helpers
    def _analyze_for_c_conversion(self, code: str) -> Dict[str, Any]:
        """Analyze Ruby code for C conversion potential"""
        return {
            "numeric_operations": len(re.findall(r'[\+\-\*\/\%]', code)),
            "string_operations": len(re.findall(r'\.(upcase|downcase|gsub|split)', code)),
            "array_operations": len(re.findall(r'\.(map|select|reduce|each)', code)),
            "complexity": self._estimate_complexity(code)
        }
    
    # Concurrency helpers
    def _find_parallelizable_sections(self, code: str) -> List[Dict[str, Any]]:
        """Find code sections suitable for parallelization"""
        sections = []
        
        # Independent iterations
        for match in re.finditer(r'(\w+)\.each\s*do.*?end', code, re.DOTALL):
            if not re.search(r'@\w+', match.group(0)):  # No instance variable access
                sections.append({
                    "type": "independent_iteration",
                    "code": match.group(0),
                    "start": match.start()
                })
        
        return sections
    
    # Kata generation helpers
    def _generate_challenge(self, difficulty: str, topic: str) -> str:
        """Generate kata challenge description"""
        challenges = {
            ("beginner", "algorithms"): "Implement a method to find the second largest number in an array",
            ("intermediate", "algorithms"): "Implement a method to find all pairs in an array that sum to a target",
            ("advanced", "algorithms"): "Implement a method to find the longest increasing subsequence"
        }
        
        return challenges.get((difficulty, topic), "Custom challenge based on your requirements")
    
    # Utility methods
    def _find_line_number(self, code: str, pattern: str) -> int:
        """Find line number for a pattern in code"""
        lines = code.split('\n')
        for i, line in enumerate(lines):
            if re.search(pattern, line):
                return i + 1
        return 0

# Factory function for easy access
def create_ruby_toolkit(model: str = "deepseek-r1:latest") -> RubyUnifiedToolkit:
    """Create an instance of the Ruby unified toolkit"""
    return RubyUnifiedToolkit(model)

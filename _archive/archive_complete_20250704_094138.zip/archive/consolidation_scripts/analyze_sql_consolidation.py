"""
SQL Consolidation Analysis
Determines what to do with remaining SQL files
"""

import os
from pathlib import Path

def analyze_sql_files():
    """Analyze remaining SQL files in pages directory"""
    
    pages_dir = Path("C:/Projects/Tuokit/pages")
    sql_files = [
        "sql_toolkit.py",
        "sql_generator_migrated.py", 
        "sql_academy.py"
    ]
    
    print("=== SQL Files Analysis ===\n")
    
    for filename in sql_files:
        filepath = pages_dir / filename
        if filepath.exists():
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = content.count('\n')
                
                # Check key features
                has_unified_toolkit = 'UnifiedSQLToolkit' in content
                has_education = 'quiz' in content.lower() or 'academy' in content.lower()
                has_generator = 'generate_sql' in content
                has_optimizer = 'optimize_sql' in content
                imports_utils = 'from utils.sql_tools import' in content
                
                print(f"{filename}:")
                print(f"  Lines: {lines}")
                print(f"  Has UnifiedSQLToolkit: {has_unified_toolkit}")
                print(f"  Has educational features: {has_education}")
                print(f"  Has SQL generation: {has_generator}")
                print(f"  Has SQL optimization: {has_optimizer}")
                print(f"  Imports from utils: {imports_utils}")
                print()
    
    print("\n=== Recommendation ===")
    print("1. KEEP sql_toolkit.py - Main consolidated tool (1500+ lines)")
    print("2. ARCHIVE sql_generator_migrated.py - Redundant with sql_toolkit")
    print("3. KEEP sql_academy.py - Unique educational focus")
    print("\nThis gives you:")
    print("- sql_toolkit.py for all SQL operations")
    print("- sql_academy.py for SQL learning/education")

if __name__ == "__main__":
    analyze_sql_files()

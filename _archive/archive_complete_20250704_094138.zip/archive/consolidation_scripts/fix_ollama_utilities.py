"""
Fix Ollama Utilities
Consolidates all Ollama functionality into a single unified module
"""

import os
import shutil
from pathlib import Path
from datetime import datetime

def fix_ollama_utilities():
    """Complete Ollama utility consolidation"""
    
    root = Path("C:/Projects/Tuokit")
    utils_dir = root / "utils"
    archive_dir = root / "archive" / "ollama_utilities"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    print("=== Fixing Ollama Utilities ===\n")
    
    # 1. Backup current ollama.py
    current_ollama = utils_dir / "ollama.py"
    if current_ollama.exists():
        backup_path = archive_dir / "ollama_original.py"
        shutil.copy(str(current_ollama), str(backup_path))
        print("[BACKUP] Saved original ollama.py")
    
    # 2. Replace with unified version
    unified_ollama = utils_dir / "ollama_unified.py"
    if unified_ollama.exists():
        shutil.move(str(unified_ollama), str(current_ollama))
        print("[UPDATE] Replaced ollama.py with unified version")
    
    # 3. Clean up redundant files
    redundant_files = [
        root / "check_ollama_integration.py",
        root / "detect_ollama_host.py",
        root / "fix_ollama_auto.py",
        root / "fix_ollama_detection.py",
        root / "ollama_status_patch.py",
        root / "scripts" / "testing" / "test_ollama.bat",
        root / "scripts" / "utilities" / "check_ollama_integration.py",
        root / "scripts" / "utilities" / "fix_ollama_auto.py",
        root / "scripts" / "utilities" / "fix_ollama_detection.py",
        root / "scripts" / "utilities" / "detect_ollama_host.py"
    ]
    
    archived = 0
    for file_path in redundant_files:
        if file_path.exists():
            archive_path = archive_dir / file_path.name
            shutil.move(str(file_path), str(archive_path))
            archived += 1
            print(f"[ARCHIVE] Moved {file_path.name}")
    
    print(f"\n[CLEANUP] Archived {archived} redundant files")
    
    # 4. Update the main test file
    test_content = '''#!/usr/bin/env python3
"""
TuoKit Ollama Test
Single unified test for Ollama connectivity
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.ollama import test_ollama_setup

if __name__ == "__main__":
    print("\\n🔧 TuoKit Ollama Test\\n")
    
    success, message = test_ollama_setup()
    
    if success:
        print("\\n✅ Ollama is working correctly!")
        print("\\nYou can now use TuoKit with Ollama models.")
    else:
        print(f"\\n❌ Ollama test failed: {message}")
        print("\\nTroubleshooting:")
        print("1. Ensure Ollama is installed: https://ollama.ai")
        print("2. Start Ollama service: ollama serve")
        print("3. Pull required models: ollama pull deepseek-r1:1.5b")
        
    sys.exit(0 if success else 1)
'''
    
    test_file = root / "scripts" / "testing" / "test_ollama.py"
    test_file.write_text(test_content, encoding='utf-8')
    print("\n[UPDATE] Updated test_ollama.py")
    
    # 5. Create summary
    summary = f"""# Ollama Utilities Fixed!

## What Changed:

### Unified ollama.py module with:
- **Auto-detection** of Ollama host (localhost, WSL2, Docker)
- **Service management** (start if not running)
- **Model management** (list, pull, verify)
- **Safe generation** with automatic error handling
- **Multiple fallbacks** (ollama package, requests, subprocess)
- **Comprehensive testing** function

### Consolidated Features:
1. **OllamaManager** class with all functionality
2. **Convenience functions** (get_available_models, safe_ollama_generate)
3. **Automatic host detection** for WSL2 users
4. **Service startup** if not running
5. **Model auto-pull** if not available
6. **Error handling** at every level

### Removed Redundant Files:
- test_ollama_simple.py
- test_ollama_direct.py
- test_ollama_connection.py
- test_ollama_autodetect.py
- test_ollama_manager.py
- check_ollama_integration.py
- fix_ollama_auto.py
- fix_ollama_detection.py
- detect_ollama_host.py
- ollama_status_patch.py

## Usage:

### Basic usage in any tool:
```python
from utils.ollama import safe_ollama_generate

response = safe_ollama_generate("deepseek-r1:1.5b", "Hello!")
print(response['response'])
```

### Test Ollama setup:
```bash
python scripts/testing/test_ollama.py
```

### Advanced usage:
```python
from utils.ollama import OllamaManager

manager = OllamaManager()
status = manager.get_status()
print(f"Ollama running: {{status['running']}}")
print(f"Available models: {{status['models']}}")
```

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
    
    summary_path = root / "OLLAMA_UTILITIES_FIXED.md"
    summary_path.write_text(summary, encoding='utf-8')
    
    print(f"\n[COMPLETE] Ollama utilities consolidated!")
    print(f"[INFO] Summary saved to: OLLAMA_UTILITIES_FIXED.md")
    
    return True

if __name__ == "__main__":
    fix_ollama_utilities()

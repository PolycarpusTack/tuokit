#!/usr/bin/env python3
"""
TuoKit Smart Cleanup Script
Organizes the codebase following TuoKit Architect principles
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
import json

class TuoKitOrganizer:
    def __init__(self, project_root="C:/Projects/Tuokit"):
        self.root = Path(project_root)
        self.changes = []
        self.backup_dir = self.root / f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
    def create_directory_structure(self):
        """Create organized directory structure"""
        directories = [
            "docs/architecture",
            "docs/implementations", 
            "docs/migrations",
            "docs/guides",
            "scripts/setup",
            "scripts/testing",
            "scripts/cleanup",
            "scripts/utilities",
            "archive/old_consolidations",
            "archive/old_migrations",
            "archive/old_tests",
            "config/database",
            "config/ollama",
        ]
        
        for dir_path in directories:
            full_path = self.root / dir_path
            full_path.mkdir(parents=True, exist_ok=True)
            self.changes.append(f"Created directory: {dir_path}")
            
    def organize_documentation(self):
        """Move documentation files to appropriate directories"""
        doc_mappings = {
            "docs/architecture": ["AGENT_*.md", "SYSTEM_ARCHITECTURE.md", 
                                  "COMPONENT_REFERENCE.md", "*_ANALYSIS.md"],
            "docs/implementations": ["*_IMPLEMENTATION*.md", "*_README.md",
                                     "*_COMPLETE.md", "*_UPDATE.md"],
            "docs/migrations": ["MIGRATION_*.md", "database_migration_*.sql",
                                "SQL_MIGRATION_GUIDE.md", "*_CONSOLIDATION*.md"],
            "docs/guides": ["DEPLOYMENT_*.md", "DEMO_SCRIPT.md", 
                            "*_GUIDE.md", "*_QUICKSTART.md"]
        }
        
        for target_dir, patterns in doc_mappings.items():
            for pattern in patterns:
                for file in self.root.glob(pattern):
                    if file.is_file():
                        target = self.root / target_dir / file.name
                        shutil.move(str(file), str(target))
                        self.changes.append(f"Moved {file.name} to {target_dir}")
                        
    def organize_scripts(self):
        """Move script files to appropriate directories"""
        script_mappings = {
            "scripts/setup": ["setup_*.py", "quick_*.py", "install_*.bat", 
                              "database_setup.sql", "*_setup.sql"],
            "scripts/testing": ["test_*.py", "run_tests.py", "test_*.bat",
                                "*_test.py", "verify_*.py"],
            "scripts/cleanup": ["cleanup_*.py", "consolidate_*.py", 
                                "rollback_*.py", "archive_*.py", "smart_cleanup.py"],
            "scripts/utilities": ["fix_*.py", "check_*.py", "detect_*.py",
                                  "count_*.py", "analyze_*.py", "extract_*.py"]
        }
        
        for target_dir, patterns in script_mappings.items():
            for pattern in patterns:
                for file in self.root.glob(pattern):
                    if file.is_file() and file.name != "smart_organize.py":
                        target = self.root / target_dir / file.name
                        shutil.move(str(file), str(target))
                        self.changes.append(f"Moved {file.name} to {target_dir}")
                        
    def archive_old_files(self):
        """Archive old consolidation attempts and backups"""
        archive_patterns = {
            "archive/old_consolidations": ["consolidation_report_*.md", 
                                            "backup_before_consolidation_*"],
            "archive/old_migrations": ["database_migration_*.sql"],
            "archive/old_tests": ["test_sql_*.py", "test_agent_*.py"],
        }
        
        for target_dir, patterns in archive_patterns.items():
            for pattern in patterns:
                for file in self.root.glob(pattern):
                    if file.is_file():
                        target = self.root / target_dir / file.name
                        shutil.move(str(file), str(target))
                        self.changes.append(f"Archived {file.name} to {target_dir}")
                        
    def identify_duplicates(self):
        """Identify duplicate functionality files"""
        duplicate_groups = {
            "ollama_tests": ["test_ollama*.py", "check_ollama*.py", "fix_ollama*.py"],
            "app_versions": ["app.py", "app_modern.py", "app_modern_backup.py", "main.py"],
            "json_helpers": ["json_helper.py", "json_helper_enhanced.py"],
            "old_files": ["*_old.py", "utils_old.py"],
            "bat_files": ["*.bat"],
        }
        
        duplicates = {}
        for group_name, patterns in duplicate_groups.items():
            files = []
            for pattern in patterns:
                files.extend([f.name for f in self.root.glob(pattern) if f.is_file()])
            if len(files) > 1:
                duplicates[group_name] = files
                
        return duplicates
        
    def create_launcher_script(self):
        """Create unified launcher to replace .bat files"""
        launcher_content = '''#!/usr/bin/env python3
"""
TuoKit Universal Launcher
Replaces multiple .bat files with single Python CLI
"""

import click
import subprocess
import sys
import os

@click.group()
def cli():
    """TuoKit Developer Portal CLI"""
    pass

@cli.command()
def start():
    """Start TuoKit application"""
    click.echo("🚀 Starting TuoKit...")
    subprocess.run([sys.executable, "-m", "streamlit", "run", "app.py"])

@cli.command()
def test():
    """Run test suite"""
    click.echo("🧪 Running tests...")
    subprocess.run([sys.executable, "scripts/testing/run_tests.py"])

@cli.command()
def setup():
    """Setup database and dependencies"""
    click.echo("⚙️ Setting up TuoKit...")
    subprocess.run([sys.executable, "scripts/setup/setup_database.py"])
    
@cli.command()
def clean():
    """Clean and organize project"""
    click.echo("🧹 Cleaning project...")
    subprocess.run([sys.executable, "smart_organize.py"])

if __name__ == "__main__":
    cli()
'''
        
        launcher_path = self.root / "tuokit"
        with open(launcher_path, "w", encoding="utf-8") as f:
            f.write(launcher_content)
        os.chmod(launcher_path, 0o755)
        self.changes.append("Created unified launcher: tuokit")
        
    def generate_report(self):
        """Generate cleanup report"""
        duplicates = self.identify_duplicates()
        
        report = f"""# TuoKit Cleanup Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Changes Made
Total changes: {len(self.changes)}

### Files Moved:
"""
        for change in self.changes[:20]:  # Show first 20 changes
            report += f"- {change}\n"
            
        if len(self.changes) > 20:
            report += f"\n... and {len(self.changes) - 20} more changes\n"
            
        report += f"""
## Duplicate Files Found

These files appear to have duplicate functionality:
"""
        for group, files in duplicates.items():
            report += f"\n### {group.replace('_', ' ').title()}\n"
            for file in files:
                report += f"- {file}\n"
                
        report += """
## Recommendations

1. **Review duplicate files** and keep only the best version
2. **Update imports** if any files were moved
3. **Run tests** to ensure nothing broke
4. **Delete .bat files** and use the new `tuokit` launcher instead

## New Project Structure
```
TuoKit/
├── app.py                 # Main application
├── tuokit                 # Universal launcher
├── requirements.txt       # Dependencies
├── pages/                 # Streamlit pages
├── utils/                 # Utility modules
├── tools/                 # Standalone tools
├── docs/                  # All documentation
│   ├── architecture/
│   ├── implementations/
│   ├── migrations/
│   └── guides/
├── scripts/               # All scripts
│   ├── setup/
│   ├── testing/
│   ├── cleanup/
│   └── utilities/
├── config/                # Configuration files
├── tests/                 # Test suites
└── archive/               # Old files for reference
```
"""
        return report
        
    def run(self, dry_run=False):
        """Execute the organization process"""
        print("🧹 TuoKit Smart Organizer")
        print("=" * 50)
        
        if dry_run:
            print("DRY RUN MODE - No files will be moved")
            
        # Create backup first
        if not dry_run:
            print(f"Creating backup at {self.backup_dir}")
            shutil.copytree(self.root, self.backup_dir, 
                           ignore=shutil.ignore_patterns('*.pyc', '__pycache__', 
                                                         '.git', 'tuokit-env'))
            
        # Execute organization steps
        print("\n📁 Creating directory structure...")
        self.create_directory_structure()
        
        print("\n📚 Organizing documentation...")
        if not dry_run:
            self.organize_documentation()
            
        print("\n📜 Organizing scripts...")
        if not dry_run:
            self.organize_scripts()
            
        print("\n🗄️ Archiving old files...")
        if not dry_run:
            self.archive_old_files()
            
        print("\n🚀 Creating unified launcher...")
        if not dry_run:
            self.create_launcher_script()
            
        # Generate report
        report = self.generate_report()
        report_path = self.root / f"cleanup_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)
            
        print(f"\n✅ Organization complete!")
        print(f"📄 Report saved to: {report_path}")
        print(f"\nTotal changes: {len(self.changes)}")
        
        return report

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Organize TuoKit project structure")
    parser.add_argument("--dry-run", action="store_true", 
                        help="Show what would be done without making changes")
    parser.add_argument("--root", default="C:/Projects/Tuokit",
                        help="Project root directory")
    
    args = parser.parse_args()
    
    organizer = TuoKitOrganizer(args.root)
    organizer.run(dry_run=args.dry_run)

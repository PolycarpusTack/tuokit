"""
Final cleanup of temporary consolidation scripts
"""

import os
import shutil
from pathlib import Path

def final_cleanup():
    """Move temporary consolidation scripts to archive"""
    
    root = Path("C:/Projects/Tuokit")
    archive_dir = root / "archive" / "consolidation_scripts"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    # Temporary scripts to archive
    temp_scripts = [
        "analyze_sql_consolidation.py",
        "complete_sql_consolidation.py",
        "analyze_agent_files.py", 
        "complete_agent_consolidation.py",
        "analyze_db_setups.py",
        "verify_consolidations.py",
        "smart_organize.py",
        "simple_organize.py",
        "daily_cleanup.py",
        "fix_ollama_utilities.py",
        "analyze_consolidation.py",
        "fix_model_selection.py",
        "fix_ollama_now.bat",
        "cleanup_root_directory.sh",
        "unified_db_setup.py"
    ]
    
    moved = 0
    for script in temp_scripts:
        src = root / script
        if src.exists():
            dst = archive_dir / script
            shutil.move(str(src), str(dst))
            moved += 1
            print(f"[ARCHIVE] {script}")
    
    # Also move batch files used for consolidation
    bat_files = [
        "apply_consolidation.bat",
        "run_consolidation_auto.bat",
        "run_consolidation_now.bat"
    ]
    
    for bat in bat_files:
        src = root / bat
        if src.exists():
            dst = archive_dir / bat
            shutil.move(str(src), str(dst))
            moved += 1
            print(f"[ARCHIVE] {bat}")
    
    print(f"\n[COMPLETE] Archived {moved} temporary consolidation scripts")
    
    # Count final files
    files = list(root.glob("*.*"))
    file_count = len([f for f in files if f.is_file()])
    print(f"\n[STATUS] Root directory now has {file_count} files")
    
    return file_count

if __name__ == "__main__":
    final_cleanup()

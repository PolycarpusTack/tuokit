#!/usr/bin/env python3
"""
TuoKit Daily Cleanup Tasks
Completes priority actions from the cleanup plan
"""

import os
import shutil
from pathlib import Path
from datetime import datetime

def cleanup_task(task_name, action_func):
    """Execute a cleanup task with error handling"""
    print(f"\n{'='*50}")
    print(f"Task: {task_name}")
    print(f"{'='*50}")
    try:
        result = action_func()
        print(f"✅ {task_name} - Complete!")
        return True, result
    except Exception as e:
        print(f"❌ {task_name} - Failed: {e}")
        return False, str(e)

def cleanup_app_versions():
    """Archive duplicate app versions"""
    root = Path("C:/Projects/Tuokit")
    archive_dir = root / "archive" / "app_versions"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    files_to_archive = [
        "app_modern.py",
        "app_modern_backup.py", 
        "main.py",
        "tuokit_mockup.py",
        "tuokit_complete_mockup.py"
    ]
    
    moved = []
    for filename in files_to_archive:
        src = root / filename
        if src.exists():
            dst = archive_dir / filename
            shutil.move(str(src), str(dst))
            moved.append(filename)
    
    return f"Archived {len(moved)} files: {', '.join(moved)}"

def cleanup_database_setup():
    """Move database setup to unified location"""
    root = Path("C:/Projects/Tuokit")
    
    # Move unified_db_setup.py to scripts/setup
    src = root / "unified_db_setup.py"
    dst = root / "scripts" / "setup" / "unified_db_setup.py"
    
    if src.exists():
        shutil.move(str(src), str(dst))
        
    # Archive other database setup files
    archive_dir = root / "archive" / "old_db_setup"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    to_archive = [
        "scripts/setup/setup_unified_database.py",
        "scripts/setup/quick_db_setup.py",
        "scripts/setup/setup_local.py",
        "scripts/setup/setup_manager.py"
    ]
    
    archived = []
    for filepath in to_archive:
        src = root / filepath
        if src.exists():
            filename = Path(filepath).name
            dst = archive_dir / filename
            shutil.move(str(src), str(dst))
            archived.append(filename)
            
    return f"Unified DB setup created, archived {len(archived)} old files"

def cleanup_ollama_tests():
    """Keep only essential Ollama test"""
    root = Path("C:/Projects/Tuokit")
    archive_dir = root / "archive" / "ollama_tests"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    # Files to archive (keep test_ollama.py)
    to_archive = [
        "test_ollama_simple.py",
        "test_ollama_direct.py",
        "test_ollama_connection.py",
        "test_ollama_autodetect.py",
        "test_ollama_manager.py",
        "check_ollama_integration.py",
        "fix_ollama_auto.py",
        "fix_ollama_detection.py",
        "detect_ollama_host.py"
    ]
    
    archived = []
    for filename in to_archive:
        # Check in root
        src = root / filename
        if not src.exists():
            # Check in scripts/testing
            src = root / "scripts" / "testing" / filename
            
        if src.exists():
            dst = archive_dir / filename
            shutil.move(str(src), str(dst))
            archived.append(filename)
            
    return f"Archived {len(archived)} redundant Ollama tests"

def cleanup_old_files():
    """Remove obvious old/backup files"""
    root = Path("C:/Projects/Tuokit")
    archive_dir = root / "archive" / "old_files"
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    patterns = [
        "*_old.py",
        "CLEANUP_COMPLETE.py",
        "verify_*.py",
        "analyze_consolidation.py",
        "extract_unique_features.py",
        "count_tools.py",
        "diagnostic_report_*.md",
        "consolidation_report_*.md"
    ]
    
    archived = []
    for pattern in patterns:
        for filepath in root.glob(pattern):
            if filepath.is_file():
                dst = archive_dir / filepath.name
                shutil.move(str(filepath), str(dst))
                archived.append(filepath.name)
                
    return f"Archived {len(archived)} old files"

def create_simple_launcher():
    """Create simple Python launcher to replace .bat files"""
    launcher_content = '''#!/usr/bin/env python3
"""TuoKit Simple Launcher"""
import subprocess
import sys

def main():
    print("Starting TuoKit...")
    subprocess.run([sys.executable, "-m", "streamlit", "run", "app.py"])

if __name__ == "__main__":
    main()
'''
    
    root = Path("C:/Projects/Tuokit")
    launcher = root / "start.py"
    launcher.write_text(launcher_content, encoding='utf-8')
    
    # Archive .bat files
    bat_dir = root / "archive" / "bat_files"
    bat_dir.mkdir(parents=True, exist_ok=True)
    
    bat_files = list(root.glob("*.bat"))
    for bat in bat_files:
        dst = bat_dir / bat.name
        shutil.move(str(bat), str(dst))
        
    return f"Created start.py launcher, archived {len(bat_files)} .bat files"

def generate_status_report():
    """Generate current status report"""
    root = Path("C:/Projects/Tuokit")
    
    # Count files
    root_files = len([f for f in root.iterdir() if f.is_file()])
    page_files = len(list((root / "pages").glob("*.py")))
    
    report = f"""
# TuoKit Cleanup Status Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}

## Files in Root Directory: {root_files}
Target: <50 files

## Pages: {page_files}
All tool pages

## Database Setup: Unified ✅
Single setup script: scripts/setup/unified_db_setup.py

## App Entry Points: Cleaned ✅
Keeping only app.py

## Ollama Tests: Cleaned ✅
Keeping only test_ollama.py

## Next Steps:
1. Test the application: python start.py
2. Complete SQL tool consolidation
3. Complete Agent consolidation
4. Group navigation into categories
"""
    
    report_path = root / "cleanup_status.md"
    report_path.write_text(report, encoding='utf-8')
    
    return f"Status report saved to cleanup_status.md"

def main():
    """Run all cleanup tasks"""
    print("🧹 TuoKit Daily Cleanup")
    print("=" * 70)
    
    tasks = [
        ("Archive duplicate app versions", cleanup_app_versions),
        ("Unify database setup", cleanup_database_setup),
        ("Clean Ollama tests", cleanup_ollama_tests),
        ("Archive old files", cleanup_old_files),
        ("Create simple launcher", create_simple_launcher),
        ("Generate status report", generate_status_report)
    ]
    
    results = []
    for task_name, task_func in tasks:
        success, result = cleanup_task(task_name, task_func)
        results.append((task_name, success, result))
    
    # Summary
    print("\n" + "=" * 70)
    print("CLEANUP SUMMARY")
    print("=" * 70)
    
    successful = sum(1 for _, success, _ in results if success)
    print(f"\nCompleted: {successful}/{len(tasks)} tasks")
    
    for task_name, success, result in results:
        status = "✅" if success else "❌"
        print(f"{status} {task_name}")
        print(f"   → {result}")
    
    print("\n✨ Cleanup complete! Next: Test with 'python start.py'")

if __name__ == "__main__":
    main()

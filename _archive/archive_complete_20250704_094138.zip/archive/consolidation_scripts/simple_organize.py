#!/usr/bin/env python3
"""
TuoKit Smart Cleanup Script - Simple version without emojis
Organizes the codebase following TuoKit Architect principles
"""

import os
import shutil
from pathlib import Path
from datetime import datetime
import sys

def safe_move(src, dst):
    """Safely move a file, handling Windows path issues"""
    try:
        # Ensure destination directory exists
        dst_dir = os.path.dirname(dst)
        os.makedirs(dst_dir, exist_ok=True)
        
        # Use shutil.move which handles cross-drive moves on Windows
        shutil.move(str(src), str(dst))
        return True, None
    except Exception as e:
        return False, str(e)

def organize_tuokit(root_path="C:/Projects/Tuokit", dry_run=True):
    """Main organization function"""
    root = Path(root_path)
    changes = []
    errors = []
    
    print("TuoKit Smart Organizer")
    print("=" * 50)
    
    if dry_run:
        print("DRY RUN MODE - No files will be moved")
        print()
    
    # Define directory structure
    directories = [
        "docs/architecture",
        "docs/implementations", 
        "docs/migrations",
        "docs/guides",
        "scripts/setup",
        "scripts/testing",
        "scripts/cleanup",
        "scripts/utilities",
        "archive/old_consolidations",
        "archive/old_migrations",
        "archive/old_tests"
    ]
    
    # Create directories
    print("Creating directory structure...")
    for dir_path in directories:
        full_path = root / dir_path
        if not dry_run:
            full_path.mkdir(parents=True, exist_ok=True)
        changes.append(f"Created directory: {dir_path}")
    
    # Define file movements
    movements = {
        # Documentation files
        "docs/architecture": [
            "AGENT_INTEGRATION_ANALYSIS.md",
            "AGENT_SYSTEMS_COMPARISON.md", 
            "AGENT_SYSTEM_README.md",
            "SYSTEM_ARCHITECTURE.md",
            "COMPONENT_REFERENCE.md"
        ],
        "docs/implementations": [
            "IMPLEMENTATION_COMPLETE.md",
            "IMPLEMENTATION_SUMMARY.md",
            "MODERN_UI_IMPLEMENTATION_SUMMARY.md",
            "COMPLETE_MOCKUP_README.md"
        ],
        "docs/migrations": [
            "MIGRATION_GUIDE.md",
            "MIGRATION_QUICK_START.md",
            "database_migration_agents.sql",
            "database_migration_knowledge_graph.sql",
            "database_migration_lite_agents.sql",
            "database_migration_v0.4.sql"
        ],
        # Script files
        "scripts/setup": [
            "setup_database.py",
            "setup_unified_database.py",
            "quick_db_setup.py",
            "setup_local.py",
            "setup_manager.py"
        ],
        "scripts/testing": [
            "test_agent_lite.py",
            "test_agent_system.py",
            "test_app.py",
            "test_ollama.py",
            "test_ollama_simple.py",
            "test_ollama_direct.py",
            "test_ollama_connection.py",
            "test_ollama_autodetect.py",
            "run_tests.py"
        ],
        "scripts/cleanup": [
            "cleanup_phase1.py",
            "cleanup_tuokit.py",
            "consolidate_tools.py",
            "consolidate_tools_v2.py",
            "rollback_consolidation.py",
            "archive_old_tools.py"
        ]
    }
    
    # Move files
    print("\nOrganizing files...")
    for target_dir, file_list in movements.items():
        for filename in file_list:
            src_path = root / filename
            if src_path.exists() and src_path.is_file():
                dst_path = root / target_dir / filename
                
                if dry_run:
                    changes.append(f"Would move: {filename} -> {target_dir}/")
                else:
                    success, error = safe_move(src_path, dst_path)
                    if success:
                        changes.append(f"Moved: {filename} -> {target_dir}/")
                    else:
                        errors.append(f"Failed to move {filename}: {error}")
    
    # Archive old files
    print("\nArchiving old files...")
    archive_patterns = {
        "archive/old_consolidations": ["consolidation_report_*.md"],
        "archive/old_tests": ["test_sql_*.py"],
    }
    
    for target_dir, patterns in archive_patterns.items():
        for pattern in patterns:
            for file_path in root.glob(pattern):
                if file_path.is_file():
                    dst_path = root / target_dir / file_path.name
                    
                    if dry_run:
                        changes.append(f"Would archive: {file_path.name} -> {target_dir}/")
                    else:
                        success, error = safe_move(file_path, dst_path)
                        if success:
                            changes.append(f"Archived: {file_path.name} -> {target_dir}/")
                        else:
                            errors.append(f"Failed to archive {file_path.name}: {error}")
    
    # Generate report
    report = f"""TuoKit Cleanup Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Total changes: {len(changes)}
Total errors: {len(errors)}

Files Organized:
"""
    
    for change in changes[:30]:  # Show first 30 changes
        report += f"  - {change}\n"
    
    if len(changes) > 30:
        report += f"\n  ... and {len(changes) - 30} more changes\n"
    
    if errors:
        report += "\n\nErrors encountered:\n"
        for error in errors:
            report += f"  - {error}\n"
    
    # Save report
    report_filename = f"cleanup_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    report_path = root / report_filename
    
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"\nReport saved to: {report_filename}")
    except Exception as e:
        print(f"\nError saving report: {e}")
        print("\n" + "=" * 50)
        print(report)
    
    print(f"\nTotal changes: {len(changes)}")
    if errors:
        print(f"Total errors: {len(errors)}")
    
    return report

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Organize TuoKit project structure")
    parser.add_argument("--dry-run", action="store_true", 
                        help="Show what would be done without making changes")
    parser.add_argument("--root", default="C:/Projects/Tuokit",
                        help="Project root directory")
    
    args = parser.parse_args()
    
    organize_tuokit(args.root, dry_run=args.dry_run)

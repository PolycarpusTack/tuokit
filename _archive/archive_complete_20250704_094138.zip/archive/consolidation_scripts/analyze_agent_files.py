"""
Agent Consolidation Analysis
Analyzes all agent files to prepare for consolidation
"""

import os
from pathlib import Path

def analyze_agent_files():
    """Analyze all agent-related files"""
    
    # Files to analyze
    files = {
        "Current Pages": [
            "C:/Projects/Tuokit/pages/agent_hub.py",
            "C:/Projects/Tuokit/pages/agent_lite.py"
        ],
        "Archived": [
            "C:/Projects/Tuokit/archive_consolidation/agent_systems/agent_portal.py",
            "C:/Projects/Tuokit/archive_consolidation/agent_systems/agent_system.py",
            "C:/Projects/Tuokit/archive_consolidation/agent_systems/agent_unified.py",
            "C:/Projects/Tuokit/archive_consolidation/agent_systems/team_agent.py"
        ]
    }
    
    print("=== Agent Files Analysis ===\n")
    
    for category, file_list in files.items():
        print(f"\n{category}:")
        print("-" * 40)
        
        for filepath in file_list:
            path = Path(filepath)
            if path.exists():
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    lines = content.count('\n')
                    
                    # Extract key features
                    features = []
                    if 'pipeline' in content.lower():
                        features.append("Pipeline execution")
                    if 'orchestrat' in content.lower():
                        features.append("Goal orchestration")
                    if 'specialist' in content.lower():
                        features.append("Specialist agents")
                    if 'team' in content.lower() and 'agent' in content.lower():
                        features.append("Team coordination")
                    if 'educational' in content.lower():
                        features.append("Educational mode")
                    if 'BaseAgent' in content:
                        features.append("Base agent class")
                    if 'AgentState' in content:
                        features.append("State management")
                    if 'AGENT_REGISTRY' in content:
                        features.append("Agent registry")
                    
                    print(f"\n{path.name}:")
                    print(f"  Lines: {lines}")
                    print(f"  Features: {', '.join(features) if features else 'None detected'}")
                    
                    # Check imports/dependencies
                    imports = []
                    if 'from agent_system import' in content:
                        imports.append("Depends on agent_system")
                    if 'from utils' in content:
                        imports.append("Uses utils")
                    if imports:
                        print(f"  Dependencies: {', '.join(imports)}")
                        
    print("\n\n=== Consolidation Plan ===")
    print("1. Use agent_hub.py as the main file")
    print("2. Merge unique features from agent_lite.py")
    print("3. Archive agent_lite.py after merging")
    print("4. Result: Single agent_hub.py with ALL features")

if __name__ == "__main__":
    analyze_agent_files()

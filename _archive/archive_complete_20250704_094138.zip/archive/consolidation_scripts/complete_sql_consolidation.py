"""
Complete SQL Consolidation
Archives redundant SQL files and updates navigation
"""

import os
import shutil
from pathlib import Path
from datetime import datetime

def complete_sql_consolidation():
    """Complete the SQL consolidation by archiving redundant files"""
    
    root = Path("C:/Projects/Tuokit")
    archive_dir = root / "archive_consolidation" / "sql_tools"
    
    print("=== Completing SQL Consolidation ===\n")
    
    # 1. Archive sql_generator_migrated.py
    src = root / "pages" / "sql_generator_migrated.py"
    if src.exists():
        dst = archive_dir / "sql_generator_migrated.py"
        shutil.move(str(src), str(dst))
        print("[DONE] Archived sql_generator_migrated.py")
    
    # 2. Update navigation if needed
    print("\n[INFO] Current SQL tools in pages/:")
    print("  - sql_toolkit.py (All SQL operations)")
    print("  - sql_academy.py (SQL education)")
    
    # 3. Check for any references to old SQL files
    print("\n[CHECK] Checking for references to old SQL files...")
    
    old_sql_files = [
        "sql_generator.py",
        "sql_optimizer.py", 
        "sql_pipeline.py",
        "sql_suite.py",
        "sql_generator_migrated.py"
    ]
    
    # Check app.py and other key files
    files_to_check = [
        root / "app.py",
        root / "utils" / "__init__.py",
        root / "utils" / "sql_tools.py"
    ]
    
    references_found = []
    for check_file in files_to_check:
        if check_file.exists():
            content = check_file.read_text(encoding='utf-8')
            for old_file in old_sql_files:
                if old_file in content:
                    references_found.append(f"{check_file.name} references {old_file}")
    
    if references_found:
        print("[WARNING] Found references to old SQL files:")
        for ref in references_found:
            print(f"  - {ref}")
        print("\nThese should be updated to use sql_toolkit.py")
    else:
        print("[OK] No references to old SQL files found")
    
    # 4. Create summary
    summary = f"""# SQL Consolidation Complete!

## Final Structure:
- **sql_toolkit.py** - Complete SQL toolkit with all features:
  - SQL generation from natural language
  - Query optimization
  - Query explanation
  - Live database connectivity
  - Educational features
  - Security validation
  
- **sql_academy.py** - Dedicated SQL learning platform:
  - Interactive tutorials
  - Concept explanations
  - Quizzes and exercises
  - Learning paths

## Archived Files:
- sql_generator.py [DONE]
- sql_optimizer.py [DONE]
- sql_pipeline.py [DONE]
- sql_suite.py [DONE]
- sql_generator_migrated.py [DONE]

## Benefits:
- Single source of truth for SQL operations
- Cleaner navigation (2 SQL tools instead of 6)
- All features preserved
- Better maintainability

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}
"""
    
    summary_path = root / "SQL_CONSOLIDATION_COMPLETE.md"
    summary_path.write_text(summary, encoding='utf-8')
    
    print(f"\n[COMPLETE] SQL Consolidation Complete!")
    print(f"[INFO] Summary saved to: SQL_CONSOLIDATION_COMPLETE.md")
    
    return True

if __name__ == "__main__":
    complete_sql_consolidation()

"""
Verify Consolidations Script
Tests that the consolidated tools work properly
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, "C:/Projects/Tuokit")

def test_imports():
    """Test that key imports still work"""
    print("=== Testing Imports ===\n")
    
    tests = [
        ("Utils", "from utils import DatabaseManager, safe_ollama_generate"),
        ("SQL Tools", "from utils.sql_tools import generate_sql_query, optimize_sql_query"),
        ("Pages exist", "import pages.sql_toolkit"),
        ("Agent Hub", "import pages.agent_hub"),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, import_str in tests:
        try:
            exec(import_str)
            print(f"[PASS] {test_name}")
            passed += 1
        except Exception as e:
            print(f"[FAIL] {test_name}: {e}")
            failed += 1
    
    print(f"\nPassed: {passed}/{len(tests)}")
    return failed == 0

def check_files():
    """Check that files are in correct locations"""
    print("\n=== Checking File Locations ===\n")
    
    expected_files = {
        "SQL Toolkit": Path("C:/Projects/Tuokit/pages/sql_toolkit.py"),
        "SQL Academy": Path("C:/Projects/Tuokit/pages/sql_academy.py"),
        "Agent Hub": Path("C:/Projects/Tuokit/pages/agent_hub.py"),
        "Unified DB Setup": Path("C:/Projects/Tuokit/scripts/setup/unified_db_setup.py"),
    }
    
    missing_files = {
        "Agent Lite": Path("C:/Projects/Tuokit/pages/agent_lite.py"),
        "SQL Generator Migrated": Path("C:/Projects/Tuokit/pages/sql_generator_migrated.py"),
    }
    
    all_good = True
    
    # Check expected files exist
    for name, path in expected_files.items():
        if path.exists():
            print(f"[OK] {name} exists")
        else:
            print(f"[ERROR] {name} missing at {path}")
            all_good = False
    
    # Check that removed files are gone
    for name, path in missing_files.items():
        if not path.exists():
            print(f"[OK] {name} removed")
        else:
            print(f"[WARNING] {name} still exists at {path}")
            all_good = False
    
    return all_good

def check_page_count():
    """Check the number of pages"""
    print("\n=== Page Count ===\n")
    
    pages_dir = Path("C:/Projects/Tuokit/pages")
    py_files = list(pages_dir.glob("*.py"))
    
    print(f"Total pages: {len(py_files)}")
    print("Expected: 41 (down from 43)")
    
    if len(py_files) == 41:
        print("[OK] Page count matches expected")
        return True
    else:
        print(f"[WARNING] Page count mismatch")
        return False

def main():
    """Run all verification tests"""
    print("TuoKit Consolidation Verification")
    print("=" * 50)
    
    results = []
    results.append(("Import Tests", test_imports()))
    results.append(("File Locations", check_files()))
    results.append(("Page Count", check_page_count()))
    
    print("\n" + "=" * 50)
    print("SUMMARY")
    print("=" * 50)
    
    all_passed = True
    for test_name, passed in results:
        status = "[PASS]" if passed else "[FAIL]"
        print(f"{status} {test_name}")
        if not passed:
            all_passed = False
    
    if all_passed:
        print("\n✅ All consolidations verified successfully!")
    else:
        print("\n⚠️ Some issues found - review the output above")

if __name__ == "__main__":
    main()

"""
TuoKit Database Consolidation Script
Identifies which database setup to keep
"""

import os
from pathlib import Path

def analyze_db_setups():
    """Analyze all database setup files"""
    setup_dir = Path("C:/Projects/Tuokit/scripts/setup")
    
    files_to_check = [
        "setup_database.py",
        "setup_unified_database.py", 
        "quick_db_setup.py",
        "setup_local.py",
        "setup_manager.py"
    ]
    
    print("=== Database Setup Analysis ===\n")
    
    for filename in files_to_check:
        filepath = setup_dir / filename
        if filepath.exists():
            size = filepath.stat().st_size
            with open(filepath, 'r', encoding='utf-8') as f:
                lines = len(f.readlines())
                f.seek(0)
                # Check for key features
                content = f.read()
                has_postgres = 'psycopg2' in content or 'postgresql' in content
                has_sqlite = 'sqlite' in content
                has_migrations = 'CREATE TABLE' in content
                
            print(f"{filename}:")
            print(f"  - Size: {size} bytes")
            print(f"  - Lines: {lines}")
            print(f"  - PostgreSQL support: {'Yes' if has_postgres else 'No'}")
            print(f"  - SQLite support: {'Yes' if has_sqlite else 'No'}")
            print(f"  - Has migrations: {'Yes' if has_migrations else 'No'}")
            print()
    
    print("\nRecommendation:")
    print("Keep setup_database.py as the single source of truth")
    print("It should support both PostgreSQL and SQLite with proper fallback")

if __name__ == "__main__":
    analyze_db_setups()

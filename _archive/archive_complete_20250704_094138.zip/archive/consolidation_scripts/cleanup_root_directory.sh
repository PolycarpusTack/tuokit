# TuoKit Cleanup Plan - Phase 1: Organize Root Directory

## Immediate Actions

### 1. Create Directory Structure
```bash
mkdir -p docs/architecture
mkdir -p docs/implementations  
mkdir -p docs/migrations
mkdir -p scripts/setup
mkdir -p scripts/testing
mkdir -p scripts/cleanup
mkdir -p archive/old_migrations
```

### 2. Move Documentation Files
```bash
# Architecture docs
mv AGENT_*.md docs/architecture/
mv SYSTEM_ARCHITECTURE.md docs/architecture/
mv COMPONENT_REFERENCE.md docs/architecture/

# Implementation docs  
mv *_IMPLEMENTATION*.md docs/implementations/
mv *_README.md docs/implementations/

# Migration docs
mv MIGRATION_*.md docs/migrations/
mv database_migration_*.sql docs/migrations/
mv SQL_MIGRATION_GUIDE.md docs/migrations/
```

### 3. Move Scripts
```bash
# Setup scripts
mv setup_*.py scripts/setup/
mv quick_*.py scripts/setup/
mv install_*.bat scripts/setup/

# Test scripts
mv test_*.py scripts/testing/
mv run_tests.py scripts/testing/

# Cleanup scripts  
mv cleanup_*.py scripts/cleanup/
mv consolidate_*.py scripts/cleanup/
mv rollback_*.py scripts/cleanup/
```

### 4. Archive Old Files
```bash
# Old consolidation reports
mv consolidation_report_*.md archive/
mv *_old.py archive/
mv backup_before_* archive/
```

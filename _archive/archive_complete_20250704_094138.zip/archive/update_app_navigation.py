"""
Update app.py to use simplified navigation
"""

import shutil
from pathlib import Path

# Backup current app.py
src = Path("C:/Projects/Tuokit/app.py")
dst = Path("C:/Projects/Tuokit/archive/app_original.py")
dst.parent.mkdir(exist_ok=True)
shutil.copy(str(src), str(dst))

# Create new app.py with navigation
new_app_content = '''import streamlit as st
from utils import OllamaManager, DatabaseManager, get_system_stats, get_available_models
from utils.navigation import NAVIGATION_CATEGORIES, get_tool_count, get_category_count

# Initialize session state
if "selected_model" not in st.session_state:
    st.session_state.selected_model = "deepseek-coder:6.7b"
if "db" not in st.session_state:
    try:
        st.session_state.db = DatabaseManager()
    except Exception as e:
        st.error(f"Database connection failed. Please check your configuration: {e}")
        st.session_state.db = None

# Check for first run
if "first_run_checked" not in st.session_state:
    st.session_state.first_run_checked = True
    # Check if user should see onboarding
    if st.session_state.db:
        try:
            # Simple check: if no queries exist, likely first run
            count = st.session_state.db.get_knowledge_count()
            recent = st.session_state.db.get_recent_queries(limit=1)
            if count == 0 and len(recent) == 0:
                st.switch_page("pages/onboarding_wizard.py")
        except:
            pass

# Page configuration
st.set_page_config(
    page_title="TuoKit Dashboard",
    page_icon="🧠",
    layout="wide"
)

# --- Sidebar Navigation ---
with st.sidebar:
    st.title("🧠 TuoKit")
    st.caption(f"{get_tool_count()} tools in {get_category_count()} categories")
    
    # Model selection
    st.subheader("AI Engine")
    model_options = get_available_models()
    if model_options:
        if st.session_state.selected_model not in model_options:
            st.session_state.selected_model = model_options[0]
        st.selectbox("Active Model", model_options, key="selected_model")
    else:
        st.warning("No Ollama models found. Please check Ollama status.")
    
    st.markdown("---")
    
    # Search
    search_query = st.text_input("🔍 Search tools", placeholder="Quick search...")
    
    # Home button
    if st.button("🏠 Home", use_container_width=True):
        st.switch_page("pages/0_🏠_Home.py")
    
    st.markdown("---")
    
    # Navigation categories
    st.subheader("Tool Categories")
    
    # If searching, show results
    if search_query:
        from utils.navigation import search_tools
        results = search_tools(search_query)
        
        if results:
            for result in results:
                if st.button(
                    f"{result['icon']} {result['name']}",
                    key=f"search_{result['id']}",
                    use_container_width=True
                ):
                    st.switch_page(f"pages/{result['file']}")
        else:
            st.info("No tools found")
    else:
        # Show categories
        for category_name, category_data in NAVIGATION_CATEGORIES.items():
            with st.expander(category_name):
                st.caption(category_data["description"])
                
                for tool_id, tool in category_data["tools"].items():
                    if st.button(
                        f"{tool['icon']} {tool['name']}",
                        key=f"nav_{tool_id}",
                        help=tool['description'],
                        use_container_width=True
                    ):
                        st.switch_page(f"pages/{tool['file']}")
    
    st.markdown("---")
    
    # System status
    with st.expander("System Status"):
        ollama_status = OllamaManager.get_status()
        st.write(f"**Ollama**: {'✅ Running' if ollama_status['running'] else '❌ Not running'}")
        st.write(f"**Models**: {ollama_status['model_count']}")
        
        if st.session_state.db and st.session_state.db.connected:
            st.write("**Database**: ✅ Connected")
        else:
            st.write("**Database**: ❌ Not connected")

# --- Main Content ---
st.title("🧠 TuoKit Dashboard")
st.markdown("**Welcome to TuoKit** - Your AI-powered developer toolkit")

# Quick stats
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Tools Available", get_tool_count())

with col2:
    st.metric("Categories", get_category_count())

with col3:
    if st.session_state.db and st.session_state.db.connected:
        count = st.session_state.db.get_knowledge_count()
        st.metric("Knowledge Units", count)
    else:
        st.metric("Knowledge Units", "N/A")

with col4:
    recent = []
    if st.session_state.db and st.session_state.db.connected:
        recent = st.session_state.db.get_recent_queries(limit=100)
    st.metric("Recent Queries", len(recent))

st.markdown("---")

# Featured tools
st.subheader("🌟 Featured Tools")

col1, col2, col3 = st.columns(3)

with col1:
    st.info("**🤖 Agent Hub**\\nAI agents for complex tasks")
    if st.button("Open Agent Hub"):
        st.switch_page("pages/agent_hub.py")

with col2:
    st.info("**🛢️ SQL Toolkit**\\nGenerate and optimize SQL")
    if st.button("Open SQL Toolkit"):
        st.switch_page("pages/sql_toolkit.py")

with col3:
    st.info("**💎 Ruby Toolkit**\\nRuby development tools")
    if st.button("Open Ruby Toolkit"):
        st.switch_page("pages/ruby_toolkit.py")

# Recent activity
if st.session_state.db and st.session_state.db.connected:
    st.markdown("---")
    st.subheader("📊 Recent Activity")
    
    recent_queries = st.session_state.db.get_recent_queries(limit=5)
    
    if recent_queries:
        for query in recent_queries:
            with st.expander(f"{query['tool']} - {query['created_at']}"):
                st.write("**Prompt:**", query['user_prompt'][:200] + "..." if len(query['user_prompt']) > 200 else query['user_prompt'])
                st.write("**Model:**", query['model'])
    else:
        st.info("No recent activity. Start using tools to see your history here!")

# Tips
st.markdown("---")
st.subheader("💡 Tips")

tips = [
    "Use the search bar in the sidebar to quickly find tools",
    "Click on category names to expand and see all tools",
    "Your queries are automatically saved to the knowledge base",
    "Visit the Help Guide for detailed tutorials",
    "The Home page shows all tools organized by category"
]

for tip in tips:
    st.write(f"• {tip}")
'''

# Write the new app.py
with open("C:/Projects/Tuokit/app.py", "w", encoding="utf-8") as f:
    f.write(new_app_content)

print("[UPDATE] Created new app.py with simplified navigation")
print("[BACKUP] Original saved to archive/app_original.py")

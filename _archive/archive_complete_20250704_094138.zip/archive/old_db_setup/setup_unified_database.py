#!/usr/bin/env python3
"""
TuoKit Unified Database Setup Script
Consolidates all database migrations into a single setup process
"""

import psycopg2
import os
import sys
from dotenv import load_dotenv
from pathlib import Path

# Load environment variables
load_dotenv()

# Database configuration from updated .env.example format
DB_CONFIG = {
    "host": os.getenv("TUOKIT_PG_HOST", "localhost"),
    "port": os.getenv("TUOKIT_PG_PORT", "5432"),
    "dbname": os.getenv("TUOKIT_PG_DB", "tuokit_knowledge"),
    "user": os.getenv("TUOKIT_PG_USER", "tuokit_user"),
    "password": os.getenv("TUOKIT_PG_PASSWORD", "your_secure_password")
}

# Admin config for initial setup
ADMIN_CONFIG = {
    "host": DB_CONFIG["host"],
    "port": DB_CONFIG["port"],
    "dbname": "postgres",  # Connect to default database first
    "user": os.getenv("PG_ADMIN_USER", "postgres"),
    "password": os.getenv("PG_ADMIN_PASSWORD", "")
}

def check_database_exists(conn, db_name):
    """Check if database exists"""
    cur = conn.cursor()
    cur.execute(
        "SELECT 1 FROM pg_database WHERE datname = %s",
        (db_name,)
    )
    exists = cur.fetchone() is not None
    cur.close()
    return exists

def check_user_exists(conn, username):
    """Check if user exists"""
    cur = conn.cursor()
    cur.execute(
        "SELECT 1 FROM pg_user WHERE usename = %s",
        (username,)
    )
    exists = cur.fetchone() is not None
    cur.close()
    return exists

def create_database_and_user():
    """Create database and user if they don't exist"""
    print("\n🔧 Setting up database and user...")
    
    try:
        # Connect as admin
        conn = psycopg2.connect(**ADMIN_CONFIG)
        conn.autocommit = True
        cur = conn.cursor()
        
        # Create user if doesn't exist
        if not check_user_exists(conn, DB_CONFIG["user"]):
            print(f"Creating user: {DB_CONFIG['user']}")
            cur.execute(
                f"CREATE USER {DB_CONFIG['user']} WITH PASSWORD %s",
                (DB_CONFIG['password'],)
            )
        else:
            print(f"User {DB_CONFIG['user']} already exists")
            # Update password anyway
            cur.execute(
                f"ALTER USER {DB_CONFIG['user']} WITH PASSWORD %s",
                (DB_CONFIG['password'],)
            )
        
        # Create database if doesn't exist
        if not check_database_exists(conn, DB_CONFIG["dbname"]):
            print(f"Creating database: {DB_CONFIG['dbname']}")
            cur.execute(f"CREATE DATABASE {DB_CONFIG['dbname']}")
        else:
            print(f"Database {DB_CONFIG['dbname']} already exists")
        
        # Grant privileges
        cur.execute(
            f"GRANT ALL PRIVILEGES ON DATABASE {DB_CONFIG['dbname']} TO {DB_CONFIG['user']}"
        )
        
        cur.close()
        conn.close()
        
        print("✅ Database and user setup complete")
        return True
        
    except psycopg2.Error as e:
        print(f"\n❌ Admin setup failed: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure PostgreSQL is running")
        print("2. Check admin credentials (PG_ADMIN_USER and PG_ADMIN_PASSWORD)")
        print("3. You may need to run as PostgreSQL superuser")
        return False

def execute_sql_file(conn, filepath):
    """Execute SQL file with proper error handling"""
    print(f"\n📄 Executing {filepath.name}...")
    
    with open(filepath, 'r') as f:
        sql = f.read()
    
    # Remove \c commands as we're already connected
    sql = '\n'.join(line for line in sql.split('\n') 
                    if not line.strip().startswith('\\c'))
    
    # Split by semicolons but keep them
    statements = []
    current = []
    for line in sql.split('\n'):
        current.append(line)
        if line.strip().endswith(';'):
            statements.append('\n'.join(current))
            current = []
    
    if current:  # Add any remaining lines
        statements.append('\n'.join(current))
    
    success_count = 0
    error_count = 0
    
    for statement in statements:
        statement = statement.strip()
        if not statement or statement.startswith('--'):
            continue
        
        # Create a new cursor for each statement to avoid transaction issues
        cur = conn.cursor()
        try:
            cur.execute(statement)
            conn.commit()  # Commit after each successful statement
            success_count += 1
        except psycopg2.Error as e:
            conn.rollback()  # Rollback on error
            error_count += 1
            error_msg = str(e).strip()
            if "already exists" not in error_msg and "duplicate key" not in error_msg:
                print(f"  ⚠️  Error: {error_msg}")
        finally:
            cur.close()
    
    print(f"  ✓ Executed {success_count} statements successfully")
    if error_count > 0:
        print(f"  ⚠️  {error_count} statements had errors (mostly duplicates)")
    
    return success_count > 0

def setup_database_schema():
    """Set up all database tables and migrations"""
    print("\n📊 Setting up database schema...")
    
    try:
        # Connect to the database as tuokit_user
        conn = psycopg2.connect(**DB_CONFIG)
        
        # Execute unified setup
        unified_sql = Path("unified_database_setup.sql")
        if unified_sql.exists():
            execute_sql_file(conn, unified_sql)
        else:
            print("⚠️  unified_database_setup.sql not found")
            print("Using individual migration files...")
            
            # Execute individual files in order
            migration_files = [
                "database_setup.sql",
                "database_migration_v0.4.sql",
                "database_migration_agents.sql",
                "database_migration_lite_agents.sql",
                "database_migration_knowledge_graph.sql",
                "database_migration_ruby_tools.sql",
                "database_migration_advanced_ruby.sql",
                "database_migration_professional_ruby.sql"
            ]
            
            for filename in migration_files:
                filepath = Path(filename)
                if filepath.exists():
                    execute_sql_file(conn, filepath)
                else:
                    print(f"  ⚠️  {filename} not found, skipping...")
        
        # Load sample data if requested
        if "--with-samples" in sys.argv:
            print("\n📚 Loading sample data...")
            sample_files = [
                "sample_knowledge_data.sql",
                "sample_documentation.sql"
            ]
            
            for filename in sample_files:
                filepath = Path(filename)
                if filepath.exists():
                    execute_sql_file(conn, filepath)
        
        # Verify setup
        cur = conn.cursor()
        cur.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_type = 'BASE TABLE'
            ORDER BY table_name
        """)
        
        tables = cur.fetchall()
        print(f"\n✅ Database setup complete! Found {len(tables)} tables:")
        for table in tables:
            print(f"  - {table[0]}")
        
        # Show counts
        cur.execute("SELECT COUNT(*) FROM queries")
        query_count = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM knowledge_units")
        knowledge_count = cur.fetchone()[0]
        
        print(f"\n📊 Current data:")
        print(f"  - Queries: {query_count}")
        print(f"  - Knowledge units: {knowledge_count}")
        
        cur.close()
        conn.close()
        
        return True
        
    except psycopg2.Error as e:
        print(f"\n❌ Schema setup failed: {e}")
        return False

def main():
    """Main setup process"""
    print("=" * 60)
    print("TuoKit Unified Database Setup")
    print("=" * 60)
    print(f"Host: {DB_CONFIG['host']}:{DB_CONFIG['port']}")
    print(f"Database: {DB_CONFIG['dbname']}")
    print(f"User: {DB_CONFIG['user']}")
    print("=" * 60)
    
    # Check if we should skip admin setup
    skip_admin = "--skip-admin" in sys.argv
    
    if not skip_admin:
        # Try to create database and user
        if not create_database_and_user():
            print("\n⚠️  Admin setup failed. Trying to continue with existing database...")
            response = input("Continue anyway? (y/n): ")
            if response.lower() != 'y':
                print("Setup cancelled.")
                return
    
    # Set up schema
    if setup_database_schema():
        print("\n✨ TuoKit database is ready to use!")
        print("\nNext steps:")
        print("1. Make sure your .env file has the correct credentials")
        print("2. Start TuoKit with: streamlit run app.py")
        
        if "--with-samples" not in sys.argv:
            print("\n💡 Tip: Run with --with-samples to load demo data:")
            print("   python setup_unified_database.py --with-samples")
    else:
        print("\n❌ Setup failed. Please check the errors above.")

if __name__ == "__main__":
    main()
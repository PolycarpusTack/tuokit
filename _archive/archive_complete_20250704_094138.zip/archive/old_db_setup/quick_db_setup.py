#!/usr/bin/env python3
"""
Quick TuoKit Database Setup
Simple script to get the database running
"""

import psycopg2
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def main():
    print("TuoKit Quick Database Setup")
    print("=" * 40)
    
    # Admin connection to create database
    admin_conn = psycopg2.connect(
        host="localhost",
        port="5432",
        dbname="postgres",
        user="postgres",
        password="Th1s1s4Work"
    )
    admin_conn.autocommit = True
    admin_cur = admin_conn.cursor()
    
    try:
        # Create database
        print("Creating database...")
        admin_cur.execute("CREATE DATABASE tuokit_knowledge")
        print("✓ Database created")
    except psycopg2.Error as e:
        if "already exists" in str(e):
            print("✓ Database already exists")
        else:
            print(f"Error: {e}")
    
    try:
        # Create user
        print("Creating user...")
        admin_cur.execute("CREATE USER tuokit_user WITH PASSWORD 'Th1s1s4Work'")
        print("✓ User created")
    except psycopg2.Error as e:
        if "already exists" in str(e):
            print("✓ User already exists")
            # Update password
            admin_cur.execute("ALTER USER tuokit_user WITH PASSWORD 'Th1s1s4Work'")
        else:
            print(f"Error: {e}")
    
    # Grant privileges
    admin_cur.execute("GRANT ALL PRIVILEGES ON DATABASE tuokit_knowledge TO tuokit_user")
    
    admin_cur.close()
    admin_conn.close()
    
    # Connect to new database
    print("\nSetting up tables...")
    conn = psycopg2.connect(
        host="localhost",
        port="5432",
        dbname="tuokit_knowledge",
        user="postgres",  # Use postgres user to ensure we have permissions
        password="Th1s1s4Work"
    )
    conn.autocommit = True
    cur = conn.cursor()
    
    # Create queries table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS queries (
            id SERIAL PRIMARY KEY,
            tool VARCHAR(100) NOT NULL,
            model VARCHAR(100) NOT NULL,
            user_prompt TEXT NOT NULL,
            ai_response TEXT NOT NULL,
            metadata JSONB,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("✓ Created queries table")
    
    # Create knowledge_units table
    cur.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_units (
            id SERIAL PRIMARY KEY,
            query_id INTEGER REFERENCES queries(id) ON DELETE CASCADE,
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL,
            category VARCHAR(100) NOT NULL,
            tags TEXT[],
            verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("✓ Created knowledge_units table")
    
    # Create indexes
    cur.execute("CREATE INDEX IF NOT EXISTS idx_queries_tool ON queries(tool)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_queries_created_at ON queries(created_at DESC)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_category ON knowledge_units(category)")
    print("✓ Created indexes")
    
    # Grant permissions to tuokit_user
    cur.execute("GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO tuokit_user")
    cur.execute("GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO tuokit_user")
    cur.execute("GRANT ALL PRIVILEGES ON SCHEMA public TO tuokit_user")
    print("✓ Granted permissions")
    
    # Add sample data
    cur.execute("""
        INSERT INTO queries (tool, model, user_prompt, ai_response)
        VALUES ('test', 'test-model', 'Test query', 'Test response')
        RETURNING id
    """)
    test_id = cur.fetchone()[0]
    print(f"✓ Added test query (ID: {test_id})")
    
    # Verify
    cur.execute("SELECT COUNT(*) FROM queries")
    count = cur.fetchone()[0]
    print(f"\n✅ Setup complete! Queries table has {count} record(s)")
    
    cur.close()
    conn.close()
    
    print("\nYou can now run TuoKit!")

if __name__ == "__main__":
    main()
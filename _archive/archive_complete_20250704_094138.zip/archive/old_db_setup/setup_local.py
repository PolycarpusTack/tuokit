"""
TuoKit Local Installation Setup
Configures connections to remote services
"""
import os
import sys
import json
import psycopg2
import requests
from pathlib import Path
import streamlit as st

def test_ollama_connection(host: str, api_key: str = None) -> tuple[bool, str]:
    """Test connection to Ollama server"""
    try:
        headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        response = requests.get(f"{host}/api/tags", headers=headers, timeout=5)
        if response.status_code == 200:
            models = response.json().get("models", [])
            return True, f"Connected! Found {len(models)} models"
        else:
            return False, f"Server returned status {response.status_code}"
    except requests.exceptions.ConnectionError:
        return False, "Could not connect to Ollama server"
    except Exception as e:
        return False, f"Error: {str(e)}"

def test_postgres_connection(host: str, port: int, database: str, 
                           user: str, password: str) -> tuple[bool, str]:
    """Test connection to PostgreSQL server"""
    try:
        conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password,
            connect_timeout=5
        )
        conn.close()
        return True, "Connected successfully!"
    except psycopg2.OperationalError as e:
        return False, f"Connection failed: {str(e)}"
    except Exception as e:
        return False, f"Error: {str(e)}"

def setup_wizard():
    """Interactive setup wizard for TuoKit"""
    st.set_page_config(page_title="TuoKit Setup", page_icon="🔧")
    st.title("🚀 TuoKit Local Installation Setup")
    st.markdown("Configure your local TuoKit to connect to remote services")
    
    # Create .env file path
    env_path = Path(".env")
    
    # Load existing config if available
    existing_config = {}
    if env_path.exists():
        with open(env_path, 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    existing_config[key] = value.strip('"')
    
    with st.form("setup_form"):
        st.subheader("🤖 Ollama Server Configuration")
        col1, col2 = st.columns(2)
        
        with col1:
            ollama_host = st.text_input(
                "Ollama Server URL",
                value=existing_config.get("TUOKIT_OLLAMA_HOST", "http://localhost:11434"),
                help="URL of your Ollama server (e.g., http://192.168.1.100:11434)"
            )
        
        with col2:
            ollama_api_key = st.text_input(
                "Ollama API Key (optional)",
                value=existing_config.get("TUOKIT_OLLAMA_API_KEY", ""),
                type="password",
                help="Leave empty if not required"
            )
        
        st.subheader("🗄️ PostgreSQL Configuration")
        col3, col4 = st.columns(2)
        
        with col3:
            pg_host = st.text_input(
                "PostgreSQL Host",
                value=existing_config.get("TUOKIT_PG_HOST", "localhost"),
                help="Hostname or IP address"
            )
            pg_port = st.number_input(
                "PostgreSQL Port",
                value=int(existing_config.get("TUOKIT_PG_PORT", "5432")),
                min_value=1,
                max_value=65535
            )
            pg_database = st.text_input(
                "Database Name",
                value=existing_config.get("TUOKIT_PG_DB", "tuokit_knowledge")
            )
        
        with col4:
            pg_user = st.text_input(
                "Username",
                value=existing_config.get("TUOKIT_PG_USER", "tuokit_user")
            )
            pg_password = st.text_input(
                "Password",
                value=existing_config.get("TUOKIT_PG_PASSWORD", ""),
                type="password"
            )
        
        st.subheader("📁 Storage Configuration")
        storage_path = st.text_input(
            "Shared Storage Path",
            value=existing_config.get("TUOKIT_STORAGE", "./data"),
            help="Local path or network share for file storage"
        )
        
        col5, col6 = st.columns(2)
        with col5:
            test_connections = st.form_submit_button("🧪 Test Connections", type="secondary")
        with col6:
            save_config = st.form_submit_button("💾 Save Configuration", type="primary")
    
    if test_connections:
        st.subheader("Connection Tests")
        
        # Test Ollama
        with st.spinner("Testing Ollama connection..."):
            ollama_ok, ollama_msg = test_ollama_connection(ollama_host, ollama_api_key)
        
        if ollama_ok:
            st.success(f"✅ Ollama: {ollama_msg}")
        else:
            st.error(f"❌ Ollama: {ollama_msg}")
        
        # Test PostgreSQL
        with st.spinner("Testing PostgreSQL connection..."):
            pg_ok, pg_msg = test_postgres_connection(
                pg_host, pg_port, pg_database, pg_user, pg_password
            )
        
        if pg_ok:
            st.success(f"✅ PostgreSQL: {pg_msg}")
        else:
            st.error(f"❌ PostgreSQL: {pg_msg}")
        
        # Test storage
        try:
            storage = Path(storage_path)
            if storage.exists() or storage.parent.exists():
                st.success(f"✅ Storage: Path is accessible")
            else:
                st.warning(f"⚠️ Storage: Path doesn't exist, will be created")
        except Exception as e:
            st.error(f"❌ Storage: {str(e)}")
    
    if save_config:
        # Save configuration to .env file
        env_content = f'''# TuoKit Configuration
# Generated by setup wizard

# Ollama Server
TUOKIT_OLLAMA_HOST="{ollama_host}"
TUOKIT_OLLAMA_API_KEY="{ollama_api_key}"

# PostgreSQL Database
TUOKIT_PG_HOST="{pg_host}"
TUOKIT_PG_PORT="{pg_port}"
TUOKIT_PG_DB="{pg_database}"
TUOKIT_PG_USER="{pg_user}"
TUOKIT_PG_PASSWORD="{pg_password}"

# Storage
TUOKIT_STORAGE="{storage_path}"

# Security
TUOKIT_SSL="true"
TUOKIT_VERIFY_SSL="true"
'''
        
        with open(env_path, 'w') as f:
            f.write(env_content)
        
        st.success("✅ Configuration saved to .env file!")
        st.info("You can now run TuoKit with: `streamlit run main.py`")
        
        # Create example launch script
        if sys.platform == "win32":
            launch_script = '''@echo off
echo Starting TuoKit...
streamlit run main.py
'''
            script_name = "start_tuokit.bat"
        else:
            launch_script = '''#!/bin/bash
echo "Starting TuoKit..."
streamlit run main.py
'''
            script_name = "start_tuokit.sh"
        
        with open(script_name, 'w') as f:
            f.write(launch_script)
        
        if sys.platform != "win32":
            os.chmod(script_name, 0o755)
        
        st.code(f"Created launch script: {script_name}", language="bash")

if __name__ == "__main__":
    setup_wizard()

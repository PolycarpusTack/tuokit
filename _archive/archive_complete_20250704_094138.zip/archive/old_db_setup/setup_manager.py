#!/usr/bin/env python3
"""
TuoKit Consolidated Setup Manager
Unified setup system for database, environment, and dependencies
"""

import os
import sys
import subprocess
import json
import platform
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import psycopg2
import sqlite3
import pymysql
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class SetupManager:
    """Manages all setup operations for TuoKit"""
    
    def __init__(self, mode: str = "interactive"):
        self.mode = mode
        self.log_file = f"setup_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        self.os_type = platform.system()
        self.setup_complete = False
        
        # Database configurations
        self.db_configs = {
            'postgresql': {
                'host': os.getenv('TUOKIT_PG_HOST', 'localhost'),
                'port': os.getenv('TUOKIT_PG_PORT', '5432'),
                'dbname': os.getenv('TUOKIT_PG_DB', 'tuokit_knowledge'),
                'user': os.getenv('TUOKIT_PG_USER', 'tuokit_user'),
                'password': os.getenv('TUOKIT_PG_PASSWORD', 'your_secure_password')
            },
            'sqlite': {
                'path': os.getenv('TUOKIT_SQLITE_PATH', 'tuokit.db')
            },
            'mysql': {
                'host': os.getenv('TUOKIT_MYSQL_HOST', 'localhost'),
                'port': int(os.getenv('TUOKIT_MYSQL_PORT', '3306')),
                'database': os.getenv('TUOKIT_MYSQL_DB', 'tuokit_knowledge'),
                'user': os.getenv('TUOKIT_MYSQL_USER', 'tuokit_user'),
                'password': os.getenv('TUOKIT_MYSQL_PASSWORD', 'your_secure_password')
            }
        }
        
        # Required Python packages
        self.required_packages = [
            'streamlit>=1.28.0',
            'pandas>=1.5.3',
            'psycopg2-binary>=2.9.9',
            'pymysql>=1.1.0',
            'python-dotenv>=1.0.0',
            'requests>=2.31.0',
            'beautifulsoup4>=4.12.2',
            'ollama>=0.1.7',
            'click>=8.1.7',
            'rich>=13.5.2'
        ]
        
    def log(self, message: str, level: str = "INFO"):
        """Log messages to console and file"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_message = f"[{timestamp}] [{level}] {message}"
        
        # Console output with color
        if level == "ERROR":
            print(f"❌ {message}")
        elif level == "SUCCESS":
            print(f"✅ {message}")
        elif level == "WARNING":
            print(f"⚠️  {message}")
        else:
            print(f"📋 {message}")
        
        # File output
        with open(self.log_file, 'a') as f:
            f.write(log_message + '\n')
    
    def run_command(self, command: List[str], timeout: int = 300) -> Tuple[bool, str, str]:
        """Run a command and return success, stdout, stderr"""
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.returncode == 0, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "Command timed out"
        except Exception as e:
            return False, "", str(e)
    
    def check_prerequisites(self) -> bool:
        """Check system prerequisites"""
        self.log("Checking prerequisites...")
        
        # Check Python version
        py_version = sys.version_info
        if py_version < (3, 7):
            self.log(f"Python {py_version.major}.{py_version.minor} found, need 3.7+", "ERROR")
            return False
        self.log(f"Python {py_version.major}.{py_version.minor}.{py_version.micro} found", "SUCCESS")
        
        # Check pip
        success, _, _ = self.run_command([sys.executable, "-m", "pip", "--version"])
        if not success:
            self.log("pip not found", "ERROR")
            return False
        self.log("pip is available", "SUCCESS")
        
        # Check git (optional but recommended)
        success, _, _ = self.run_command(["git", "--version"])
        if not success:
            self.log("git not found (optional but recommended)", "WARNING")
        else:
            self.log("git is available", "SUCCESS")
        
        return True
    
    def setup_python_environment(self) -> bool:
        """Set up Python virtual environment"""
        self.log("Setting up Python environment...")
        
        venv_path = Path("tuokit-env")
        
        # Check if venv exists
        if venv_path.exists():
            self.log("Virtual environment already exists", "SUCCESS")
        else:
            # Create virtual environment
            self.log("Creating virtual environment...")
            success, _, error = self.run_command([sys.executable, "-m", "venv", "tuokit-env"])
            if not success:
                self.log(f"Failed to create virtual environment: {error}", "ERROR")
                return False
            self.log("Virtual environment created", "SUCCESS")
        
        # Get activation script path
        if self.os_type == "Windows":
            activate_script = venv_path / "Scripts" / "activate.bat"
            pip_path = venv_path / "Scripts" / "pip.exe"
        else:
            activate_script = venv_path / "bin" / "activate"
            pip_path = venv_path / "bin" / "pip"
        
        # Install required packages
        self.log("Installing required packages...")
        for package in self.required_packages:
            self.log(f"Installing {package}...")
            success, _, error = self.run_command([str(pip_path), "install", package])
            if not success:
                self.log(f"Failed to install {package}: {error}", "ERROR")
                return False
        
        self.log("All packages installed successfully", "SUCCESS")
        
        # Create activation helper scripts
        self._create_activation_scripts()
        
        return True
    
    def _create_activation_scripts(self):
        """Create OS-specific activation helper scripts"""
        if self.os_type == "Windows":
            # Windows batch script
            script_content = """@echo off
call tuokit-env\\Scripts\\activate.bat
echo TuoKit environment activated!
"""
            with open("activate.bat", "w") as f:
                f.write(script_content)
            self.log("Created activate.bat", "SUCCESS")
        else:
            # Unix shell script
            script_content = """#!/bin/bash
source tuokit-env/bin/activate
echo "TuoKit environment activated!"
"""
            with open("activate.sh", "w") as f:
                f.write(script_content)
            os.chmod("activate.sh", 0o755)
            self.log("Created activate.sh", "SUCCESS")
    
    def test_database_connection(self, db_type: str) -> bool:
        """Test database connection"""
        self.log(f"Testing {db_type} connection...")
        
        try:
            if db_type == 'postgresql':
                config = self.db_configs['postgresql']
                conn = psycopg2.connect(**config)
                conn.close()
            elif db_type == 'sqlite':
                config = self.db_configs['sqlite']
                conn = sqlite3.connect(config['path'])
                conn.close()
            elif db_type == 'mysql':
                config = self.db_configs['mysql']
                conn = pymysql.connect(**config)
                conn.close()
            else:
                self.log(f"Unknown database type: {db_type}", "ERROR")
                return False
            
            self.log(f"{db_type} connection successful", "SUCCESS")
            return True
            
        except Exception as e:
            self.log(f"{db_type} connection failed: {str(e)}", "ERROR")
            return False
    
    def setup_postgresql(self) -> bool:
        """Set up PostgreSQL database"""
        self.log("Setting up PostgreSQL database...")
        
        # Try admin connection first
        admin_config = {
            'host': self.db_configs['postgresql']['host'],
            'port': self.db_configs['postgresql']['port'],
            'dbname': 'postgres',
            'user': os.getenv('PG_ADMIN_USER', 'postgres'),
            'password': os.getenv('PG_ADMIN_PASSWORD', '')
        }
        
        try:
            # Connect as admin
            admin_conn = psycopg2.connect(**admin_config)
            admin_conn.autocommit = True
            cur = admin_conn.cursor()
            
            # Create user if doesn't exist
            user = self.db_configs['postgresql']['user']
            password = self.db_configs['postgresql']['password']
            
            cur.execute("SELECT 1 FROM pg_user WHERE usename = %s", (user,))
            if not cur.fetchone():
                cur.execute(f"CREATE USER {user} WITH PASSWORD %s", (password,))
                self.log(f"Created user: {user}", "SUCCESS")
            else:
                cur.execute(f"ALTER USER {user} WITH PASSWORD %s", (password,))
                self.log(f"Updated password for user: {user}", "SUCCESS")
            
            # Create database if doesn't exist
            dbname = self.db_configs['postgresql']['dbname']
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (dbname,))
            if not cur.fetchone():
                cur.execute(f"CREATE DATABASE {dbname}")
                self.log(f"Created database: {dbname}", "SUCCESS")
            else:
                self.log(f"Database {dbname} already exists", "SUCCESS")
            
            # Grant privileges
            cur.execute(f"GRANT ALL PRIVILEGES ON DATABASE {dbname} TO {user}")
            
            cur.close()
            admin_conn.close()
            
        except psycopg2.Error as e:
            self.log(f"Admin setup failed: {e}", "ERROR")
            self.log("Attempting to continue with existing database...", "WARNING")
        
        # Now set up schema
        try:
            conn = psycopg2.connect(**self.db_configs['postgresql'])
            self._execute_sql_files(conn, 'postgresql')
            conn.close()
            self.log("PostgreSQL setup complete", "SUCCESS")
            return True
            
        except Exception as e:
            self.log(f"Schema setup failed: {e}", "ERROR")
            return False
    
    def setup_sqlite(self) -> bool:
        """Set up SQLite database"""
        self.log("Setting up SQLite database...")
        
        try:
            db_path = self.db_configs['sqlite']['path']
            conn = sqlite3.connect(db_path)
            self._execute_sql_files(conn, 'sqlite')
            conn.close()
            self.log(f"SQLite database created at: {db_path}", "SUCCESS")
            return True
            
        except Exception as e:
            self.log(f"SQLite setup failed: {e}", "ERROR")
            return False
    
    def setup_mysql(self) -> bool:
        """Set up MySQL database"""
        self.log("Setting up MySQL database...")
        
        config = self.db_configs['mysql'].copy()
        db_name = config.pop('database')
        
        try:
            # Connect without database first
            conn = pymysql.connect(**config)
            cur = conn.cursor()
            
            # Create database if doesn't exist
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
            self.log(f"Database {db_name} ready", "SUCCESS")
            
            cur.close()
            conn.close()
            
            # Now connect to the database
            config['database'] = db_name
            conn = pymysql.connect(**config)
            self._execute_sql_files(conn, 'mysql')
            conn.close()
            
            self.log("MySQL setup complete", "SUCCESS")
            return True
            
        except Exception as e:
            self.log(f"MySQL setup failed: {e}", "ERROR")
            return False
    
    def _execute_sql_files(self, conn, db_type: str):
        """Execute SQL migration files"""
        sql_files = [
            "unified_database_setup.sql",
            "database_setup.sql",
            "database_migration_v0.4.sql",
            "database_migration_agents.sql",
            "database_migration_lite_agents.sql",
            "database_migration_knowledge_graph.sql",
            "database_migration_ruby_tools.sql",
            "database_migration_advanced_ruby.sql",
            "database_migration_professional_ruby.sql"
        ]
        
        # Try unified setup first
        if Path("unified_database_setup.sql").exists():
            self.log("Executing unified database setup...")
            self._execute_single_sql_file(conn, "unified_database_setup.sql", db_type)
        else:
            # Execute individual files
            for sql_file in sql_files:
                if Path(sql_file).exists():
                    self._execute_single_sql_file(conn, sql_file, db_type)
    
    def _execute_single_sql_file(self, conn, filepath: str, db_type: str):
        """Execute a single SQL file"""
        self.log(f"Executing {filepath}...")
        
        with open(filepath, 'r') as f:
            sql = f.read()
        
        # Adapt SQL for different databases
        if db_type == 'sqlite':
            sql = self._adapt_sql_for_sqlite(sql)
        elif db_type == 'mysql':
            sql = self._adapt_sql_for_mysql(sql)
        
        # Split and execute statements
        statements = self._split_sql_statements(sql)
        
        cur = conn.cursor()
        success_count = 0
        error_count = 0
        
        for statement in statements:
            if not statement.strip():
                continue
            
            try:
                cur.execute(statement)
                if db_type == 'postgresql':
                    conn.commit()
                success_count += 1
            except Exception as e:
                if db_type == 'postgresql':
                    conn.rollback()
                error_count += 1
                if "already exists" not in str(e).lower():
                    self.log(f"Error: {str(e)[:100]}...", "WARNING")
        
        if db_type != 'postgresql':
            conn.commit()
        
        cur.close()
        self.log(f"Executed {success_count} statements, {error_count} errors", "SUCCESS")
    
    def _split_sql_statements(self, sql: str) -> List[str]:
        """Split SQL into individual statements"""
        # Remove comments
        lines = []
        for line in sql.split('\n'):
            if not line.strip().startswith('--'):
                lines.append(line)
        sql = '\n'.join(lines)
        
        # Split by semicolon
        statements = sql.split(';')
        return [s.strip() for s in statements if s.strip()]
    
    def _adapt_sql_for_sqlite(self, sql: str) -> str:
        """Adapt PostgreSQL SQL for SQLite"""
        # Replace SERIAL with INTEGER PRIMARY KEY AUTOINCREMENT
        sql = sql.replace('SERIAL PRIMARY KEY', 'INTEGER PRIMARY KEY AUTOINCREMENT')
        sql = sql.replace('BIGSERIAL PRIMARY KEY', 'INTEGER PRIMARY KEY AUTOINCREMENT')
        
        # Replace BOOLEAN with INTEGER
        sql = sql.replace('BOOLEAN', 'INTEGER')
        
        # Replace NOW() with CURRENT_TIMESTAMP
        sql = sql.replace('NOW()', 'CURRENT_TIMESTAMP')
        
        # Remove or replace PostgreSQL-specific features
        sql = sql.replace('JSONB', 'TEXT')
        sql = sql.replace('TEXT[]', 'TEXT')
        sql = sql.replace('TIMESTAMPTZ', 'TIMESTAMP')
        
        # Remove USING GIN
        import re
        sql = re.sub(r'CREATE INDEX .* USING GIN\(.*?\);', '', sql)
        
        return sql
    
    def _adapt_sql_for_mysql(self, sql: str) -> str:
        """Adapt PostgreSQL SQL for MySQL"""
        # Replace SERIAL with AUTO_INCREMENT
        sql = sql.replace('SERIAL PRIMARY KEY', 'INT AUTO_INCREMENT PRIMARY KEY')
        sql = sql.replace('BIGSERIAL PRIMARY KEY', 'BIGINT AUTO_INCREMENT PRIMARY KEY')
        
        # Replace NOW() with CURRENT_TIMESTAMP
        sql = sql.replace('NOW()', 'CURRENT_TIMESTAMP')
        
        # Replace PostgreSQL-specific types
        sql = sql.replace('JSONB', 'JSON')
        sql = sql.replace('TEXT[]', 'TEXT')
        sql = sql.replace('TIMESTAMPTZ', 'TIMESTAMP')
        
        # Remove USING GIN
        import re
        sql = re.sub(r'CREATE INDEX .* USING GIN\(.*?\);', '', sql)
        
        return sql
    
    def setup_ollama(self) -> bool:
        """Set up and verify Ollama connection"""
        self.log("Setting up Ollama...")
        
        # Check if Ollama is installed
        success, _, _ = self.run_command(["ollama", "--version"])
        if not success:
            self.log("Ollama not installed", "ERROR")
            self.log("Install from: https://ollama.ai", "WARNING")
            return False
        
        # Check if Ollama is running
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                self.log(f"Ollama is running with {len(models)} models", "SUCCESS")
                
                if not models:
                    self.log("No models found. Pull a model with: ollama pull llama2", "WARNING")
                
                return True
        except:
            self.log("Ollama is not running", "ERROR")
            self.log("Start Ollama with: ollama serve", "WARNING")
            return False
    
    def create_env_file(self):
        """Create or update .env file"""
        self.log("Creating .env file...")
        
        env_content = f"""# TuoKit Configuration
# Generated by setup_manager.py on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# PostgreSQL Configuration
TUOKIT_PG_HOST={self.db_configs['postgresql']['host']}
TUOKIT_PG_PORT={self.db_configs['postgresql']['port']}
TUOKIT_PG_DB={self.db_configs['postgresql']['dbname']}
TUOKIT_PG_USER={self.db_configs['postgresql']['user']}
TUOKIT_PG_PASSWORD={self.db_configs['postgresql']['password']}

# SQLite Configuration
TUOKIT_SQLITE_PATH={self.db_configs['sqlite']['path']}

# MySQL Configuration
TUOKIT_MYSQL_HOST={self.db_configs['mysql']['host']}
TUOKIT_MYSQL_PORT={self.db_configs['mysql']['port']}
TUOKIT_MYSQL_DB={self.db_configs['mysql']['database']}
TUOKIT_MYSQL_USER={self.db_configs['mysql']['user']}
TUOKIT_MYSQL_PASSWORD={self.db_configs['mysql']['password']}

# Active Database (postgresql, sqlite, or mysql)
TUOKIT_DB_TYPE=postgresql

# Ollama Configuration
OLLAMA_HOST=http://localhost:11434

# Feature Flags
USE_NEXT_GEN_TOOLS=false
ENABLE_CACHING=true
DEBUG_MODE=false
"""
        
        # Backup existing .env
        if Path(".env").exists():
            backup_path = f".env.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            Path(".env").rename(backup_path)
            self.log(f"Backed up existing .env to {backup_path}", "SUCCESS")
        
        # Write new .env
        with open(".env", "w") as f:
            f.write(env_content)
        
        self.log(".env file created", "SUCCESS")
    
    def verify_setup(self) -> bool:
        """Verify the complete setup"""
        self.log("Verifying setup...")
        
        checks = {
            "Python environment": Path("tuokit-env").exists(),
            ".env file": Path(".env").exists(),
            "Activation script": Path("activate.bat" if self.os_type == "Windows" else "activate.sh").exists()
        }
        
        all_good = True
        for check, result in checks.items():
            if result:
                self.log(f"{check}: OK", "SUCCESS")
            else:
                self.log(f"{check}: MISSING", "ERROR")
                all_good = False
        
        return all_good
    
    def run_quick_setup(self) -> bool:
        """Run quick setup with defaults"""
        self.log("Running quick setup with defaults...")
        
        # Check prerequisites
        if not self.check_prerequisites():
            return False
        
        # Set up Python environment
        if not self.setup_python_environment():
            return False
        
        # Create .env file
        self.create_env_file()
        
        # Set up PostgreSQL by default
        self.setup_postgresql()
        
        # Set up Ollama
        self.setup_ollama()
        
        # Verify
        return self.verify_setup()
    
    def run_interactive_setup(self) -> bool:
        """Run interactive setup with user choices"""
        print("\n" + "="*60)
        print("🚀 TuoKit Interactive Setup")
        print("="*60 + "\n")
        
        # Check prerequisites
        if not self.check_prerequisites():
            input("\nPress Enter to exit...")
            return False
        
        # Python environment
        response = input("\nSet up Python virtual environment? (y/n): ")
        if response.lower() == 'y':
            if not self.setup_python_environment():
                return False
        
        # Database selection
        print("\nSelect database type:")
        print("1. PostgreSQL (recommended)")
        print("2. SQLite (simple, file-based)")
        print("3. MySQL")
        print("4. All of the above")
        
        db_choice = input("\nEnter choice (1-4): ")
        
        databases_to_setup = []
        if db_choice == '1':
            databases_to_setup = ['postgresql']
        elif db_choice == '2':
            databases_to_setup = ['sqlite']
        elif db_choice == '3':
            databases_to_setup = ['mysql']
        elif db_choice == '4':
            databases_to_setup = ['postgresql', 'sqlite', 'mysql']
        else:
            self.log("Invalid choice", "ERROR")
            return False
        
        # Set up selected databases
        for db_type in databases_to_setup:
            if db_type == 'postgresql':
                self.setup_postgresql()
            elif db_type == 'sqlite':
                self.setup_sqlite()
            elif db_type == 'mysql':
                self.setup_mysql()
        
        # Create .env file
        response = input("\nCreate/update .env file? (y/n): ")
        if response.lower() == 'y':
            self.create_env_file()
        
        # Ollama setup
        response = input("\nSet up Ollama? (y/n): ")
        if response.lower() == 'y':
            self.setup_ollama()
        
        # Final verification
        self.verify_setup()
        
        print("\n" + "="*60)
        print("✅ Setup Complete!")
        print("="*60)
        print("\nNext steps:")
        print("1. Activate environment:")
        if self.os_type == "Windows":
            print("   activate.bat")
        else:
            print("   source activate.sh")
        print("2. Start TuoKit:")
        print("   streamlit run app.py")
        
        return True
    
    def diagnose_issues(self):
        """Diagnose common setup issues"""
        self.log("Running diagnostics...")
        
        issues = []
        
        # Check Python packages
        try:
            import streamlit
        except ImportError:
            issues.append("Streamlit not installed")
        
        try:
            import psycopg2
        except ImportError:
            issues.append("psycopg2 not installed")
        
        # Check database connections
        for db_type in ['postgresql', 'sqlite', 'mysql']:
            if not self.test_database_connection(db_type):
                issues.append(f"{db_type} connection failed")
        
        # Check Ollama
        if not self.setup_ollama():
            issues.append("Ollama not available")
        
        # Report findings
        if issues:
            self.log("\nFound issues:", "WARNING")
            for issue in issues:
                self.log(f"  - {issue}", "ERROR")
            
            self.log("\nSuggested fixes:", "WARNING")
            if "not installed" in str(issues):
                self.log("  - Run: pip install -r requirements.txt", "WARNING")
            if "connection failed" in str(issues):
                self.log("  - Check database credentials in .env", "WARNING")
                self.log("  - Ensure database server is running", "WARNING")
            if "Ollama" in str(issues):
                self.log("  - Install Ollama from https://ollama.ai", "WARNING")
                self.log("  - Start Ollama: ollama serve", "WARNING")
        else:
            self.log("No issues found!", "SUCCESS")


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="TuoKit Setup Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python setup_manager.py --quick           # Quick setup with defaults
  python setup_manager.py --interactive     # Interactive setup
  python setup_manager.py --diagnose        # Diagnose issues
  python setup_manager.py --verify          # Verify setup

Database options:
  --postgresql    Set up PostgreSQL
  --sqlite        Set up SQLite  
  --mysql         Set up MySQL
  --all-db        Set up all databases
        """
    )
    
    parser.add_argument('--quick', action='store_true', help='Quick setup with defaults')
    parser.add_argument('--interactive', action='store_true', help='Interactive setup')
    parser.add_argument('--diagnose', action='store_true', help='Diagnose setup issues')
    parser.add_argument('--verify', action='store_true', help='Verify current setup')
    
    # Database options
    parser.add_argument('--postgresql', action='store_true', help='Set up PostgreSQL')
    parser.add_argument('--sqlite', action='store_true', help='Set up SQLite')
    parser.add_argument('--mysql', action='store_true', help='Set up MySQL')
    parser.add_argument('--all-db', action='store_true', help='Set up all databases')
    
    # Environment options
    parser.add_argument('--skip-venv', action='store_true', help='Skip virtual environment setup')
    parser.add_argument('--skip-ollama', action='store_true', help='Skip Ollama setup')
    
    args = parser.parse_args()
    
    # Create setup manager
    manager = SetupManager()
    
    # Handle different modes
    if args.diagnose:
        manager.diagnose_issues()
    elif args.verify:
        manager.verify_setup()
    elif args.quick:
        manager.run_quick_setup()
    elif args.interactive or not any(vars(args).values()):
        manager.run_interactive_setup()
    else:
        # Custom setup based on flags
        if not args.skip_venv:
            manager.setup_python_environment()
        
        if args.postgresql or args.all_db:
            manager.setup_postgresql()
        if args.sqlite or args.all_db:
            manager.setup_sqlite()
        if args.mysql or args.all_db:
            manager.setup_mysql()
        
        if not args.skip_ollama:
            manager.setup_ollama()
        
        manager.create_env_file()
        manager.verify_setup()
    
    print(f"\nLog saved to: {manager.log_file}")


if __name__ == "__main__":
    main()
"""
🤖 TuoKit Unified Agent System
Merges ALL features from agent_system.py and agent_lite.py
Includes: Specialist agents, pipeline automator, educational companion, orchestration
"""

import streamlit as st
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum
import json
import time
from datetime import datetime

from utils import DatabaseManager, safe_ollama_generate

# ========== AGENT TYPES AND STATE (from agent_system) ==========

class AgentType(Enum):
    SPECIALIST = "specialist"
    TEAM = "team"
    META = "meta"
    PIPELINE = "pipeline"
    EDUCATIONAL = "educational"

@dataclass
class AgentState:
    goal: str
    phase: str = "planning"  # planning → execution → validation
    steps: List[Dict] = None
    current_step: int = 0
    attempts: int = 0
    max_retries: int = 3
    results: Dict = None
    agent_history: List[str] = None
    
    def __post_init__(self):
        if self.steps is None:
            self.steps = []
        if self.results is None:
            self.results = {}
        if self.agent_history is None:
            self.agent_history = []

# ========== BASE AGENT CLASS (from agent_system) ==========

class BaseAgent:
    """Base class for all TuoKit agents"""
    def __init__(self, name: str, description: str, tools: List[str]):
        self.name = name
        self.description = description
        self.tools = tools
        self.db = DatabaseManager()
        
    def plan(self, goal: str, model: str = "deepseek-r1:1.5b") -> List[Dict]:
        """Generate execution plan for the goal"""
        prompt = f"""
        As {self.name}, create a step-by-step plan for: {goal}
        
        Available tools: {', '.join(self.tools)}
        
        Return JSON array of steps:
        [{{"step": 1, "action": "...", "tool": "...", "expected_output": "..."}}]
        """
        
        response = safe_ollama_generate(model=model, prompt=prompt)
        try:
            # Extract JSON from response
            import re
            json_match = re.search(r'\[.*\]', response['response'], re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except:
            # Fallback to simple plan
            return [{"step": 1, "action": goal, "tool": self.tools[0], "expected_output": "result"}]
    
    def execute_tool(self, tool: str, params: Dict) -> Dict:
        """Execute a specific tool with error handling"""
        tool_map = {
            "code_explainer": self._execute_code_explainer,
            "sql_generator": self._execute_sql_generator,
            "doc_qa": self._execute_doc_qa,
            "error_decoder": self._execute_error_decoder,
            "regex_generator": self._execute_regex_generator,
            "doc_summarizer": self._execute_doc_summarizer,
            "sql_optimizer": self._execute_sql_optimizer
        }
        
        if tool not in tool_map:
            return {"success": False, "error": f"Unknown tool: {tool}"}
        
        try:
            result = tool_map[tool](params)
            # Log to knowledge base
            if self.db.connected:
                self.db.log_query(
                    tool=f"agent_{self.name}_{tool}",
                    model=params.get('model', 'deepseek-r1:1.5b'),
                    prompt=str(params),
                    response=str(result)
                )
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _execute_code_explainer(self, params: Dict) -> str:
        """Execute code explanation using existing tool logic"""
        try:
            from pages.code_tools import explain_code
            return explain_code(params['code'], params.get('model', 'deepseek-coder:6.7b'))
        except ImportError:
            # Fallback implementation
            prompt = f"Explain this code:\n{params['code']}"
            response = safe_ollama_generate(params.get('model', 'deepseek-coder:6.7b'), prompt)
            return response['response']
    
    def _execute_sql_generator(self, params: Dict) -> str:
        """Execute SQL generation"""
        prompt = f"Generate SQL for: {params['query']}\nDialect: {params.get('dialect', 'PostgreSQL')}"
        response = safe_ollama_generate(
            model=params.get('model', 'deepseek-coder:6.7b'),
            prompt=prompt
        )
        return response['response']
    
    def _execute_sql_optimizer(self, params: Dict) -> str:
        """Execute SQL optimization"""
        prompt = f"Optimize this SQL:\n{params['sql']}\nTarget: {params.get('target', 'performance')}"
        response = safe_ollama_generate(
            model=params.get('model', 'deepseek-coder:6.7b'),
            prompt=prompt
        )
        return response['response']
    
    def _execute_doc_qa(self, params: Dict) -> str:
        """Execute document Q&A"""
        prompt = f"Based on this document: {params['document'][:1000]}...\nQuestion: {params['question']}"
        response = safe_ollama_generate(
            model=params.get('model', 'deepseek-r1:1.5b'),
            prompt=prompt
        )
        return response['response']
    
    def _execute_doc_summarizer(self, params: Dict) -> str:
        """Execute document summarization"""
        prompt = f"Summarize this text in {params.get('length', 100)} words: {params.get('text', '')}"
        response = safe_ollama_generate("deepseek-r1:1.5b", prompt)
        return response['response']
    
    def _execute_error_decoder(self, params: Dict) -> str:
        """Decode error messages"""
        try:
            from pages.error_tool import decode_error_comprehensive
            return decode_error_comprehensive(
                params['error_message'],
                params.get('code_context', ''),
                params.get('model', 'deepseek-coder:6.7b')
            )
        except ImportError:
            # Fallback implementation
            prompt = f"Explain this error:\n{params['error_message']}\nCode:\n{params.get('code_context', '')}"
            response = safe_ollama_generate(params.get('model', 'deepseek-coder:6.7b'), prompt)
            return response['response']
    
    def _execute_regex_generator(self, params: Dict) -> str:
        """Generate regex patterns"""
        try:
            from pages.regex_tool import generate_regex
            return generate_regex(
                params['description'],
                params.get('model', 'deepseek-coder:6.7b')
            )
        except ImportError:
            # Fallback implementation
            prompt = f"Generate a regex pattern for: {params['description']}"
            response = safe_ollama_generate(params.get('model', 'deepseek-coder:6.7b'), prompt)
            return response['response']

# ========== SPECIALIST AGENT (from agent_system) ==========

class SpecialistAgent(BaseAgent):
    """Agent specialized in specific domain tasks"""
    def execute(self, state: AgentState) -> AgentState:
        """Execute the agent's plan with state tracking"""
        state.phase = "execution"
        
        for i, step in enumerate(state.steps):
            state.current_step = i
            state.agent_history.append(f"[{self.name}] Executing: {step['action']}")
            
            # Execute with retry logic
            for attempt in range(state.max_retries):
                state.attempts = attempt + 1
                result = self.execute_tool(step['tool'], step.get('params', {}))
                
                if result['success']:
                    state.results[f"step_{i}"] = result['result']
                    break
                elif attempt < state.max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
            else:
                state.results[f"step_{i}"] = f"Failed after {state.max_retries} attempts"
        
        state.phase = "validation"
        return state

# ========== PIPELINE EXECUTION (from agent_lite) ==========

def run_pipeline(steps: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Execute tool sequence with data passing"""
    results = {}
    execution_log = []
    
    # Create a base agent for tool execution
    pipeline_agent = BaseAgent("PipelineExecutor", "Executes tool pipelines", [])
    
    for i, step in enumerate(steps):
        tool = step["tool"]
        params = step.get("params", {})
        step_name = step.get("name", f"Step {i+1}")
        
        try:
            # Make previous results available
            params["previous_results"] = results
            
            # Execute through the base agent
            result = pipeline_agent.execute_tool(tool, params)
            
            if result["success"]:
                output = result["result"]
                success = True
            else:
                output = result["error"]
                success = False
            
            # Store results for next steps
            results[step_name] = output
            
            execution_log.append({
                "step": step_name,
                "tool": tool,
                "input": params,
                "output": output[:200] + "..." if len(str(output)) > 200 else output,
                "success": success,
                "timestamp": datetime.now().isoformat()
            })
            
        except Exception as e:
            error_msg = f"Error in {tool}: {str(e)}"
            results[step_name] = error_msg
            execution_log.append({
                "step": step_name,
                "tool": tool,
                "input": params,
                "output": error_msg,
                "success": False,
                "timestamp": datetime.now().isoformat()
            })
    
    return {"results": results, "log": execution_log}

# ========== EDUCATIONAL COMPANION (from agent_lite) ==========

class EducationalAgent:
    """Provides contextual guidance and learning support"""
    
    def __init__(self):
        self.db = DatabaseManager()
    
    def guide(self, context: str, action: str) -> Dict[str, str]:
        """Provide contextual guidance"""
        prompt = f"""
        User is working on: {context}
        Current action: {action}
        
        Provide helpful guidance in JSON format:
        {{
            "explanation": "One clear sentence explaining what this action does",
            "tip": "Best practice tip for this situation",
            "mistake": "Common mistake to avoid",
            "next_step": "Suggested next action"
        }}
        
        Be specific and practical. Focus on TuoKit tools.
        """
        
        response = safe_ollama_generate(
            model=st.session_state.get("selected_model", "deepseek-r1:1.5b"),
            prompt=prompt,
            temperature=0.7
        )
        
        try:
            # Try to parse JSON response
            import re
            json_match = re.search(r'\{.*\}', response['response'], re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                return result
        except:
            # Fallback to structured response
            return {
                "explanation": "This action helps process your data efficiently.",
                "tip": "Start with simple parameters and refine as needed.",
                "mistake": "Avoid complex queries on your first attempt.",
                "next_step": "Test with a small dataset first."
            }

# ========== AGENT ORCHESTRATOR (from agent_system) ==========

class AgentOrchestrator:
    """Manages agent selection and execution workflow"""
    def __init__(self):
        # Pre-configured Specialist Agents
        self.agents = {
            "data_engineer": SpecialistAgent(
                name="DataEngineer",
                description="SQL generation, data analysis, ETL pipelines",
                tools=["sql_generator", "sql_optimizer", "sql_pipeline"]
            ),
            "code_architect": SpecialistAgent(
                name="CodeArchitect", 
                description="Code explanation, debugging, generation",
                tools=["code_explainer", "error_decoder", "regex_generator"]
            ),
            "doc_scientist": SpecialistAgent(
                name="DocScientist",
                description="Document analysis, Q&A, summarization",
                tools=["doc_qa", "doc_summarizer"]
            ),
            "full_stack": SpecialistAgent(
                name="FullStackDeveloper",
                description="End-to-end development tasks",
                tools=["code_explainer", "sql_generator", "error_decoder", "regex_generator"]
            )
        }
        self.db = DatabaseManager()
        
    def analyze_goal(self, goal: str, model: str = "deepseek-r1:1.5b") -> str:
        """Determine which agent is best suited for the goal"""
        agent_descriptions = "\n".join([
            f"- {name}: {agent.description}" 
            for name, agent in self.agents.items()
        ])
        
        prompt = f"""
        Given this goal: {goal}
        
        Available agents:
        {agent_descriptions}
        
        Which agent is best suited? Return ONLY the agent name.
        """
        
        response = safe_ollama_generate(model=model, prompt=prompt)
        agent_name = response['response'].strip().lower()
        
        # Match to known agent
        for key in self.agents.keys():
            if key in agent_name:
                return key
        
        # Default to data engineer
        return "data_engineer"
    
    def execute_with_agent(self, goal: str, agent_name: str = None) -> AgentState:
        """Execute goal with specified or auto-selected agent"""
        # Select agent
        if not agent_name:
            agent_name = self.analyze_goal(goal)
        
        if agent_name not in self.agents:
            agent_name = "data_engineer"  # Default
        
        agent = self.agents[agent_name]
        
        # Create state
        state = AgentState(goal=goal)
        state.agent_history.append(f"Selected agent: {agent.name}")
        
        # Planning phase
        state.phase = "planning"
        state.steps = agent.plan(goal)
        state.agent_history.append(f"Created plan with {len(state.steps)} steps")
        
        # Execution phase
        state = agent.execute(state)
        
        return state

# ========== STREAMLIT UI (Merged from both) ==========

def show():
    st.set_page_config(
        page_title="TuoKit - Unified Agent System",
        page_icon="🤖",
        layout="wide"
    )
    
    st.title("🤖 Unified Agent System")
    st.markdown("**Complete automation with specialist agents, pipelines, and learning companion**")
    
    # Initialize database
    if "db" not in st.session_state:
        st.session_state.db = DatabaseManager()
    
    # Initialize orchestrator
    if "orchestrator" not in st.session_state:
        st.session_state.orchestrator = AgentOrchestrator()
    
    # Agent selection
    agent_mode = st.radio(
        "Select Agent Mode",
        ["🎯 Specialist Agents", "🔄 Pipeline Automator", "🎓 Educational Companion"],
        horizontal=True,
        help="Choose how you want to work with agents"
    )
    
    # SPECIALIST AGENTS MODE (from agent_system)
    if agent_mode == "🎯 Specialist Agents":
        render_specialist_agents_mode()
    
    # PIPELINE AUTOMATOR MODE (from agent_lite)
    elif agent_mode == "🔄 Pipeline Automator":
        render_pipeline_automator_mode()
    
    # EDUCATIONAL COMPANION MODE (from agent_lite)
    else:  # Educational Companion
        render_educational_companion_mode()
    
    # Sidebar with unified help
    render_sidebar_help()


def render_specialist_agents_mode():
    """Render specialist agents interface"""
    st.subheader("Specialist Agent Execution")
    st.markdown("Let AI agents plan and execute complex tasks automatically")
    
    # Goal input
    col1, col2 = st.columns([3, 1])
    
    with col1:
        goal = st.text_area(
            "Describe your goal",
            height=100,
            placeholder="Example: Analyze customer purchase patterns and create a dashboard with insights"
        )
        
        # Agent selection
        orchestrator = st.session_state.orchestrator
        agent_options = ["Auto-select"] + list(orchestrator.agents.keys())
        selected_agent = st.selectbox(
            "Select Agent",
            options=agent_options,
            format_func=lambda x: x.replace("_", " ").title()
        )
    
    with col2:
        st.markdown("### Available Agents")
        for name, agent in orchestrator.agents.items():
            st.info(f"**{agent.name}**\n{agent.description}")
    
    # Execute button
    if st.button("🚀 Execute with Agent", type="primary", disabled=not goal):
        with st.spinner("Agent working..."):
            # Execute with selected or auto-selected agent
            agent_name = None if selected_agent == "Auto-select" else selected_agent
            state = orchestrator.execute_with_agent(goal, agent_name)
            
            # Store in session state
            st.session_state.last_agent_state = state
    
    # Display results
    if "last_agent_state" in st.session_state:
        state = st.session_state.last_agent_state
        
        st.divider()
        
        # Execution summary
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Phase", state.phase.title())
        with col2:
            st.metric("Steps Completed", f"{state.current_step}/{len(state.steps)}")
        with col3:
            st.metric("Success Rate", f"{len([r for r in state.results.values() if 'Failed' not in str(r)])} / {len(state.results)}")
        
        # Detailed results
        tab1, tab2, tab3 = st.tabs(["📊 Results", "📋 Execution Plan", "📜 History"])
        
        with tab1:
            st.subheader("Execution Results")
            for step_name, result in state.results.items():
                with st.expander(f"**{step_name}**", expanded=True):
                    if isinstance(result, str) and len(result) > 500:
                        st.code(result[:500] + "...\n\n[Truncated]")
                    else:
                        st.code(result)
        
        with tab2:
            st.subheader("Execution Plan")
            for i, step in enumerate(state.steps):
                status = "✅" if f"step_{i}" in state.results else "⏳"
                with st.expander(f"{status} Step {i+1}: {step.get('action', 'Unknown')}"):
                    st.json(step)
        
        with tab3:
            st.subheader("Agent History")
            for entry in state.agent_history:
                st.write(f"• {entry}")
        
        # Save results
        if st.button("💾 Save Agent Session"):
            try:
                # Log to database
                query_id = st.session_state.db.log_query(
                    tool="specialist_agent",
                    model="multiple",
                    prompt=goal,
                    response=json.dumps(state.results),
                    metadata={
                        "agent": state.agent_history[0].split(": ")[1] if state.agent_history else "unknown",
                        "steps": len(state.steps),
                        "phase": state.phase
                    }
                )
                st.success("Agent session saved!")
            except Exception as e:
                st.error(f"Error saving: {str(e)}")


def render_pipeline_automator_mode():
    """Render pipeline automator interface (from agent_lite)"""
    st.subheader("Build Workflow Pipeline")
    st.markdown("Chain tools together to automate complex tasks")
    
    # Initialize pipeline steps
    if "pipeline_steps" not in st.session_state:
        st.session_state.pipeline_steps = []
    
    # Step builder
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("### Pipeline Steps")
        
        # Display existing steps
        for i, step in enumerate(st.session_state.pipeline_steps):
            with st.container(border=True):
                step_cols = st.columns([2, 2, 1])
                
                with step_cols[0]:
                    step["name"] = st.text_input(
                        f"Step {i+1} Name",
                        value=step.get("name", ""),
                        placeholder="e.g., Extract Data",
                        key=f"name_{i}"
                    )
                
                with step_cols[1]:
                    tools = ["", "sql_generator", "sql_optimizer", "code_explainer", 
                            "doc_summarizer", "regex_generator", "error_decoder", "doc_qa"]
                    current_tool = step.get("tool", "")
                    tool_index = tools.index(current_tool) if current_tool in tools else 0
                    
                    step["tool"] = st.selectbox(
                        "Tool",
                        tools,
                        index=tool_index,
                        key=f"tool_{i}"
                    )
                
                with step_cols[2]:
                    if st.button("❌ Remove", key=f"remove_{i}"):
                        st.session_state.pipeline_steps.pop(i)
                        st.rerun()
                
                # Tool-specific parameters
                if step["tool"]:
                    render_tool_parameters(step, i)
        
        # Add step button
        if st.button("➕ Add Step", type="primary", use_container_width=True):
            st.session_state.pipeline_steps.append({
                "name": "",
                "tool": "",
                "params": {}
            })
            st.rerun()
    
    with col2:
        st.markdown("### Actions")
        
        # Execute pipeline
        steps_ready = any(step.get("tool") for step in st.session_state.pipeline_steps)
        if st.button("▶️ Execute Pipeline", 
                    type="primary",
                    disabled=not steps_ready,
                    use_container_width=True):
            
            with st.spinner("Running workflow..."):
                result = run_pipeline(st.session_state.pipeline_steps)
            
            st.session_state.last_result = result
            
            # Save to database if connected
            if st.session_state.db.connected:
                pipeline_name = " → ".join([
                    s["name"] or s["tool"] 
                    for s in st.session_state.pipeline_steps if s.get("tool")
                ])
                
                # Log as a special query type
                st.session_state.db.log_query(
                    tool="pipeline_automator",
                    model="multiple",
                    prompt=json.dumps(st.session_state.pipeline_steps),
                    response=json.dumps(result),
                    metadata={
                        "pipeline_name": pipeline_name,
                        "step_count": len(st.session_state.pipeline_steps),
                        "success": all(step["success"] for step in result["log"])
                    }
                )
        
        # Load example pipelines
        st.markdown("### Example Pipelines")
        render_example_pipelines()
    
    # Display results
    if "last_result" in st.session_state:
        render_pipeline_results()


def render_educational_companion_mode():
    """Render educational companion interface (from agent_lite)"""
    st.subheader("🎓 Learning Companion")
    st.markdown("Get real-time guidance while using TuoKit tools")
    
    # Initialize agent
    if "edu_agent" not in st.session_state:
        st.session_state.edu_agent = EducationalAgent()
        st.session_state.guidance_history = []
    
    # Context input
    col1, col2 = st.columns([2, 1])
    
    with col1:
        context = st.text_area(
            "What are you working on?",
            placeholder="Example: Trying to analyze customer feedback from CSV files and generate insights",
            height=100
        )
        
        if context:
            # Action selection
            user_action = st.selectbox(
                "What are you trying to do?",
                [
                    "Selecting the right tool",
                    "Configuring tool parameters",
                    "Understanding tool output",
                    "Debugging errors",
                    "Optimizing my workflow",
                    "Learning best practices"
                ]
            )
            
            # Get guidance
            if st.button("💡 Get Guidance", type="primary"):
                with st.spinner("Thinking..."):
                    guidance = st.session_state.edu_agent.guide(context, user_action)
                
                # Store in history
                st.session_state.guidance_history.append({
                    "context": context,
                    "action": user_action,
                    "guidance": guidance,
                    "timestamp": datetime.now()
                })
                
                # Display guidance
                st.success("Here's your guidance:")
                
                col_a, col_b = st.columns(2)
                
                with col_a:
                    st.markdown(f"**📖 Explanation**")
                    st.info(guidance.get("explanation", ""))
                    
                    st.markdown(f"**💡 Pro Tip**")
                    st.success(guidance.get("tip", ""))
                
                with col_b:
                    st.markdown(f"**⚠️ Common Mistake**")
                    st.warning(guidance.get("mistake", ""))
                    
                    st.markdown(f"**➡️ Next Step**")
                    st.info(guidance.get("next_step", ""))
    
    with col2:
        st.markdown("### Quick Scenarios")
        
        scenarios = {
            "📊 Data Analysis": {
                "context": "I need to analyze sales data from multiple CSV files",
                "action": "Selecting the right tool"
            },
            "🔍 Text Processing": {
                "context": "I want to extract phone numbers from documents",
                "action": "Configuring tool parameters"
            },
            "🐛 Error Fixing": {
                "context": "My SQL query is returning unexpected results",
                "action": "Debugging errors"
            },
            "🚀 Performance": {
                "context": "My pipeline is taking too long to run",
                "action": "Optimizing my workflow"
            }
        }
        
        for scenario_name, scenario_data in scenarios.items():
            if st.button(scenario_name, use_container_width=True):
                # Pre-fill the scenario
                st.session_state.prefill_context = scenario_data["context"]
                st.session_state.prefill_action = scenario_data["action"]
                st.rerun()
    
    # Apply pre-filled scenario if exists
    if "prefill_context" in st.session_state:
        context = st.session_state.prefill_context
        del st.session_state.prefill_context
    
    # Guidance History
    if st.session_state.guidance_history:
        render_guidance_history()


def render_tool_parameters(step, index):
    """Render tool-specific parameters"""
    st.markdown(f"**Parameters for {step['tool']}:**")
    
    if step["tool"] == "sql_generator":
        step.setdefault("params", {})
        step["params"]["query"] = st.text_area(
            "Query Description",
            value=step["params"].get("query", ""),
            placeholder="Find top customers by revenue",
            key=f"query_{index}"
        )
        step["params"]["dialect"] = st.selectbox(
            "SQL Dialect",
            ["PostgreSQL", "MySQL", "SQLite", "Oracle"],
            key=f"dialect_{index}"
        )
    
    elif step["tool"] == "sql_optimizer":
        step.setdefault("params", {})
        step["params"]["sql"] = st.text_area(
            "SQL to Optimize",
            value=step["params"].get("sql", ""),
            placeholder="Paste SQL query...",
            key=f"sql_opt_{index}"
        )
        step["params"]["target"] = st.selectbox(
            "Optimization Target",
            ["performance", "memory", "readability"],
            key=f"target_{index}"
        )
    
    elif step["tool"] == "code_explainer":
        step.setdefault("params", {})
        step["params"]["code"] = st.text_area(
            "Code to Explain",
            value=step["params"].get("code", ""),
            placeholder="Paste code here...",
            key=f"code_{index}"
        )
    
    elif step["tool"] == "doc_summarizer":
        step.setdefault("params", {})
        step["params"]["text"] = st.text_area(
            "Text to Summarize",
            value=step["params"].get("text", ""),
            placeholder="Paste document text...",
            key=f"text_{index}"
        )
        step["params"]["length"] = st.slider(
            "Summary Length (words)",
            50, 500,
            value=step["params"].get("length", 100),
            key=f"length_{index}"
        )
    
    elif step["tool"] == "doc_qa":
        step.setdefault("params", {})
        step["params"]["document"] = st.text_area(
            "Document Content",
            value=step["params"].get("document", ""),
            placeholder="Paste document...",
            key=f"doc_{index}"
        )
        step["params"]["question"] = st.text_input(
            "Question",
            value=step["params"].get("question", ""),
            placeholder="What would you like to know?",
            key=f"question_{index}"
        )
    
    elif step["tool"] == "regex_generator":
        step.setdefault("params", {})
        step["params"]["description"] = st.text_input(
            "Pattern Description",
            value=step["params"].get("description", ""),
            placeholder="Match email addresses",
            key=f"regex_{index}"
        )
    
    elif step["tool"] == "error_decoder":
        step.setdefault("params", {})
        step["params"]["error_message"] = st.text_area(
            "Error Message",
            value=step["params"].get("error_message", ""),
            placeholder="Paste error message...",
            key=f"error_{index}"
        )
        step["params"]["code_context"] = st.text_area(
            "Related Code (optional)",
            value=step["params"].get("code_context", ""),
            key=f"error_code_{index}"
        )


def render_example_pipelines():
    """Render example pipeline buttons"""
    if st.button("📊 Data Analysis Pipeline", use_container_width=True):
        st.session_state.pipeline_steps = [
            {
                "name": "Generate Query",
                "tool": "sql_generator",
                "params": {"query": "Get customer orders from last month", "dialect": "PostgreSQL"}
            },
            {
                "name": "Optimize Query",
                "tool": "sql_optimizer",
                "params": {"sql": "-- Will use previous result", "target": "performance"}
            },
            {
                "name": "Extract Patterns",
                "tool": "regex_generator",
                "params": {"description": "Extract and validate email addresses"}
            }
        ]
        st.rerun()
    
    if st.button("🔧 Code Migration Pipeline", use_container_width=True):
        st.session_state.pipeline_steps = [
            {
                "name": "Analyze Legacy Code",
                "tool": "code_explainer",
                "params": {"code": "# Add your legacy code here"}
            },
            {
                "name": "Debug Issues",
                "tool": "error_decoder",
                "params": {"error_message": "# Add any error messages"}
            },
            {
                "name": "Generate New SQL",
                "tool": "sql_generator",
                "params": {"query": "Create modern equivalent", "dialect": "PostgreSQL"}
            }
        ]
        st.rerun()
    
    if st.button("📄 Document Processing", use_container_width=True):
        st.session_state.pipeline_steps = [
            {
                "name": "Summarize Document",
                "tool": "doc_summarizer",
                "params": {"text": "# Add document text", "length": 200}
            },
            {
                "name": "Answer Questions",
                "tool": "doc_qa",
                "params": {"document": "# Will use summary", "question": "What are the key points?"}
            }
        ]
        st.rerun()


def render_pipeline_results():
    """Render pipeline execution results"""
    st.divider()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Pipeline Results")
        for step_name, output in st.session_state.last_result["results"].items():
            with st.expander(f"**{step_name}**", expanded=True):
                if isinstance(output, str) and len(output) > 500:
                    st.code(output[:500] + "...\n\n[Truncated]")
                else:
                    st.code(output)
    
    with col2:
        st.subheader("📝 Execution Log")
        for entry in st.session_state.last_result["log"]:
            status = "✅" if entry["success"] else "❌"
            with st.expander(f"{status} {entry['step']}"):
                st.json(entry)


def render_guidance_history():
    """Render educational guidance history"""
    st.divider()
    st.subheader("📚 Your Learning Journey")
    
    # Display in reverse chronological order
    for i, entry in enumerate(reversed(st.session_state.guidance_history)):
        with st.expander(
            f"Guidance #{len(st.session_state.guidance_history) - i} - "
            f"{entry['timestamp'].strftime('%I:%M %p')}"
        ):
            st.markdown(f"**Context:** {entry['context']}")
            st.markdown(f"**Action:** {entry['action']}")
            st.markdown("---")
            
            guidance = entry['guidance']
            st.markdown(f"📖 **Explanation:** {guidance.get('explanation', '')}")
            st.markdown(f"💡 **Tip:** {guidance.get('tip', '')}")
            st.markdown(f"⚠️ **Avoid:** {guidance.get('mistake', '')}")
            st.markdown(f"➡️ **Next:** {guidance.get('next_step', '')}")
    
    # Export learning history
    if st.button("📥 Export Learning History"):
        history_text = "# TuoKit Learning History\n\n"
        for entry in st.session_state.guidance_history:
            history_text += f"## {entry['timestamp'].strftime('%Y-%m-%d %I:%M %p')}\n"
            history_text += f"**Context:** {entry['context']}\n"
            history_text += f"**Action:** {entry['action']}\n\n"
            
            guidance = entry['guidance']
            history_text += f"### Guidance\n"
            history_text += f"- **Explanation:** {guidance.get('explanation', '')}\n"
            history_text += f"- **Tip:** {guidance.get('tip', '')}\n"
            history_text += f"- **Avoid:** {guidance.get('mistake', '')}\n"
            history_text += f"- **Next Step:** {guidance.get('next_step', '')}\n\n"
            history_text += "---\n\n"
        
        st.download_button(
            label="Download History",
            data=history_text,
            file_name=f"tuokit_learning_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
            mime="text/markdown"
        )


def render_sidebar_help():
    """Render unified sidebar help"""
    with st.sidebar:
        st.markdown("### 🤖 Agent System Help")
        
        with st.expander("Specialist Agents"):
            st.markdown("""
            **Autonomous task execution:**
            1. Describe your goal in natural language
            2. Let the AI select the best agent
            3. Watch as it plans and executes steps
            4. Review comprehensive results
            
            **Available Specialists:**
            - **DataEngineer**: SQL and data tasks
            - **CodeArchitect**: Code analysis & generation
            - **DocScientist**: Document processing
            - **FullStack**: Combined capabilities
            """)
        
        with st.expander("Pipeline Automator"):
            st.markdown("""
            **Build multi-step workflows:**
            1. Add steps with the ➕ button
            2. Select tools for each step
            3. Configure parameters
            4. Execute to run all steps in sequence
            
            **Tips:**
            - Name your steps clearly
            - Start simple, then add complexity
            - Previous results are available to later steps
            """)
        
        with st.expander("Educational Companion"):
            st.markdown("""
            **Get contextual help:**
            1. Describe what you're working on
            2. Select your current action
            3. Get tailored guidance
            
            **Best for:**
            - Learning which tool to use
            - Understanding parameters
            - Avoiding common mistakes
            - Planning next steps
            """)
        
        st.divider()
        
        # Agent stats
        if st.session_state.db.connected:
            st.subheader("📊 Agent Stats")
            
            # Count different agent uses
            specialist_count = st.session_state.db.get_tool_usage_count("specialist_agent")
            pipeline_count = st.session_state.db.get_tool_usage_count("pipeline_automator")
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Specialist Runs", specialist_count)
            with col2:
                st.metric("Pipelines Run", pipeline_count)


# Entry point
if __name__ == "__main__":
    show()
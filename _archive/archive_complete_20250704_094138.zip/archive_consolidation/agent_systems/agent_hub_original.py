"""
🤖 TuoKit Agent Hub - Unified Agent Interface
Consolidates agent_lite (simple) and agent_system (advanced)
Following TuoKit principle: Start simple, add complexity only when needed
"""

import streamlit as st
from utils import DatabaseManager, safe_ollama_generate, capture_knowledge
from typing import List, Dict, Any
from datetime import datetime
import json

# Initialize database
db = DatabaseManager()

# Simple pipeline execution (from agent_lite)
def run_simple_pipeline(steps: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Execute tool sequence with data passing - clean and simple"""
    results = {}
    execution_log = []
    
    for i, step in enumerate(steps):
        tool = step["tool"]
        params = step.get("params", {})
        step_name = step.get("name", f"Step {i+1}")
        
        try:
            # Make previous results available
            if results:
                params["previous_results"] = results
            
            # Execute the tool
            if tool == "sql_generator":
                from utils.sql_tools import SQLTools
                output = SQLTools.generate(
                    params.get("query", ""),
                    params.get("dialect", "postgresql")
                )
                
            elif tool == "code_explainer":
                prompt = f"Explain this code:\n{params.get('code', '')}"
                response = safe_ollama_generate("deepseek-coder:6.7b", prompt)
                output = response['response']                
            elif tool == "doc_summarizer":
                prompt = f"Summarize in {params.get('length', 100)} words:\n{params.get('text', '')}"
                response = safe_ollama_generate("deepseek-r1:1.5b", prompt)
                output = response['response']
                
            elif tool == "error_analyzer":
                prompt = f"Analyze this error:\n{params.get('error', '')}\nContext: {params.get('context', '')}"
                response = safe_ollama_generate("deepseek-coder:6.7b", prompt)
                output = response['response']
                
            elif tool == "test_generator":
                prompt = f"Generate tests for:\n{params.get('code', '')}\nFramework: {params.get('framework', 'pytest')}"
                response = safe_ollama_generate("deepseek-coder:6.7b", prompt)
                output = response['response']
                
            else:
                output = f"Tool '{tool}' not implemented yet"
            
            # Store results
            results[step_name] = output
            
            execution_log.append({
                "step": step_name,
                "tool": tool,
                "input": params,
                "output": output[:200] + "..." if len(str(output)) > 200 else output,
                "success": True,
                "timestamp": datetime.now().isoformat()
            })
            
        except Exception as e:
            error_msg = f"Error in {tool}: {str(e)}"
            results[step_name] = error_msg
            execution_log.append({
                "step": step_name,
                "tool": tool,
                "error": error_msg,
                "success": False,
                "timestamp": datetime.now().isoformat()
            })
    
    return {"results": results, "log": execution_log}

# Advanced goal orchestration (simplified from agent_system)
def run_goal_orchestration(goal: str) -> Dict[str, Any]:
    """Break down complex goal into steps and execute"""
    
    # Step 1: Analyze goal and create plan
    planning_prompt = f"""Break down this goal into 3-5 concrete steps:
Goal: {goal}

Return a JSON list of steps, each with:
- "action": what to do
- "tool": which tool to use (sql_generator, code_explainer, doc_summarizer, etc)
- "input": what input the tool needs
"""
    
    plan_response = safe_ollama_generate(
        model=st.session_state.get("selected_model", "deepseek-r1:latest"),
        prompt=planning_prompt,
        temperature=0.3
    )
    
    try:
        # Parse the plan
        import re
        json_match = re.search(r'\[.*\]', plan_response['response'], re.DOTALL)
        if json_match:
            steps = json.loads(json_match.group())
        else:
            # Fallback: create a simple plan
            steps = [{
                "action": "Process the request",
                "tool": "code_explainer",
                "input": goal
            }]
    except:
        steps = [{"action": "Process request", "tool": "code_explainer", "input": goal}]
    
    # Step 2: Execute the plan
    pipeline_steps = []
    for i, step in enumerate(steps):
        pipeline_steps.append({
            "name": f"{step['action']}",
            "tool": step['tool'],
            "params": {"query": step['input'], "text": step['input'], "code": step['input']}
        })
    
    return run_simple_pipeline(pipeline_steps)

def show():
    st.title("🤖 TuoKit Agent Hub")
    st.caption("AI agents that chain tools together to solve complex tasks")
    
    # Mode selection
    mode = st.radio(
        "Choose your mode:",
        ["🔧 Simple Pipeline (Visual Builder)", "🎯 Goal-Based (Describe & Execute)"],
        horizontal=True
    )
    
    st.divider()
    
    if mode == "🔧 Simple Pipeline (Visual Builder)":
        st.header("Visual Pipeline Builder")
        st.caption("Chain tools together step by step")
        
        # Initialize pipeline steps
        if 'pipeline_steps' not in st.session_state:
            st.session_state.pipeline_steps = []
        
        # Available tools
        available_tools = {
            "sql_generator": "Generate SQL from description",
            "code_explainer": "Explain code in plain English",
            "doc_summarizer": "Summarize documents",
            "error_analyzer": "Analyze error messages",
            "test_generator": "Generate test cases"
        }
        
        # Add step interface
        with st.expander("➕ Add New Step", expanded=True):
            col1, col2 = st.columns([2, 3])
            
            with col1:
                tool = st.selectbox(
                    "Select Tool",
                    options=list(available_tools.keys()),
                    format_func=lambda x: f"{x} - {available_tools[x]}"
                )
            
            with col2:
                step_name = st.text_input("Step Name", value=f"Step {len(st.session_state.pipeline_steps) + 1}")            
            # Tool-specific parameters
            params = {}
            if tool == "sql_generator":
                params["query"] = st.text_area("Describe the SQL you need", height=80)
                params["dialect"] = st.selectbox("Database", ["PostgreSQL", "MySQL", "SQLite"])
            elif tool == "code_explainer":
                params["code"] = st.text_area("Code to explain", height=100)
            elif tool == "doc_summarizer":
                params["text"] = st.text_area("Text to summarize", height=100)
                params["length"] = st.slider("Summary length (words)", 50, 500, 100)
            elif tool == "error_analyzer":
                params["error"] = st.text_area("Error message", height=80)
                params["context"] = st.text_area("Context/Code (optional)", height=80)
            elif tool == "test_generator":
                params["code"] = st.text_area("Code to test", height=100)
                params["framework"] = st.selectbox("Test Framework", ["pytest", "unittest", "jest"])
            
            if st.button("Add Step", type="primary"):
                st.session_state.pipeline_steps.append({
                    "name": step_name,
                    "tool": tool,
                    "params": params
                })
                st.rerun()
        
        # Display current pipeline
        if st.session_state.pipeline_steps:
            st.subheader("Current Pipeline")
            
            for i, step in enumerate(st.session_state.pipeline_steps):
                col1, col2, col3 = st.columns([3, 2, 1])
                with col1:
                    st.write(f"**{i+1}. {step['name']}**")
                    st.caption(f"Tool: {step['tool']}")
                with col2:
                    # Show params preview
                    param_preview = str(step['params'])[:50] + "..."
                    st.caption(f"Params: {param_preview}")
                with col3:
                    if st.button("🗑️", key=f"del_{i}"):
                        st.session_state.pipeline_steps.pop(i)
                        st.rerun()            
            # Execute pipeline
            st.divider()
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🚀 Execute Pipeline", type="primary", 
                           disabled=len(st.session_state.pipeline_steps) == 0):
                    with st.spinner("Executing pipeline..."):
                        results = run_simple_pipeline(st.session_state.pipeline_steps)
                        st.session_state.last_results = results
                        
            with col2:
                if st.button("🔄 Clear Pipeline"):
                    st.session_state.pipeline_steps = []
                    if 'last_results' in st.session_state:
                        del st.session_state.last_results
                    st.rerun()
            
            # Show results
            if 'last_results' in st.session_state:
                st.subheader("Execution Results")
                
                # Show each step's output
                results = st.session_state.last_results
                for step_name, output in results['results'].items():
                    with st.expander(f"✅ {step_name}", expanded=True):
                        st.write(output)
                
                # Execution log
                with st.expander("📋 Execution Log"):
                    for log_entry in results['log']:
                        if log_entry['success']:
                            st.success(f"{log_entry['step']} - {log_entry['tool']}")
                        else:
                            st.error(f"{log_entry['step']} - Failed: {log_entry.get('error', 'Unknown error')}")
        else:
            st.info("👆 Add steps to build your pipeline")
    
    else:  # Goal-Based Mode
        st.header("Goal-Based Orchestration")
        st.caption("Describe what you want to achieve, and AI will plan and execute it")        
        # Goal input
        goal = st.text_area(
            "Describe your goal",
            height=120,
            placeholder="Example: Create a SQL query to find top customers, explain the logic, and generate test cases for it"
        )
        
        # Example goals
        with st.expander("📚 Example Goals"):
            examples = {
                "Data Analysis": "Generate SQL to analyze monthly sales trends, explain the query, and create a summary report",
                "Code Review": "Analyze this Python function for errors, explain what it does, and generate unit tests",
                "Documentation": "Take this complex code, explain it simply, and create user documentation"
            }
            
            for name, example_goal in examples.items():
                if st.button(name, key=f"goal_ex_{name}"):
                    st.session_state.example_goal = example_goal
                    st.rerun()
        
        # Load example if selected
        if 'example_goal' in st.session_state:
            goal = st.session_state.example_goal
            del st.session_state.example_goal
        
        if st.button("🎯 Execute Goal", type="primary", disabled=not goal):
            with st.spinner("Planning and executing..."):
                results = run_goal_orchestration(goal)
                st.session_state.goal_results = results
        
        # Show results
        if 'goal_results' in st.session_state:
            st.subheader("Execution Results")
            
            results = st.session_state.goal_results
            
            # Show the plan
            with st.expander("📋 Execution Plan", expanded=True):
                for entry in results['log']:
                    st.write(f"- {entry['step']}")
            
            # Show outputs
            for step_name, output in results['results'].items():
                with st.expander(f"📄 {step_name}", expanded=True):
                    st.write(output)
            
            # Save option
            if st.button("💾 Save Results"):
                # Log to database
                for step_name, output in results['results'].items():
                    capture_knowledge(
                        tool_name="agent_hub",
                        prompt=goal,
                        response=output,
                        metadata={"step": step_name, "mode": "goal-based"}
                    )
                st.success("Results saved to knowledge base!")

# Entry point
if __name__ == "__main__":
    show()
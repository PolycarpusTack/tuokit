"""
SQL Generator Page - Migrated to use unified SQL tools
Uses utils/sql_tools.py instead of local implementations
"""
import streamlit as st
from utils.sql_tools import (
    generate_sql_query,
    optimize_sql_query, 
    explain_sql_query,
    validate_sql_syntax
)
from utils.database import DatabaseManager
from utils.ollama import safe_ollama_generate

def show():
    st.title("🗄️ SQL Query Generator")
    st.markdown("Generate optimized SQL queries from natural language")
    
    # Input section
    col1, col2 = st.columns([3, 1])
    
    with col1:
        query_input = st.text_area(
            "Describe what you want to query:",
            placeholder="Example: Show me all users who made purchases over $100 in the last month",
            height=100
        )
    
    with col2:
        dialect = st.selectbox(
            "SQL Dialect:",
            ["PostgreSQL", "MySQL", "SQLite", "SQL Server", "Oracle"]
        )
        
        include_explanation = st.checkbox("Include explanation", value=True)
        optimize_query = st.checkbox("Auto-optimize", value=True)
    
    # Generate button
    if st.button("🚀 Generate SQL", type="primary", use_container_width=True):
        if not query_input:
            st.warning("Please describe what you want to query")
            return
            
        with st.spinner("Generating SQL query..."):
            try:
                # Generate base query
                sql_query = generate_sql_query(
                    query_input, 
                    dialect=dialect,
                    model=st.session_state.get("selected_model", "deepseek-coder:6.7b")
                )
                
                # Display results
                if sql_query:
                    # Syntax validation
                    is_valid, error_msg = validate_sql_syntax(sql_query, dialect)
                    
                    if is_valid:
                        st.success("✅ Valid SQL generated!")
                        
                        # Show query
                        st.code(sql_query, language="sql")
                        
                        # Optimize if requested  
                        if optimize_query:
                            with st.spinner("Optimizing query..."):
                                optimized = optimize_sql_query(sql_query, dialect)
                                if optimized != sql_query:
                                    st.info("🔧 Optimization applied:")
                                    st.code(optimized, language="sql")
                                    sql_query = optimized
                        
                        # Show explanation if requested
                        if include_explanation:
                            explanation = explain_sql_query(sql_query, dialect)
                            with st.expander("📖 Query Explanation"):
                                st.markdown(explanation)
                        
                        # Save to knowledge base
                        if st.session_state.get("db"):
                            st.session_state.db.save_query(
                                "sql_generator",
                                query_input,
                                sql_query,
                                {"dialect": dialect, "optimized": optimize_query}
                            )
                            
                        # Copy button
                        st.button(
                            "📋 Copy to clipboard",
                            on_click=lambda: st.write(sql_query),
                            help="Query copied!"
                        )
                    else:
                        st.error(f"❌ SQL Syntax Error: {error_msg}")
                        st.code(sql_query, language="sql")
                        
                        # Offer fix
                        if st.button("🔧 Try to fix"):
                            fixed = safe_ollama_generate(
                                f"Fix this SQL syntax error:\n{sql_query}\nError: {error_msg}",
                                st.session_state.get("selected_model", "deepseek-coder:6.7b")
                            )
                            if fixed:
                                st.code(fixed, language="sql")
                else:
                    st.error("Failed to generate SQL query")
                    
            except Exception as e:
                st.error(f"Error: {str(e)}")
    
    # Examples section
    with st.expander("💡 Example Queries"):
        examples = [
            "Find top 10 customers by total purchase amount",
            "Show all products that haven't been ordered in 30 days",
            "Calculate monthly revenue for the last year",
            "List employees with their department and manager names",
            "Find duplicate email addresses in the users table"
        ]
        
        for example in examples:
            if st.button(example, key=f"ex_{example[:20]}"):
                st.rerun()

if __name__ == "__main__":
    # For testing
    show()

"""
🛢️ TuoKit SQL Suite - Unified SQL Tools
Single entry point for all SQL operations
Following TuoKit principle: One tool, clear purpose
"""

import streamlit as st
from utils.sql_tools import SQLTools
from utils import DatabaseManager, safe_ollama_generate, capture_knowledge
import json

# Initialize database
db = DatabaseManager()

def show():
    st.title("🛢️ TuoKit SQL Suite")
    st.caption("All your SQL tools in one place - Generate, Optimize, Pipeline")
    
    # Initialize session state
    if 'generated_sql' not in st.session_state:
        st.session_state.generated_sql = ""
    if 'pipeline_step' not in st.session_state:
        st.session_state.pipeline_step = 1
    
    # Main interface with tabs
    tab_gen, tab_opt, tab_pipe, tab_translate = st.tabs([
        "📝 Generate", 
        "⚡ Optimize", 
        "🔄 Pipeline",
        "🌐 Translate"
    ])
    
    # TAB 1: SQL Generation
    with tab_gen:
        st.header("Natural Language to SQL")
        
        # Quick examples in sidebar-like column
        col1, col2 = st.columns([3, 1])
        
        with col1:
            query_desc = st.text_area(
                "Describe what you need",
                height=100,
                placeholder="Show top 5 customers by total orders in 2023"
            )
            
            dialect = st.radio(
                "Database Type",
                ["PostgreSQL", "MySQL", "SQLite", "Oracle"],
                horizontal=True
            )
            
            # Optional schema hint
            with st.expander("Add Schema Info (Optional)"):
                schema_info = st.text_area(
                    "Table structure",
                    placeholder="customers(id, name, email)\norders(id, customer_id, amount, date)"
                )
 
 
 
 
            # schema_info is defined in the expander above
        
        with col2:
            st.subheader("Quick Examples")
            examples = {
                "Sales Report": "Monthly sales totals with growth %",
                "Find Duplicates": "Find duplicate customer emails",
                "Join Tables": "Join orders with customer details"
            }
            for name, query in examples.items():
                if st.button(name, key=f"ex_{name}"):
                    st.session_state.example_query = query
                    st.rerun()
        
        # Load example if selected
        if 'example_query' in st.session_state:
            query_desc = st.session_state.example_query
            del st.session_state.example_query
        
        if st.button("🚀 Generate SQL", type="primary", disabled=not query_desc):
            with st.spinner("Generating SQL..."):
                sql = SQLTools.generate(query_desc, dialect.lower(), schema_info)
                st.session_state.generated_sql = sql
                
            st.success("✅ SQL Generated!")
            st.code(sql, language="sql")
            
            # Quick actions
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button("📋 Copy", key="copy_gen"):
                    st.toast("SQL copied to clipboard!")
            with col2:
                if st.button("⚡ Optimize", key="opt_from_gen"):
                    st.session_state.tab_switch = "optimize"
                    st.rerun()
            with col3:
                if st.button("📖 Explain", key="exp_from_gen"):
                    with st.spinner("Explaining..."):
                        explanation = SQLTools.explain(sql)
                        st.info(explanation)
    
    # TAB 2: SQL Optimization
    with tab_opt:
        st.header("Query Performance Optimizer")
        
        # Auto-populate from generated SQL if available
        sql_to_optimize = st.text_area(
            "SQL to optimize",
            height=200,
            value=st.session_state.generated_sql,
            placeholder="Paste your SQL query here..."
        )
        
        # Schema info for better optimization
        with st.expander("Add Index/Schema Info (Optional)"):
            index_info = st.text_area(
                "Available indexes",
                placeholder="idx_customer_email on customers(email)\nidx_order_date on orders(order_date)"
            )
        
        if st.button("🔍 Analyze & Optimize", type="primary", disabled=not sql_to_optimize):
            # Validate SQL first
            is_valid, msg = SQLTools.validate(sql_to_optimize)
            if not is_valid:
                st.error(f"❌ {msg}")
            else:
                with st.spinner("Analyzing query performance..."):
                    optimization = SQLTools.optimize(sql_to_optimize, index_info)
                
                st.success("✅ Optimization Complete!")
                st.markdown(optimization)
                
                # Show formatted version
                st.subheader("Formatted SQL")
                formatted = SQLTools.format(sql_to_optimize)
                st.code(formatted, language="sql")    
    # TAB 3: SQL Pipeline (Step-by-step workflow)
    with tab_pipe:
        st.header("Guided SQL Pipeline")
        st.caption("Build complex queries step by step")
        
        # Pipeline state management
        step = st.session_state.pipeline_step
        
        # Step indicator
        st.progress(step / 4, text=f"Step {step} of 4")
        
        # Step 1: Describe the need
        if step == 1:
            st.subheader("Step 1: Describe Your Need")
            need = st.text_area(
                "What data do you need?",
                placeholder="I need a report showing customer purchase patterns..."
            )
            
            if st.button("Next →", disabled=not need):
                with st.spinner("Generating initial SQL..."):
                    sql = SQLTools.generate(need, "postgresql")
                    st.session_state.pipeline_sql = sql
                    st.session_state.pipeline_need = need
                    st.session_state.pipeline_step = 2
                    st.rerun()
        
        # Step 2: Review and refine
        elif step == 2:
            st.subheader("Step 2: Review Generated SQL")
            st.code(st.session_state.pipeline_sql, language="sql")
            
            # Explanation
            with st.expander("Understand this query"):
                explanation = SQLTools.explain(st.session_state.pipeline_sql)
                st.markdown(explanation)            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("← Back"):
                    st.session_state.pipeline_step = 1
                    st.rerun()
            with col2:
                if st.button("Next →", type="primary"):
                    st.session_state.pipeline_step = 3
                    st.rerun()
        
        # Step 3: Optimize
        elif step == 3:
            st.subheader("Step 3: Optimize Performance")
            
            # Show current SQL
            st.code(st.session_state.pipeline_sql, language="sql")
            
            if st.button("⚡ Optimize This Query"):
                with st.spinner("Optimizing..."):
                    optimization = SQLTools.optimize(st.session_state.pipeline_sql)
                    st.markdown(optimization)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("← Back"):
                    st.session_state.pipeline_step = 2
                    st.rerun()
            with col2:
                if st.button("Next →", type="primary"):
                    st.session_state.pipeline_step = 4
                    st.rerun()
        
        # Step 4: Save and use
        elif step == 4:
            st.subheader("Step 4: Save Your Query")
            st.success("✅ Your SQL query is ready!")
            
            final_sql = st.session_state.pipeline_sql
            st.code(final_sql, language="sql")            
            # Save options
            title = st.text_input("Query Title", value=f"Query: {st.session_state.pipeline_need[:50]}...")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                if st.button("💾 Save to Knowledge Base"):
                    # Save to knowledge base
                    query_id = db.log_query(
                        tool="sql_suite",
                        model=st.session_state.get("selected_model", "deepseek-coder:6.7b"),
                        prompt=st.session_state.pipeline_need,
                        response=final_sql
                    )
                    db.save_knowledge_unit(
                        query_id=query_id,
                        title=title,
                        content=final_sql,
                        category="SQL Pattern"
                    )
                    st.success("Saved to knowledge base!")
            
            with col2:
                if st.button("📋 Copy SQL"):
                    st.toast("SQL copied!")
            
            with col3:
                if st.button("🔄 Start New Pipeline"):
                    st.session_state.pipeline_step = 1
                    st.session_state.pipeline_sql = ""
                    st.rerun()
    
    # TAB 4: SQL Translation
    with tab_translate:
        st.header("SQL Dialect Translator")
        st.caption("Convert queries between database systems")
        
        col1, col2 = st.columns(2)
        with col1:
            source_db = st.selectbox("From", ["PostgreSQL", "MySQL", "Oracle", "SQLite"])
        with col2:
            target_db = st.selectbox("To", ["MySQL", "PostgreSQL", "SQLite", "Oracle"])        
        sql_to_translate = st.text_area(
            "SQL to translate",
            height=150,
            value=st.session_state.generated_sql,
            placeholder="Enter SQL in source dialect..."
        )
        
        if st.button("🔄 Translate", type="primary", disabled=not sql_to_translate or source_db == target_db):
            if source_db == target_db:
                st.warning("Source and target must be different!")
            else:
                with st.spinner(f"Translating from {source_db} to {target_db}..."):
                    # Use the translation prompt
                    prompt = f"""Translate this {source_db} SQL to {target_db}:
{sql_to_translate}

Key differences to handle:
- Function names (NVL→COALESCE, etc)
- Date/time functions
- String concatenation
- Limit/offset syntax
- Data types

Return ONLY the translated SQL."""
                    
                    translated = safe_ollama_generate(
                        model=st.session_state.get("selected_model", "deepseek-coder:6.7b"),
                        prompt=prompt,
                        temperature=0.1
                    )
                    
                st.success("✅ Translation Complete!")
                st.code(translated['response'], language="sql")
                
                # Common conversions reference
                with st.expander("📚 Common Conversions"):
                    st.markdown("""
                    | Feature | PostgreSQL | MySQL | Oracle | SQLite |
                    |---------|------------|-------|---------|---------|
                    | Limit | LIMIT n | LIMIT n | ROWNUM <= n | LIMIT n |
                    | String concat | \\|\\| | CONCAT() | \\|\\| | \\|\\| |
                    | Current time | NOW() | NOW() | SYSDATE | datetime('now') |
                    | UUID | gen_random_uuid() | UUID() | SYS_GUID() | - |
                    """)

# Entry point
if __name__ == "__main__":
    show()